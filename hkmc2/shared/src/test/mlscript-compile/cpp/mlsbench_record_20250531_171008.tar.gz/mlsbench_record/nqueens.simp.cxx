#include "mlsprelude.h"
struct _mls_List;
struct _mls_Cons;
struct _mls_Nil;
_mlsValue _mls_extend(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_length(_mlsValue);
_mlsValue _mls_queens(_mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_safe(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_find_solution(_mlsValue, _mlsValue);
_mlsValue _mls_append_safe(_mlsValue, _mlsValue, _mlsValue);
struct _mls_List: public _mlsObject {
  
  constexpr static inline const char *typeName = "List";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_List; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Cons: public _mls_List {
  _mlsValue _mls_head;
  _mlsValue _mls_tail;
  constexpr static inline const char *typeName = "Cons";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_head.print(); std::printf(", "); this->_mls_tail.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_head); _mlsValue::destroy(this->_mls_tail);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_head.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_head.asObject()) && this->_mls_tail.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_tail.asObject()); }
  static _mlsValue create(_mlsValue _mls_head, _mlsValue _mls_tail) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Cons; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_head = _mls_head; _mlsVal->_mls_tail = _mls_tail;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Nil: public _mls_List {
  
  constexpr static inline const char *typeName = "Nil";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Nil; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_append_safe(_mlsValue _mls_queen2, _mlsValue _mls_xs1, _mlsValue _mls_xss) {
  _mlsValue _mls_retval;
  auto _mls_x24 = (_mls_queen2 <= _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x24, 1)) {
    _mls_retval = _mls_xss;
  } else {
    auto _mls_x25 = _mls_safe(_mls_queen2, _mlsValue::fromIntLit(1), _mls_xs1);
    if (_mlsValue::isIntLit(_mls_x25, 1)) {
      auto _mls_x27 = (_mls_queen2 - _mlsValue::fromIntLit(1));
      auto _mls_x28 = _mlsValue::create<_mls_Cons>(_mls_queen2, _mls_xs1);
      auto _mls_x29 = _mlsValue::create<_mls_Cons>(_mls_x28, _mls_xss);
      auto _mls_x30 = _mls_append_safe(_mls_x27, _mls_xs1, _mls_x29);
      _mls_retval = _mls_x30;
    } else {
      auto _mls_x26 = _mls_append_safe(_mls_queen2, _mls_xs1, _mls_xss);
      _mls_retval = _mls_x26;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_queens(_mlsValue _mls_n1) {
  _mlsValue _mls_retval;
  auto _mls_x8 = _mls_find_solution(_mls_n1, _mls_n1);
  auto _mls_x9 = _mls_length(_mls_x8);
  _mls_retval = _mls_x9;
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x35 = _mls_queens(_mlsValue::fromIntLit(8));
  _mls_retval = _mls_x35;
  return _mls_retval;
}
_mlsValue _mls_safe(_mlsValue _mls_queen1, _mlsValue _mls_diag, _mlsValue _mls_sol) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_sol)) {
    auto _mls_x10 = _mlsValue::cast<_mls_Cons>(_mls_sol)->_mls_head;
    auto _mls_x11 = _mlsValue::cast<_mls_Cons>(_mls_sol)->_mls_tail;
    auto _mls_x12 = (_mls_queen1 != _mls_x10);
    auto _mls_x13 = (_mls_x10 + _mls_diag);
    auto _mls_x14 = (_mls_queen1 != _mls_x13);
    auto _mls_x15 = (_mls_x12 && _mls_x14);
    auto _mls_x16 = (_mls_x10 - _mls_diag);
    auto _mls_x17 = (_mls_queen1 != _mls_x16);
    auto _mls_x18 = (_mls_x15 && _mls_x17);
    if (_mlsValue::isIntLit(_mls_x18, 1)) {
      _mls_retval = _mlsValue::fromIntLit(1);
    } else {
      auto _mls_x19 = (_mls_diag + _mlsValue::fromIntLit(1));
      auto _mls_x20 = _mls_safe(_mls_queen1, _mls_x19, _mls_x11);
      _mls_retval = _mls_x20;
    }
  } else {
    _mls_retval = _mlsValue::fromIntLit(1);
  }
  return _mls_retval;
}
_mlsValue _mls_extend(_mlsValue _mls_queen3, _mlsValue _mls_acc, _mlsValue _mls_xss1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_xss1)) {
    auto _mls_x31 = _mlsValue::cast<_mls_Cons>(_mls_xss1)->_mls_head;
    auto _mls_x32 = _mlsValue::cast<_mls_Cons>(_mls_xss1)->_mls_tail;
    auto _mls_x33 = _mls_append_safe(_mls_queen3, _mls_x31, _mls_acc);
    auto _mls_x34 = _mls_extend(_mls_queen3, _mls_x33, _mls_x32);
    _mls_retval = _mls_x34;
  } else {
    _mls_retval = _mls_acc;
  }
  return _mls_retval;
}
_mlsValue _mls_find_solution(_mlsValue _mls_n, _mlsValue _mls_queen) {
  _mlsValue _mls_retval;
  auto _mls_x = (_mls_queen == _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x, 1)) {
    auto _mls_x5 = _mlsValue::create<_mls_Nil>();
    auto _mls_x6 = _mlsValue::create<_mls_Nil>();
    auto _mls_x7 = _mlsValue::create<_mls_Cons>(_mls_x5, _mls_x6);
    _mls_retval = _mls_x7;
  } else {
    auto _mls_x1 = (_mls_queen - _mlsValue::fromIntLit(1));
    auto _mls_x2 = _mls_find_solution(_mls_n, _mls_x1);
    auto _mls_x3 = _mlsValue::create<_mls_Nil>();
    auto _mls_x4 = _mls_extend(_mls_n, _mls_x3, _mls_x2);
    _mls_retval = _mls_x4;
  }
  return _mls_retval;
}
_mlsValue _mls_length(_mlsValue _mls_xs) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs)) {
    auto _mls_x21 = _mlsValue::cast<_mls_Cons>(_mls_xs)->_mls_tail;
    auto _mls_x22 = _mls_length(_mls_x21);
    auto _mls_x23 = (_mlsValue::fromIntLit(1) + _mls_x22);
    _mls_retval = _mls_x23;
  } else {
    _mls_retval = _mlsValue::fromIntLit(0);
  }
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
