#include "mlsprelude.h"
struct _mls_Expr;
struct _mls_Add;
struct _mls_Mul;
struct _mls_Val;
struct _mls_Var;
_mlsValue _mls_appendAdd(_mlsValue, _mlsValue);
_mlsValue _mls_appendMul(_mlsValue, _mlsValue);
_mlsValue _mls_constFolding(_mlsValue);
_mlsValue _mls_constFolding_case0_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_constFolding_case0_sr_post_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_constFolding_case0_sr_post_caller_post_case0(_mlsValue, _mlsValue);
_mlsValue _mls_constFolding_case0_sr_post_caller_post_default(_mlsValue, _mlsValue);
_mlsValue _mls_constFolding_case0_sr_post_case0(_mlsValue, _mlsValue);
_mlsValue _mls_constFolding_case0_sr_post_case1(_mlsValue, _mlsValue);
_mlsValue _mls_constFolding_case0_sr_post_default(_mlsValue, _mlsValue);
_mlsValue _mls_constFolding_case1_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_constFolding_case1_sr_post_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_constFolding_case1_sr_post_caller_post_case0(_mlsValue, _mlsValue);
_mlsValue _mls_constFolding_case1_sr_post_caller_post_default(_mlsValue, _mlsValue);
_mlsValue _mls_constFolding_case1_sr_post_case0(_mlsValue, _mlsValue);
_mlsValue _mls_constFolding_case1_sr_post_case1(_mlsValue, _mlsValue);
_mlsValue _mls_constFolding_case1_sr_post_default(_mlsValue, _mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_eval1(_mlsValue);
_mlsValue _mls_eval_case1(_mlsValue);
_mlsValue _mls_eval_case2(_mlsValue);
_mlsValue _mls_eval_case2_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_eval_case3(_mlsValue);
_mlsValue _mls_eval_case3_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_main();
_mlsValue _mls_main_caller_post_post(_mlsValue, _mlsValue);
_mlsValue _mls_main_caller_post_post_caller_post_post(_mlsValue, _mlsValue);
_mlsValue _mls_main_caller_post_post_case0(_mlsValue, _mlsValue);
_mlsValue _mls_main_caller_post_post_case1(_mlsValue, _mlsValue);
_mlsValue _mls_main_caller_post_post_default(_mlsValue, _mlsValue);
_mlsValue _mls_mkExpr(_mlsValue, _mlsValue);
_mlsValue _mls_mkExpr_case0(_mlsValue);
_mlsValue _mls_mkExpr_case0_case0();
_mlsValue _mls_mkExpr_case0_default(_mlsValue);
std::tuple<_mlsValue, _mlsValue> _mls_mkExpr_case0_pre(_mlsValue);
_mlsValue _mls_mkExpr_default(_mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_mkExpr_pre(_mlsValue, _mlsValue);
_mlsValue _mls_reassoc(_mlsValue);
_mlsValue _mls_reassoc_case0(_mlsValue);
_mlsValue _mls_reassoc_case0_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_reassoc_case0_sr_post_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_reassoc_case1(_mlsValue);
_mlsValue _mls_reassoc_case1_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_reassoc_case1_sr_post_caller_post(_mlsValue, _mlsValue);
struct _mls_Expr: public _mlsObject {
  
  constexpr static inline const char *typeName = "Expr";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Expr; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Add: public _mls_Expr {
  _mlsValue _mls_e1;
  _mlsValue _mls_e2;
  constexpr static inline const char *typeName = "Add";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e1.print(); std::printf(", "); this->_mls_e2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e1); _mlsValue::destroy(this->_mls_e2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e1.asObject()->operator==(*other.cast<_mls_Add>()->_mls_e1.asObject()) && this->_mls_e2.asObject()->operator==(*other.cast<_mls_Add>()->_mls_e2.asObject()); }
  static _mlsValue create(_mlsValue _mls_e1, _mlsValue _mls_e2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Add; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e1 = _mls_e1; _mlsVal->_mls_e2 = _mls_e2;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Mul: public _mls_Expr {
  _mlsValue _mls_e1;
  _mlsValue _mls_e2;
  constexpr static inline const char *typeName = "Mul";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e1.print(); std::printf(", "); this->_mls_e2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e1); _mlsValue::destroy(this->_mls_e2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e1.asObject()->operator==(*other.cast<_mls_Mul>()->_mls_e1.asObject()) && this->_mls_e2.asObject()->operator==(*other.cast<_mls_Mul>()->_mls_e2.asObject()); }
  static _mlsValue create(_mlsValue _mls_e1, _mlsValue _mls_e2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Mul; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e1 = _mls_e1; _mlsVal->_mls_e2 = _mls_e2;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Val: public _mls_Expr {
  _mlsValue _mls_n;
  constexpr static inline const char *typeName = "Val";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_n.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_n);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_n.asObject()->operator==(*other.cast<_mls_Val>()->_mls_n.asObject()); }
  static _mlsValue create(_mlsValue _mls_n) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Val; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_n = _mls_n;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Var: public _mls_Expr {
  _mlsValue _mls_x;
  constexpr static inline const char *typeName = "Var";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_x.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_x);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_x.asObject()->operator==(*other.cast<_mls_Var>()->_mls_x.asObject()); }
  static _mlsValue create(_mlsValue _mls_x) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Var; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_x = _mls_x;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_appendAdd(_mlsValue _mls_e12, _mlsValue _mls_e22) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_e12)) {
    auto _mls_x2 = _mlsValue::cast<_mls_Add>(_mls_e12)->_mls_e1;
    auto _mls_x3 = _mlsValue::cast<_mls_Add>(_mls_e12)->_mls_e2;
    auto _mls_x4 = _mls_appendAdd(_mls_x3, _mls_e22);
    auto _mls_x5 = _mlsValue::create<_mls_Add>(_mls_x2, _mls_x4);
    _mls_retval = _mls_x5;
  } else {
    auto _mls_x1 = _mlsValue::create<_mls_Add>(_mls_e12, _mls_e22);
    _mls_retval = _mls_x1;
  }
  return _mls_retval;
}
_mlsValue _mls_appendMul(_mlsValue _mls_e13, _mlsValue _mls_e23) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Mul>(_mls_e13)) {
    auto _mls_x7 = _mlsValue::cast<_mls_Mul>(_mls_e13)->_mls_e1;
    auto _mls_x8 = _mlsValue::cast<_mls_Mul>(_mls_e13)->_mls_e2;
    auto _mls_x9 = _mls_appendMul(_mls_x8, _mls_e23);
    auto _mls_x10 = _mlsValue::create<_mls_Mul>(_mls_x7, _mls_x9);
    _mls_retval = _mls_x10;
  } else {
    auto _mls_x6 = _mlsValue::create<_mls_Mul>(_mls_e13, _mls_e23);
    _mls_retval = _mls_x6;
  }
  return _mls_retval;
}
_mlsValue _mls_constFolding(_mlsValue _mls_x) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_x)) {
    auto _mls_x95 = _mlsValue::cast<_mls_Add>(_mls_x)->_mls_e1;
    auto _mls_x96 = _mlsValue::cast<_mls_Add>(_mls_x)->_mls_e2;
    _mls_retval = _mls_constFolding_case0_sr_post(_mls_x95, _mls_x96);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x)) {
    auto _mls_x93 = _mlsValue::cast<_mls_Mul>(_mls_x)->_mls_e1;
    auto _mls_x94 = _mlsValue::cast<_mls_Mul>(_mls_x)->_mls_e2;
    _mls_retval = _mls_constFolding_case1_sr_post(_mls_x93, _mls_x94);
  } else {
    _mls_retval = _mls_x;
  }
  return _mls_retval;
}
_mlsValue _mls_constFolding_case0_sr_post(_mlsValue _mls_x97, _mlsValue _mls_x98) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_x97)) {
    auto _mls_x103 = _mlsValue::cast<_mls_Add>(_mls_x97)->_mls_e1;
    auto _mls_x104 = _mlsValue::cast<_mls_Add>(_mls_x97)->_mls_e2;
    auto _mls_x105 = _mls_constFolding_case0_sr_post(_mls_x103, _mls_x104);
    _mls_retval = _mls_constFolding_case0_sr_post_caller_post(_mls_x98, _mls_x105);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x97)) {
    auto _mls_x100 = _mlsValue::cast<_mls_Mul>(_mls_x97)->_mls_e1;
    auto _mls_x101 = _mlsValue::cast<_mls_Mul>(_mls_x97)->_mls_e2;
    auto _mls_x102 = _mls_constFolding_case1_sr_post(_mls_x100, _mls_x101);
    _mls_retval = _mls_constFolding_case0_sr_post_caller_post(_mls_x98, _mls_x102);
  } else {
    auto _mls_x99 = _mls_constFolding(_mls_x98);
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x97)) {
      _mls_retval = _mls_constFolding_case0_sr_post_caller_post_case0(_mls_x97, _mls_x99);
    } else {
      _mls_retval = _mls_constFolding_case0_sr_post_caller_post_default(_mls_x97, _mls_x99);
    }
  }
  return _mls_retval;
}
_mlsValue _mls_constFolding_case0_sr_post_caller_post(_mlsValue _mls_x106, _mlsValue _mls_x108) {
  _mlsValue _mls_retval;
  auto _mls_x107 = _mls_constFolding(_mls_x106);
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x108)) {
    _mls_retval = _mls_constFolding_case0_sr_post_caller_post_case0(_mls_x108, _mls_x107);
  } else {
    _mls_retval = _mls_constFolding_case0_sr_post_caller_post_default(_mls_x108, _mls_x107);
  }
  return _mls_retval;
}
_mlsValue _mls_constFolding_case0_sr_post_caller_post_case0(_mlsValue _mls_x110, _mlsValue _mls_x111) {
  _mlsValue _mls_retval;
  auto _mls_x109 = _mlsValue::cast<_mls_Val>(_mls_x110)->_mls_n;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x111)) {
    auto _mls_x124 = _mlsValue::cast<_mls_Val>(_mls_x111)->_mls_n;
    auto _mls_x125 = (_mls_x109 + _mls_x124);
    auto _mls_x126 = _mlsValue::create<_mls_Val>(_mls_x125);
    _mls_retval = _mls_x126;
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x111)) {
    auto _mls_x113 = _mlsValue::cast<_mls_Add>(_mls_x111)->_mls_e1;
    auto _mls_x114 = _mlsValue::cast<_mls_Add>(_mls_x111)->_mls_e2;
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x114)) {
      auto _mls_x120 = _mlsValue::cast<_mls_Val>(_mls_x114)->_mls_n;
      auto _mls_x121 = (_mls_x109 + _mls_x120);
      auto _mls_x122 = _mlsValue::create<_mls_Val>(_mls_x121);
      auto _mls_x123 = _mlsValue::create<_mls_Add>(_mls_x122, _mls_x113);
      _mls_retval = _mls_x123;
    } else {
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x113)) {
        auto _mls_x116 = _mlsValue::cast<_mls_Val>(_mls_x113)->_mls_n;
        auto _mls_x117 = (_mls_x109 + _mls_x116);
        auto _mls_x118 = _mlsValue::create<_mls_Val>(_mls_x117);
        auto _mls_x119 = _mlsValue::create<_mls_Add>(_mls_x118, _mls_x114);
        _mls_retval = _mls_x119;
      } else {
        auto _mls_x115 = _mlsValue::create<_mls_Add>(_mls_x110, _mls_x111);
        _mls_retval = _mls_x115;
      }
    }
  } else {
    auto _mls_x112 = _mlsValue::create<_mls_Add>(_mls_x110, _mls_x111);
    _mls_retval = _mls_x112;
  }
  return _mls_retval;
}
_mlsValue _mls_constFolding_case0_sr_post_caller_post_default(_mlsValue _mls_x128, _mlsValue _mls_x129) {
  _mlsValue _mls_retval;
  auto _mls_x127 = _mlsValue::create<_mls_Add>(_mls_x128, _mls_x129);
  _mls_retval = _mls_x127;
  return _mls_retval;
}
_mlsValue _mls_constFolding_case0_sr_post_case0(_mlsValue _mls_x131, _mlsValue _mls_x134) {
  _mlsValue _mls_retval;
  auto _mls_x130 = _mlsValue::cast<_mls_Add>(_mls_x131)->_mls_e1;
  auto _mls_x132 = _mlsValue::cast<_mls_Add>(_mls_x131)->_mls_e2;
  auto _mls_x133 = _mls_constFolding_case0_sr_post(_mls_x130, _mls_x132);
  _mls_retval = _mls_constFolding_case0_sr_post_caller_post(_mls_x134, _mls_x133);
  return _mls_retval;
}
_mlsValue _mls_constFolding_case0_sr_post_case1(_mlsValue _mls_x136, _mlsValue _mls_x139) {
  _mlsValue _mls_retval;
  auto _mls_x135 = _mlsValue::cast<_mls_Mul>(_mls_x136)->_mls_e1;
  auto _mls_x137 = _mlsValue::cast<_mls_Mul>(_mls_x136)->_mls_e2;
  auto _mls_x138 = _mls_constFolding_case1_sr_post(_mls_x135, _mls_x137);
  _mls_retval = _mls_constFolding_case0_sr_post_caller_post(_mls_x139, _mls_x138);
  return _mls_retval;
}
_mlsValue _mls_constFolding_case0_sr_post_default(_mlsValue _mls_x140, _mlsValue _mls_x142) {
  _mlsValue _mls_retval;
  auto _mls_x141 = _mls_constFolding(_mls_x140);
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x142)) {
    _mls_retval = _mls_constFolding_case0_sr_post_caller_post_case0(_mls_x142, _mls_x141);
  } else {
    _mls_retval = _mls_constFolding_case0_sr_post_caller_post_default(_mls_x142, _mls_x141);
  }
  return _mls_retval;
}
_mlsValue _mls_constFolding_case1_sr_post(_mlsValue _mls_x143, _mlsValue _mls_x144) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_x143)) {
    auto _mls_x149 = _mlsValue::cast<_mls_Add>(_mls_x143)->_mls_e1;
    auto _mls_x150 = _mlsValue::cast<_mls_Add>(_mls_x143)->_mls_e2;
    auto _mls_x151 = _mls_constFolding_case0_sr_post(_mls_x149, _mls_x150);
    _mls_retval = _mls_constFolding_case1_sr_post_caller_post(_mls_x144, _mls_x151);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x143)) {
    auto _mls_x146 = _mlsValue::cast<_mls_Mul>(_mls_x143)->_mls_e1;
    auto _mls_x147 = _mlsValue::cast<_mls_Mul>(_mls_x143)->_mls_e2;
    auto _mls_x148 = _mls_constFolding_case1_sr_post(_mls_x146, _mls_x147);
    _mls_retval = _mls_constFolding_case1_sr_post_caller_post(_mls_x144, _mls_x148);
  } else {
    auto _mls_x145 = _mls_constFolding(_mls_x144);
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x143)) {
      _mls_retval = _mls_constFolding_case1_sr_post_caller_post_case0(_mls_x143, _mls_x145);
    } else {
      _mls_retval = _mls_constFolding_case1_sr_post_caller_post_default(_mls_x143, _mls_x145);
    }
  }
  return _mls_retval;
}
_mlsValue _mls_constFolding_case1_sr_post_caller_post(_mlsValue _mls_x152, _mlsValue _mls_x154) {
  _mlsValue _mls_retval;
  auto _mls_x153 = _mls_constFolding(_mls_x152);
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x154)) {
    _mls_retval = _mls_constFolding_case1_sr_post_caller_post_case0(_mls_x154, _mls_x153);
  } else {
    _mls_retval = _mls_constFolding_case1_sr_post_caller_post_default(_mls_x154, _mls_x153);
  }
  return _mls_retval;
}
_mlsValue _mls_constFolding_case1_sr_post_caller_post_case0(_mlsValue _mls_x156, _mlsValue _mls_x157) {
  _mlsValue _mls_retval;
  auto _mls_x155 = _mlsValue::cast<_mls_Val>(_mls_x156)->_mls_n;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x157)) {
    auto _mls_x170 = _mlsValue::cast<_mls_Val>(_mls_x157)->_mls_n;
    auto _mls_x171 = (_mls_x155 * _mls_x170);
    auto _mls_x172 = _mlsValue::create<_mls_Val>(_mls_x171);
    _mls_retval = _mls_x172;
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x157)) {
    auto _mls_x159 = _mlsValue::cast<_mls_Mul>(_mls_x157)->_mls_e1;
    auto _mls_x160 = _mlsValue::cast<_mls_Mul>(_mls_x157)->_mls_e2;
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x160)) {
      auto _mls_x166 = _mlsValue::cast<_mls_Val>(_mls_x160)->_mls_n;
      auto _mls_x167 = (_mls_x155 * _mls_x166);
      auto _mls_x168 = _mlsValue::create<_mls_Val>(_mls_x167);
      auto _mls_x169 = _mlsValue::create<_mls_Mul>(_mls_x168, _mls_x159);
      _mls_retval = _mls_x169;
    } else {
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x159)) {
        auto _mls_x162 = _mlsValue::cast<_mls_Val>(_mls_x159)->_mls_n;
        auto _mls_x163 = (_mls_x155 * _mls_x162);
        auto _mls_x164 = _mlsValue::create<_mls_Val>(_mls_x163);
        auto _mls_x165 = _mlsValue::create<_mls_Mul>(_mls_x164, _mls_x160);
        _mls_retval = _mls_x165;
      } else {
        auto _mls_x161 = _mlsValue::create<_mls_Mul>(_mls_x156, _mls_x157);
        _mls_retval = _mls_x161;
      }
    }
  } else {
    auto _mls_x158 = _mlsValue::create<_mls_Mul>(_mls_x156, _mls_x157);
    _mls_retval = _mls_x158;
  }
  return _mls_retval;
}
_mlsValue _mls_constFolding_case1_sr_post_caller_post_default(_mlsValue _mls_x174, _mlsValue _mls_x175) {
  _mlsValue _mls_retval;
  auto _mls_x173 = _mlsValue::create<_mls_Mul>(_mls_x174, _mls_x175);
  _mls_retval = _mls_x173;
  return _mls_retval;
}
_mlsValue _mls_constFolding_case1_sr_post_case0(_mlsValue _mls_x177, _mlsValue _mls_x180) {
  _mlsValue _mls_retval;
  auto _mls_x176 = _mlsValue::cast<_mls_Add>(_mls_x177)->_mls_e1;
  auto _mls_x178 = _mlsValue::cast<_mls_Add>(_mls_x177)->_mls_e2;
  auto _mls_x179 = _mls_constFolding_case0_sr_post(_mls_x176, _mls_x178);
  _mls_retval = _mls_constFolding_case1_sr_post_caller_post(_mls_x180, _mls_x179);
  return _mls_retval;
}
_mlsValue _mls_constFolding_case1_sr_post_case1(_mlsValue _mls_x182, _mlsValue _mls_x185) {
  _mlsValue _mls_retval;
  auto _mls_x181 = _mlsValue::cast<_mls_Mul>(_mls_x182)->_mls_e1;
  auto _mls_x183 = _mlsValue::cast<_mls_Mul>(_mls_x182)->_mls_e2;
  auto _mls_x184 = _mls_constFolding_case1_sr_post(_mls_x181, _mls_x183);
  _mls_retval = _mls_constFolding_case1_sr_post_caller_post(_mls_x185, _mls_x184);
  return _mls_retval;
}
_mlsValue _mls_constFolding_case1_sr_post_default(_mlsValue _mls_x186, _mlsValue _mls_x188) {
  _mlsValue _mls_retval;
  auto _mls_x187 = _mls_constFolding(_mls_x186);
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x188)) {
    _mls_retval = _mls_constFolding_case1_sr_post_caller_post_case0(_mls_x188, _mls_x187);
  } else {
    _mls_retval = _mls_constFolding_case1_sr_post_caller_post_default(_mls_x188, _mls_x187);
  }
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x53 = _mls_main();
  _mls_retval = _mls_x53;
  return _mls_retval;
}
_mlsValue _mls_eval1(_mlsValue _mls_x189) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Var>(_mls_x189)) {
    _mls_retval = _mlsValue::fromIntLit(0);
  } else if (_mlsValue::isValueOf<_mls_Val>(_mls_x189)) {
    auto _mls_x194 = _mlsValue::cast<_mls_Val>(_mls_x189)->_mls_n;
    _mls_retval = _mls_x194;
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x189)) {
    auto _mls_x192 = _mlsValue::cast<_mls_Add>(_mls_x189)->_mls_e1;
    auto _mls_x193 = _mlsValue::cast<_mls_Add>(_mls_x189)->_mls_e2;
    _mls_retval = _mls_eval_case2_sr_post(_mls_x192, _mls_x193);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x189)) {
    auto _mls_x190 = _mlsValue::cast<_mls_Mul>(_mls_x189)->_mls_e1;
    auto _mls_x191 = _mlsValue::cast<_mls_Mul>(_mls_x189)->_mls_e2;
    _mls_retval = _mls_eval_case3_sr_post(_mls_x190, _mls_x191);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_eval_case1(_mlsValue _mls_x196) {
  _mlsValue _mls_retval;
  auto _mls_x195 = _mlsValue::cast<_mls_Val>(_mls_x196)->_mls_n;
  _mls_retval = _mls_x195;
  return _mls_retval;
}
_mlsValue _mls_eval_case2(_mlsValue _mls_x198) {
  _mlsValue _mls_retval;
  auto _mls_x197 = _mlsValue::cast<_mls_Add>(_mls_x198)->_mls_e1;
  auto _mls_x199 = _mlsValue::cast<_mls_Add>(_mls_x198)->_mls_e2;
  _mls_retval = _mls_eval_case2_sr_post(_mls_x197, _mls_x199);
  return _mls_retval;
}
_mlsValue _mls_eval_case2_sr_post(_mlsValue _mls_x200, _mlsValue _mls_x202) {
  _mlsValue _mls_retval;
  auto _mls_x201 = _mls_eval1(_mls_x200);
  auto _mls_x203 = _mls_eval1(_mls_x202);
  auto _mls_x204 = (_mls_x201 + _mls_x203);
  _mls_retval = _mls_x204;
  return _mls_retval;
}
_mlsValue _mls_eval_case3(_mlsValue _mls_x206) {
  _mlsValue _mls_retval;
  auto _mls_x205 = _mlsValue::cast<_mls_Mul>(_mls_x206)->_mls_e1;
  auto _mls_x207 = _mlsValue::cast<_mls_Mul>(_mls_x206)->_mls_e2;
  _mls_retval = _mls_eval_case3_sr_post(_mls_x205, _mls_x207);
  return _mls_retval;
}
_mlsValue _mls_eval_case3_sr_post(_mlsValue _mls_x208, _mlsValue _mls_x210) {
  _mlsValue _mls_retval;
  auto _mls_x209 = _mls_eval1(_mls_x208);
  auto _mls_x211 = _mls_eval1(_mls_x210);
  auto _mls_x212 = (_mls_x209 * _mls_x211);
  _mls_retval = _mls_x212;
  return _mls_retval;
}
_mlsValue _mls_main() {
  _mlsValue _mls_retval;
  auto [_mls_x213, _mls_x214, _mls_x215] = _mls_mkExpr_pre(_mlsValue::fromIntLit(21), _mlsValue::fromIntLit(1));
  if (_mlsValue::isIntLit(_mls_x213, 1)) {
    auto [_mls_x223, _mls_x224] = _mls_mkExpr_case0_pre(_mls_x214);
    if (_mlsValue::isIntLit(_mls_x223, 1)) {
      auto _mls_x227 = _mls_mkExpr_case0_case0();
      _mls_retval = _mls_main_caller_post_post_default(_mls_x227, _mlsValue::fromIntLit(0));
    } else {
      auto _mls_x225 = _mls_mkExpr_case0_default(_mls_x224);
      auto _mls_x226 = _mlsValue::cast<_mls_Val>(_mls_x225)->_mls_n;
      _mls_retval = _mls_main_caller_post_post(_mls_x225, _mls_x226);
    }
  } else {
    auto _mls_x216 = _mls_mkExpr_default(_mls_x215, _mls_x214);
    auto _mls_x217 = _mlsValue::cast<_mls_Add>(_mls_x216)->_mls_e1;
    auto _mls_x218 = _mlsValue::cast<_mls_Add>(_mls_x216)->_mls_e2;
    auto _mls_x219 = _mls_eval_case2_sr_post(_mls_x217, _mls_x218);
    auto _mls_x220 = _mlsValue::cast<_mls_Add>(_mls_x216)->_mls_e1;
    auto _mls_x221 = _mlsValue::cast<_mls_Add>(_mls_x216)->_mls_e2;
    auto _mls_x222 = _mls_reassoc_case0_sr_post(_mls_x220, _mls_x221);
    _mls_retval = _mls_main_caller_post_post(_mls_x222, _mls_x219);
  }
  return _mls_retval;
}
_mlsValue _mls_main_caller_post_post(_mlsValue _mls_x228, _mlsValue _mls_x229) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_x228)) {
    _mls_retval = _mls_main_caller_post_post_case0(_mls_x228, _mls_x229);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x228)) {
    _mls_retval = _mls_main_caller_post_post_case1(_mls_x228, _mls_x229);
  } else {
    _mls_retval = _mls_main_caller_post_post_default(_mls_x228, _mls_x229);
  }
  return _mls_retval;
}
_mlsValue _mls_main_caller_post_post_caller_post_post(_mlsValue _mls_x231, _mlsValue _mls_x232) {
  _mlsValue _mls_retval;
  auto _mls_x230 = (_mls_x231 == _mls_x232);
  _mls_retval = _mls_x230;
  return _mls_retval;
}
_mlsValue _mls_main_caller_post_post_case0(_mlsValue _mls_x234, _mlsValue _mls_x238) {
  _mlsValue _mls_retval;
  auto _mls_x233 = _mlsValue::cast<_mls_Add>(_mls_x234)->_mls_e1;
  auto _mls_x235 = _mlsValue::cast<_mls_Add>(_mls_x234)->_mls_e2;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_x233)) {
    auto _mls_x241 = _mls_constFolding_case0_sr_post_case0(_mls_x233, _mls_x235);
    auto _mls_x242 = _mls_eval1(_mls_x241);
    _mls_retval = _mls_main_caller_post_post_caller_post_post(_mls_x238, _mls_x242);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x233)) {
    auto _mls_x239 = _mls_constFolding_case0_sr_post_case1(_mls_x233, _mls_x235);
    auto _mls_x240 = _mls_eval1(_mls_x239);
    _mls_retval = _mls_main_caller_post_post_caller_post_post(_mls_x238, _mls_x240);
  } else {
    auto _mls_x236 = _mls_constFolding_case0_sr_post_default(_mls_x235, _mls_x233);
    auto _mls_x237 = _mls_eval1(_mls_x236);
    _mls_retval = _mls_main_caller_post_post_caller_post_post(_mls_x238, _mls_x237);
  }
  return _mls_retval;
}
_mlsValue _mls_main_caller_post_post_case1(_mlsValue _mls_x244, _mlsValue _mls_x248) {
  _mlsValue _mls_retval;
  auto _mls_x243 = _mlsValue::cast<_mls_Mul>(_mls_x244)->_mls_e1;
  auto _mls_x245 = _mlsValue::cast<_mls_Mul>(_mls_x244)->_mls_e2;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_x243)) {
    auto _mls_x251 = _mls_constFolding_case1_sr_post_case0(_mls_x243, _mls_x245);
    auto _mls_x252 = _mls_eval1(_mls_x251);
    _mls_retval = _mls_main_caller_post_post_caller_post_post(_mls_x248, _mls_x252);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x243)) {
    auto _mls_x249 = _mls_constFolding_case1_sr_post_case1(_mls_x243, _mls_x245);
    auto _mls_x250 = _mls_eval1(_mls_x249);
    _mls_retval = _mls_main_caller_post_post_caller_post_post(_mls_x248, _mls_x250);
  } else {
    auto _mls_x246 = _mls_constFolding_case1_sr_post_default(_mls_x245, _mls_x243);
    auto _mls_x247 = _mls_eval1(_mls_x246);
    _mls_retval = _mls_main_caller_post_post_caller_post_post(_mls_x248, _mls_x247);
  }
  return _mls_retval;
}
_mlsValue _mls_main_caller_post_post_default(_mlsValue _mls_x253, _mlsValue _mls_x255) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Var>(_mls_x253)) {
    _mls_retval = _mls_main_caller_post_post_caller_post_post(_mls_x255, _mlsValue::fromIntLit(0));
  } else if (_mlsValue::isValueOf<_mls_Val>(_mls_x253)) {
    auto _mls_x257 = _mls_eval_case1(_mls_x253);
    _mls_retval = _mls_main_caller_post_post_caller_post_post(_mls_x255, _mls_x257);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x253)) {
    auto _mls_x256 = _mls_eval_case2(_mls_x253);
    _mls_retval = _mls_main_caller_post_post_caller_post_post(_mls_x255, _mls_x256);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x253)) {
    auto _mls_x254 = _mls_eval_case3(_mls_x253);
    _mls_retval = _mls_main_caller_post_post_caller_post_post(_mls_x255, _mls_x254);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_mkExpr(_mlsValue _mls_x258, _mlsValue _mls_x259) {
  _mlsValue _mls_retval;
  auto [_mls_x260, _mls_x261, _mls_x262] = _mls_mkExpr_pre(_mls_x258, _mls_x259);
  if (_mlsValue::isIntLit(_mls_x260, 1)) {
    _mls_retval = _mls_mkExpr_case0(_mls_x261);
  } else {
    _mls_retval = _mls_mkExpr_default(_mls_x262, _mls_x261);
  }
  return _mls_retval;
}
_mlsValue _mls_mkExpr_case0(_mlsValue _mls_x263) {
  _mlsValue _mls_retval;
  auto [_mls_x264, _mls_x265] = _mls_mkExpr_case0_pre(_mls_x263);
  if (_mlsValue::isIntLit(_mls_x264, 1)) {
    _mls_retval = _mls_mkExpr_case0_case0();
  } else {
    _mls_retval = _mls_mkExpr_case0_default(_mls_x265);
  }
  return _mls_retval;
}
_mlsValue _mls_mkExpr_case0_case0() {
  _mlsValue _mls_retval;
  auto _mls_x266 = _mlsValue::create<_mls_Var>(_mlsValue::fromIntLit(1));
  _mls_retval = _mls_x266;
  return _mls_retval;
}
_mlsValue _mls_mkExpr_case0_default(_mlsValue _mls_x268) {
  _mlsValue _mls_retval;
  auto _mls_x267 = _mlsValue::create<_mls_Val>(_mls_x268);
  _mls_retval = _mls_x267;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue> _mls_mkExpr_case0_pre(_mlsValue _mls_x270) {
  std::tuple<_mlsValue, _mlsValue> _mls_retval;
  auto _mls_x269 = (_mls_x270 == _mlsValue::fromIntLit(0));
  _mls_retval = std::make_tuple(_mls_x269, _mls_x270);
  return _mls_retval;
}
_mlsValue _mls_mkExpr_default(_mlsValue _mls_x272, _mlsValue _mls_x274) {
  _mlsValue _mls_retval;
  auto _mls_x271 = (_mls_x272 - _mlsValue::fromIntLit(1));
  auto _mls_x273 = (_mls_x274 + _mlsValue::fromIntLit(1));
  auto _mls_x275 = _mls_mkExpr(_mls_x271, _mls_x273);
  auto _mls_x276 = (_mls_x272 - _mlsValue::fromIntLit(1));
  auto _mls_x277 = (_mls_x274 - _mlsValue::fromIntLit(1));
  auto _mls_x278 = _mls_mkExpr(_mls_x276, _mls_x277);
  auto _mls_x279 = _mlsValue::create<_mls_Add>(_mls_x275, _mls_x278);
  _mls_retval = _mls_x279;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_mkExpr_pre(_mlsValue _mls_x281, _mlsValue _mls_x282) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x280 = (_mls_x281 == _mlsValue::fromIntLit(0));
  _mls_retval = std::make_tuple(_mls_x280, _mls_x282, _mls_x281);
  return _mls_retval;
}
_mlsValue _mls_reassoc(_mlsValue _mls_x283) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_x283)) {
    _mls_retval = _mls_reassoc_case0(_mls_x283);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x283)) {
    _mls_retval = _mls_reassoc_case1(_mls_x283);
  } else {
    _mls_retval = _mls_x283;
  }
  return _mls_retval;
}
_mlsValue _mls_reassoc_case0(_mlsValue _mls_x285) {
  _mlsValue _mls_retval;
  auto _mls_x284 = _mlsValue::cast<_mls_Add>(_mls_x285)->_mls_e1;
  auto _mls_x286 = _mlsValue::cast<_mls_Add>(_mls_x285)->_mls_e2;
  _mls_retval = _mls_reassoc_case0_sr_post(_mls_x284, _mls_x286);
  return _mls_retval;
}
_mlsValue _mls_reassoc_case0_sr_post(_mlsValue _mls_x287, _mlsValue _mls_x288) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_x287)) {
    auto _mls_x294 = _mlsValue::cast<_mls_Add>(_mls_x287)->_mls_e1;
    auto _mls_x295 = _mlsValue::cast<_mls_Add>(_mls_x287)->_mls_e2;
    auto _mls_x296 = _mls_reassoc_case0_sr_post(_mls_x294, _mls_x295);
    _mls_retval = _mls_reassoc_case0_sr_post_caller_post(_mls_x288, _mls_x296);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x287)) {
    auto _mls_x291 = _mlsValue::cast<_mls_Mul>(_mls_x287)->_mls_e1;
    auto _mls_x292 = _mlsValue::cast<_mls_Mul>(_mls_x287)->_mls_e2;
    auto _mls_x293 = _mls_reassoc_case1_sr_post(_mls_x291, _mls_x292);
    _mls_retval = _mls_reassoc_case0_sr_post_caller_post(_mls_x288, _mls_x293);
  } else {
    auto _mls_x289 = _mls_reassoc(_mls_x288);
    auto _mls_x290 = _mls_appendAdd(_mls_x287, _mls_x289);
    _mls_retval = _mls_x290;
  }
  return _mls_retval;
}
_mlsValue _mls_reassoc_case0_sr_post_caller_post(_mlsValue _mls_x297, _mlsValue _mls_x299) {
  _mlsValue _mls_retval;
  auto _mls_x298 = _mls_reassoc(_mls_x297);
  auto _mls_x300 = _mls_appendAdd(_mls_x299, _mls_x298);
  _mls_retval = _mls_x300;
  return _mls_retval;
}
_mlsValue _mls_reassoc_case1(_mlsValue _mls_x302) {
  _mlsValue _mls_retval;
  auto _mls_x301 = _mlsValue::cast<_mls_Mul>(_mls_x302)->_mls_e1;
  auto _mls_x303 = _mlsValue::cast<_mls_Mul>(_mls_x302)->_mls_e2;
  _mls_retval = _mls_reassoc_case1_sr_post(_mls_x301, _mls_x303);
  return _mls_retval;
}
_mlsValue _mls_reassoc_case1_sr_post(_mlsValue _mls_x304, _mlsValue _mls_x305) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_x304)) {
    auto _mls_x311 = _mlsValue::cast<_mls_Add>(_mls_x304)->_mls_e1;
    auto _mls_x312 = _mlsValue::cast<_mls_Add>(_mls_x304)->_mls_e2;
    auto _mls_x313 = _mls_reassoc_case0_sr_post(_mls_x311, _mls_x312);
    _mls_retval = _mls_reassoc_case1_sr_post_caller_post(_mls_x305, _mls_x313);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x304)) {
    auto _mls_x308 = _mlsValue::cast<_mls_Mul>(_mls_x304)->_mls_e1;
    auto _mls_x309 = _mlsValue::cast<_mls_Mul>(_mls_x304)->_mls_e2;
    auto _mls_x310 = _mls_reassoc_case1_sr_post(_mls_x308, _mls_x309);
    _mls_retval = _mls_reassoc_case1_sr_post_caller_post(_mls_x305, _mls_x310);
  } else {
    auto _mls_x306 = _mls_reassoc(_mls_x305);
    auto _mls_x307 = _mls_appendMul(_mls_x304, _mls_x306);
    _mls_retval = _mls_x307;
  }
  return _mls_retval;
}
_mlsValue _mls_reassoc_case1_sr_post_caller_post(_mlsValue _mls_x314, _mlsValue _mls_x316) {
  _mlsValue _mls_retval;
  auto _mls_x315 = _mls_reassoc(_mls_x314);
  auto _mls_x317 = _mls_appendMul(_mls_x316, _mls_x315);
  _mls_retval = _mls_x317;
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
