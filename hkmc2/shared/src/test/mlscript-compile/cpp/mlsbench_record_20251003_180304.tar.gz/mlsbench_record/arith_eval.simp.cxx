#include "mlsprelude.h"
struct _mls_Expr;
struct _mls_Add;
struct _mls_Val;
struct _mls_Var;
_mlsValue _mls_dec(_mlsValue);
_mlsValue _mls_eeval(_mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_main();
_mlsValue _mls_mk_expr(_mlsValue, _mlsValue);
struct _mls_Expr: public _mlsObject {
  
  constexpr static inline const char *typeName = "Expr";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Expr; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Add: public _mls_Expr {
  _mlsValue _mls_e1;
  _mlsValue _mls_e2;
  constexpr static inline const char *typeName = "Add";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e1.print(); std::printf(", "); this->_mls_e2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e1); _mlsValue::destroy(this->_mls_e2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e1.asObject()->operator==(*other.cast<_mls_Add>()->_mls_e1.asObject()) && this->_mls_e2.asObject()->operator==(*other.cast<_mls_Add>()->_mls_e2.asObject()); }
  static _mlsValue create(_mlsValue _mls_e1, _mlsValue _mls_e2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Add; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e1 = _mls_e1; _mlsVal->_mls_e2 = _mls_e2;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Val: public _mls_Expr {
  _mlsValue _mls_n;
  constexpr static inline const char *typeName = "Val";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_n.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_n);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_n.asObject()->operator==(*other.cast<_mls_Val>()->_mls_n.asObject()); }
  static _mlsValue create(_mlsValue _mls_n) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Val; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_n = _mls_n;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Var: public _mls_Expr {
  _mlsValue _mls_x;
  constexpr static inline const char *typeName = "Var";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_x.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_x);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_x.asObject()->operator==(*other.cast<_mls_Var>()->_mls_x.asObject()); }
  static _mlsValue create(_mlsValue _mls_x) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Var; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_x = _mls_x;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_dec(_mlsValue _mls_n1) {
  _mlsValue _mls_retval;
  auto _mls_x1 = (_mls_n1 == _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x1, 1)) {
    _mls_retval = _mlsValue::fromIntLit(0);
  } else {
    auto _mls_x2 = (_mls_n1 - _mlsValue::fromIntLit(1));
    _mls_retval = _mls_x2;
  }
  return _mls_retval;
}
_mlsValue _mls_eeval(_mlsValue _mls_e) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_e)) {
    auto _mls_x8 = _mlsValue::cast<_mls_Val>(_mls_e)->_mls_n;
    _mls_retval = _mls_x8;
  } else if (_mlsValue::isValueOf<_mls_Var>(_mls_e)) {
    _mls_retval = _mlsValue::fromIntLit(0);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_e)) {
    auto _mls_x3 = _mlsValue::cast<_mls_Add>(_mls_e)->_mls_e1;
    auto _mls_x4 = _mlsValue::cast<_mls_Add>(_mls_e)->_mls_e2;
    auto _mls_x5 = _mls_eeval(_mls_x3);
    auto _mls_x6 = _mls_eeval(_mls_x4);
    auto _mls_x7 = (_mls_x5 + _mls_x6);
    _mls_retval = _mls_x7;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x9 = _mls_main();
  _mls_retval = _mls_x9;
  return _mls_retval;
}
_mlsValue _mls_main() {
  _mlsValue _mls_retval;
  auto _mls_x10 = _mls_mk_expr(_mlsValue::fromIntLit(25), _mlsValue::fromIntLit(1));
  auto _mls_x11 = _mls_eeval(_mls_x10);
  _mls_retval = _mls_x11;
  return _mls_retval;
}
_mlsValue _mls_mk_expr(_mlsValue _mls_n2, _mlsValue _mls_v) {
  _mlsValue _mls_retval;
  auto _mls_x12 = (_mls_n2 == _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x12, 1)) {
    auto _mls_x20 = _mlsValue::create<_mls_Val>(_mls_v);
    _mls_retval = _mls_x20;
  } else {
    auto _mls_x13 = (_mls_n2 - _mlsValue::fromIntLit(1));
    auto _mls_x14 = (_mls_v + _mlsValue::fromIntLit(1));
    auto _mls_x15 = _mls_mk_expr(_mls_x13, _mls_x14);
    auto _mls_x16 = (_mls_n2 - _mlsValue::fromIntLit(1));
    auto _mls_x17 = _mls_dec(_mls_v);
    auto _mls_x18 = _mls_mk_expr(_mls_x16, _mls_x17);
    auto _mls_x19 = _mlsValue::create<_mls_Add>(_mls_x15, _mls_x18);
    _mls_retval = _mls_x19;
  }
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
