#include "mlsprelude.h"
struct _mls_Lambda_f;
struct _mls_Lambda_f1;
struct _mls_Lambda_lambda;
struct _mls_Lambda_lscomp;
struct _mls_Lambda_lscomp1;
struct _mls_Lambda_lscomp2;
struct _mls_Lambda_lscomp21;
struct _mls_Lambda_lscomp3;
struct _mls_Lambda_lscomp4;
struct _mls_Lambda_lscomp5;
struct _mls_Lambda_lscomp6;
struct _mls_Lambda_lscomp7;
struct _mls_Lambda_lscomp8;
struct _mls_Lambda_snd;
struct _mls_Lambda_sphmap;
struct _mls_Lambda_vecadd;
struct _mls_Light;
struct _mls_Directional;
struct _mls_List;
struct _mls_Cons;
struct _mls_Nil;
struct _mls_Point;
struct _mls_Sphere;
struct _mls_Surfspec;
struct _mls_Ambient;
struct _mls_Body;
struct _mls_Diffuse;
struct _mls_Reflect;
struct _mls_Refract;
struct _mls_Specpow;
struct _mls_Specular;
struct _mls_Transmit;
struct _mls_Tuple2;
struct _mls_Tuple3;
_mlsValue _mls_ambientsurf_case1_sr_post(_mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_ambientsurf_pre(_mlsValue);
_mlsValue _mls_append(_mlsValue, _mlsValue);
_mlsValue _mls_append_case1_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_bodysurf(_mlsValue);
_mlsValue _mls_bodysurf_case1(_mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_bodysurf_pre(_mlsValue);
_mlsValue _mls_camparams_caller_post_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_camparams_caller_post_caller_post_caller_post_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_camparams_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_camparams_caller_post_caller_post_caller_post_caller_post_case0(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_camparams_caller_post_caller_post_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_camparams_caller_post_case0_pre(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_camparams_case0_case0_pre(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_diffusesurf_case1_sr_post(_mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_diffusesurf_pre(_mlsValue);
_mlsValue _mls_dtor(_mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_enumFromTo(_mlsValue, _mlsValue);
_mlsValue _mls_foldr(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_head1(_mlsValue);
_mlsValue _mls_is_zerovector(_mlsValue);
_mlsValue _mls_j1(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_j2(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_j4(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_j3(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_j_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_j_caller_post_case0(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_j_caller_post_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_j_caller_post_post1(_mlsValue);
_mlsValue _mls_j_caller_post_post(_mlsValue);
_mlsValue _mls_j_case0(_mlsValue);
_mlsValue _mls_j_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_j_case0_sr_post_caller_post_case0(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_j_case0_sr_post_case0();
_mlsValue _mls_j_case0_sr_post_default(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_j_case0_sr_post_default_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_j_case0_sr_post_pre(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_j_default(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_j_default1(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_j_default_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_lightcolour(_mlsValue);
_mlsValue _mls_lightdirection_caller_post_post(_mlsValue);
_mlsValue _mls_lightdirection_case0_sr_post_case0_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_lightdirection_case1_sr_post_case0_case0(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_lightray(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_lightray_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_lightray_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_lightray_caller_post_caller_post_case0_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post1(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post1(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_lightray_caller_post_caller_post_case0_caller_post_case0(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_lightray_caller_post_caller_post_case0_caller_post_default(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_lightray_caller_post_caller_post_case0_caller_post_pre(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_lightray_caller_post_caller_post_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_lightray_caller_post_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_map(_mlsValue, _mlsValue);
_mlsValue _mls_map_case0(_mlsValue, _mlsValue);
_mlsValue _mls_map_case0_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_map_case1();
_mlsValue _mls_ray(_mlsValue);
_mlsValue _mls_ray_caller_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_reflectray(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_reflectray_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_reflectray_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_reflectray_caller_post_caller_post1(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_reflectray_caller_post_caller_post_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_reflectsurf(_mlsValue);
_mlsValue _mls_refractray_case0_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_refractray_case0_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_refractray_case0_pre(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_refractray_pre(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_refractsurf(_mlsValue);
_mlsValue _mls_repeatRun(_mlsValue, _mlsValue);
_mlsValue _mls_run(_mlsValue);
_mlsValue _mls_s2();
_mlsValue _mls_shade(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_shade_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_shade_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_shade_caller_post_caller_post_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_shade_caller_post_caller_post_caller_post_caller_post1(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post1(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_shade_caller_post_caller_post_caller_post_pre(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_shade_caller_post_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_shade_case0(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_shade_case0_pre(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_shadowed_caller_post_caller_post_caller_post_case0(_mlsValue);
_mlsValue _mls_shadowed_caller_post_caller_post_caller_post_default(_mlsValue);
_mlsValue _mls_shadowed_caller_post_caller_post_case0(_mlsValue, _mlsValue);
_mlsValue _mls_shadowed_caller_post_caller_post_case0_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_shadowed_caller_post_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_shadowed_case0_pre(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_snd(_mlsValue);
_mlsValue _mls_specpowsurf(_mlsValue);
_mlsValue _mls_specularsurf(_mlsValue);
_mlsValue _mls_specularsurf_case1_sr_post(_mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_specularsurf_pre(_mlsValue);
_mlsValue _mls_sphereintersect(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_sphereintersect_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_sphereintersect_caller_post_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_spherenormal_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_spherenormal_case0_sr_post_case0(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_spheresurf(_mlsValue);
_mlsValue _mls_tail1(_mlsValue);
_mlsValue _mls_testlights();
_mlsValue _mls_testspheres();
_mlsValue _mls_trace_caller_post_case0(_mlsValue);
_mlsValue _mls_trace_caller_post_default(_mlsValue, _mlsValue);
_mlsValue _mls_trace_caller_post_default_case0_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_trace_caller_post_default_pre(_mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_trace_pre(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_tracepixel(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_tracepixel_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_tracepixel_caller_post_caller_post_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_tracepixel_caller_post_caller_post_caller_post_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_tracepixel_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_transmitray(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_transmitray_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_transmitray_caller_post_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_transmitray_caller_post_caller_post_caller_post1(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_transmitray_caller_post_caller_post_caller_post_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_transmitray_caller_post_caller_post_case0(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_transmitray_caller_post_case0(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_transmitray_caller_post_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_transmitray_caller_post_default(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_transmitsurf(_mlsValue);
_mlsValue _mls_vecadd(_mlsValue, _mlsValue);
_mlsValue _mls_vecadd_case0(_mlsValue, _mlsValue);
_mlsValue _mls_vecadd_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_vecadd_case0_sr_post_case0(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_vecadd_case0_sr_post_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_veccross_case0(_mlsValue, _mlsValue);
_mlsValue _mls_veccross_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_veccross_case0_sr_post_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_vecdot(_mlsValue, _mlsValue);
_mlsValue _mls_vecdot_case0(_mlsValue, _mlsValue);
_mlsValue _mls_vecdot_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_vecmult(_mlsValue, _mlsValue);
_mlsValue _mls_vecmult_case0(_mlsValue, _mlsValue);
_mlsValue _mls_vecmult_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_vecmult_case0_sr_post_case0(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_vecmult_case0_sr_post_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_vecnorm_case0(_mlsValue);
_mlsValue _mls_vecnorm_case0_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_vecscale(_mlsValue, _mlsValue);
_mlsValue _mls_vecscale_case0(_mlsValue, _mlsValue);
_mlsValue _mls_vecscale_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_vecsub(_mlsValue, _mlsValue);
_mlsValue _mls_vecsub_case0_case0(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_vecsub_case0_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_vecsub_case0_pre(_mlsValue, _mlsValue);
_mlsValue _mls_vecsub_case0_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_vecsub_case0_sr_post_case0(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_vecsum(_mlsValue);
struct _mls_Lambda_f: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  _mlsValue _mls_lam_arg1;
  _mlsValue _mls_lam_arg2;
  _mlsValue _mls_lam_arg3;
  constexpr static inline const char *typeName = "Lambda_f";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print(); std::printf(", "); this->_mls_lam_arg1.print(); std::printf(", "); this->_mls_lam_arg2.print(); std::printf(", "); this->_mls_lam_arg3.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0); _mlsValue::destroy(this->_mls_lam_arg1); _mlsValue::destroy(this->_mls_lam_arg2); _mlsValue::destroy(this->_mls_lam_arg3);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_f>()->_mls_lam_arg0.asObject()) && this->_mls_lam_arg1.asObject()->operator==(*other.cast<_mls_Lambda_f>()->_mls_lam_arg1.asObject()) && this->_mls_lam_arg2.asObject()->operator==(*other.cast<_mls_Lambda_f>()->_mls_lam_arg2.asObject()) && this->_mls_lam_arg3.asObject()->operator==(*other.cast<_mls_Lambda_f>()->_mls_lam_arg3.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0, _mlsValue _mls_lam_arg1, _mlsValue _mls_lam_arg2, _mlsValue _mls_lam_arg3) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_f; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0; _mlsVal->_mls_lam_arg1 = _mls_lam_arg1; _mlsVal->_mls_lam_arg2 = _mls_lam_arg2; _mlsVal->_mls_lam_arg3 = _mls_lam_arg3;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_f1: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_f";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_f1; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_lambda: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  _mlsValue _mls_lam_arg1;
  _mlsValue _mls_lam_arg2;
  _mlsValue _mls_lam_arg3;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print(); std::printf(", "); this->_mls_lam_arg1.print(); std::printf(", "); this->_mls_lam_arg2.print(); std::printf(", "); this->_mls_lam_arg3.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0); _mlsValue::destroy(this->_mls_lam_arg1); _mlsValue::destroy(this->_mls_lam_arg2); _mlsValue::destroy(this->_mls_lam_arg3);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda>()->_mls_lam_arg0.asObject()) && this->_mls_lam_arg1.asObject()->operator==(*other.cast<_mls_Lambda_lambda>()->_mls_lam_arg1.asObject()) && this->_mls_lam_arg2.asObject()->operator==(*other.cast<_mls_Lambda_lambda>()->_mls_lam_arg2.asObject()) && this->_mls_lam_arg3.asObject()->operator==(*other.cast<_mls_Lambda_lambda>()->_mls_lam_arg3.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0, _mlsValue _mls_lam_arg1, _mlsValue _mls_lam_arg2, _mlsValue _mls_lam_arg3) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0; _mlsVal->_mls_lam_arg1 = _mls_lam_arg1; _mlsVal->_mls_lam_arg2 = _mls_lam_arg2; _mlsVal->_mls_lam_arg3 = _mls_lam_arg3;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lscomp: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lscomp";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lscomp; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lscomp1: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  _mlsValue _mls_lam_arg1;
  constexpr static inline const char *typeName = "Lambda_lscomp1";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print(); std::printf(", "); this->_mls_lam_arg1.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0); _mlsValue::destroy(this->_mls_lam_arg1);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lscomp1>()->_mls_lam_arg0.asObject()) && this->_mls_lam_arg1.asObject()->operator==(*other.cast<_mls_Lambda_lscomp1>()->_mls_lam_arg1.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0, _mlsValue _mls_lam_arg1) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lscomp1; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0; _mlsVal->_mls_lam_arg1 = _mls_lam_arg1;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lscomp2: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lscomp";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lscomp2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lscomp21: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  _mlsValue _mls_lam_arg1;
  _mlsValue _mls_lam_arg2;
  _mlsValue _mls_lam_arg3;
  constexpr static inline const char *typeName = "Lambda_lscomp2";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print(); std::printf(", "); this->_mls_lam_arg1.print(); std::printf(", "); this->_mls_lam_arg2.print(); std::printf(", "); this->_mls_lam_arg3.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0); _mlsValue::destroy(this->_mls_lam_arg1); _mlsValue::destroy(this->_mls_lam_arg2); _mlsValue::destroy(this->_mls_lam_arg3);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lscomp21>()->_mls_lam_arg0.asObject()) && this->_mls_lam_arg1.asObject()->operator==(*other.cast<_mls_Lambda_lscomp21>()->_mls_lam_arg1.asObject()) && this->_mls_lam_arg2.asObject()->operator==(*other.cast<_mls_Lambda_lscomp21>()->_mls_lam_arg2.asObject()) && this->_mls_lam_arg3.asObject()->operator==(*other.cast<_mls_Lambda_lscomp21>()->_mls_lam_arg3.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0, _mlsValue _mls_lam_arg1, _mlsValue _mls_lam_arg2, _mlsValue _mls_lam_arg3) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lscomp21; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0; _mlsVal->_mls_lam_arg1 = _mls_lam_arg1; _mlsVal->_mls_lam_arg2 = _mls_lam_arg2; _mlsVal->_mls_lam_arg3 = _mls_lam_arg3;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lscomp3: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lscomp";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lscomp3; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lscomp4: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lscomp";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lscomp4; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lscomp5: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lscomp";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lscomp5; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lscomp6: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lscomp";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lscomp6; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lscomp7: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lscomp";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lscomp7; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lscomp8: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lscomp";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lscomp8; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_snd: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_snd";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_snd; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_sphmap: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  _mlsValue _mls_lam_arg1;
  constexpr static inline const char *typeName = "Lambda_sphmap";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print(); std::printf(", "); this->_mls_lam_arg1.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0); _mlsValue::destroy(this->_mls_lam_arg1);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_sphmap>()->_mls_lam_arg0.asObject()) && this->_mls_lam_arg1.asObject()->operator==(*other.cast<_mls_Lambda_sphmap>()->_mls_lam_arg1.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0, _mlsValue _mls_lam_arg1) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_sphmap; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0; _mlsVal->_mls_lam_arg1 = _mls_lam_arg1;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_vecadd: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_vecadd";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_vecadd; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Light: public _mlsObject {
  
  constexpr static inline const char *typeName = "Light";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Light; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Directional: public _mls_Light {
  _mlsValue _mls_x;
  _mlsValue _mls_y;
  constexpr static inline const char *typeName = "Directional";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_x.print(); std::printf(", "); this->_mls_y.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_x); _mlsValue::destroy(this->_mls_y);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_x.asObject()->operator==(*other.cast<_mls_Directional>()->_mls_x.asObject()) && this->_mls_y.asObject()->operator==(*other.cast<_mls_Directional>()->_mls_y.asObject()); }
  static _mlsValue create(_mlsValue _mls_x, _mlsValue _mls_y) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Directional; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_x = _mls_x; _mlsVal->_mls_y = _mls_y;  return _mlsValue(_mlsVal); }
  
};
struct _mls_List: public _mlsObject {
  
  constexpr static inline const char *typeName = "List";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_List; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Cons: public _mls_List {
  _mlsValue _mls_head;
  _mlsValue _mls_tail;
  constexpr static inline const char *typeName = "Cons";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_head.print(); std::printf(", "); this->_mls_tail.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_head); _mlsValue::destroy(this->_mls_tail);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_head.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_head.asObject()) && this->_mls_tail.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_tail.asObject()); }
  static _mlsValue create(_mlsValue _mls_head, _mlsValue _mls_tail) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Cons; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_head = _mls_head; _mlsVal->_mls_tail = _mls_tail;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Nil: public _mls_List {
  
  constexpr static inline const char *typeName = "Nil";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Nil; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Point: public _mls_Light {
  _mlsValue _mls_x;
  _mlsValue _mls_y;
  constexpr static inline const char *typeName = "Point";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_x.print(); std::printf(", "); this->_mls_y.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_x); _mlsValue::destroy(this->_mls_y);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_x.asObject()->operator==(*other.cast<_mls_Point>()->_mls_x.asObject()) && this->_mls_y.asObject()->operator==(*other.cast<_mls_Point>()->_mls_y.asObject()); }
  static _mlsValue create(_mlsValue _mls_x, _mlsValue _mls_y) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Point; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_x = _mls_x; _mlsVal->_mls_y = _mls_y;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Sphere: public _mlsObject {
  _mlsValue _mls_pos;
  _mlsValue _mls_radius;
  _mlsValue _mls_surface;
  constexpr static inline const char *typeName = "Sphere";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_pos.print(); std::printf(", "); this->_mls_radius.print(); std::printf(", "); this->_mls_surface.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_pos); _mlsValue::destroy(this->_mls_radius); _mlsValue::destroy(this->_mls_surface);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_pos.asObject()->operator==(*other.cast<_mls_Sphere>()->_mls_pos.asObject()) && this->_mls_radius.asObject()->operator==(*other.cast<_mls_Sphere>()->_mls_radius.asObject()) && this->_mls_surface.asObject()->operator==(*other.cast<_mls_Sphere>()->_mls_surface.asObject()); }
  static _mlsValue create(_mlsValue _mls_pos, _mlsValue _mls_radius, _mlsValue _mls_surface) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Sphere; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_pos = _mls_pos; _mlsVal->_mls_radius = _mls_radius; _mlsVal->_mls_surface = _mls_surface;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Surfspec: public _mlsObject {
  
  constexpr static inline const char *typeName = "Surfspec";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Surfspec; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Ambient: public _mls_Surfspec {
  _mlsValue _mls_v;
  constexpr static inline const char *typeName = "Ambient";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_v.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_v);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_v.asObject()->operator==(*other.cast<_mls_Ambient>()->_mls_v.asObject()); }
  static _mlsValue create(_mlsValue _mls_v) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Ambient; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_v = _mls_v;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Body: public _mls_Surfspec {
  _mlsValue _mls_v;
  constexpr static inline const char *typeName = "Body";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_v.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_v);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_v.asObject()->operator==(*other.cast<_mls_Body>()->_mls_v.asObject()); }
  static _mlsValue create(_mlsValue _mls_v) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Body; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_v = _mls_v;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Diffuse: public _mls_Surfspec {
  _mlsValue _mls_v;
  constexpr static inline const char *typeName = "Diffuse";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_v.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_v);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_v.asObject()->operator==(*other.cast<_mls_Diffuse>()->_mls_v.asObject()); }
  static _mlsValue create(_mlsValue _mls_v) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Diffuse; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_v = _mls_v;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Reflect: public _mls_Surfspec {
  _mlsValue _mls_v;
  constexpr static inline const char *typeName = "Reflect";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_v.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_v);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_v.asObject()->operator==(*other.cast<_mls_Reflect>()->_mls_v.asObject()); }
  static _mlsValue create(_mlsValue _mls_v) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Reflect; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_v = _mls_v;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Refract: public _mls_Surfspec {
  _mlsValue _mls_v;
  constexpr static inline const char *typeName = "Refract";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_v.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_v);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_v.asObject()->operator==(*other.cast<_mls_Refract>()->_mls_v.asObject()); }
  static _mlsValue create(_mlsValue _mls_v) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Refract; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_v = _mls_v;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Specpow: public _mls_Surfspec {
  _mlsValue _mls_v;
  constexpr static inline const char *typeName = "Specpow";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_v.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_v);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_v.asObject()->operator==(*other.cast<_mls_Specpow>()->_mls_v.asObject()); }
  static _mlsValue create(_mlsValue _mls_v) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Specpow; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_v = _mls_v;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Specular: public _mls_Surfspec {
  _mlsValue _mls_v;
  constexpr static inline const char *typeName = "Specular";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_v.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_v);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_v.asObject()->operator==(*other.cast<_mls_Specular>()->_mls_v.asObject()); }
  static _mlsValue create(_mlsValue _mls_v) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Specular; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_v = _mls_v;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Transmit: public _mls_Surfspec {
  _mlsValue _mls_v;
  constexpr static inline const char *typeName = "Transmit";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_v.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_v);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_v.asObject()->operator==(*other.cast<_mls_Transmit>()->_mls_v.asObject()); }
  static _mlsValue create(_mlsValue _mls_v) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Transmit; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_v = _mls_v;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Tuple2: public _mlsObject {
  _mlsValue _mls_field0;
  _mlsValue _mls_field1;
  constexpr static inline const char *typeName = "Tuple2";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_field0.print(); std::printf(", "); this->_mls_field1.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_field0); _mlsValue::destroy(this->_mls_field1);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_field0.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field0.asObject()) && this->_mls_field1.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field1.asObject()); }
  static _mlsValue create(_mlsValue _mls_field0, _mlsValue _mls_field1) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Tuple2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_field0 = _mls_field0; _mlsVal->_mls_field1 = _mls_field1;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Tuple3: public _mlsObject {
  _mlsValue _mls_field0;
  _mlsValue _mls_field1;
  _mlsValue _mls_field2;
  constexpr static inline const char *typeName = "Tuple3";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_field0.print(); std::printf(", "); this->_mls_field1.print(); std::printf(", "); this->_mls_field2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_field0); _mlsValue::destroy(this->_mls_field1); _mlsValue::destroy(this->_mls_field2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_field0.asObject()->operator==(*other.cast<_mls_Tuple3>()->_mls_field0.asObject()) && this->_mls_field1.asObject()->operator==(*other.cast<_mls_Tuple3>()->_mls_field1.asObject()) && this->_mls_field2.asObject()->operator==(*other.cast<_mls_Tuple3>()->_mls_field2.asObject()); }
  static _mlsValue create(_mlsValue _mls_field0, _mlsValue _mls_field1, _mlsValue _mls_field2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Tuple3; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_field0 = _mls_field0; _mlsVal->_mls_field1 = _mls_field1; _mlsVal->_mls_field2 = _mls_field2;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_ambientsurf_case1_sr_post(_mlsValue _mls_x94, _mlsValue _mls_x583, _mlsValue _mls_x584) {
  _mlsValue _mls_retval;
  auto _mls_x585 = _mls_append_case1_sr_post(_mls_x94, _mls_x583, _mls_x584);
  auto _mls_x586 = _mlsValue::cast<_mls_Cons>(_mls_x585)->_mls_head;
  _mls_retval = _mls_x586;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_ambientsurf_pre(_mlsValue _mls_x588) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x587 = _mlsValue::create<_mls_Lambda_lscomp4>();
  auto _mls_x589 = _mlsMethodCall<_mls_Callable>(_mls_x587)->_mls_apply1(_mls_x588);
  auto _mls_x590 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
  auto _mls_x591 = _mlsValue::create<_mls_Nil>();
  auto _mls_x592 = _mlsValue::create<_mls_Cons>(_mls_x590, _mls_x591);
  _mls_retval = std::make_tuple(_mls_x589, _mls_x590, _mls_x592);
  return _mls_retval;
}
_mlsValue _mls_append(_mlsValue _mls_x596, _mlsValue _mls_x599) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x593, _mls_x594, _mls_x595;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x596)) {
    _mls_retval = _mls_x599;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x596)) {
    auto _mls_x597 = _mlsValue::cast<_mls_Cons>(_mls_x596)->_mls_head;
    auto _mls_x598 = _mlsValue::cast<_mls_Cons>(_mls_x596)->_mls_tail;
    _mls_x593 = _mls_x598;
    _mls_x594 = _mls_x599;
    _mls_x595 = _mls_x597;
    goto _mls_append_case1_sr_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_append_case1_sr_post:
  {
    auto _mls_x600 = _mls_append(_mls_x593, _mls_x594);
    auto _mls_x601 = _mlsValue::create<_mls_Cons>(_mls_x595, _mls_x600);
    _mls_retval = _mls_x601;
    return _mls_retval;
  }
}
_mlsValue _mls_append_case1_sr_post(_mlsValue _mls_x593, _mlsValue _mls_x594, _mlsValue _mls_x595) {
  _mlsValue _mls_retval;
  auto _mls_x600 = _mls_append(_mls_x593, _mls_x594);
  auto _mls_x601 = _mlsValue::create<_mls_Cons>(_mls_x595, _mls_x600);
  _mls_retval = _mls_x601;
  return _mls_retval;
}
_mlsValue _mls_bodysurf(_mlsValue _mls_x604) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x602, _mls_x603;
  auto [_mls_x605, _mls_x606, _mls_x607] = _mls_bodysurf_pre(_mls_x604);
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x605)) {
    _mls_retval = _mls_x606;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x605)) {
    _mls_x602 = _mls_x605;
    _mls_x603 = _mls_x607;
    goto _mls_bodysurf_case1;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_bodysurf_case1:
  {
    auto _mls_x608 = _mlsValue::cast<_mls_Cons>(_mls_x602)->_mls_head;
    auto _mls_x609 = _mlsValue::cast<_mls_Cons>(_mls_x602)->_mls_tail;
    auto _mls_x610 = _mls_append_case1_sr_post(_mls_x609, _mls_x603, _mls_x608);
    auto _mls_x611 = _mlsValue::cast<_mls_Cons>(_mls_x610)->_mls_head;
    _mls_retval = _mls_x611;
    return _mls_retval;
  }
}
_mlsValue _mls_bodysurf_case1(_mlsValue _mls_x602, _mlsValue _mls_x603) {
  _mlsValue _mls_retval;
  auto _mls_x608 = _mlsValue::cast<_mls_Cons>(_mls_x602)->_mls_head;
  auto _mls_x609 = _mlsValue::cast<_mls_Cons>(_mls_x602)->_mls_tail;
  auto _mls_x610 = _mls_append_case1_sr_post(_mls_x609, _mls_x603, _mls_x608);
  auto _mls_x611 = _mlsValue::cast<_mls_Cons>(_mls_x610)->_mls_head;
  _mls_retval = _mls_x611;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_bodysurf_pre(_mlsValue _mls_x613) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x612 = _mlsValue::create<_mls_Lambda_lscomp2>();
  auto _mls_x614 = _mlsMethodCall<_mls_Callable>(_mls_x612)->_mls_apply1(_mls_x613);
  auto _mls_x615 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0));
  auto _mls_x616 = _mlsValue::create<_mls_Nil>();
  auto _mls_x617 = _mlsValue::create<_mls_Cons>(_mls_x615, _mls_x616);
  _mls_retval = std::make_tuple(_mls_x614, _mls_x615, _mls_x617);
  return _mls_retval;
}
_mlsValue _mls_camparams_caller_post_caller_post_caller_post(_mlsValue _mls_x636, _mlsValue _mls_x641, _mlsValue _mls_x645, _mlsValue _mls_x642, _mlsValue _mls_x643, _mlsValue _mls_x644) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x618, _mls_x619, _mls_x620, _mls_x621, _mls_x622, _mls_x623;
  _mlsValue _mls_x624, _mls_x625, _mls_x626, _mls_x627, _mls_x628, _mls_x629;
  _mlsValue _mls_x630, _mls_x631, _mls_x632, _mls_x633, _mls_x634, _mls_x635;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x636)) {
    auto _mls_x637 = _mlsValue::cast<_mls_Tuple3>(_mls_x636)->_mls_field0;
    auto _mls_x638 = _mlsValue::cast<_mls_Tuple3>(_mls_x636)->_mls_field1;
    auto _mls_x639 = _mlsValue::cast<_mls_Tuple3>(_mls_x636)->_mls_field2;
    auto _mls_x640 = _mls_vecnorm_case0_sr_post(_mls_x637, _mls_x638, _mls_x639);
    _mls_x618 = _mls_x640;
    _mls_x619 = _mls_x641;
    _mls_x620 = _mls_x642;
    _mls_x621 = _mls_x643;
    _mls_x622 = _mls_x644;
    _mls_x623 = _mls_x645;
    goto _mls_camparams_caller_post_caller_post_caller_post_caller_post_case0;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_camparams_caller_post_caller_post_caller_post_caller_post_case0:
  {
    auto _mls_x646 = _mlsValue::cast<_mls_Tuple2>(_mls_x618)->_mls_field0;
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x646)) {
      auto _mls_x647 = _mls_veccross_case0(_mls_x646, _mls_x621);
      _mls_x624 = _mls_x619;
      _mls_x625 = _mls_x646;
      _mls_x626 = _mls_x620;
      _mls_x627 = _mls_x647;
      _mls_x628 = _mls_x622;
      _mls_x629 = _mls_x623;
      goto _mls_camparams_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_camparams_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x627)) {
      auto _mls_x648 = _mls_vecnorm_case0(_mls_x627);
      _mls_x630 = _mls_x648;
      _mls_x631 = _mls_x629;
      _mls_x632 = _mls_x628;
      _mls_x633 = _mls_x626;
      _mls_x634 = _mls_x624;
      _mls_x635 = _mls_x625;
      goto _mls_camparams_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_camparams_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x630)) {
      auto _mls_x649 = _mlsValue::cast<_mls_Tuple2>(_mls_x630)->_mls_field0;
      auto _mls_x650 = (_mlsValue::create<_mls_Float>(2.0) * _mls_x631);
      auto _mls_x651 = (_mls_x633 / _mlsValue::create<_mls_Float>(2.0));
      auto _mls_x652 = _mls_dtor(_mls_x651);
      auto _mls_x653 = _mls_builtin_tan(_mls_x652);
      auto _mls_x654 = (_mls_x650 * _mls_x653);
      auto _mls_x655 = (_mls_x654 / _mls_x634);
      auto _mls_x656 = (_mlsValue::create<_mls_Float>(2.0) * _mls_x631);
      auto _mls_x657 = (_mls_x633 / _mlsValue::create<_mls_Float>(2.0));
      auto _mls_x658 = _mls_dtor(_mls_x657);
      auto _mls_x659 = _mls_builtin_tan(_mls_x658);
      auto _mls_x660 = (_mls_x656 * _mls_x659);
      auto _mls_x661 = (_mls_x660 / _mls_x634);
      auto _mls_x662 = _mls_vecscale(_mls_x635, _mls_x655);
      auto _mls_x663 = _mls_vecscale(_mls_x649, _mls_x661);
      auto _mls_x664 = (_mlsValue::create<_mls_Float>(0.5) * _mls_x634);
      auto _mls_x665 = _mls_vecscale(_mls_x662, _mls_x664);
      auto _mls_x666 = (_mlsValue::create<_mls_Float>(0.5) * _mls_x634);
      auto _mls_x667 = _mls_vecscale(_mls_x663, _mls_x666);
      auto _mls_x668 = _mls_vecadd(_mls_x665, _mls_x667);
      auto _mls_x669 = _mls_vecsub(_mls_x632, _mls_x668);
      auto _mls_x670 = _mlsValue::create<_mls_Tuple3>(_mls_x669, _mls_x662, _mls_x663);
      _mls_retval = _mls_x670;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_camparams_caller_post_caller_post_caller_post_caller_post_caller_post(_mlsValue _mls_x624, _mlsValue _mls_x625, _mlsValue _mls_x626, _mlsValue _mls_x627, _mlsValue _mls_x628, _mlsValue _mls_x629) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x630, _mls_x631, _mls_x632, _mls_x633, _mls_x634, _mls_x635;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x627)) {
    auto _mls_x648 = _mls_vecnorm_case0(_mls_x627);
    _mls_x630 = _mls_x648;
    _mls_x631 = _mls_x629;
    _mls_x632 = _mls_x628;
    _mls_x633 = _mls_x626;
    _mls_x634 = _mls_x624;
    _mls_x635 = _mls_x625;
    goto _mls_camparams_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_camparams_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x630)) {
      auto _mls_x649 = _mlsValue::cast<_mls_Tuple2>(_mls_x630)->_mls_field0;
      auto _mls_x650 = (_mlsValue::create<_mls_Float>(2.0) * _mls_x631);
      auto _mls_x651 = (_mls_x633 / _mlsValue::create<_mls_Float>(2.0));
      auto _mls_x652 = _mls_dtor(_mls_x651);
      auto _mls_x653 = _mls_builtin_tan(_mls_x652);
      auto _mls_x654 = (_mls_x650 * _mls_x653);
      auto _mls_x655 = (_mls_x654 / _mls_x634);
      auto _mls_x656 = (_mlsValue::create<_mls_Float>(2.0) * _mls_x631);
      auto _mls_x657 = (_mls_x633 / _mlsValue::create<_mls_Float>(2.0));
      auto _mls_x658 = _mls_dtor(_mls_x657);
      auto _mls_x659 = _mls_builtin_tan(_mls_x658);
      auto _mls_x660 = (_mls_x656 * _mls_x659);
      auto _mls_x661 = (_mls_x660 / _mls_x634);
      auto _mls_x662 = _mls_vecscale(_mls_x635, _mls_x655);
      auto _mls_x663 = _mls_vecscale(_mls_x649, _mls_x661);
      auto _mls_x664 = (_mlsValue::create<_mls_Float>(0.5) * _mls_x634);
      auto _mls_x665 = _mls_vecscale(_mls_x662, _mls_x664);
      auto _mls_x666 = (_mlsValue::create<_mls_Float>(0.5) * _mls_x634);
      auto _mls_x667 = _mls_vecscale(_mls_x663, _mls_x666);
      auto _mls_x668 = _mls_vecadd(_mls_x665, _mls_x667);
      auto _mls_x669 = _mls_vecsub(_mls_x632, _mls_x668);
      auto _mls_x670 = _mlsValue::create<_mls_Tuple3>(_mls_x669, _mls_x662, _mls_x663);
      _mls_retval = _mls_x670;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_camparams_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post(_mlsValue _mls_x630, _mlsValue _mls_x631, _mlsValue _mls_x632, _mlsValue _mls_x633, _mlsValue _mls_x634, _mlsValue _mls_x635) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x630)) {
    auto _mls_x649 = _mlsValue::cast<_mls_Tuple2>(_mls_x630)->_mls_field0;
    auto _mls_x650 = (_mlsValue::create<_mls_Float>(2.0) * _mls_x631);
    auto _mls_x651 = (_mls_x633 / _mlsValue::create<_mls_Float>(2.0));
    auto _mls_x652 = _mls_dtor(_mls_x651);
    auto _mls_x653 = _mls_builtin_tan(_mls_x652);
    auto _mls_x654 = (_mls_x650 * _mls_x653);
    auto _mls_x655 = (_mls_x654 / _mls_x634);
    auto _mls_x656 = (_mlsValue::create<_mls_Float>(2.0) * _mls_x631);
    auto _mls_x657 = (_mls_x633 / _mlsValue::create<_mls_Float>(2.0));
    auto _mls_x658 = _mls_dtor(_mls_x657);
    auto _mls_x659 = _mls_builtin_tan(_mls_x658);
    auto _mls_x660 = (_mls_x656 * _mls_x659);
    auto _mls_x661 = (_mls_x660 / _mls_x634);
    auto _mls_x662 = _mls_vecscale(_mls_x635, _mls_x655);
    auto _mls_x663 = _mls_vecscale(_mls_x649, _mls_x661);
    auto _mls_x664 = (_mlsValue::create<_mls_Float>(0.5) * _mls_x634);
    auto _mls_x665 = _mls_vecscale(_mls_x662, _mls_x664);
    auto _mls_x666 = (_mlsValue::create<_mls_Float>(0.5) * _mls_x634);
    auto _mls_x667 = _mls_vecscale(_mls_x663, _mls_x666);
    auto _mls_x668 = _mls_vecadd(_mls_x665, _mls_x667);
    auto _mls_x669 = _mls_vecsub(_mls_x632, _mls_x668);
    auto _mls_x670 = _mlsValue::create<_mls_Tuple3>(_mls_x669, _mls_x662, _mls_x663);
    _mls_retval = _mls_x670;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_camparams_caller_post_caller_post_caller_post_caller_post_case0(_mlsValue _mls_x618, _mlsValue _mls_x619, _mlsValue _mls_x620, _mlsValue _mls_x621, _mlsValue _mls_x622, _mlsValue _mls_x623) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x624, _mls_x625, _mls_x626, _mls_x627, _mls_x628, _mls_x629;
  _mlsValue _mls_x630, _mls_x631, _mls_x632, _mls_x633, _mls_x634, _mls_x635;
  auto _mls_x646 = _mlsValue::cast<_mls_Tuple2>(_mls_x618)->_mls_field0;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x646)) {
    auto _mls_x647 = _mls_veccross_case0(_mls_x646, _mls_x621);
    _mls_x624 = _mls_x619;
    _mls_x625 = _mls_x646;
    _mls_x626 = _mls_x620;
    _mls_x627 = _mls_x647;
    _mls_x628 = _mls_x622;
    _mls_x629 = _mls_x623;
    goto _mls_camparams_caller_post_caller_post_caller_post_caller_post_caller_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_camparams_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x627)) {
      auto _mls_x648 = _mls_vecnorm_case0(_mls_x627);
      _mls_x630 = _mls_x648;
      _mls_x631 = _mls_x629;
      _mls_x632 = _mls_x628;
      _mls_x633 = _mls_x626;
      _mls_x634 = _mls_x624;
      _mls_x635 = _mls_x625;
      goto _mls_camparams_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_camparams_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x630)) {
      auto _mls_x649 = _mlsValue::cast<_mls_Tuple2>(_mls_x630)->_mls_field0;
      auto _mls_x650 = (_mlsValue::create<_mls_Float>(2.0) * _mls_x631);
      auto _mls_x651 = (_mls_x633 / _mlsValue::create<_mls_Float>(2.0));
      auto _mls_x652 = _mls_dtor(_mls_x651);
      auto _mls_x653 = _mls_builtin_tan(_mls_x652);
      auto _mls_x654 = (_mls_x650 * _mls_x653);
      auto _mls_x655 = (_mls_x654 / _mls_x634);
      auto _mls_x656 = (_mlsValue::create<_mls_Float>(2.0) * _mls_x631);
      auto _mls_x657 = (_mls_x633 / _mlsValue::create<_mls_Float>(2.0));
      auto _mls_x658 = _mls_dtor(_mls_x657);
      auto _mls_x659 = _mls_builtin_tan(_mls_x658);
      auto _mls_x660 = (_mls_x656 * _mls_x659);
      auto _mls_x661 = (_mls_x660 / _mls_x634);
      auto _mls_x662 = _mls_vecscale(_mls_x635, _mls_x655);
      auto _mls_x663 = _mls_vecscale(_mls_x649, _mls_x661);
      auto _mls_x664 = (_mlsValue::create<_mls_Float>(0.5) * _mls_x634);
      auto _mls_x665 = _mls_vecscale(_mls_x662, _mls_x664);
      auto _mls_x666 = (_mlsValue::create<_mls_Float>(0.5) * _mls_x634);
      auto _mls_x667 = _mls_vecscale(_mls_x663, _mls_x666);
      auto _mls_x668 = _mls_vecadd(_mls_x665, _mls_x667);
      auto _mls_x669 = _mls_vecsub(_mls_x632, _mls_x668);
      auto _mls_x670 = _mlsValue::create<_mls_Tuple3>(_mls_x669, _mls_x662, _mls_x663);
      _mls_retval = _mls_x670;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_camparams_caller_post_caller_post_case0_sr_post(_mlsValue _mls_x683, _mlsValue _mls_x671, _mlsValue _mls_x675, _mlsValue _mls_x681, _mlsValue _mls_x680, _mlsValue _mls_x682) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x636, _mls_x641, _mls_x645, _mls_x642, _mls_x643, _mls_x644;
  _mlsValue _mls_x618, _mls_x619, _mls_x620, _mls_x621, _mls_x622, _mls_x623;
  _mlsValue _mls_x624, _mls_x625, _mls_x626, _mls_x627, _mls_x628, _mls_x629;
  _mlsValue _mls_x630, _mls_x631, _mls_x632, _mls_x633, _mls_x634, _mls_x635;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x671)) {
    auto _mls_x672 = _mlsValue::cast<_mls_Tuple3>(_mls_x671)->_mls_field0;
    auto _mls_x673 = _mlsValue::cast<_mls_Tuple3>(_mls_x671)->_mls_field1;
    auto _mls_x674 = _mlsValue::cast<_mls_Tuple3>(_mls_x671)->_mls_field2;
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x675)) {
      auto _mls_x676 = _mlsValue::cast<_mls_Tuple3>(_mls_x675)->_mls_field0;
      auto _mls_x677 = _mlsValue::cast<_mls_Tuple3>(_mls_x675)->_mls_field1;
      auto _mls_x678 = _mlsValue::cast<_mls_Tuple3>(_mls_x675)->_mls_field2;
      auto _mls_x679 = _mls_veccross_case0_sr_post_case0_sr_post(_mls_x673, _mls_x672, _mls_x674, _mls_x678, _mls_x676, _mls_x677);
      _mls_x636 = _mls_x679;
      _mls_x641 = _mls_x680;
      _mls_x645 = _mls_x681;
      _mls_x642 = _mls_x682;
      _mls_x643 = _mls_x671;
      _mls_x644 = _mls_x683;
      goto _mls_camparams_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_camparams_caller_post_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x636)) {
      auto _mls_x637 = _mlsValue::cast<_mls_Tuple3>(_mls_x636)->_mls_field0;
      auto _mls_x638 = _mlsValue::cast<_mls_Tuple3>(_mls_x636)->_mls_field1;
      auto _mls_x639 = _mlsValue::cast<_mls_Tuple3>(_mls_x636)->_mls_field2;
      auto _mls_x640 = _mls_vecnorm_case0_sr_post(_mls_x637, _mls_x638, _mls_x639);
      _mls_x618 = _mls_x640;
      _mls_x619 = _mls_x641;
      _mls_x620 = _mls_x642;
      _mls_x621 = _mls_x643;
      _mls_x622 = _mls_x644;
      _mls_x623 = _mls_x645;
      goto _mls_camparams_caller_post_caller_post_caller_post_caller_post_case0;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_camparams_caller_post_caller_post_caller_post_caller_post_case0:
  {
    auto _mls_x646 = _mlsValue::cast<_mls_Tuple2>(_mls_x618)->_mls_field0;
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x646)) {
      auto _mls_x647 = _mls_veccross_case0(_mls_x646, _mls_x621);
      _mls_x624 = _mls_x619;
      _mls_x625 = _mls_x646;
      _mls_x626 = _mls_x620;
      _mls_x627 = _mls_x647;
      _mls_x628 = _mls_x622;
      _mls_x629 = _mls_x623;
      goto _mls_camparams_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_camparams_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x627)) {
      auto _mls_x648 = _mls_vecnorm_case0(_mls_x627);
      _mls_x630 = _mls_x648;
      _mls_x631 = _mls_x629;
      _mls_x632 = _mls_x628;
      _mls_x633 = _mls_x626;
      _mls_x634 = _mls_x624;
      _mls_x635 = _mls_x625;
      goto _mls_camparams_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_camparams_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x630)) {
      auto _mls_x649 = _mlsValue::cast<_mls_Tuple2>(_mls_x630)->_mls_field0;
      auto _mls_x650 = (_mlsValue::create<_mls_Float>(2.0) * _mls_x631);
      auto _mls_x651 = (_mls_x633 / _mlsValue::create<_mls_Float>(2.0));
      auto _mls_x652 = _mls_dtor(_mls_x651);
      auto _mls_x653 = _mls_builtin_tan(_mls_x652);
      auto _mls_x654 = (_mls_x650 * _mls_x653);
      auto _mls_x655 = (_mls_x654 / _mls_x634);
      auto _mls_x656 = (_mlsValue::create<_mls_Float>(2.0) * _mls_x631);
      auto _mls_x657 = (_mls_x633 / _mlsValue::create<_mls_Float>(2.0));
      auto _mls_x658 = _mls_dtor(_mls_x657);
      auto _mls_x659 = _mls_builtin_tan(_mls_x658);
      auto _mls_x660 = (_mls_x656 * _mls_x659);
      auto _mls_x661 = (_mls_x660 / _mls_x634);
      auto _mls_x662 = _mls_vecscale(_mls_x635, _mls_x655);
      auto _mls_x663 = _mls_vecscale(_mls_x649, _mls_x661);
      auto _mls_x664 = (_mlsValue::create<_mls_Float>(0.5) * _mls_x634);
      auto _mls_x665 = _mls_vecscale(_mls_x662, _mls_x664);
      auto _mls_x666 = (_mlsValue::create<_mls_Float>(0.5) * _mls_x634);
      auto _mls_x667 = _mls_vecscale(_mls_x663, _mls_x666);
      auto _mls_x668 = _mls_vecadd(_mls_x665, _mls_x667);
      auto _mls_x669 = _mls_vecsub(_mls_x632, _mls_x668);
      auto _mls_x670 = _mlsValue::create<_mls_Tuple3>(_mls_x669, _mls_x662, _mls_x663);
      _mls_retval = _mls_x670;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_camparams_caller_post_case0_pre(_mlsValue _mls_x685, _mlsValue _mls_x690, _mlsValue _mls_x689, _mlsValue _mls_x691) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x684 = _mlsValue::cast<_mls_Tuple3>(_mls_x685)->_mls_field0;
  auto _mls_x686 = _mlsValue::cast<_mls_Tuple3>(_mls_x685)->_mls_field1;
  auto _mls_x687 = _mlsValue::cast<_mls_Tuple3>(_mls_x685)->_mls_field2;
  auto _mls_x688 = _mls_vecnorm_case0_sr_post(_mls_x684, _mls_x686, _mls_x687);
  _mls_retval = std::make_tuple(_mls_x689, _mls_x685, _mls_x690, _mls_x688, _mls_x691);
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_camparams_case0_case0_pre(_mlsValue _mls_x695, _mlsValue _mls_x698, _mlsValue _mls_x699, _mlsValue _mls_x694, _mlsValue _mls_x693, _mlsValue _mls_x692, _mlsValue _mls_x697) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x696 = _mls_vecsub_case0_case0(_mls_x692, _mls_x693, _mls_x694, _mls_x695);
  auto [_mls_x700, _mls_x701, _mls_x702, _mls_x703, _mls_x704] = _mls_camparams_caller_post_case0_pre(_mls_x696, _mls_x697, _mls_x698, _mls_x699);
  _mls_retval = std::make_tuple(_mls_x702, _mls_x704, _mls_x703, _mls_x700, _mls_x701);
  return _mls_retval;
}
_mlsValue _mls_diffusesurf_case1_sr_post(_mlsValue _mls_x705, _mlsValue _mls_x706, _mlsValue _mls_x707) {
  _mlsValue _mls_retval;
  auto _mls_x708 = _mls_append_case1_sr_post(_mls_x705, _mls_x706, _mls_x707);
  auto _mls_x709 = _mlsValue::cast<_mls_Cons>(_mls_x708)->_mls_head;
  _mls_retval = _mls_x709;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_diffusesurf_pre(_mlsValue _mls_x711) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x710 = _mlsValue::create<_mls_Lambda_lscomp3>();
  auto _mls_x712 = _mlsMethodCall<_mls_Callable>(_mls_x710)->_mls_apply1(_mls_x711);
  auto _mls_x713 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
  auto _mls_x714 = _mlsValue::create<_mls_Nil>();
  auto _mls_x715 = _mlsValue::create<_mls_Cons>(_mls_x713, _mls_x714);
  _mls_retval = std::make_tuple(_mls_x712, _mls_x713, _mls_x715);
  return _mls_retval;
}
_mlsValue _mls_dtor(_mlsValue _mls_x152) {
  _mlsValue _mls_retval;
  auto _mls_x151 = (_mls_x152 * _mlsValue::create<_mls_Float>(3.141592653589793));
  auto _mls_x153 = (_mls_x151 / _mlsValue::create<_mls_Float>(180.0));
  _mls_retval = _mls_x153;
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x716 = _mls_repeatRun(_mlsValue::create<_mls_Float>(30.0), _mlsValue::fromIntLit(50));
  _mls_retval = _mls_x716;
  return _mls_retval;
}
_mlsValue _mls_enumFromTo(_mlsValue _mls_a, _mlsValue _mls_b) {
  _mlsValue _mls_retval;
  auto _mls_x155 = (_mls_a <= _mls_b);
  if (_mlsValue::isIntLit(_mls_x155, 1)) {
    auto _mls_x157 = (_mls_a + _mlsValue::create<_mls_Float>(1.0));
    auto _mls_x158 = _mls_enumFromTo(_mls_x157, _mls_b);
    auto _mls_x159 = _mlsValue::create<_mls_Cons>(_mls_a, _mls_x158);
    _mls_retval = _mls_x159;
  } else {
    auto _mls_x156 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x156;
  }
  return _mls_retval;
}
_mlsValue _mls_foldr(_mlsValue _mls_f, _mlsValue _mls_z, _mlsValue _mls_xs1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs1)) {
    _mls_retval = _mls_z;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs1)) {
    auto _mls_x160 = _mlsValue::cast<_mls_Cons>(_mls_xs1)->_mls_head;
    auto _mls_x161 = _mlsValue::cast<_mls_Cons>(_mls_xs1)->_mls_tail;
    auto _mls_x162 = _mls_foldr(_mls_f, _mls_z, _mls_x161);
    auto _mls_x163 = _mlsMethodCall<_mls_Callable>(_mls_f)->_mls_apply2(_mls_x160, _mls_x162);
    _mls_retval = _mls_x163;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_head1(_mlsValue _mls_x717) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x717)) {
    auto _mls_x718 = _mlsValue::cast<_mls_Cons>(_mls_x717)->_mls_head;
    _mls_retval = _mls_x718;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_is_zerovector(_mlsValue _mls_x167) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x167)) {
    auto _mls_x168 = _mlsValue::cast<_mls_Tuple3>(_mls_x167)->_mls_field0;
    auto _mls_x169 = _mlsValue::cast<_mls_Tuple3>(_mls_x167)->_mls_field1;
    auto _mls_x170 = _mlsValue::cast<_mls_Tuple3>(_mls_x167)->_mls_field2;
    auto _mls_x171 = (_mls_x168 < _mlsValue::create<_mls_Float>(1.0E-6));
    auto _mls_x172 = (_mls_x169 < _mlsValue::create<_mls_Float>(1.0E-6));
    auto _mls_x173 = (_mls_x171 && _mls_x172);
    auto _mls_x174 = (_mls_x170 < _mlsValue::create<_mls_Float>(1.0E-6));
    auto _mls_x175 = (_mls_x173 && _mls_x174);
    _mls_retval = _mls_x175;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_j1(_mlsValue _mls_x727, _mlsValue _mls_x730, _mlsValue _mls_x731, _mlsValue _mls_x729) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x719, _mls_x720, _mls_x721;
  _mlsValue _mls_x722, _mls_x723, _mls_x724, _mls_x725, _mls_x726;
  auto _mls_x728 = _mls_is_zerovector(_mls_x727);
  if (_mlsValue::isIntLit(_mls_x728, 1)) {
    _mls_retval = _mls_x731;
  } else {
    _mls_x719 = _mls_x729;
    _mls_x720 = _mls_x730;
    _mls_x721 = _mls_x731;
    goto _mls_j_default;
  }
  return _mls_retval;
  _mls_j_default:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x719)) {
      auto _mls_x732 = _mlsValue::cast<_mls_Tuple3>(_mls_x719)->_mls_field0;
      auto _mls_x733 = _mlsValue::cast<_mls_Tuple3>(_mls_x719)->_mls_field1;
      auto _mls_x734 = _mlsValue::cast<_mls_Tuple3>(_mls_x719)->_mls_field2;
      _mls_x722 = _mls_x720;
      _mls_x723 = _mls_x721;
      _mls_x724 = _mls_x732;
      _mls_x725 = _mls_x733;
      _mls_x726 = _mls_x734;
      goto _mls_j_default_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_default_case0_sr_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x722)) {
      auto _mls_x735 = _mlsValue::cast<_mls_Tuple3>(_mls_x722)->_mls_field0;
      auto _mls_x736 = _mlsValue::cast<_mls_Tuple3>(_mls_x722)->_mls_field1;
      auto _mls_x737 = _mlsValue::cast<_mls_Tuple3>(_mls_x722)->_mls_field2;
      auto _mls_x738 = _mls_vecmult_case0_sr_post_case0_sr_post(_mls_x737, _mls_x725, _mls_x736, _mls_x726, _mls_x724, _mls_x735);
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x723)) {
        auto _mls_x739 = _mls_vecadd_case0(_mls_x723, _mls_x738);
        _mls_retval = _mls_x739;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_j2(_mlsValue _mls_x745, _mlsValue _mls_x747, _mlsValue _mls_x748, _mlsValue _mls_x749) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x740;
  _mlsValue _mls_x741, _mls_x742, _mls_x743;
  _mlsValue _mls_x744;
  auto _mls_x746 = _mls_is_zerovector(_mls_x745);
  if (_mlsValue::isIntLit(_mls_x746, 1)) {
    _mls_x740 = _mls_x749;
    goto _mls_j_case0;
  } else {
    _mls_x741 = _mls_x747;
    _mls_x742 = _mls_x748;
    _mls_x743 = _mls_x749;
    goto _mls_j_default1;
  }
  return _mls_retval;
  _mls_j_case0:
  {
    auto _mls_x750 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x740);
    _mls_retval = _mls_x750;
    return _mls_retval;
  }
  _mls_j_default1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x741)) {
      auto _mls_x751 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field0;
      auto _mls_x752 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field1;
      auto _mls_x753 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field2;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x742)) {
        auto _mls_x754 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field0;
        auto _mls_x755 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field1;
        auto _mls_x756 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field2;
        auto _mls_x757 = _mls_vecmult_case0_sr_post_case0_sr_post(_mls_x756, _mls_x752, _mls_x755, _mls_x753, _mls_x751, _mls_x754);
        auto _mls_x758 = _mls_vecadd_case0(_mls_x757, _mls_x743);
        _mls_x744 = _mls_x758;
        goto _mls_j_caller_post_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post_post:
  {
    auto _mls_x759 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x744);
    _mls_retval = _mls_x759;
    return _mls_retval;
  }
}
_mlsValue _mls_j4(_mlsValue _mls_refl1, _mlsValue _mls_hitpos1, _mlsValue _mls_tmp3, _mlsValue _mls_surf, _mlsValue _mls_trintensity, _mlsValue _mls_contrib1, _mlsValue _mls_lights1) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x760, _mls_x761, _mls_x762, _mls_x763, _mls_x764, _mls_x765, _mls_x766, _mls_x767, _mls_x768;
  _mlsValue _mls_x769, _mls_x770, _mls_x771, _mls_x772, _mls_x773, _mls_x774, _mls_x775, _mls_x776, _mls_x777, _mls_x778, _mls_x779;
  _mlsValue _mls_refl, _mls_hitpos, _mls_trcol, _mls_tmp2, _mls_contrib, _mls_lights;
  _mlsValue _mls_x780, _mls_x781, _mls_x782, _mls_x783, _mls_x784, _mls_x785, _mls_x786;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_tmp3)) {
    auto _mls_x184 = _mlsValue::cast<_mls_Tuple2>(_mls_tmp3)->_mls_field0;
    auto _mls_x185 = _mlsValue::cast<_mls_Tuple2>(_mls_tmp3)->_mls_field1;
    auto [_mls_x787, _mls_x788, _mls_x789] = _mls_specularsurf_pre(_mls_surf);
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x787)) {
      auto _mls_x793 = _mls_reflectsurf(_mls_surf);
      auto _mls_x794 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field0;
      auto _mls_x795 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field1;
      auto _mls_x796 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field2;
      _mls_x769 = _mls_refl1;
      _mls_x770 = _mls_x184;
      _mls_x771 = _mls_x796;
      _mls_x772 = _mls_hitpos1;
      _mls_x773 = _mls_x185;
      _mls_x774 = _mls_x795;
      _mls_x775 = _mls_lights1;
      _mls_x776 = _mls_trintensity;
      _mls_x777 = _mls_contrib1;
      _mls_x778 = _mls_x794;
      _mls_x779 = _mls_x793;
      goto _mls_j_caller_post_case0_sr_post;
    } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x787)) {
      auto _mls_x790 = _mlsValue::cast<_mls_Cons>(_mls_x787)->_mls_head;
      auto _mls_x791 = _mlsValue::cast<_mls_Cons>(_mls_x787)->_mls_tail;
      auto _mls_x792 = _mls_specularsurf_case1_sr_post(_mls_x791, _mls_x789, _mls_x790);
      _mls_x760 = _mls_trintensity;
      _mls_x761 = _mls_refl1;
      _mls_x762 = _mls_lights1;
      _mls_x763 = _mls_surf;
      _mls_x764 = _mls_x185;
      _mls_x765 = _mls_x184;
      _mls_x766 = _mls_x792;
      _mls_x767 = _mls_hitpos1;
      _mls_x768 = _mls_contrib1;
      goto _mls_j_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_j_caller_post:
  {
    auto _mls_x797 = _mls_reflectsurf(_mls_x763);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x766)) {
      auto _mls_x798 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field0;
      auto _mls_x799 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field1;
      auto _mls_x800 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field2;
      _mls_x769 = _mls_x761;
      _mls_x770 = _mls_x765;
      _mls_x771 = _mls_x800;
      _mls_x772 = _mls_x767;
      _mls_x773 = _mls_x764;
      _mls_x774 = _mls_x799;
      _mls_x775 = _mls_x762;
      _mls_x776 = _mls_x760;
      _mls_x777 = _mls_x768;
      _mls_x778 = _mls_x798;
      _mls_x779 = _mls_x797;
      goto _mls_j_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post_case0_sr_post:
  {
    auto _mls_x801 = _mls_vecscale_case0_sr_post(_mls_x779, _mls_x778, _mls_x774, _mls_x771);
    if (_mlsValue::isIntLit(_mls_x770, 1)) {
      _mls_x780 = _mls_x772;
      _mls_x781 = _mls_x775;
      _mls_x782 = _mls_x769;
      _mls_x783 = _mls_x777;
      _mls_x784 = _mls_x801;
      _mls_x785 = _mls_x773;
      _mls_x786 = _mls_x776;
      goto _mls_j_caller_post_case0;
    } else {
      _mls_refl = _mls_x769;
      _mls_hitpos = _mls_x772;
      _mls_trcol = _mls_x773;
      _mls_tmp2 = _mls_x801;
      _mls_contrib = _mls_x777;
      _mls_lights = _mls_x775;
      goto _mls_j3;
    }
    return _mls_retval;
  }
  _mls_j3:
  {
    auto _mls_x190 = _mls_is_zerovector(_mls_tmp2);
    if (_mlsValue::isIntLit(_mls_x190, 1)) {
      _mls_retval = _mls_trcol;
    } else {
      auto _mls_x191 = _mls_reflectray(_mls_hitpos, _mls_refl, _mls_lights, _mls_tmp2, _mls_contrib, _mls_trcol);
      _mls_retval = _mls_x191;
    }
    return _mls_retval;
  }
  _mls_j_caller_post_case0:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x786)) {
      auto _mls_x802 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field0;
      auto _mls_x803 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field1;
      auto _mls_x804 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field2;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x784)) {
        auto _mls_x805 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field0;
        auto _mls_x806 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field1;
        auto _mls_x807 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field2;
        auto _mls_x808 = _mls_vecadd_case0_sr_post_case0_sr_post(_mls_x802, _mls_x804, _mls_x805, _mls_x807, _mls_x803, _mls_x806);
        _mls_refl = _mls_x782;
        _mls_hitpos = _mls_x780;
        _mls_trcol = _mls_x785;
        _mls_tmp2 = _mls_x808;
        _mls_contrib = _mls_x783;
        _mls_lights = _mls_x781;
        goto _mls_j3;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_j3(_mlsValue _mls_refl, _mlsValue _mls_hitpos, _mlsValue _mls_trcol, _mlsValue _mls_tmp2, _mlsValue _mls_contrib, _mlsValue _mls_lights) {
  _mlsValue _mls_retval;
  auto _mls_x190 = _mls_is_zerovector(_mls_tmp2);
  if (_mlsValue::isIntLit(_mls_x190, 1)) {
    _mls_retval = _mls_trcol;
  } else {
    auto _mls_x191 = _mls_reflectray(_mls_hitpos, _mls_refl, _mls_lights, _mls_tmp2, _mls_contrib, _mls_trcol);
    _mls_retval = _mls_x191;
  }
  return _mls_retval;
}
_mlsValue _mls_j_caller_post(_mlsValue _mls_x760, _mlsValue _mls_x761, _mlsValue _mls_x762, _mlsValue _mls_x763, _mlsValue _mls_x764, _mlsValue _mls_x765, _mlsValue _mls_x766, _mlsValue _mls_x767, _mlsValue _mls_x768) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x769, _mls_x770, _mls_x771, _mls_x772, _mls_x773, _mls_x774, _mls_x775, _mls_x776, _mls_x777, _mls_x778, _mls_x779;
  _mlsValue _mls_refl, _mls_hitpos, _mls_trcol, _mls_tmp2, _mls_contrib, _mls_lights;
  _mlsValue _mls_x780, _mls_x781, _mls_x782, _mls_x783, _mls_x784, _mls_x785, _mls_x786;
  auto _mls_x797 = _mls_reflectsurf(_mls_x763);
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x766)) {
    auto _mls_x798 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field0;
    auto _mls_x799 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field1;
    auto _mls_x800 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field2;
    _mls_x769 = _mls_x761;
    _mls_x770 = _mls_x765;
    _mls_x771 = _mls_x800;
    _mls_x772 = _mls_x767;
    _mls_x773 = _mls_x764;
    _mls_x774 = _mls_x799;
    _mls_x775 = _mls_x762;
    _mls_x776 = _mls_x760;
    _mls_x777 = _mls_x768;
    _mls_x778 = _mls_x798;
    _mls_x779 = _mls_x797;
    goto _mls_j_caller_post_case0_sr_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_j_caller_post_case0_sr_post:
  {
    auto _mls_x801 = _mls_vecscale_case0_sr_post(_mls_x779, _mls_x778, _mls_x774, _mls_x771);
    if (_mlsValue::isIntLit(_mls_x770, 1)) {
      _mls_x780 = _mls_x772;
      _mls_x781 = _mls_x775;
      _mls_x782 = _mls_x769;
      _mls_x783 = _mls_x777;
      _mls_x784 = _mls_x801;
      _mls_x785 = _mls_x773;
      _mls_x786 = _mls_x776;
      goto _mls_j_caller_post_case0;
    } else {
      _mls_refl = _mls_x769;
      _mls_hitpos = _mls_x772;
      _mls_trcol = _mls_x773;
      _mls_tmp2 = _mls_x801;
      _mls_contrib = _mls_x777;
      _mls_lights = _mls_x775;
      goto _mls_j3;
    }
    return _mls_retval;
  }
  _mls_j3:
  {
    auto _mls_x190 = _mls_is_zerovector(_mls_tmp2);
    if (_mlsValue::isIntLit(_mls_x190, 1)) {
      _mls_retval = _mls_trcol;
    } else {
      auto _mls_x191 = _mls_reflectray(_mls_hitpos, _mls_refl, _mls_lights, _mls_tmp2, _mls_contrib, _mls_trcol);
      _mls_retval = _mls_x191;
    }
    return _mls_retval;
  }
  _mls_j_caller_post_case0:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x786)) {
      auto _mls_x802 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field0;
      auto _mls_x803 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field1;
      auto _mls_x804 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field2;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x784)) {
        auto _mls_x805 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field0;
        auto _mls_x806 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field1;
        auto _mls_x807 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field2;
        auto _mls_x808 = _mls_vecadd_case0_sr_post_case0_sr_post(_mls_x802, _mls_x804, _mls_x805, _mls_x807, _mls_x803, _mls_x806);
        _mls_refl = _mls_x782;
        _mls_hitpos = _mls_x780;
        _mls_trcol = _mls_x785;
        _mls_tmp2 = _mls_x808;
        _mls_contrib = _mls_x783;
        _mls_lights = _mls_x781;
        goto _mls_j3;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_j_caller_post_case0(_mlsValue _mls_x780, _mlsValue _mls_x781, _mlsValue _mls_x782, _mlsValue _mls_x783, _mlsValue _mls_x784, _mlsValue _mls_x785, _mlsValue _mls_x786) {
  _mlsValue _mls_retval;
  _mlsValue _mls_refl, _mls_hitpos, _mls_trcol, _mls_tmp2, _mls_contrib, _mls_lights;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x786)) {
    auto _mls_x802 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field0;
    auto _mls_x803 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field1;
    auto _mls_x804 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field2;
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x784)) {
      auto _mls_x805 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field0;
      auto _mls_x806 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field1;
      auto _mls_x807 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field2;
      auto _mls_x808 = _mls_vecadd_case0_sr_post_case0_sr_post(_mls_x802, _mls_x804, _mls_x805, _mls_x807, _mls_x803, _mls_x806);
      _mls_refl = _mls_x782;
      _mls_hitpos = _mls_x780;
      _mls_trcol = _mls_x785;
      _mls_tmp2 = _mls_x808;
      _mls_contrib = _mls_x783;
      _mls_lights = _mls_x781;
      goto _mls_j3;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_j3:
  {
    auto _mls_x190 = _mls_is_zerovector(_mls_tmp2);
    if (_mlsValue::isIntLit(_mls_x190, 1)) {
      _mls_retval = _mls_trcol;
    } else {
      auto _mls_x191 = _mls_reflectray(_mls_hitpos, _mls_refl, _mls_lights, _mls_tmp2, _mls_contrib, _mls_trcol);
      _mls_retval = _mls_x191;
    }
    return _mls_retval;
  }
}
_mlsValue _mls_j_caller_post_case0_sr_post(_mlsValue _mls_x769, _mlsValue _mls_x770, _mlsValue _mls_x771, _mlsValue _mls_x772, _mlsValue _mls_x773, _mlsValue _mls_x774, _mlsValue _mls_x775, _mlsValue _mls_x776, _mlsValue _mls_x777, _mlsValue _mls_x778, _mlsValue _mls_x779) {
  _mlsValue _mls_retval;
  _mlsValue _mls_refl, _mls_hitpos, _mls_trcol, _mls_tmp2, _mls_contrib, _mls_lights;
  _mlsValue _mls_x780, _mls_x781, _mls_x782, _mls_x783, _mls_x784, _mls_x785, _mls_x786;
  auto _mls_x801 = _mls_vecscale_case0_sr_post(_mls_x779, _mls_x778, _mls_x774, _mls_x771);
  if (_mlsValue::isIntLit(_mls_x770, 1)) {
    _mls_x780 = _mls_x772;
    _mls_x781 = _mls_x775;
    _mls_x782 = _mls_x769;
    _mls_x783 = _mls_x777;
    _mls_x784 = _mls_x801;
    _mls_x785 = _mls_x773;
    _mls_x786 = _mls_x776;
    goto _mls_j_caller_post_case0;
  } else {
    _mls_refl = _mls_x769;
    _mls_hitpos = _mls_x772;
    _mls_trcol = _mls_x773;
    _mls_tmp2 = _mls_x801;
    _mls_contrib = _mls_x777;
    _mls_lights = _mls_x775;
    goto _mls_j3;
  }
  return _mls_retval;
  _mls_j3:
  {
    auto _mls_x190 = _mls_is_zerovector(_mls_tmp2);
    if (_mlsValue::isIntLit(_mls_x190, 1)) {
      _mls_retval = _mls_trcol;
    } else {
      auto _mls_x191 = _mls_reflectray(_mls_hitpos, _mls_refl, _mls_lights, _mls_tmp2, _mls_contrib, _mls_trcol);
      _mls_retval = _mls_x191;
    }
    return _mls_retval;
  }
  _mls_j_caller_post_case0:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x786)) {
      auto _mls_x802 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field0;
      auto _mls_x803 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field1;
      auto _mls_x804 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field2;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x784)) {
        auto _mls_x805 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field0;
        auto _mls_x806 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field1;
        auto _mls_x807 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field2;
        auto _mls_x808 = _mls_vecadd_case0_sr_post_case0_sr_post(_mls_x802, _mls_x804, _mls_x805, _mls_x807, _mls_x803, _mls_x806);
        _mls_refl = _mls_x782;
        _mls_hitpos = _mls_x780;
        _mls_trcol = _mls_x785;
        _mls_tmp2 = _mls_x808;
        _mls_contrib = _mls_x783;
        _mls_lights = _mls_x781;
        goto _mls_j3;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_j_caller_post_post1(_mlsValue _mls_x810) {
  _mlsValue _mls_retval;
  auto _mls_x809 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x810);
  _mls_retval = _mls_x809;
  return _mls_retval;
}
_mlsValue _mls_j_caller_post_post(_mlsValue _mls_x744) {
  _mlsValue _mls_retval;
  auto _mls_x759 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x744);
  _mls_retval = _mls_x759;
  return _mls_retval;
}
_mlsValue _mls_j_case0(_mlsValue _mls_x740) {
  _mlsValue _mls_retval;
  auto _mls_x750 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x740);
  _mls_retval = _mls_x750;
  return _mls_retval;
}
_mlsValue _mls_j_case0_sr_post(_mlsValue _mls_x818, _mlsValue _mls_x819, _mlsValue _mls_x820, _mlsValue _mls_x821) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x811, _mls_x812, _mls_x813, _mls_x814;
  _mlsValue _mls_x815, _mls_x816, _mls_x817;
  _mlsValue _mls_x810;
  auto [_mls_x822, _mls_x823, _mls_x824, _mls_x825, _mls_x826] = _mls_j_case0_sr_post_pre(_mls_x818, _mls_x819, _mls_x820, _mls_x821);
  if (_mlsValue::isIntLit(_mls_x824, 1)) {
    goto _mls_j_case0_sr_post_case0;
  } else {
    _mls_x811 = _mls_x826;
    _mls_x812 = _mls_x825;
    _mls_x813 = _mls_x823;
    _mls_x814 = _mls_x822;
    goto _mls_j_case0_sr_post_default;
  }
  return _mls_retval;
  _mls_j_case0_sr_post_case0:
  {
    auto _mls_x827 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
    auto _mls_x828 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(1), _mls_x827);
    _mls_retval = _mls_x828;
    return _mls_retval;
  }
  _mls_j_case0_sr_post_default:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x811)) {
      auto _mls_x829 = _mlsValue::cast<_mls_Tuple3>(_mls_x811)->_mls_field0;
      auto _mls_x830 = _mlsValue::cast<_mls_Tuple3>(_mls_x811)->_mls_field1;
      auto _mls_x831 = _mlsValue::cast<_mls_Tuple3>(_mls_x811)->_mls_field2;
      auto _mls_x832 = _mls_vecscale_case0_sr_post(_mls_x812, _mls_x829, _mls_x830, _mls_x831);
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x813)) {
        _mls_x815 = _mls_x813;
        _mls_x816 = _mls_x814;
        _mls_x817 = _mls_x832;
        goto _mls_j_case0_sr_post_caller_post_case0;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_case0_sr_post_caller_post_case0:
  {
    auto _mls_x833 = _mlsValue::cast<_mls_Tuple3>(_mls_x815)->_mls_field0;
    auto _mls_x834 = _mlsValue::cast<_mls_Tuple3>(_mls_x815)->_mls_field1;
    auto _mls_x835 = _mlsValue::cast<_mls_Tuple3>(_mls_x815)->_mls_field2;
    auto _mls_x836 = _mls_vecscale_case0_sr_post(_mls_x816, _mls_x833, _mls_x834, _mls_x835);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x817)) {
      auto _mls_x837 = _mlsValue::cast<_mls_Tuple3>(_mls_x817)->_mls_field0;
      auto _mls_x838 = _mlsValue::cast<_mls_Tuple3>(_mls_x817)->_mls_field1;
      auto _mls_x839 = _mlsValue::cast<_mls_Tuple3>(_mls_x817)->_mls_field2;
      auto _mls_x840 = _mls_vecadd_case0_sr_post(_mls_x836, _mls_x837, _mls_x838, _mls_x839);
      _mls_x810 = _mls_x840;
      goto _mls_j_caller_post_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post_post1:
  {
    auto _mls_x809 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x810);
    _mls_retval = _mls_x809;
    return _mls_retval;
  }
}
_mlsValue _mls_j_case0_sr_post_caller_post_case0(_mlsValue _mls_x815, _mlsValue _mls_x816, _mlsValue _mls_x817) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x810;
  auto _mls_x833 = _mlsValue::cast<_mls_Tuple3>(_mls_x815)->_mls_field0;
  auto _mls_x834 = _mlsValue::cast<_mls_Tuple3>(_mls_x815)->_mls_field1;
  auto _mls_x835 = _mlsValue::cast<_mls_Tuple3>(_mls_x815)->_mls_field2;
  auto _mls_x836 = _mls_vecscale_case0_sr_post(_mls_x816, _mls_x833, _mls_x834, _mls_x835);
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x817)) {
    auto _mls_x837 = _mlsValue::cast<_mls_Tuple3>(_mls_x817)->_mls_field0;
    auto _mls_x838 = _mlsValue::cast<_mls_Tuple3>(_mls_x817)->_mls_field1;
    auto _mls_x839 = _mlsValue::cast<_mls_Tuple3>(_mls_x817)->_mls_field2;
    auto _mls_x840 = _mls_vecadd_case0_sr_post(_mls_x836, _mls_x837, _mls_x838, _mls_x839);
    _mls_x810 = _mls_x840;
    goto _mls_j_caller_post_post1;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_j_caller_post_post1:
  {
    auto _mls_x809 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x810);
    _mls_retval = _mls_x809;
    return _mls_retval;
  }
}
_mlsValue _mls_j_case0_sr_post_case0() {
  _mlsValue _mls_retval;
  auto _mls_x827 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
  auto _mls_x828 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(1), _mls_x827);
  _mls_retval = _mls_x828;
  return _mls_retval;
}
_mlsValue _mls_j_case0_sr_post_default(_mlsValue _mls_x811, _mlsValue _mls_x812, _mlsValue _mls_x813, _mlsValue _mls_x814) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x815, _mls_x816, _mls_x817;
  _mlsValue _mls_x810;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x811)) {
    auto _mls_x829 = _mlsValue::cast<_mls_Tuple3>(_mls_x811)->_mls_field0;
    auto _mls_x830 = _mlsValue::cast<_mls_Tuple3>(_mls_x811)->_mls_field1;
    auto _mls_x831 = _mlsValue::cast<_mls_Tuple3>(_mls_x811)->_mls_field2;
    auto _mls_x832 = _mls_vecscale_case0_sr_post(_mls_x812, _mls_x829, _mls_x830, _mls_x831);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x813)) {
      _mls_x815 = _mls_x813;
      _mls_x816 = _mls_x814;
      _mls_x817 = _mls_x832;
      goto _mls_j_case0_sr_post_caller_post_case0;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_j_case0_sr_post_caller_post_case0:
  {
    auto _mls_x833 = _mlsValue::cast<_mls_Tuple3>(_mls_x815)->_mls_field0;
    auto _mls_x834 = _mlsValue::cast<_mls_Tuple3>(_mls_x815)->_mls_field1;
    auto _mls_x835 = _mlsValue::cast<_mls_Tuple3>(_mls_x815)->_mls_field2;
    auto _mls_x836 = _mls_vecscale_case0_sr_post(_mls_x816, _mls_x833, _mls_x834, _mls_x835);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x817)) {
      auto _mls_x837 = _mlsValue::cast<_mls_Tuple3>(_mls_x817)->_mls_field0;
      auto _mls_x838 = _mlsValue::cast<_mls_Tuple3>(_mls_x817)->_mls_field1;
      auto _mls_x839 = _mlsValue::cast<_mls_Tuple3>(_mls_x817)->_mls_field2;
      auto _mls_x840 = _mls_vecadd_case0_sr_post(_mls_x836, _mls_x837, _mls_x838, _mls_x839);
      _mls_x810 = _mls_x840;
      goto _mls_j_caller_post_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post_post1:
  {
    auto _mls_x809 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x810);
    _mls_retval = _mls_x809;
    return _mls_retval;
  }
}
_mlsValue _mls_j_case0_sr_post_default_case0_sr_post(_mlsValue _mls_x847, _mlsValue _mls_x844, _mlsValue _mls_x841, _mlsValue _mls_x846, _mlsValue _mls_x842, _mlsValue _mls_x843) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x815, _mls_x816, _mls_x817;
  _mlsValue _mls_x810;
  auto _mls_x845 = _mls_vecscale_case0_sr_post(_mls_x841, _mls_x842, _mls_x843, _mls_x844);
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x846)) {
    _mls_x815 = _mls_x846;
    _mls_x816 = _mls_x847;
    _mls_x817 = _mls_x845;
    goto _mls_j_case0_sr_post_caller_post_case0;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_j_case0_sr_post_caller_post_case0:
  {
    auto _mls_x833 = _mlsValue::cast<_mls_Tuple3>(_mls_x815)->_mls_field0;
    auto _mls_x834 = _mlsValue::cast<_mls_Tuple3>(_mls_x815)->_mls_field1;
    auto _mls_x835 = _mlsValue::cast<_mls_Tuple3>(_mls_x815)->_mls_field2;
    auto _mls_x836 = _mls_vecscale_case0_sr_post(_mls_x816, _mls_x833, _mls_x834, _mls_x835);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x817)) {
      auto _mls_x837 = _mlsValue::cast<_mls_Tuple3>(_mls_x817)->_mls_field0;
      auto _mls_x838 = _mlsValue::cast<_mls_Tuple3>(_mls_x817)->_mls_field1;
      auto _mls_x839 = _mlsValue::cast<_mls_Tuple3>(_mls_x817)->_mls_field2;
      auto _mls_x840 = _mls_vecadd_case0_sr_post(_mls_x836, _mls_x837, _mls_x838, _mls_x839);
      _mls_x810 = _mls_x840;
      goto _mls_j_caller_post_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post_post1:
  {
    auto _mls_x809 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x810);
    _mls_retval = _mls_x809;
    return _mls_retval;
  }
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_j_case0_sr_post_pre(_mlsValue _mls_x849, _mlsValue _mls_x851, _mlsValue _mls_x860, _mlsValue _mls_x859) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x848 = (_mls_x849 * _mls_x849);
  auto _mls_x850 = (_mls_x851 * _mls_x851);
  auto _mls_x852 = (_mlsValue::create<_mls_Float>(1.0) - _mls_x850);
  auto _mls_x853 = (_mls_x848 * _mls_x852);
  auto _mls_x854 = (_mlsValue::create<_mls_Float>(1.0) - _mls_x853);
  auto _mls_x855 = (_mls_x849 * _mls_x851);
  auto _mls_x856 = _mls_builtin_sqrt(_mls_x854);
  auto _mls_x857 = (_mls_x855 - _mls_x856);
  auto _mls_x858 = (_mls_x854 < _mlsValue::create<_mls_Float>(0.0));
  _mls_retval = std::make_tuple(_mls_x849, _mls_x859, _mls_x858, _mls_x857, _mls_x860);
  return _mls_retval;
}
_mlsValue _mls_j_default(_mlsValue _mls_x719, _mlsValue _mls_x720, _mlsValue _mls_x721) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x722, _mls_x723, _mls_x724, _mls_x725, _mls_x726;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x719)) {
    auto _mls_x732 = _mlsValue::cast<_mls_Tuple3>(_mls_x719)->_mls_field0;
    auto _mls_x733 = _mlsValue::cast<_mls_Tuple3>(_mls_x719)->_mls_field1;
    auto _mls_x734 = _mlsValue::cast<_mls_Tuple3>(_mls_x719)->_mls_field2;
    _mls_x722 = _mls_x720;
    _mls_x723 = _mls_x721;
    _mls_x724 = _mls_x732;
    _mls_x725 = _mls_x733;
    _mls_x726 = _mls_x734;
    goto _mls_j_default_case0_sr_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_j_default_case0_sr_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x722)) {
      auto _mls_x735 = _mlsValue::cast<_mls_Tuple3>(_mls_x722)->_mls_field0;
      auto _mls_x736 = _mlsValue::cast<_mls_Tuple3>(_mls_x722)->_mls_field1;
      auto _mls_x737 = _mlsValue::cast<_mls_Tuple3>(_mls_x722)->_mls_field2;
      auto _mls_x738 = _mls_vecmult_case0_sr_post_case0_sr_post(_mls_x737, _mls_x725, _mls_x736, _mls_x726, _mls_x724, _mls_x735);
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x723)) {
        auto _mls_x739 = _mls_vecadd_case0(_mls_x723, _mls_x738);
        _mls_retval = _mls_x739;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_j_default1(_mlsValue _mls_x741, _mlsValue _mls_x742, _mlsValue _mls_x743) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x744;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x741)) {
    auto _mls_x751 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field0;
    auto _mls_x752 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field1;
    auto _mls_x753 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field2;
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x742)) {
      auto _mls_x754 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field0;
      auto _mls_x755 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field1;
      auto _mls_x756 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field2;
      auto _mls_x757 = _mls_vecmult_case0_sr_post_case0_sr_post(_mls_x756, _mls_x752, _mls_x755, _mls_x753, _mls_x751, _mls_x754);
      auto _mls_x758 = _mls_vecadd_case0(_mls_x757, _mls_x743);
      _mls_x744 = _mls_x758;
      goto _mls_j_caller_post_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_j_caller_post_post:
  {
    auto _mls_x759 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x744);
    _mls_retval = _mls_x759;
    return _mls_retval;
  }
}
_mlsValue _mls_j_default_case0_sr_post(_mlsValue _mls_x722, _mlsValue _mls_x723, _mlsValue _mls_x724, _mlsValue _mls_x725, _mlsValue _mls_x726) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x722)) {
    auto _mls_x735 = _mlsValue::cast<_mls_Tuple3>(_mls_x722)->_mls_field0;
    auto _mls_x736 = _mlsValue::cast<_mls_Tuple3>(_mls_x722)->_mls_field1;
    auto _mls_x737 = _mlsValue::cast<_mls_Tuple3>(_mls_x722)->_mls_field2;
    auto _mls_x738 = _mls_vecmult_case0_sr_post_case0_sr_post(_mls_x737, _mls_x725, _mls_x736, _mls_x726, _mls_x724, _mls_x735);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x723)) {
      auto _mls_x739 = _mls_vecadd_case0(_mls_x723, _mls_x738);
      _mls_retval = _mls_x739;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_lightcolour(_mlsValue _mls_x210) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Directional>(_mls_x210)) {
    auto _mls_x212 = _mlsValue::cast<_mls_Directional>(_mls_x210)->_mls_y;
    _mls_retval = _mls_x212;
  } else if (_mlsValue::isValueOf<_mls_Point>(_mls_x210)) {
    auto _mls_x211 = _mlsValue::cast<_mls_Point>(_mls_x210)->_mls_y;
    _mls_retval = _mls_x211;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_lightdirection_caller_post_post(_mlsValue _mls_x862) {
  _mlsValue _mls_retval;
  auto _mls_x861 = _mlsValue::create<_mls_Tuple2>(_mls_x862, _mlsValue::create<_mls_Float>(1.0E8));
  _mls_retval = _mls_x861;
  return _mls_retval;
}
_mlsValue _mls_lightdirection_case0_sr_post_case0_sr_post(_mlsValue _mls_x863, _mlsValue _mls_x864, _mlsValue _mls_x865) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x862;
  auto _mls_x866 = _mls_vecnorm_case0_sr_post(_mls_x863, _mls_x864, _mls_x865);
  auto _mls_x867 = _mlsValue::cast<_mls_Tuple2>(_mls_x866)->_mls_field0;
  _mls_x862 = _mls_x867;
  goto _mls_lightdirection_caller_post_post;
  return _mls_retval;
  _mls_lightdirection_caller_post_post:
  {
    auto _mls_x861 = _mlsValue::create<_mls_Tuple2>(_mls_x862, _mlsValue::create<_mls_Float>(1.0E8));
    _mls_retval = _mls_x861;
    return _mls_retval;
  }
}
_mlsValue _mls_lightdirection_case1_sr_post_case0_case0(_mlsValue _mls_x869, _mlsValue _mls_x872, _mlsValue _mls_x873, _mlsValue _mls_x874) {
  _mlsValue _mls_retval;
  auto _mls_x868 = _mlsValue::cast<_mls_Tuple3>(_mls_x869)->_mls_field0;
  auto _mls_x870 = _mlsValue::cast<_mls_Tuple3>(_mls_x869)->_mls_field1;
  auto _mls_x871 = _mlsValue::cast<_mls_Tuple3>(_mls_x869)->_mls_field2;
  auto _mls_x875 = _mls_vecsub_case0_case0_sr_post(_mls_x872, _mls_x868, _mls_x871, _mls_x870, _mls_x873, _mls_x874);
  auto _mls_x876 = _mlsValue::cast<_mls_Tuple3>(_mls_x875)->_mls_field0;
  auto _mls_x877 = _mlsValue::cast<_mls_Tuple3>(_mls_x875)->_mls_field1;
  auto _mls_x878 = _mlsValue::cast<_mls_Tuple3>(_mls_x875)->_mls_field2;
  auto _mls_x879 = _mls_vecnorm_case0_sr_post(_mls_x876, _mls_x877, _mls_x878);
  _mls_retval = _mls_x879;
  return _mls_retval;
}
_mlsValue _mls_lightray(_mlsValue _mls_l2, _mlsValue _mls_pos1, _mlsValue _mls_norm, _mlsValue _mls_refl2, _mlsValue _mls_surf1) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x880, _mls_x881, _mls_x882, _mls_x883, _mls_x884, _mls_x885;
  _mlsValue _mls_x886, _mls_x887, _mls_x888, _mls_x889, _mls_x890, _mls_x891;
  _mlsValue _mls_x892, _mls_x893, _mls_x894, _mls_x895, _mls_x896;
  _mlsValue _mls_x897, _mls_x898, _mls_x899, _mls_x900, _mls_x901, _mls_x902;
  _mlsValue _mls_x903, _mls_x904, _mls_x905, _mls_x906, _mls_x907, _mls_x908;
  _mlsValue _mls_x909, _mls_x910, _mls_x911, _mls_x912, _mls_x913, _mls_x914, _mls_x915;
  _mlsValue _mls_x916, _mls_x917, _mls_x918, _mls_x919, _mls_x920, _mls_x921, _mls_x922;
  _mlsValue _mls_x923, _mls_x924, _mls_x925, _mls_x926, _mls_x927;
  _mlsValue _mls_x928, _mls_x929, _mls_x930, _mls_x931, _mls_x932;
  _mlsValue _mls_x933, _mls_x934, _mls_x935, _mls_x936, _mls_x937;
  _mlsValue _mls_x938, _mls_x939, _mls_x940, _mls_x941, _mls_x942;
  if (_mlsValue::isValueOf<_mls_Directional>(_mls_l2)) {
    auto _mls_x948 = _mlsValue::cast<_mls_Directional>(_mls_l2)->_mls_x;
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x948)) {
      auto _mls_x949 = _mlsValue::cast<_mls_Tuple3>(_mls_x948)->_mls_field0;
      auto _mls_x950 = _mlsValue::cast<_mls_Tuple3>(_mls_x948)->_mls_field1;
      auto _mls_x951 = _mlsValue::cast<_mls_Tuple3>(_mls_x948)->_mls_field2;
      auto _mls_x952 = _mls_lightdirection_case0_sr_post_case0_sr_post(_mls_x949, _mls_x950, _mls_x951);
      auto _mls_x953 = _mlsValue::cast<_mls_Tuple2>(_mls_x952)->_mls_field0;
      _mls_x886 = _mls_l2;
      _mls_x887 = _mls_norm;
      _mls_x888 = _mls_pos1;
      _mls_x889 = _mls_surf1;
      _mls_x890 = _mls_refl2;
      _mls_x891 = _mls_x953;
      goto _mls_lightray_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else if (_mlsValue::isValueOf<_mls_Point>(_mls_l2)) {
    auto _mls_x943 = _mlsValue::cast<_mls_Point>(_mls_l2)->_mls_x;
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x943)) {
      auto _mls_x944 = _mlsValue::cast<_mls_Tuple3>(_mls_x943)->_mls_field0;
      auto _mls_x945 = _mlsValue::cast<_mls_Tuple3>(_mls_x943)->_mls_field1;
      auto _mls_x946 = _mlsValue::cast<_mls_Tuple3>(_mls_x943)->_mls_field2;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_pos1)) {
        auto _mls_x947 = _mls_lightdirection_case1_sr_post_case0_case0(_mls_pos1, _mls_x945, _mls_x944, _mls_x946);
        _mls_x880 = _mls_norm;
        _mls_x881 = _mls_refl2;
        _mls_x882 = _mls_x947;
        _mls_x883 = _mls_l2;
        _mls_x884 = _mls_surf1;
        _mls_x885 = _mls_pos1;
        goto _mls_lightray_caller_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_lightray_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x882)) {
      auto _mls_x954 = _mlsValue::cast<_mls_Tuple2>(_mls_x882)->_mls_field0;
      _mls_x886 = _mls_x883;
      _mls_x887 = _mls_x880;
      _mls_x888 = _mls_x885;
      _mls_x889 = _mls_x884;
      _mls_x890 = _mls_x881;
      _mls_x891 = _mls_x954;
      goto _mls_lightray_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_case0_sr_post:
  {
    auto _mls_x955 = _mls_vecdot(_mls_x891, _mls_x887);
    auto _mls_x956 = _mls_lightcolour(_mls_x886);
    auto _mls_x957 = _mls_testspheres();
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x891)) {
      auto [_mls_x958, _mls_x959, _mls_x960, _mls_x961] = _mls_shadowed_case0_pre(_mls_x891, _mls_x956, _mls_x888, _mls_x957);
      auto _mls_x962 = _mls_shadowed_caller_post_post(_mls_x958, _mls_x959, _mls_x960, _mls_x961);
      _mls_x892 = _mls_x890;
      _mls_x893 = _mls_x962;
      _mls_x894 = _mls_x891;
      _mls_x895 = _mls_x889;
      _mls_x896 = _mls_x955;
      goto _mls_lightray_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x893)) {
      auto _mls_x963 = _mlsValue::cast<_mls_Tuple2>(_mls_x893)->_mls_field0;
      auto _mls_x964 = _mlsValue::cast<_mls_Tuple2>(_mls_x893)->_mls_field1;
      _mls_x897 = _mls_x896;
      _mls_x898 = _mls_x894;
      _mls_x899 = _mls_x964;
      _mls_x900 = _mls_x895;
      _mls_x901 = _mls_x963;
      _mls_x902 = _mls_x892;
      goto _mls_lightray_caller_post_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_sr_post:
  {
    if (_mlsValue::isIntLit(_mls_x901, 1)) {
      auto _mls_x979 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
      _mls_retval = _mls_x979;
    } else {
      auto [_mls_x965, _mls_x966, _mls_x967] = _mls_diffusesurf_pre(_mls_x900);
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x965)) {
        auto [_mls_x971, _mls_x972, _mls_x973, _mls_x974, _mls_x975, _mls_x976, _mls_x977, _mls_x978] = _mls_lightray_caller_post_caller_post_case0_caller_post_pre(_mls_x897, _mls_x898, _mls_x899, _mls_x900, _mls_x966, _mls_x902);
        if (_mlsValue::isIntLit(_mls_x976, 1)) {
          _mls_x909 = _mls_x971;
          _mls_x910 = _mls_x972;
          _mls_x911 = _mls_x973;
          _mls_x912 = _mls_x974;
          _mls_x913 = _mls_x975;
          _mls_x914 = _mls_x977;
          _mls_x915 = _mls_x978;
          goto _mls_lightray_caller_post_caller_post_case0_caller_post_case0;
        } else {
          _mls_x916 = _mls_x971;
          _mls_x917 = _mls_x972;
          _mls_x918 = _mls_x973;
          _mls_x919 = _mls_x974;
          _mls_x920 = _mls_x975;
          _mls_x921 = _mls_x977;
          _mls_x922 = _mls_x978;
          goto _mls_lightray_caller_post_caller_post_case0_caller_post_default;
        }
      } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x965)) {
        auto _mls_x968 = _mlsValue::cast<_mls_Cons>(_mls_x965)->_mls_head;
        auto _mls_x969 = _mlsValue::cast<_mls_Cons>(_mls_x965)->_mls_tail;
        auto _mls_x970 = _mls_diffusesurf_case1_sr_post(_mls_x969, _mls_x967, _mls_x968);
        _mls_x903 = _mls_x897;
        _mls_x904 = _mls_x898;
        _mls_x905 = _mls_x899;
        _mls_x906 = _mls_x900;
        _mls_x907 = _mls_x970;
        _mls_x908 = _mls_x902;
        goto _mls_lightray_caller_post_caller_post_case0_caller_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post:
  {
    auto [_mls_x980, _mls_x981, _mls_x982, _mls_x983, _mls_x984, _mls_x985, _mls_x986, _mls_x987] = _mls_lightray_caller_post_caller_post_case0_caller_post_pre(_mls_x903, _mls_x904, _mls_x905, _mls_x906, _mls_x907, _mls_x908);
    if (_mlsValue::isIntLit(_mls_x985, 1)) {
      _mls_x909 = _mls_x980;
      _mls_x910 = _mls_x981;
      _mls_x911 = _mls_x982;
      _mls_x912 = _mls_x983;
      _mls_x913 = _mls_x984;
      _mls_x914 = _mls_x986;
      _mls_x915 = _mls_x987;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_case0;
    } else {
      _mls_x916 = _mls_x980;
      _mls_x917 = _mls_x981;
      _mls_x918 = _mls_x982;
      _mls_x919 = _mls_x983;
      _mls_x920 = _mls_x984;
      _mls_x921 = _mls_x986;
      _mls_x922 = _mls_x987;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_default;
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_case0:
  {
    auto _mls_x988 = _mls_bodysurf(_mls_x915);
    auto _mls_x989 = _mls_vecdot(_mls_x911, _mls_x909);
    auto _mls_x990 = (-_mls_x989);
    auto _mls_x991 = (-_mls_x913);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x912)) {
      auto _mls_x992 = _mlsValue::cast<_mls_Tuple3>(_mls_x912)->_mls_field0;
      auto _mls_x993 = _mlsValue::cast<_mls_Tuple3>(_mls_x912)->_mls_field1;
      auto _mls_x994 = _mlsValue::cast<_mls_Tuple3>(_mls_x912)->_mls_field2;
      auto _mls_x995 = _mls_vecscale_case0_sr_post(_mls_x991, _mls_x992, _mls_x993, _mls_x994);
      _mls_x923 = _mls_x988;
      _mls_x924 = _mls_x995;
      _mls_x925 = _mls_x914;
      _mls_x926 = _mls_x910;
      _mls_x927 = _mls_x990;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_default:
  {
    auto _mls_x996 = _mls_specularsurf(_mls_x922);
    auto _mls_x997 = _mls_vecdot(_mls_x918, _mls_x916);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x919)) {
      auto _mls_x998 = _mlsValue::cast<_mls_Tuple3>(_mls_x919)->_mls_field0;
      auto _mls_x999 = _mlsValue::cast<_mls_Tuple3>(_mls_x919)->_mls_field1;
      auto _mls_x1000 = _mlsValue::cast<_mls_Tuple3>(_mls_x919)->_mls_field2;
      auto _mls_x1001 = _mls_vecscale_case0_sr_post(_mls_x920, _mls_x998, _mls_x999, _mls_x1000);
      _mls_x928 = _mls_x996;
      _mls_x929 = _mls_x921;
      _mls_x930 = _mls_x997;
      _mls_x931 = _mls_x917;
      _mls_x932 = _mls_x1001;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x924)) {
      auto _mls_x1002 = _mls_vecmult_case0(_mls_x924, _mls_x925);
      _mls_x933 = _mls_x1002;
      _mls_x934 = _mls_x926;
      _mls_x935 = _mls_x925;
      _mls_x936 = _mls_x923;
      _mls_x937 = _mls_x927;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x932)) {
      auto _mls_x1003 = _mls_vecmult_case0(_mls_x932, _mls_x929);
      _mls_x938 = _mls_x928;
      _mls_x939 = _mls_x929;
      _mls_x940 = _mls_x931;
      _mls_x941 = _mls_x1003;
      _mls_x942 = _mls_x930;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post:
  {
    auto _mls_x1004 = (_mls_x937 <= _mlsValue::create<_mls_Float>(0.0));
    if (_mlsValue::isIntLit(_mls_x1004, 1)) {
      auto _mls_x1009 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
      auto _mls_x1010 = _mls_vecadd(_mls_x933, _mls_x1009);
      _mls_retval = _mls_x1010;
    } else {
      auto _mls_x1005 = _mls_builtin_pow(_mls_x937, _mls_x934);
      auto _mls_x1006 = _mls_vecscale(_mls_x936, _mls_x1005);
      auto _mls_x1007 = _mls_vecmult(_mls_x1006, _mls_x935);
      auto _mls_x1008 = _mls_vecadd(_mls_x933, _mls_x1007);
      _mls_retval = _mls_x1008;
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post1:
  {
    auto _mls_x1011 = (_mls_x942 < _mlsValue::create<_mls_Float>(0.0));
    if (_mlsValue::isIntLit(_mls_x1011, 1)) {
      auto _mls_x1016 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
      auto _mls_x1017 = _mls_vecadd(_mls_x941, _mls_x1016);
      _mls_retval = _mls_x1017;
    } else {
      auto _mls_x1012 = _mls_builtin_pow(_mls_x942, _mls_x940);
      auto _mls_x1013 = _mls_vecscale(_mls_x938, _mls_x1012);
      auto _mls_x1014 = _mls_vecmult(_mls_x1013, _mls_x939);
      auto _mls_x1015 = _mls_vecadd(_mls_x941, _mls_x1014);
      _mls_retval = _mls_x1015;
    }
    return _mls_retval;
  }
}
_mlsValue _mls_lightray_caller_post(_mlsValue _mls_x880, _mlsValue _mls_x881, _mlsValue _mls_x882, _mlsValue _mls_x883, _mlsValue _mls_x884, _mlsValue _mls_x885) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x886, _mls_x887, _mls_x888, _mls_x889, _mls_x890, _mls_x891;
  _mlsValue _mls_x892, _mls_x893, _mls_x894, _mls_x895, _mls_x896;
  _mlsValue _mls_x897, _mls_x898, _mls_x899, _mls_x900, _mls_x901, _mls_x902;
  _mlsValue _mls_x903, _mls_x904, _mls_x905, _mls_x906, _mls_x907, _mls_x908;
  _mlsValue _mls_x909, _mls_x910, _mls_x911, _mls_x912, _mls_x913, _mls_x914, _mls_x915;
  _mlsValue _mls_x916, _mls_x917, _mls_x918, _mls_x919, _mls_x920, _mls_x921, _mls_x922;
  _mlsValue _mls_x923, _mls_x924, _mls_x925, _mls_x926, _mls_x927;
  _mlsValue _mls_x928, _mls_x929, _mls_x930, _mls_x931, _mls_x932;
  _mlsValue _mls_x933, _mls_x934, _mls_x935, _mls_x936, _mls_x937;
  _mlsValue _mls_x938, _mls_x939, _mls_x940, _mls_x941, _mls_x942;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x882)) {
    auto _mls_x954 = _mlsValue::cast<_mls_Tuple2>(_mls_x882)->_mls_field0;
    _mls_x886 = _mls_x883;
    _mls_x887 = _mls_x880;
    _mls_x888 = _mls_x885;
    _mls_x889 = _mls_x884;
    _mls_x890 = _mls_x881;
    _mls_x891 = _mls_x954;
    goto _mls_lightray_caller_post_case0_sr_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_lightray_caller_post_case0_sr_post:
  {
    auto _mls_x955 = _mls_vecdot(_mls_x891, _mls_x887);
    auto _mls_x956 = _mls_lightcolour(_mls_x886);
    auto _mls_x957 = _mls_testspheres();
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x891)) {
      auto [_mls_x958, _mls_x959, _mls_x960, _mls_x961] = _mls_shadowed_case0_pre(_mls_x891, _mls_x956, _mls_x888, _mls_x957);
      auto _mls_x962 = _mls_shadowed_caller_post_post(_mls_x958, _mls_x959, _mls_x960, _mls_x961);
      _mls_x892 = _mls_x890;
      _mls_x893 = _mls_x962;
      _mls_x894 = _mls_x891;
      _mls_x895 = _mls_x889;
      _mls_x896 = _mls_x955;
      goto _mls_lightray_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x893)) {
      auto _mls_x963 = _mlsValue::cast<_mls_Tuple2>(_mls_x893)->_mls_field0;
      auto _mls_x964 = _mlsValue::cast<_mls_Tuple2>(_mls_x893)->_mls_field1;
      _mls_x897 = _mls_x896;
      _mls_x898 = _mls_x894;
      _mls_x899 = _mls_x964;
      _mls_x900 = _mls_x895;
      _mls_x901 = _mls_x963;
      _mls_x902 = _mls_x892;
      goto _mls_lightray_caller_post_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_sr_post:
  {
    if (_mlsValue::isIntLit(_mls_x901, 1)) {
      auto _mls_x979 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
      _mls_retval = _mls_x979;
    } else {
      auto [_mls_x965, _mls_x966, _mls_x967] = _mls_diffusesurf_pre(_mls_x900);
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x965)) {
        auto [_mls_x971, _mls_x972, _mls_x973, _mls_x974, _mls_x975, _mls_x976, _mls_x977, _mls_x978] = _mls_lightray_caller_post_caller_post_case0_caller_post_pre(_mls_x897, _mls_x898, _mls_x899, _mls_x900, _mls_x966, _mls_x902);
        if (_mlsValue::isIntLit(_mls_x976, 1)) {
          _mls_x909 = _mls_x971;
          _mls_x910 = _mls_x972;
          _mls_x911 = _mls_x973;
          _mls_x912 = _mls_x974;
          _mls_x913 = _mls_x975;
          _mls_x914 = _mls_x977;
          _mls_x915 = _mls_x978;
          goto _mls_lightray_caller_post_caller_post_case0_caller_post_case0;
        } else {
          _mls_x916 = _mls_x971;
          _mls_x917 = _mls_x972;
          _mls_x918 = _mls_x973;
          _mls_x919 = _mls_x974;
          _mls_x920 = _mls_x975;
          _mls_x921 = _mls_x977;
          _mls_x922 = _mls_x978;
          goto _mls_lightray_caller_post_caller_post_case0_caller_post_default;
        }
      } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x965)) {
        auto _mls_x968 = _mlsValue::cast<_mls_Cons>(_mls_x965)->_mls_head;
        auto _mls_x969 = _mlsValue::cast<_mls_Cons>(_mls_x965)->_mls_tail;
        auto _mls_x970 = _mls_diffusesurf_case1_sr_post(_mls_x969, _mls_x967, _mls_x968);
        _mls_x903 = _mls_x897;
        _mls_x904 = _mls_x898;
        _mls_x905 = _mls_x899;
        _mls_x906 = _mls_x900;
        _mls_x907 = _mls_x970;
        _mls_x908 = _mls_x902;
        goto _mls_lightray_caller_post_caller_post_case0_caller_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post:
  {
    auto [_mls_x980, _mls_x981, _mls_x982, _mls_x983, _mls_x984, _mls_x985, _mls_x986, _mls_x987] = _mls_lightray_caller_post_caller_post_case0_caller_post_pre(_mls_x903, _mls_x904, _mls_x905, _mls_x906, _mls_x907, _mls_x908);
    if (_mlsValue::isIntLit(_mls_x985, 1)) {
      _mls_x909 = _mls_x980;
      _mls_x910 = _mls_x981;
      _mls_x911 = _mls_x982;
      _mls_x912 = _mls_x983;
      _mls_x913 = _mls_x984;
      _mls_x914 = _mls_x986;
      _mls_x915 = _mls_x987;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_case0;
    } else {
      _mls_x916 = _mls_x980;
      _mls_x917 = _mls_x981;
      _mls_x918 = _mls_x982;
      _mls_x919 = _mls_x983;
      _mls_x920 = _mls_x984;
      _mls_x921 = _mls_x986;
      _mls_x922 = _mls_x987;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_default;
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_case0:
  {
    auto _mls_x988 = _mls_bodysurf(_mls_x915);
    auto _mls_x989 = _mls_vecdot(_mls_x911, _mls_x909);
    auto _mls_x990 = (-_mls_x989);
    auto _mls_x991 = (-_mls_x913);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x912)) {
      auto _mls_x992 = _mlsValue::cast<_mls_Tuple3>(_mls_x912)->_mls_field0;
      auto _mls_x993 = _mlsValue::cast<_mls_Tuple3>(_mls_x912)->_mls_field1;
      auto _mls_x994 = _mlsValue::cast<_mls_Tuple3>(_mls_x912)->_mls_field2;
      auto _mls_x995 = _mls_vecscale_case0_sr_post(_mls_x991, _mls_x992, _mls_x993, _mls_x994);
      _mls_x923 = _mls_x988;
      _mls_x924 = _mls_x995;
      _mls_x925 = _mls_x914;
      _mls_x926 = _mls_x910;
      _mls_x927 = _mls_x990;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_default:
  {
    auto _mls_x996 = _mls_specularsurf(_mls_x922);
    auto _mls_x997 = _mls_vecdot(_mls_x918, _mls_x916);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x919)) {
      auto _mls_x998 = _mlsValue::cast<_mls_Tuple3>(_mls_x919)->_mls_field0;
      auto _mls_x999 = _mlsValue::cast<_mls_Tuple3>(_mls_x919)->_mls_field1;
      auto _mls_x1000 = _mlsValue::cast<_mls_Tuple3>(_mls_x919)->_mls_field2;
      auto _mls_x1001 = _mls_vecscale_case0_sr_post(_mls_x920, _mls_x998, _mls_x999, _mls_x1000);
      _mls_x928 = _mls_x996;
      _mls_x929 = _mls_x921;
      _mls_x930 = _mls_x997;
      _mls_x931 = _mls_x917;
      _mls_x932 = _mls_x1001;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x924)) {
      auto _mls_x1002 = _mls_vecmult_case0(_mls_x924, _mls_x925);
      _mls_x933 = _mls_x1002;
      _mls_x934 = _mls_x926;
      _mls_x935 = _mls_x925;
      _mls_x936 = _mls_x923;
      _mls_x937 = _mls_x927;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x932)) {
      auto _mls_x1003 = _mls_vecmult_case0(_mls_x932, _mls_x929);
      _mls_x938 = _mls_x928;
      _mls_x939 = _mls_x929;
      _mls_x940 = _mls_x931;
      _mls_x941 = _mls_x1003;
      _mls_x942 = _mls_x930;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post:
  {
    auto _mls_x1004 = (_mls_x937 <= _mlsValue::create<_mls_Float>(0.0));
    if (_mlsValue::isIntLit(_mls_x1004, 1)) {
      auto _mls_x1009 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
      auto _mls_x1010 = _mls_vecadd(_mls_x933, _mls_x1009);
      _mls_retval = _mls_x1010;
    } else {
      auto _mls_x1005 = _mls_builtin_pow(_mls_x937, _mls_x934);
      auto _mls_x1006 = _mls_vecscale(_mls_x936, _mls_x1005);
      auto _mls_x1007 = _mls_vecmult(_mls_x1006, _mls_x935);
      auto _mls_x1008 = _mls_vecadd(_mls_x933, _mls_x1007);
      _mls_retval = _mls_x1008;
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post1:
  {
    auto _mls_x1011 = (_mls_x942 < _mlsValue::create<_mls_Float>(0.0));
    if (_mlsValue::isIntLit(_mls_x1011, 1)) {
      auto _mls_x1016 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
      auto _mls_x1017 = _mls_vecadd(_mls_x941, _mls_x1016);
      _mls_retval = _mls_x1017;
    } else {
      auto _mls_x1012 = _mls_builtin_pow(_mls_x942, _mls_x940);
      auto _mls_x1013 = _mls_vecscale(_mls_x938, _mls_x1012);
      auto _mls_x1014 = _mls_vecmult(_mls_x1013, _mls_x939);
      auto _mls_x1015 = _mls_vecadd(_mls_x941, _mls_x1014);
      _mls_retval = _mls_x1015;
    }
    return _mls_retval;
  }
}
_mlsValue _mls_lightray_caller_post_caller_post(_mlsValue _mls_x892, _mlsValue _mls_x893, _mlsValue _mls_x894, _mlsValue _mls_x895, _mlsValue _mls_x896) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x897, _mls_x898, _mls_x899, _mls_x900, _mls_x901, _mls_x902;
  _mlsValue _mls_x903, _mls_x904, _mls_x905, _mls_x906, _mls_x907, _mls_x908;
  _mlsValue _mls_x909, _mls_x910, _mls_x911, _mls_x912, _mls_x913, _mls_x914, _mls_x915;
  _mlsValue _mls_x916, _mls_x917, _mls_x918, _mls_x919, _mls_x920, _mls_x921, _mls_x922;
  _mlsValue _mls_x923, _mls_x924, _mls_x925, _mls_x926, _mls_x927;
  _mlsValue _mls_x928, _mls_x929, _mls_x930, _mls_x931, _mls_x932;
  _mlsValue _mls_x933, _mls_x934, _mls_x935, _mls_x936, _mls_x937;
  _mlsValue _mls_x938, _mls_x939, _mls_x940, _mls_x941, _mls_x942;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x893)) {
    auto _mls_x963 = _mlsValue::cast<_mls_Tuple2>(_mls_x893)->_mls_field0;
    auto _mls_x964 = _mlsValue::cast<_mls_Tuple2>(_mls_x893)->_mls_field1;
    _mls_x897 = _mls_x896;
    _mls_x898 = _mls_x894;
    _mls_x899 = _mls_x964;
    _mls_x900 = _mls_x895;
    _mls_x901 = _mls_x963;
    _mls_x902 = _mls_x892;
    goto _mls_lightray_caller_post_caller_post_case0_sr_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_lightray_caller_post_caller_post_case0_sr_post:
  {
    if (_mlsValue::isIntLit(_mls_x901, 1)) {
      auto _mls_x979 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
      _mls_retval = _mls_x979;
    } else {
      auto [_mls_x965, _mls_x966, _mls_x967] = _mls_diffusesurf_pre(_mls_x900);
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x965)) {
        auto [_mls_x971, _mls_x972, _mls_x973, _mls_x974, _mls_x975, _mls_x976, _mls_x977, _mls_x978] = _mls_lightray_caller_post_caller_post_case0_caller_post_pre(_mls_x897, _mls_x898, _mls_x899, _mls_x900, _mls_x966, _mls_x902);
        if (_mlsValue::isIntLit(_mls_x976, 1)) {
          _mls_x909 = _mls_x971;
          _mls_x910 = _mls_x972;
          _mls_x911 = _mls_x973;
          _mls_x912 = _mls_x974;
          _mls_x913 = _mls_x975;
          _mls_x914 = _mls_x977;
          _mls_x915 = _mls_x978;
          goto _mls_lightray_caller_post_caller_post_case0_caller_post_case0;
        } else {
          _mls_x916 = _mls_x971;
          _mls_x917 = _mls_x972;
          _mls_x918 = _mls_x973;
          _mls_x919 = _mls_x974;
          _mls_x920 = _mls_x975;
          _mls_x921 = _mls_x977;
          _mls_x922 = _mls_x978;
          goto _mls_lightray_caller_post_caller_post_case0_caller_post_default;
        }
      } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x965)) {
        auto _mls_x968 = _mlsValue::cast<_mls_Cons>(_mls_x965)->_mls_head;
        auto _mls_x969 = _mlsValue::cast<_mls_Cons>(_mls_x965)->_mls_tail;
        auto _mls_x970 = _mls_diffusesurf_case1_sr_post(_mls_x969, _mls_x967, _mls_x968);
        _mls_x903 = _mls_x897;
        _mls_x904 = _mls_x898;
        _mls_x905 = _mls_x899;
        _mls_x906 = _mls_x900;
        _mls_x907 = _mls_x970;
        _mls_x908 = _mls_x902;
        goto _mls_lightray_caller_post_caller_post_case0_caller_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post:
  {
    auto [_mls_x980, _mls_x981, _mls_x982, _mls_x983, _mls_x984, _mls_x985, _mls_x986, _mls_x987] = _mls_lightray_caller_post_caller_post_case0_caller_post_pre(_mls_x903, _mls_x904, _mls_x905, _mls_x906, _mls_x907, _mls_x908);
    if (_mlsValue::isIntLit(_mls_x985, 1)) {
      _mls_x909 = _mls_x980;
      _mls_x910 = _mls_x981;
      _mls_x911 = _mls_x982;
      _mls_x912 = _mls_x983;
      _mls_x913 = _mls_x984;
      _mls_x914 = _mls_x986;
      _mls_x915 = _mls_x987;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_case0;
    } else {
      _mls_x916 = _mls_x980;
      _mls_x917 = _mls_x981;
      _mls_x918 = _mls_x982;
      _mls_x919 = _mls_x983;
      _mls_x920 = _mls_x984;
      _mls_x921 = _mls_x986;
      _mls_x922 = _mls_x987;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_default;
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_case0:
  {
    auto _mls_x988 = _mls_bodysurf(_mls_x915);
    auto _mls_x989 = _mls_vecdot(_mls_x911, _mls_x909);
    auto _mls_x990 = (-_mls_x989);
    auto _mls_x991 = (-_mls_x913);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x912)) {
      auto _mls_x992 = _mlsValue::cast<_mls_Tuple3>(_mls_x912)->_mls_field0;
      auto _mls_x993 = _mlsValue::cast<_mls_Tuple3>(_mls_x912)->_mls_field1;
      auto _mls_x994 = _mlsValue::cast<_mls_Tuple3>(_mls_x912)->_mls_field2;
      auto _mls_x995 = _mls_vecscale_case0_sr_post(_mls_x991, _mls_x992, _mls_x993, _mls_x994);
      _mls_x923 = _mls_x988;
      _mls_x924 = _mls_x995;
      _mls_x925 = _mls_x914;
      _mls_x926 = _mls_x910;
      _mls_x927 = _mls_x990;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_default:
  {
    auto _mls_x996 = _mls_specularsurf(_mls_x922);
    auto _mls_x997 = _mls_vecdot(_mls_x918, _mls_x916);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x919)) {
      auto _mls_x998 = _mlsValue::cast<_mls_Tuple3>(_mls_x919)->_mls_field0;
      auto _mls_x999 = _mlsValue::cast<_mls_Tuple3>(_mls_x919)->_mls_field1;
      auto _mls_x1000 = _mlsValue::cast<_mls_Tuple3>(_mls_x919)->_mls_field2;
      auto _mls_x1001 = _mls_vecscale_case0_sr_post(_mls_x920, _mls_x998, _mls_x999, _mls_x1000);
      _mls_x928 = _mls_x996;
      _mls_x929 = _mls_x921;
      _mls_x930 = _mls_x997;
      _mls_x931 = _mls_x917;
      _mls_x932 = _mls_x1001;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x924)) {
      auto _mls_x1002 = _mls_vecmult_case0(_mls_x924, _mls_x925);
      _mls_x933 = _mls_x1002;
      _mls_x934 = _mls_x926;
      _mls_x935 = _mls_x925;
      _mls_x936 = _mls_x923;
      _mls_x937 = _mls_x927;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x932)) {
      auto _mls_x1003 = _mls_vecmult_case0(_mls_x932, _mls_x929);
      _mls_x938 = _mls_x928;
      _mls_x939 = _mls_x929;
      _mls_x940 = _mls_x931;
      _mls_x941 = _mls_x1003;
      _mls_x942 = _mls_x930;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post:
  {
    auto _mls_x1004 = (_mls_x937 <= _mlsValue::create<_mls_Float>(0.0));
    if (_mlsValue::isIntLit(_mls_x1004, 1)) {
      auto _mls_x1009 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
      auto _mls_x1010 = _mls_vecadd(_mls_x933, _mls_x1009);
      _mls_retval = _mls_x1010;
    } else {
      auto _mls_x1005 = _mls_builtin_pow(_mls_x937, _mls_x934);
      auto _mls_x1006 = _mls_vecscale(_mls_x936, _mls_x1005);
      auto _mls_x1007 = _mls_vecmult(_mls_x1006, _mls_x935);
      auto _mls_x1008 = _mls_vecadd(_mls_x933, _mls_x1007);
      _mls_retval = _mls_x1008;
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post1:
  {
    auto _mls_x1011 = (_mls_x942 < _mlsValue::create<_mls_Float>(0.0));
    if (_mlsValue::isIntLit(_mls_x1011, 1)) {
      auto _mls_x1016 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
      auto _mls_x1017 = _mls_vecadd(_mls_x941, _mls_x1016);
      _mls_retval = _mls_x1017;
    } else {
      auto _mls_x1012 = _mls_builtin_pow(_mls_x942, _mls_x940);
      auto _mls_x1013 = _mls_vecscale(_mls_x938, _mls_x1012);
      auto _mls_x1014 = _mls_vecmult(_mls_x1013, _mls_x939);
      auto _mls_x1015 = _mls_vecadd(_mls_x941, _mls_x1014);
      _mls_retval = _mls_x1015;
    }
    return _mls_retval;
  }
}
_mlsValue _mls_lightray_caller_post_caller_post_case0_caller_post(_mlsValue _mls_x903, _mlsValue _mls_x904, _mlsValue _mls_x905, _mlsValue _mls_x906, _mlsValue _mls_x907, _mlsValue _mls_x908) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x909, _mls_x910, _mls_x911, _mls_x912, _mls_x913, _mls_x914, _mls_x915;
  _mlsValue _mls_x916, _mls_x917, _mls_x918, _mls_x919, _mls_x920, _mls_x921, _mls_x922;
  _mlsValue _mls_x923, _mls_x924, _mls_x925, _mls_x926, _mls_x927;
  _mlsValue _mls_x928, _mls_x929, _mls_x930, _mls_x931, _mls_x932;
  _mlsValue _mls_x933, _mls_x934, _mls_x935, _mls_x936, _mls_x937;
  _mlsValue _mls_x938, _mls_x939, _mls_x940, _mls_x941, _mls_x942;
  auto [_mls_x980, _mls_x981, _mls_x982, _mls_x983, _mls_x984, _mls_x985, _mls_x986, _mls_x987] = _mls_lightray_caller_post_caller_post_case0_caller_post_pre(_mls_x903, _mls_x904, _mls_x905, _mls_x906, _mls_x907, _mls_x908);
  if (_mlsValue::isIntLit(_mls_x985, 1)) {
    _mls_x909 = _mls_x980;
    _mls_x910 = _mls_x981;
    _mls_x911 = _mls_x982;
    _mls_x912 = _mls_x983;
    _mls_x913 = _mls_x984;
    _mls_x914 = _mls_x986;
    _mls_x915 = _mls_x987;
    goto _mls_lightray_caller_post_caller_post_case0_caller_post_case0;
  } else {
    _mls_x916 = _mls_x980;
    _mls_x917 = _mls_x981;
    _mls_x918 = _mls_x982;
    _mls_x919 = _mls_x983;
    _mls_x920 = _mls_x984;
    _mls_x921 = _mls_x986;
    _mls_x922 = _mls_x987;
    goto _mls_lightray_caller_post_caller_post_case0_caller_post_default;
  }
  return _mls_retval;
  _mls_lightray_caller_post_caller_post_case0_caller_post_case0:
  {
    auto _mls_x988 = _mls_bodysurf(_mls_x915);
    auto _mls_x989 = _mls_vecdot(_mls_x911, _mls_x909);
    auto _mls_x990 = (-_mls_x989);
    auto _mls_x991 = (-_mls_x913);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x912)) {
      auto _mls_x992 = _mlsValue::cast<_mls_Tuple3>(_mls_x912)->_mls_field0;
      auto _mls_x993 = _mlsValue::cast<_mls_Tuple3>(_mls_x912)->_mls_field1;
      auto _mls_x994 = _mlsValue::cast<_mls_Tuple3>(_mls_x912)->_mls_field2;
      auto _mls_x995 = _mls_vecscale_case0_sr_post(_mls_x991, _mls_x992, _mls_x993, _mls_x994);
      _mls_x923 = _mls_x988;
      _mls_x924 = _mls_x995;
      _mls_x925 = _mls_x914;
      _mls_x926 = _mls_x910;
      _mls_x927 = _mls_x990;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_default:
  {
    auto _mls_x996 = _mls_specularsurf(_mls_x922);
    auto _mls_x997 = _mls_vecdot(_mls_x918, _mls_x916);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x919)) {
      auto _mls_x998 = _mlsValue::cast<_mls_Tuple3>(_mls_x919)->_mls_field0;
      auto _mls_x999 = _mlsValue::cast<_mls_Tuple3>(_mls_x919)->_mls_field1;
      auto _mls_x1000 = _mlsValue::cast<_mls_Tuple3>(_mls_x919)->_mls_field2;
      auto _mls_x1001 = _mls_vecscale_case0_sr_post(_mls_x920, _mls_x998, _mls_x999, _mls_x1000);
      _mls_x928 = _mls_x996;
      _mls_x929 = _mls_x921;
      _mls_x930 = _mls_x997;
      _mls_x931 = _mls_x917;
      _mls_x932 = _mls_x1001;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x924)) {
      auto _mls_x1002 = _mls_vecmult_case0(_mls_x924, _mls_x925);
      _mls_x933 = _mls_x1002;
      _mls_x934 = _mls_x926;
      _mls_x935 = _mls_x925;
      _mls_x936 = _mls_x923;
      _mls_x937 = _mls_x927;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x932)) {
      auto _mls_x1003 = _mls_vecmult_case0(_mls_x932, _mls_x929);
      _mls_x938 = _mls_x928;
      _mls_x939 = _mls_x929;
      _mls_x940 = _mls_x931;
      _mls_x941 = _mls_x1003;
      _mls_x942 = _mls_x930;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post:
  {
    auto _mls_x1004 = (_mls_x937 <= _mlsValue::create<_mls_Float>(0.0));
    if (_mlsValue::isIntLit(_mls_x1004, 1)) {
      auto _mls_x1009 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
      auto _mls_x1010 = _mls_vecadd(_mls_x933, _mls_x1009);
      _mls_retval = _mls_x1010;
    } else {
      auto _mls_x1005 = _mls_builtin_pow(_mls_x937, _mls_x934);
      auto _mls_x1006 = _mls_vecscale(_mls_x936, _mls_x1005);
      auto _mls_x1007 = _mls_vecmult(_mls_x1006, _mls_x935);
      auto _mls_x1008 = _mls_vecadd(_mls_x933, _mls_x1007);
      _mls_retval = _mls_x1008;
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post1:
  {
    auto _mls_x1011 = (_mls_x942 < _mlsValue::create<_mls_Float>(0.0));
    if (_mlsValue::isIntLit(_mls_x1011, 1)) {
      auto _mls_x1016 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
      auto _mls_x1017 = _mls_vecadd(_mls_x941, _mls_x1016);
      _mls_retval = _mls_x1017;
    } else {
      auto _mls_x1012 = _mls_builtin_pow(_mls_x942, _mls_x940);
      auto _mls_x1013 = _mls_vecscale(_mls_x938, _mls_x1012);
      auto _mls_x1014 = _mls_vecmult(_mls_x1013, _mls_x939);
      auto _mls_x1015 = _mls_vecadd(_mls_x941, _mls_x1014);
      _mls_retval = _mls_x1015;
    }
    return _mls_retval;
  }
}
_mlsValue _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post1(_mlsValue _mls_x928, _mlsValue _mls_x929, _mlsValue _mls_x930, _mlsValue _mls_x931, _mlsValue _mls_x932) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x938, _mls_x939, _mls_x940, _mls_x941, _mls_x942;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x932)) {
    auto _mls_x1003 = _mls_vecmult_case0(_mls_x932, _mls_x929);
    _mls_x938 = _mls_x928;
    _mls_x939 = _mls_x929;
    _mls_x940 = _mls_x931;
    _mls_x941 = _mls_x1003;
    _mls_x942 = _mls_x930;
    goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post1;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post1:
  {
    auto _mls_x1011 = (_mls_x942 < _mlsValue::create<_mls_Float>(0.0));
    if (_mlsValue::isIntLit(_mls_x1011, 1)) {
      auto _mls_x1016 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
      auto _mls_x1017 = _mls_vecadd(_mls_x941, _mls_x1016);
      _mls_retval = _mls_x1017;
    } else {
      auto _mls_x1012 = _mls_builtin_pow(_mls_x942, _mls_x940);
      auto _mls_x1013 = _mls_vecscale(_mls_x938, _mls_x1012);
      auto _mls_x1014 = _mls_vecmult(_mls_x1013, _mls_x939);
      auto _mls_x1015 = _mls_vecadd(_mls_x941, _mls_x1014);
      _mls_retval = _mls_x1015;
    }
    return _mls_retval;
  }
}
_mlsValue _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post(_mlsValue _mls_x923, _mlsValue _mls_x924, _mlsValue _mls_x925, _mlsValue _mls_x926, _mlsValue _mls_x927) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x933, _mls_x934, _mls_x935, _mls_x936, _mls_x937;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x924)) {
    auto _mls_x1002 = _mls_vecmult_case0(_mls_x924, _mls_x925);
    _mls_x933 = _mls_x1002;
    _mls_x934 = _mls_x926;
    _mls_x935 = _mls_x925;
    _mls_x936 = _mls_x923;
    _mls_x937 = _mls_x927;
    goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post:
  {
    auto _mls_x1004 = (_mls_x937 <= _mlsValue::create<_mls_Float>(0.0));
    if (_mlsValue::isIntLit(_mls_x1004, 1)) {
      auto _mls_x1009 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
      auto _mls_x1010 = _mls_vecadd(_mls_x933, _mls_x1009);
      _mls_retval = _mls_x1010;
    } else {
      auto _mls_x1005 = _mls_builtin_pow(_mls_x937, _mls_x934);
      auto _mls_x1006 = _mls_vecscale(_mls_x936, _mls_x1005);
      auto _mls_x1007 = _mls_vecmult(_mls_x1006, _mls_x935);
      auto _mls_x1008 = _mls_vecadd(_mls_x933, _mls_x1007);
      _mls_retval = _mls_x1008;
    }
    return _mls_retval;
  }
}
_mlsValue _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post(_mlsValue _mls_x933, _mlsValue _mls_x934, _mlsValue _mls_x935, _mlsValue _mls_x936, _mlsValue _mls_x937) {
  _mlsValue _mls_retval;
  auto _mls_x1004 = (_mls_x937 <= _mlsValue::create<_mls_Float>(0.0));
  if (_mlsValue::isIntLit(_mls_x1004, 1)) {
    auto _mls_x1009 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
    auto _mls_x1010 = _mls_vecadd(_mls_x933, _mls_x1009);
    _mls_retval = _mls_x1010;
  } else {
    auto _mls_x1005 = _mls_builtin_pow(_mls_x937, _mls_x934);
    auto _mls_x1006 = _mls_vecscale(_mls_x936, _mls_x1005);
    auto _mls_x1007 = _mls_vecmult(_mls_x1006, _mls_x935);
    auto _mls_x1008 = _mls_vecadd(_mls_x933, _mls_x1007);
    _mls_retval = _mls_x1008;
  }
  return _mls_retval;
}
_mlsValue _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post1(_mlsValue _mls_x938, _mlsValue _mls_x939, _mlsValue _mls_x940, _mlsValue _mls_x941, _mlsValue _mls_x942) {
  _mlsValue _mls_retval;
  auto _mls_x1011 = (_mls_x942 < _mlsValue::create<_mls_Float>(0.0));
  if (_mlsValue::isIntLit(_mls_x1011, 1)) {
    auto _mls_x1016 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
    auto _mls_x1017 = _mls_vecadd(_mls_x941, _mls_x1016);
    _mls_retval = _mls_x1017;
  } else {
    auto _mls_x1012 = _mls_builtin_pow(_mls_x942, _mls_x940);
    auto _mls_x1013 = _mls_vecscale(_mls_x938, _mls_x1012);
    auto _mls_x1014 = _mls_vecmult(_mls_x1013, _mls_x939);
    auto _mls_x1015 = _mls_vecadd(_mls_x941, _mls_x1014);
    _mls_retval = _mls_x1015;
  }
  return _mls_retval;
}
_mlsValue _mls_lightray_caller_post_caller_post_case0_caller_post_case0(_mlsValue _mls_x909, _mlsValue _mls_x910, _mlsValue _mls_x911, _mlsValue _mls_x912, _mlsValue _mls_x913, _mlsValue _mls_x914, _mlsValue _mls_x915) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x923, _mls_x924, _mls_x925, _mls_x926, _mls_x927;
  _mlsValue _mls_x933, _mls_x934, _mls_x935, _mls_x936, _mls_x937;
  auto _mls_x988 = _mls_bodysurf(_mls_x915);
  auto _mls_x989 = _mls_vecdot(_mls_x911, _mls_x909);
  auto _mls_x990 = (-_mls_x989);
  auto _mls_x991 = (-_mls_x913);
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x912)) {
    auto _mls_x992 = _mlsValue::cast<_mls_Tuple3>(_mls_x912)->_mls_field0;
    auto _mls_x993 = _mlsValue::cast<_mls_Tuple3>(_mls_x912)->_mls_field1;
    auto _mls_x994 = _mlsValue::cast<_mls_Tuple3>(_mls_x912)->_mls_field2;
    auto _mls_x995 = _mls_vecscale_case0_sr_post(_mls_x991, _mls_x992, _mls_x993, _mls_x994);
    _mls_x923 = _mls_x988;
    _mls_x924 = _mls_x995;
    _mls_x925 = _mls_x914;
    _mls_x926 = _mls_x910;
    _mls_x927 = _mls_x990;
    goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x924)) {
      auto _mls_x1002 = _mls_vecmult_case0(_mls_x924, _mls_x925);
      _mls_x933 = _mls_x1002;
      _mls_x934 = _mls_x926;
      _mls_x935 = _mls_x925;
      _mls_x936 = _mls_x923;
      _mls_x937 = _mls_x927;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post:
  {
    auto _mls_x1004 = (_mls_x937 <= _mlsValue::create<_mls_Float>(0.0));
    if (_mlsValue::isIntLit(_mls_x1004, 1)) {
      auto _mls_x1009 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
      auto _mls_x1010 = _mls_vecadd(_mls_x933, _mls_x1009);
      _mls_retval = _mls_x1010;
    } else {
      auto _mls_x1005 = _mls_builtin_pow(_mls_x937, _mls_x934);
      auto _mls_x1006 = _mls_vecscale(_mls_x936, _mls_x1005);
      auto _mls_x1007 = _mls_vecmult(_mls_x1006, _mls_x935);
      auto _mls_x1008 = _mls_vecadd(_mls_x933, _mls_x1007);
      _mls_retval = _mls_x1008;
    }
    return _mls_retval;
  }
}
_mlsValue _mls_lightray_caller_post_caller_post_case0_caller_post_default(_mlsValue _mls_x916, _mlsValue _mls_x917, _mlsValue _mls_x918, _mlsValue _mls_x919, _mlsValue _mls_x920, _mlsValue _mls_x921, _mlsValue _mls_x922) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x928, _mls_x929, _mls_x930, _mls_x931, _mls_x932;
  _mlsValue _mls_x938, _mls_x939, _mls_x940, _mls_x941, _mls_x942;
  auto _mls_x996 = _mls_specularsurf(_mls_x922);
  auto _mls_x997 = _mls_vecdot(_mls_x918, _mls_x916);
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x919)) {
    auto _mls_x998 = _mlsValue::cast<_mls_Tuple3>(_mls_x919)->_mls_field0;
    auto _mls_x999 = _mlsValue::cast<_mls_Tuple3>(_mls_x919)->_mls_field1;
    auto _mls_x1000 = _mlsValue::cast<_mls_Tuple3>(_mls_x919)->_mls_field2;
    auto _mls_x1001 = _mls_vecscale_case0_sr_post(_mls_x920, _mls_x998, _mls_x999, _mls_x1000);
    _mls_x928 = _mls_x996;
    _mls_x929 = _mls_x921;
    _mls_x930 = _mls_x997;
    _mls_x931 = _mls_x917;
    _mls_x932 = _mls_x1001;
    goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post1;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x932)) {
      auto _mls_x1003 = _mls_vecmult_case0(_mls_x932, _mls_x929);
      _mls_x938 = _mls_x928;
      _mls_x939 = _mls_x929;
      _mls_x940 = _mls_x931;
      _mls_x941 = _mls_x1003;
      _mls_x942 = _mls_x930;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post1:
  {
    auto _mls_x1011 = (_mls_x942 < _mlsValue::create<_mls_Float>(0.0));
    if (_mlsValue::isIntLit(_mls_x1011, 1)) {
      auto _mls_x1016 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
      auto _mls_x1017 = _mls_vecadd(_mls_x941, _mls_x1016);
      _mls_retval = _mls_x1017;
    } else {
      auto _mls_x1012 = _mls_builtin_pow(_mls_x942, _mls_x940);
      auto _mls_x1013 = _mls_vecscale(_mls_x938, _mls_x1012);
      auto _mls_x1014 = _mls_vecmult(_mls_x1013, _mls_x939);
      auto _mls_x1015 = _mls_vecadd(_mls_x941, _mls_x1014);
      _mls_retval = _mls_x1015;
    }
    return _mls_retval;
  }
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_lightray_caller_post_caller_post_case0_caller_post_pre(_mlsValue _mls_x1021, _mlsValue _mls_x1022, _mlsValue _mls_x1025, _mlsValue _mls_x1018, _mlsValue _mls_x1024, _mlsValue _mls_x1023) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x1019 = _mls_specpowsurf(_mls_x1018);
  auto _mls_x1020 = (_mls_x1021 <= _mlsValue::create<_mls_Float>(0.0));
  _mls_retval = std::make_tuple(_mls_x1022, _mls_x1019, _mls_x1023, _mls_x1024, _mls_x1021, _mls_x1020, _mls_x1025, _mls_x1018);
  return _mls_retval;
}
_mlsValue _mls_lightray_caller_post_caller_post_case0_sr_post(_mlsValue _mls_x897, _mlsValue _mls_x898, _mlsValue _mls_x899, _mlsValue _mls_x900, _mlsValue _mls_x901, _mlsValue _mls_x902) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x903, _mls_x904, _mls_x905, _mls_x906, _mls_x907, _mls_x908;
  _mlsValue _mls_x909, _mls_x910, _mls_x911, _mls_x912, _mls_x913, _mls_x914, _mls_x915;
  _mlsValue _mls_x916, _mls_x917, _mls_x918, _mls_x919, _mls_x920, _mls_x921, _mls_x922;
  _mlsValue _mls_x923, _mls_x924, _mls_x925, _mls_x926, _mls_x927;
  _mlsValue _mls_x928, _mls_x929, _mls_x930, _mls_x931, _mls_x932;
  _mlsValue _mls_x933, _mls_x934, _mls_x935, _mls_x936, _mls_x937;
  _mlsValue _mls_x938, _mls_x939, _mls_x940, _mls_x941, _mls_x942;
  if (_mlsValue::isIntLit(_mls_x901, 1)) {
    auto _mls_x979 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
    _mls_retval = _mls_x979;
  } else {
    auto [_mls_x965, _mls_x966, _mls_x967] = _mls_diffusesurf_pre(_mls_x900);
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x965)) {
      auto [_mls_x971, _mls_x972, _mls_x973, _mls_x974, _mls_x975, _mls_x976, _mls_x977, _mls_x978] = _mls_lightray_caller_post_caller_post_case0_caller_post_pre(_mls_x897, _mls_x898, _mls_x899, _mls_x900, _mls_x966, _mls_x902);
      if (_mlsValue::isIntLit(_mls_x976, 1)) {
        _mls_x909 = _mls_x971;
        _mls_x910 = _mls_x972;
        _mls_x911 = _mls_x973;
        _mls_x912 = _mls_x974;
        _mls_x913 = _mls_x975;
        _mls_x914 = _mls_x977;
        _mls_x915 = _mls_x978;
        goto _mls_lightray_caller_post_caller_post_case0_caller_post_case0;
      } else {
        _mls_x916 = _mls_x971;
        _mls_x917 = _mls_x972;
        _mls_x918 = _mls_x973;
        _mls_x919 = _mls_x974;
        _mls_x920 = _mls_x975;
        _mls_x921 = _mls_x977;
        _mls_x922 = _mls_x978;
        goto _mls_lightray_caller_post_caller_post_case0_caller_post_default;
      }
    } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x965)) {
      auto _mls_x968 = _mlsValue::cast<_mls_Cons>(_mls_x965)->_mls_head;
      auto _mls_x969 = _mlsValue::cast<_mls_Cons>(_mls_x965)->_mls_tail;
      auto _mls_x970 = _mls_diffusesurf_case1_sr_post(_mls_x969, _mls_x967, _mls_x968);
      _mls_x903 = _mls_x897;
      _mls_x904 = _mls_x898;
      _mls_x905 = _mls_x899;
      _mls_x906 = _mls_x900;
      _mls_x907 = _mls_x970;
      _mls_x908 = _mls_x902;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  }
  return _mls_retval;
  _mls_lightray_caller_post_caller_post_case0_caller_post:
  {
    auto [_mls_x980, _mls_x981, _mls_x982, _mls_x983, _mls_x984, _mls_x985, _mls_x986, _mls_x987] = _mls_lightray_caller_post_caller_post_case0_caller_post_pre(_mls_x903, _mls_x904, _mls_x905, _mls_x906, _mls_x907, _mls_x908);
    if (_mlsValue::isIntLit(_mls_x985, 1)) {
      _mls_x909 = _mls_x980;
      _mls_x910 = _mls_x981;
      _mls_x911 = _mls_x982;
      _mls_x912 = _mls_x983;
      _mls_x913 = _mls_x984;
      _mls_x914 = _mls_x986;
      _mls_x915 = _mls_x987;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_case0;
    } else {
      _mls_x916 = _mls_x980;
      _mls_x917 = _mls_x981;
      _mls_x918 = _mls_x982;
      _mls_x919 = _mls_x983;
      _mls_x920 = _mls_x984;
      _mls_x921 = _mls_x986;
      _mls_x922 = _mls_x987;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_default;
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_case0:
  {
    auto _mls_x988 = _mls_bodysurf(_mls_x915);
    auto _mls_x989 = _mls_vecdot(_mls_x911, _mls_x909);
    auto _mls_x990 = (-_mls_x989);
    auto _mls_x991 = (-_mls_x913);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x912)) {
      auto _mls_x992 = _mlsValue::cast<_mls_Tuple3>(_mls_x912)->_mls_field0;
      auto _mls_x993 = _mlsValue::cast<_mls_Tuple3>(_mls_x912)->_mls_field1;
      auto _mls_x994 = _mlsValue::cast<_mls_Tuple3>(_mls_x912)->_mls_field2;
      auto _mls_x995 = _mls_vecscale_case0_sr_post(_mls_x991, _mls_x992, _mls_x993, _mls_x994);
      _mls_x923 = _mls_x988;
      _mls_x924 = _mls_x995;
      _mls_x925 = _mls_x914;
      _mls_x926 = _mls_x910;
      _mls_x927 = _mls_x990;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_default:
  {
    auto _mls_x996 = _mls_specularsurf(_mls_x922);
    auto _mls_x997 = _mls_vecdot(_mls_x918, _mls_x916);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x919)) {
      auto _mls_x998 = _mlsValue::cast<_mls_Tuple3>(_mls_x919)->_mls_field0;
      auto _mls_x999 = _mlsValue::cast<_mls_Tuple3>(_mls_x919)->_mls_field1;
      auto _mls_x1000 = _mlsValue::cast<_mls_Tuple3>(_mls_x919)->_mls_field2;
      auto _mls_x1001 = _mls_vecscale_case0_sr_post(_mls_x920, _mls_x998, _mls_x999, _mls_x1000);
      _mls_x928 = _mls_x996;
      _mls_x929 = _mls_x921;
      _mls_x930 = _mls_x997;
      _mls_x931 = _mls_x917;
      _mls_x932 = _mls_x1001;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x924)) {
      auto _mls_x1002 = _mls_vecmult_case0(_mls_x924, _mls_x925);
      _mls_x933 = _mls_x1002;
      _mls_x934 = _mls_x926;
      _mls_x935 = _mls_x925;
      _mls_x936 = _mls_x923;
      _mls_x937 = _mls_x927;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x932)) {
      auto _mls_x1003 = _mls_vecmult_case0(_mls_x932, _mls_x929);
      _mls_x938 = _mls_x928;
      _mls_x939 = _mls_x929;
      _mls_x940 = _mls_x931;
      _mls_x941 = _mls_x1003;
      _mls_x942 = _mls_x930;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post:
  {
    auto _mls_x1004 = (_mls_x937 <= _mlsValue::create<_mls_Float>(0.0));
    if (_mlsValue::isIntLit(_mls_x1004, 1)) {
      auto _mls_x1009 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
      auto _mls_x1010 = _mls_vecadd(_mls_x933, _mls_x1009);
      _mls_retval = _mls_x1010;
    } else {
      auto _mls_x1005 = _mls_builtin_pow(_mls_x937, _mls_x934);
      auto _mls_x1006 = _mls_vecscale(_mls_x936, _mls_x1005);
      auto _mls_x1007 = _mls_vecmult(_mls_x1006, _mls_x935);
      auto _mls_x1008 = _mls_vecadd(_mls_x933, _mls_x1007);
      _mls_retval = _mls_x1008;
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post1:
  {
    auto _mls_x1011 = (_mls_x942 < _mlsValue::create<_mls_Float>(0.0));
    if (_mlsValue::isIntLit(_mls_x1011, 1)) {
      auto _mls_x1016 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
      auto _mls_x1017 = _mls_vecadd(_mls_x941, _mls_x1016);
      _mls_retval = _mls_x1017;
    } else {
      auto _mls_x1012 = _mls_builtin_pow(_mls_x942, _mls_x940);
      auto _mls_x1013 = _mls_vecscale(_mls_x938, _mls_x1012);
      auto _mls_x1014 = _mls_vecmult(_mls_x1013, _mls_x939);
      auto _mls_x1015 = _mls_vecadd(_mls_x941, _mls_x1014);
      _mls_retval = _mls_x1015;
    }
    return _mls_retval;
  }
}
_mlsValue _mls_lightray_caller_post_case0_sr_post(_mlsValue _mls_x886, _mlsValue _mls_x887, _mlsValue _mls_x888, _mlsValue _mls_x889, _mlsValue _mls_x890, _mlsValue _mls_x891) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x892, _mls_x893, _mls_x894, _mls_x895, _mls_x896;
  _mlsValue _mls_x897, _mls_x898, _mls_x899, _mls_x900, _mls_x901, _mls_x902;
  _mlsValue _mls_x903, _mls_x904, _mls_x905, _mls_x906, _mls_x907, _mls_x908;
  _mlsValue _mls_x909, _mls_x910, _mls_x911, _mls_x912, _mls_x913, _mls_x914, _mls_x915;
  _mlsValue _mls_x916, _mls_x917, _mls_x918, _mls_x919, _mls_x920, _mls_x921, _mls_x922;
  _mlsValue _mls_x923, _mls_x924, _mls_x925, _mls_x926, _mls_x927;
  _mlsValue _mls_x928, _mls_x929, _mls_x930, _mls_x931, _mls_x932;
  _mlsValue _mls_x933, _mls_x934, _mls_x935, _mls_x936, _mls_x937;
  _mlsValue _mls_x938, _mls_x939, _mls_x940, _mls_x941, _mls_x942;
  auto _mls_x955 = _mls_vecdot(_mls_x891, _mls_x887);
  auto _mls_x956 = _mls_lightcolour(_mls_x886);
  auto _mls_x957 = _mls_testspheres();
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x891)) {
    auto [_mls_x958, _mls_x959, _mls_x960, _mls_x961] = _mls_shadowed_case0_pre(_mls_x891, _mls_x956, _mls_x888, _mls_x957);
    auto _mls_x962 = _mls_shadowed_caller_post_post(_mls_x958, _mls_x959, _mls_x960, _mls_x961);
    _mls_x892 = _mls_x890;
    _mls_x893 = _mls_x962;
    _mls_x894 = _mls_x891;
    _mls_x895 = _mls_x889;
    _mls_x896 = _mls_x955;
    goto _mls_lightray_caller_post_caller_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_lightray_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x893)) {
      auto _mls_x963 = _mlsValue::cast<_mls_Tuple2>(_mls_x893)->_mls_field0;
      auto _mls_x964 = _mlsValue::cast<_mls_Tuple2>(_mls_x893)->_mls_field1;
      _mls_x897 = _mls_x896;
      _mls_x898 = _mls_x894;
      _mls_x899 = _mls_x964;
      _mls_x900 = _mls_x895;
      _mls_x901 = _mls_x963;
      _mls_x902 = _mls_x892;
      goto _mls_lightray_caller_post_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_sr_post:
  {
    if (_mlsValue::isIntLit(_mls_x901, 1)) {
      auto _mls_x979 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
      _mls_retval = _mls_x979;
    } else {
      auto [_mls_x965, _mls_x966, _mls_x967] = _mls_diffusesurf_pre(_mls_x900);
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x965)) {
        auto [_mls_x971, _mls_x972, _mls_x973, _mls_x974, _mls_x975, _mls_x976, _mls_x977, _mls_x978] = _mls_lightray_caller_post_caller_post_case0_caller_post_pre(_mls_x897, _mls_x898, _mls_x899, _mls_x900, _mls_x966, _mls_x902);
        if (_mlsValue::isIntLit(_mls_x976, 1)) {
          _mls_x909 = _mls_x971;
          _mls_x910 = _mls_x972;
          _mls_x911 = _mls_x973;
          _mls_x912 = _mls_x974;
          _mls_x913 = _mls_x975;
          _mls_x914 = _mls_x977;
          _mls_x915 = _mls_x978;
          goto _mls_lightray_caller_post_caller_post_case0_caller_post_case0;
        } else {
          _mls_x916 = _mls_x971;
          _mls_x917 = _mls_x972;
          _mls_x918 = _mls_x973;
          _mls_x919 = _mls_x974;
          _mls_x920 = _mls_x975;
          _mls_x921 = _mls_x977;
          _mls_x922 = _mls_x978;
          goto _mls_lightray_caller_post_caller_post_case0_caller_post_default;
        }
      } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x965)) {
        auto _mls_x968 = _mlsValue::cast<_mls_Cons>(_mls_x965)->_mls_head;
        auto _mls_x969 = _mlsValue::cast<_mls_Cons>(_mls_x965)->_mls_tail;
        auto _mls_x970 = _mls_diffusesurf_case1_sr_post(_mls_x969, _mls_x967, _mls_x968);
        _mls_x903 = _mls_x897;
        _mls_x904 = _mls_x898;
        _mls_x905 = _mls_x899;
        _mls_x906 = _mls_x900;
        _mls_x907 = _mls_x970;
        _mls_x908 = _mls_x902;
        goto _mls_lightray_caller_post_caller_post_case0_caller_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post:
  {
    auto [_mls_x980, _mls_x981, _mls_x982, _mls_x983, _mls_x984, _mls_x985, _mls_x986, _mls_x987] = _mls_lightray_caller_post_caller_post_case0_caller_post_pre(_mls_x903, _mls_x904, _mls_x905, _mls_x906, _mls_x907, _mls_x908);
    if (_mlsValue::isIntLit(_mls_x985, 1)) {
      _mls_x909 = _mls_x980;
      _mls_x910 = _mls_x981;
      _mls_x911 = _mls_x982;
      _mls_x912 = _mls_x983;
      _mls_x913 = _mls_x984;
      _mls_x914 = _mls_x986;
      _mls_x915 = _mls_x987;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_case0;
    } else {
      _mls_x916 = _mls_x980;
      _mls_x917 = _mls_x981;
      _mls_x918 = _mls_x982;
      _mls_x919 = _mls_x983;
      _mls_x920 = _mls_x984;
      _mls_x921 = _mls_x986;
      _mls_x922 = _mls_x987;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_default;
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_case0:
  {
    auto _mls_x988 = _mls_bodysurf(_mls_x915);
    auto _mls_x989 = _mls_vecdot(_mls_x911, _mls_x909);
    auto _mls_x990 = (-_mls_x989);
    auto _mls_x991 = (-_mls_x913);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x912)) {
      auto _mls_x992 = _mlsValue::cast<_mls_Tuple3>(_mls_x912)->_mls_field0;
      auto _mls_x993 = _mlsValue::cast<_mls_Tuple3>(_mls_x912)->_mls_field1;
      auto _mls_x994 = _mlsValue::cast<_mls_Tuple3>(_mls_x912)->_mls_field2;
      auto _mls_x995 = _mls_vecscale_case0_sr_post(_mls_x991, _mls_x992, _mls_x993, _mls_x994);
      _mls_x923 = _mls_x988;
      _mls_x924 = _mls_x995;
      _mls_x925 = _mls_x914;
      _mls_x926 = _mls_x910;
      _mls_x927 = _mls_x990;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_default:
  {
    auto _mls_x996 = _mls_specularsurf(_mls_x922);
    auto _mls_x997 = _mls_vecdot(_mls_x918, _mls_x916);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x919)) {
      auto _mls_x998 = _mlsValue::cast<_mls_Tuple3>(_mls_x919)->_mls_field0;
      auto _mls_x999 = _mlsValue::cast<_mls_Tuple3>(_mls_x919)->_mls_field1;
      auto _mls_x1000 = _mlsValue::cast<_mls_Tuple3>(_mls_x919)->_mls_field2;
      auto _mls_x1001 = _mls_vecscale_case0_sr_post(_mls_x920, _mls_x998, _mls_x999, _mls_x1000);
      _mls_x928 = _mls_x996;
      _mls_x929 = _mls_x921;
      _mls_x930 = _mls_x997;
      _mls_x931 = _mls_x917;
      _mls_x932 = _mls_x1001;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x924)) {
      auto _mls_x1002 = _mls_vecmult_case0(_mls_x924, _mls_x925);
      _mls_x933 = _mls_x1002;
      _mls_x934 = _mls_x926;
      _mls_x935 = _mls_x925;
      _mls_x936 = _mls_x923;
      _mls_x937 = _mls_x927;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x932)) {
      auto _mls_x1003 = _mls_vecmult_case0(_mls_x932, _mls_x929);
      _mls_x938 = _mls_x928;
      _mls_x939 = _mls_x929;
      _mls_x940 = _mls_x931;
      _mls_x941 = _mls_x1003;
      _mls_x942 = _mls_x930;
      goto _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post:
  {
    auto _mls_x1004 = (_mls_x937 <= _mlsValue::create<_mls_Float>(0.0));
    if (_mlsValue::isIntLit(_mls_x1004, 1)) {
      auto _mls_x1009 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
      auto _mls_x1010 = _mls_vecadd(_mls_x933, _mls_x1009);
      _mls_retval = _mls_x1010;
    } else {
      auto _mls_x1005 = _mls_builtin_pow(_mls_x937, _mls_x934);
      auto _mls_x1006 = _mls_vecscale(_mls_x936, _mls_x1005);
      auto _mls_x1007 = _mls_vecmult(_mls_x1006, _mls_x935);
      auto _mls_x1008 = _mls_vecadd(_mls_x933, _mls_x1007);
      _mls_retval = _mls_x1008;
    }
    return _mls_retval;
  }
  _mls_lightray_caller_post_caller_post_case0_caller_post_caller_post_caller_post1:
  {
    auto _mls_x1011 = (_mls_x942 < _mlsValue::create<_mls_Float>(0.0));
    if (_mlsValue::isIntLit(_mls_x1011, 1)) {
      auto _mls_x1016 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
      auto _mls_x1017 = _mls_vecadd(_mls_x941, _mls_x1016);
      _mls_retval = _mls_x1017;
    } else {
      auto _mls_x1012 = _mls_builtin_pow(_mls_x942, _mls_x940);
      auto _mls_x1013 = _mls_vecscale(_mls_x938, _mls_x1012);
      auto _mls_x1014 = _mls_vecmult(_mls_x1013, _mls_x939);
      auto _mls_x1015 = _mls_vecadd(_mls_x941, _mls_x1014);
      _mls_retval = _mls_x1015;
    }
    return _mls_retval;
  }
}
_mlsValue _mls_map(_mlsValue _mls_x1032, _mlsValue _mls_x1029) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1026, _mls_x1027, _mls_x1028;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1029)) {
    auto _mls_x1030 = _mlsValue::cast<_mls_Cons>(_mls_x1029)->_mls_head;
    auto _mls_x1031 = _mlsValue::cast<_mls_Cons>(_mls_x1029)->_mls_tail;
    _mls_x1026 = _mls_x1032;
    _mls_x1027 = _mls_x1030;
    _mls_x1028 = _mls_x1031;
    goto _mls_map_case0_sr_post;
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1029)) {
    goto _mls_map_case1;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_map_case0_sr_post:
  {
    auto _mls_x1033 = _mlsMethodCall<_mls_Callable>(_mls_x1026)->_mls_apply1(_mls_x1027);
    auto _mls_x1034 = _mls_map(_mls_x1026, _mls_x1028);
    auto _mls_x1035 = _mlsValue::create<_mls_Cons>(_mls_x1033, _mls_x1034);
    _mls_retval = _mls_x1035;
    return _mls_retval;
  }
  _mls_map_case1:
  {
    auto _mls_x1036 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x1036;
    return _mls_retval;
  }
}
_mlsValue _mls_map_case0(_mlsValue _mls_x1038, _mlsValue _mls_x1040) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1026, _mls_x1027, _mls_x1028;
  auto _mls_x1037 = _mlsValue::cast<_mls_Cons>(_mls_x1038)->_mls_head;
  auto _mls_x1039 = _mlsValue::cast<_mls_Cons>(_mls_x1038)->_mls_tail;
  _mls_x1026 = _mls_x1040;
  _mls_x1027 = _mls_x1037;
  _mls_x1028 = _mls_x1039;
  goto _mls_map_case0_sr_post;
  return _mls_retval;
  _mls_map_case0_sr_post:
  {
    auto _mls_x1033 = _mlsMethodCall<_mls_Callable>(_mls_x1026)->_mls_apply1(_mls_x1027);
    auto _mls_x1034 = _mls_map(_mls_x1026, _mls_x1028);
    auto _mls_x1035 = _mlsValue::create<_mls_Cons>(_mls_x1033, _mls_x1034);
    _mls_retval = _mls_x1035;
    return _mls_retval;
  }
}
_mlsValue _mls_map_case0_sr_post(_mlsValue _mls_x1026, _mlsValue _mls_x1027, _mlsValue _mls_x1028) {
  _mlsValue _mls_retval;
  auto _mls_x1033 = _mlsMethodCall<_mls_Callable>(_mls_x1026)->_mls_apply1(_mls_x1027);
  auto _mls_x1034 = _mls_map(_mls_x1026, _mls_x1028);
  auto _mls_x1035 = _mlsValue::create<_mls_Cons>(_mls_x1033, _mls_x1034);
  _mls_retval = _mls_x1035;
  return _mls_retval;
}
_mlsValue _mls_map_case1() {
  _mlsValue _mls_retval;
  auto _mls_x1036 = _mlsValue::create<_mls_Nil>();
  _mls_retval = _mls_x1036;
  return _mls_retval;
}
_mlsValue _mls_ray(_mlsValue _mls_winsize1) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1041, _mls_x1042, _mls_x1043;
  auto _mls_x261 = _mls_testlights();
  auto _mls_x262 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(2.1), _mlsValue::create<_mls_Float>(1.3), _mlsValue::create<_mls_Float>(1.7));
  auto _mls_x264 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(1.0));
  auto [_mls_x1044, _mls_x1045, _mls_x1046, _mls_x1047, _mls_x1048] = _mls_camparams_case0_case0_pre(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(45.0), _mls_winsize1, _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mls_x262, _mls_x264);
  auto _mls_x1049 = _mlsValue::cast<_mls_Tuple2>(_mls_x1046)->_mls_field0;
  auto _mls_x1050 = _mlsValue::cast<_mls_Tuple2>(_mls_x1046)->_mls_field1;
  auto _mls_x1051 = _mls_camparams_caller_post_caller_post_case0_sr_post(_mls_x1048, _mls_x1049, _mls_x1044, _mls_x1050, _mls_x1045, _mls_x1047);
  _mls_x1041 = _mls_x1051;
  _mls_x1042 = _mls_x261;
  _mls_x1043 = _mls_winsize1;
  goto _mls_ray_caller_post;
  return _mls_retval;
  _mls_ray_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1041)) {
      auto _mls_x1052 = _mlsValue::cast<_mls_Tuple3>(_mls_x1041)->_mls_field0;
      auto _mls_x1053 = _mlsValue::cast<_mls_Tuple3>(_mls_x1041)->_mls_field1;
      auto _mls_x1054 = _mlsValue::cast<_mls_Tuple3>(_mls_x1041)->_mls_field2;
      auto _mls_x1055 = _mlsValue::create<_mls_Lambda_f>(_mls_x1052, _mls_x1053, _mls_x1042, _mls_x1054);
      auto _mls_x1056 = _mlsValue::create<_mls_Lambda_lscomp1>(_mls_x1055, _mls_x1043);
      auto _mls_x1057 = (_mls_x1043 - _mlsValue::create<_mls_Float>(1.0));
      auto _mls_x1058 = _mls_enumFromTo(_mlsValue::create<_mls_Float>(0.0), _mls_x1057);
      auto _mls_x1059 = _mlsMethodCall<_mls_Callable>(_mls_x1056)->_mls_apply1(_mls_x1058);
      _mls_retval = _mls_x1059;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_ray_caller_post(_mlsValue _mls_x1041, _mlsValue _mls_x1042, _mlsValue _mls_x1043) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1041)) {
    auto _mls_x1052 = _mlsValue::cast<_mls_Tuple3>(_mls_x1041)->_mls_field0;
    auto _mls_x1053 = _mlsValue::cast<_mls_Tuple3>(_mls_x1041)->_mls_field1;
    auto _mls_x1054 = _mlsValue::cast<_mls_Tuple3>(_mls_x1041)->_mls_field2;
    auto _mls_x1055 = _mlsValue::create<_mls_Lambda_f>(_mls_x1052, _mls_x1053, _mls_x1042, _mls_x1054);
    auto _mls_x1056 = _mlsValue::create<_mls_Lambda_lscomp1>(_mls_x1055, _mls_x1043);
    auto _mls_x1057 = (_mls_x1043 - _mlsValue::create<_mls_Float>(1.0));
    auto _mls_x1058 = _mls_enumFromTo(_mlsValue::create<_mls_Float>(0.0), _mls_x1057);
    auto _mls_x1059 = _mlsMethodCall<_mls_Callable>(_mls_x1056)->_mls_apply1(_mls_x1058);
    _mls_retval = _mls_x1059;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_reflectray(_mlsValue _mls_pos2, _mlsValue _mls_newdir, _mlsValue _mls_lights2, _mlsValue _mls_intens2, _mlsValue _mls_contrib2, _mlsValue _mls_colour2) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1060, _mls_x1061, _mls_x1062, _mls_x1063, _mls_x1064, _mls_x1065;
  _mlsValue _mls_x1066, _mls_x1067, _mls_x1068, _mls_x1069, _mls_x1070, _mls_x1071;
  _mlsValue _mls_x1072, _mls_x1073, _mls_x1074, _mls_x1075, _mls_x1076, _mls_x1077, _mls_x1078;
  _mlsValue _mls_x1079, _mls_x1080, _mls_x1081, _mls_x1082, _mls_x1083, _mls_x1084, _mls_x1085, _mls_x1086, _mls_x1087;
  _mlsValue _mls_x727, _mls_x730, _mls_x731, _mls_x729;
  _mlsValue _mls_x722, _mls_x723, _mls_x724, _mls_x725, _mls_x726;
  _mlsValue _mls_x719, _mls_x720, _mls_x721;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_intens2)) {
    auto _mls_x1088 = _mlsValue::cast<_mls_Tuple3>(_mls_intens2)->_mls_field0;
    auto _mls_x1089 = _mlsValue::cast<_mls_Tuple3>(_mls_intens2)->_mls_field1;
    auto _mls_x1090 = _mlsValue::cast<_mls_Tuple3>(_mls_intens2)->_mls_field2;
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_contrib2)) {
      auto _mls_x1091 = _mlsValue::cast<_mls_Tuple3>(_mls_contrib2)->_mls_field0;
      auto _mls_x1092 = _mlsValue::cast<_mls_Tuple3>(_mls_contrib2)->_mls_field1;
      auto _mls_x1093 = _mlsValue::cast<_mls_Tuple3>(_mls_contrib2)->_mls_field2;
      auto _mls_x1094 = _mls_vecmult_case0_sr_post_case0_sr_post(_mls_x1093, _mls_x1089, _mls_x1092, _mls_x1090, _mls_x1088, _mls_x1091);
      _mls_x1060 = _mls_newdir;
      _mls_x1061 = _mls_pos2;
      _mls_x1062 = _mls_intens2;
      _mls_x1063 = _mls_x1094;
      _mls_x1064 = _mls_colour2;
      _mls_x1065 = _mls_lights2;
      goto _mls_reflectray_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_reflectray_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1060)) {
      auto _mls_x1095 = _mlsValue::cast<_mls_Tuple3>(_mls_x1060)->_mls_field0;
      auto _mls_x1096 = _mlsValue::cast<_mls_Tuple3>(_mls_x1060)->_mls_field1;
      auto _mls_x1097 = _mlsValue::cast<_mls_Tuple3>(_mls_x1060)->_mls_field2;
      auto _mls_x1098 = _mls_vecscale_case0_sr_post(_mlsValue::create<_mls_Float>(1.0E-6), _mls_x1095, _mls_x1096, _mls_x1097);
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1061)) {
        auto _mls_x1099 = _mlsValue::cast<_mls_Tuple3>(_mls_x1061)->_mls_field0;
        auto _mls_x1102 = _mlsValue::cast<_mls_Tuple3>(_mls_x1061)->_mls_field1;
        auto _mls_x1103 = _mlsValue::cast<_mls_Tuple3>(_mls_x1061)->_mls_field2;
        auto _mls_x1104 = _mls_vecadd_case0_sr_post_case0(_mls_x1098, _mls_x1099, _mls_x1102, _mls_x1103);
        _mls_x1066 = _mls_x1062;
        _mls_x1067 = _mls_x1060;
        _mls_x1068 = _mls_x1064;
        _mls_x1069 = _mls_x1063;
        _mls_x1070 = _mls_x1065;
        _mls_x1071 = _mls_x1104;
        goto _mls_reflectray_caller_post_caller_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_reflectray_caller_post_caller_post:
  {
    auto _mls_x1105 = _mls_testspheres();
    auto [_mls_x1106, _mls_x1107, _mls_x1108] = _mls_trace_pre(_mls_x1105, _mls_x1071, _mls_x1067);
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1106)) {
      auto _mls_x1113 = _mls_trace_caller_post_case0(_mls_x1107);
      auto _mls_x1114 = _mlsValue::cast<_mls_Tuple3>(_mls_x1113)->_mls_field0;
      auto _mls_x1115 = _mlsValue::cast<_mls_Tuple3>(_mls_x1113)->_mls_field1;
      auto _mls_x1116 = _mlsValue::cast<_mls_Tuple3>(_mls_x1113)->_mls_field2;
      _mls_x1079 = _mls_x1067;
      _mls_x1080 = _mls_x1069;
      _mls_x1081 = _mls_x1068;
      _mls_x1082 = _mls_x1114;
      _mls_x1083 = _mls_x1070;
      _mls_x1084 = _mls_x1115;
      _mls_x1085 = _mls_x1066;
      _mls_x1086 = _mls_x1071;
      _mls_x1087 = _mls_x1116;
      goto _mls_reflectray_caller_post_caller_post_case0_sr_post;
    } else {
      auto _mls_x1109 = _mls_trace_caller_post_default_pre(_mls_x1106, _mls_x1108);
      if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x1109)) {
        auto _mls_x1110 = _mlsValue::cast<_mls_Tuple2>(_mls_x1109)->_mls_field0;
        auto _mls_x1111 = _mlsValue::cast<_mls_Tuple2>(_mls_x1109)->_mls_field1;
        auto _mls_x1112 = _mls_trace_caller_post_default_case0_sr_post(_mls_x1110, _mls_x1111);
        _mls_x1072 = _mls_x1066;
        _mls_x1073 = _mls_x1067;
        _mls_x1074 = _mls_x1068;
        _mls_x1075 = _mls_x1112;
        _mls_x1076 = _mls_x1069;
        _mls_x1077 = _mls_x1070;
        _mls_x1078 = _mls_x1071;
        goto _mls_reflectray_caller_post_caller_post1;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    }
    return _mls_retval;
  }
  _mls_reflectray_caller_post_caller_post1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1075)) {
      auto _mls_x1117 = _mlsValue::cast<_mls_Tuple3>(_mls_x1075)->_mls_field0;
      auto _mls_x1118 = _mlsValue::cast<_mls_Tuple3>(_mls_x1075)->_mls_field1;
      auto _mls_x1119 = _mlsValue::cast<_mls_Tuple3>(_mls_x1075)->_mls_field2;
      _mls_x1079 = _mls_x1073;
      _mls_x1080 = _mls_x1076;
      _mls_x1081 = _mls_x1074;
      _mls_x1082 = _mls_x1117;
      _mls_x1083 = _mls_x1077;
      _mls_x1084 = _mls_x1118;
      _mls_x1085 = _mls_x1072;
      _mls_x1086 = _mls_x1078;
      _mls_x1087 = _mls_x1119;
      goto _mls_reflectray_caller_post_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_reflectray_caller_post_caller_post_case0_sr_post:
  {
    if (_mlsValue::isIntLit(_mls_x1082, 1)) {
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1079)) {
        auto [_mls_x1121, _mls_x1122, _mls_x1123, _mls_x1124, _mls_x1125, _mls_x1126] = _mls_shade_case0_pre(_mls_x1087, _mls_x1084, _mls_x1080, _mls_x1083, _mls_x1079, _mls_x1086);
        auto _mls_x1127 = _mls_shade_caller_post(_mls_x1122, _mls_x1124, _mls_x1123, _mls_x1126, _mls_x1121, _mls_x1125);
        _mls_x727 = _mls_x1080;
        _mls_x730 = _mls_x1085;
        _mls_x731 = _mls_x1081;
        _mls_x729 = _mls_x1127;
        goto _mls_j1;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      auto _mls_x1120 = _mls_is_zerovector(_mls_x1080);
      if (_mlsValue::isIntLit(_mls_x1120, 1)) {
        _mls_retval = _mls_x1081;
      } else {
        _mls_x722 = _mls_x1085;
        _mls_x723 = _mls_x1081;
        _mls_x724 = _mlsValue::create<_mls_Float>(0.078);
        _mls_x725 = _mlsValue::create<_mls_Float>(0.361);
        _mls_x726 = _mlsValue::create<_mls_Float>(0.753);
        goto _mls_j_default_case0_sr_post;
      }
    }
    return _mls_retval;
  }
  _mls_j1:
  {
    auto _mls_x728 = _mls_is_zerovector(_mls_x727);
    if (_mlsValue::isIntLit(_mls_x728, 1)) {
      _mls_retval = _mls_x731;
    } else {
      _mls_x719 = _mls_x729;
      _mls_x720 = _mls_x730;
      _mls_x721 = _mls_x731;
      goto _mls_j_default;
    }
    return _mls_retval;
  }
  _mls_j_default_case0_sr_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x722)) {
      auto _mls_x735 = _mlsValue::cast<_mls_Tuple3>(_mls_x722)->_mls_field0;
      auto _mls_x736 = _mlsValue::cast<_mls_Tuple3>(_mls_x722)->_mls_field1;
      auto _mls_x737 = _mlsValue::cast<_mls_Tuple3>(_mls_x722)->_mls_field2;
      auto _mls_x738 = _mls_vecmult_case0_sr_post_case0_sr_post(_mls_x737, _mls_x725, _mls_x736, _mls_x726, _mls_x724, _mls_x735);
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x723)) {
        auto _mls_x739 = _mls_vecadd_case0(_mls_x723, _mls_x738);
        _mls_retval = _mls_x739;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_default:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x719)) {
      auto _mls_x732 = _mlsValue::cast<_mls_Tuple3>(_mls_x719)->_mls_field0;
      auto _mls_x733 = _mlsValue::cast<_mls_Tuple3>(_mls_x719)->_mls_field1;
      auto _mls_x734 = _mlsValue::cast<_mls_Tuple3>(_mls_x719)->_mls_field2;
      _mls_x722 = _mls_x720;
      _mls_x723 = _mls_x721;
      _mls_x724 = _mls_x732;
      _mls_x725 = _mls_x733;
      _mls_x726 = _mls_x734;
      goto _mls_j_default_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_reflectray_caller_post(_mlsValue _mls_x1060, _mlsValue _mls_x1061, _mlsValue _mls_x1062, _mlsValue _mls_x1063, _mlsValue _mls_x1064, _mlsValue _mls_x1065) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1066, _mls_x1067, _mls_x1068, _mls_x1069, _mls_x1070, _mls_x1071;
  _mlsValue _mls_x1072, _mls_x1073, _mls_x1074, _mls_x1075, _mls_x1076, _mls_x1077, _mls_x1078;
  _mlsValue _mls_x1079, _mls_x1080, _mls_x1081, _mls_x1082, _mls_x1083, _mls_x1084, _mls_x1085, _mls_x1086, _mls_x1087;
  _mlsValue _mls_x727, _mls_x730, _mls_x731, _mls_x729;
  _mlsValue _mls_x722, _mls_x723, _mls_x724, _mls_x725, _mls_x726;
  _mlsValue _mls_x719, _mls_x720, _mls_x721;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1060)) {
    auto _mls_x1095 = _mlsValue::cast<_mls_Tuple3>(_mls_x1060)->_mls_field0;
    auto _mls_x1096 = _mlsValue::cast<_mls_Tuple3>(_mls_x1060)->_mls_field1;
    auto _mls_x1097 = _mlsValue::cast<_mls_Tuple3>(_mls_x1060)->_mls_field2;
    auto _mls_x1098 = _mls_vecscale_case0_sr_post(_mlsValue::create<_mls_Float>(1.0E-6), _mls_x1095, _mls_x1096, _mls_x1097);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1061)) {
      auto _mls_x1099 = _mlsValue::cast<_mls_Tuple3>(_mls_x1061)->_mls_field0;
      auto _mls_x1102 = _mlsValue::cast<_mls_Tuple3>(_mls_x1061)->_mls_field1;
      auto _mls_x1103 = _mlsValue::cast<_mls_Tuple3>(_mls_x1061)->_mls_field2;
      auto _mls_x1104 = _mls_vecadd_case0_sr_post_case0(_mls_x1098, _mls_x1099, _mls_x1102, _mls_x1103);
      _mls_x1066 = _mls_x1062;
      _mls_x1067 = _mls_x1060;
      _mls_x1068 = _mls_x1064;
      _mls_x1069 = _mls_x1063;
      _mls_x1070 = _mls_x1065;
      _mls_x1071 = _mls_x1104;
      goto _mls_reflectray_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_reflectray_caller_post_caller_post:
  {
    auto _mls_x1105 = _mls_testspheres();
    auto [_mls_x1106, _mls_x1107, _mls_x1108] = _mls_trace_pre(_mls_x1105, _mls_x1071, _mls_x1067);
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1106)) {
      auto _mls_x1113 = _mls_trace_caller_post_case0(_mls_x1107);
      auto _mls_x1114 = _mlsValue::cast<_mls_Tuple3>(_mls_x1113)->_mls_field0;
      auto _mls_x1115 = _mlsValue::cast<_mls_Tuple3>(_mls_x1113)->_mls_field1;
      auto _mls_x1116 = _mlsValue::cast<_mls_Tuple3>(_mls_x1113)->_mls_field2;
      _mls_x1079 = _mls_x1067;
      _mls_x1080 = _mls_x1069;
      _mls_x1081 = _mls_x1068;
      _mls_x1082 = _mls_x1114;
      _mls_x1083 = _mls_x1070;
      _mls_x1084 = _mls_x1115;
      _mls_x1085 = _mls_x1066;
      _mls_x1086 = _mls_x1071;
      _mls_x1087 = _mls_x1116;
      goto _mls_reflectray_caller_post_caller_post_case0_sr_post;
    } else {
      auto _mls_x1109 = _mls_trace_caller_post_default_pre(_mls_x1106, _mls_x1108);
      if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x1109)) {
        auto _mls_x1110 = _mlsValue::cast<_mls_Tuple2>(_mls_x1109)->_mls_field0;
        auto _mls_x1111 = _mlsValue::cast<_mls_Tuple2>(_mls_x1109)->_mls_field1;
        auto _mls_x1112 = _mls_trace_caller_post_default_case0_sr_post(_mls_x1110, _mls_x1111);
        _mls_x1072 = _mls_x1066;
        _mls_x1073 = _mls_x1067;
        _mls_x1074 = _mls_x1068;
        _mls_x1075 = _mls_x1112;
        _mls_x1076 = _mls_x1069;
        _mls_x1077 = _mls_x1070;
        _mls_x1078 = _mls_x1071;
        goto _mls_reflectray_caller_post_caller_post1;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    }
    return _mls_retval;
  }
  _mls_reflectray_caller_post_caller_post1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1075)) {
      auto _mls_x1117 = _mlsValue::cast<_mls_Tuple3>(_mls_x1075)->_mls_field0;
      auto _mls_x1118 = _mlsValue::cast<_mls_Tuple3>(_mls_x1075)->_mls_field1;
      auto _mls_x1119 = _mlsValue::cast<_mls_Tuple3>(_mls_x1075)->_mls_field2;
      _mls_x1079 = _mls_x1073;
      _mls_x1080 = _mls_x1076;
      _mls_x1081 = _mls_x1074;
      _mls_x1082 = _mls_x1117;
      _mls_x1083 = _mls_x1077;
      _mls_x1084 = _mls_x1118;
      _mls_x1085 = _mls_x1072;
      _mls_x1086 = _mls_x1078;
      _mls_x1087 = _mls_x1119;
      goto _mls_reflectray_caller_post_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_reflectray_caller_post_caller_post_case0_sr_post:
  {
    if (_mlsValue::isIntLit(_mls_x1082, 1)) {
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1079)) {
        auto [_mls_x1121, _mls_x1122, _mls_x1123, _mls_x1124, _mls_x1125, _mls_x1126] = _mls_shade_case0_pre(_mls_x1087, _mls_x1084, _mls_x1080, _mls_x1083, _mls_x1079, _mls_x1086);
        auto _mls_x1127 = _mls_shade_caller_post(_mls_x1122, _mls_x1124, _mls_x1123, _mls_x1126, _mls_x1121, _mls_x1125);
        _mls_x727 = _mls_x1080;
        _mls_x730 = _mls_x1085;
        _mls_x731 = _mls_x1081;
        _mls_x729 = _mls_x1127;
        goto _mls_j1;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      auto _mls_x1120 = _mls_is_zerovector(_mls_x1080);
      if (_mlsValue::isIntLit(_mls_x1120, 1)) {
        _mls_retval = _mls_x1081;
      } else {
        _mls_x722 = _mls_x1085;
        _mls_x723 = _mls_x1081;
        _mls_x724 = _mlsValue::create<_mls_Float>(0.078);
        _mls_x725 = _mlsValue::create<_mls_Float>(0.361);
        _mls_x726 = _mlsValue::create<_mls_Float>(0.753);
        goto _mls_j_default_case0_sr_post;
      }
    }
    return _mls_retval;
  }
  _mls_j1:
  {
    auto _mls_x728 = _mls_is_zerovector(_mls_x727);
    if (_mlsValue::isIntLit(_mls_x728, 1)) {
      _mls_retval = _mls_x731;
    } else {
      _mls_x719 = _mls_x729;
      _mls_x720 = _mls_x730;
      _mls_x721 = _mls_x731;
      goto _mls_j_default;
    }
    return _mls_retval;
  }
  _mls_j_default_case0_sr_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x722)) {
      auto _mls_x735 = _mlsValue::cast<_mls_Tuple3>(_mls_x722)->_mls_field0;
      auto _mls_x736 = _mlsValue::cast<_mls_Tuple3>(_mls_x722)->_mls_field1;
      auto _mls_x737 = _mlsValue::cast<_mls_Tuple3>(_mls_x722)->_mls_field2;
      auto _mls_x738 = _mls_vecmult_case0_sr_post_case0_sr_post(_mls_x737, _mls_x725, _mls_x736, _mls_x726, _mls_x724, _mls_x735);
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x723)) {
        auto _mls_x739 = _mls_vecadd_case0(_mls_x723, _mls_x738);
        _mls_retval = _mls_x739;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_default:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x719)) {
      auto _mls_x732 = _mlsValue::cast<_mls_Tuple3>(_mls_x719)->_mls_field0;
      auto _mls_x733 = _mlsValue::cast<_mls_Tuple3>(_mls_x719)->_mls_field1;
      auto _mls_x734 = _mlsValue::cast<_mls_Tuple3>(_mls_x719)->_mls_field2;
      _mls_x722 = _mls_x720;
      _mls_x723 = _mls_x721;
      _mls_x724 = _mls_x732;
      _mls_x725 = _mls_x733;
      _mls_x726 = _mls_x734;
      goto _mls_j_default_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_reflectray_caller_post_caller_post(_mlsValue _mls_x1066, _mlsValue _mls_x1067, _mlsValue _mls_x1068, _mlsValue _mls_x1069, _mlsValue _mls_x1070, _mlsValue _mls_x1071) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1072, _mls_x1073, _mls_x1074, _mls_x1075, _mls_x1076, _mls_x1077, _mls_x1078;
  _mlsValue _mls_x1079, _mls_x1080, _mls_x1081, _mls_x1082, _mls_x1083, _mls_x1084, _mls_x1085, _mls_x1086, _mls_x1087;
  _mlsValue _mls_x727, _mls_x730, _mls_x731, _mls_x729;
  _mlsValue _mls_x722, _mls_x723, _mls_x724, _mls_x725, _mls_x726;
  _mlsValue _mls_x719, _mls_x720, _mls_x721;
  auto _mls_x1105 = _mls_testspheres();
  auto [_mls_x1106, _mls_x1107, _mls_x1108] = _mls_trace_pre(_mls_x1105, _mls_x1071, _mls_x1067);
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1106)) {
    auto _mls_x1113 = _mls_trace_caller_post_case0(_mls_x1107);
    auto _mls_x1114 = _mlsValue::cast<_mls_Tuple3>(_mls_x1113)->_mls_field0;
    auto _mls_x1115 = _mlsValue::cast<_mls_Tuple3>(_mls_x1113)->_mls_field1;
    auto _mls_x1116 = _mlsValue::cast<_mls_Tuple3>(_mls_x1113)->_mls_field2;
    _mls_x1079 = _mls_x1067;
    _mls_x1080 = _mls_x1069;
    _mls_x1081 = _mls_x1068;
    _mls_x1082 = _mls_x1114;
    _mls_x1083 = _mls_x1070;
    _mls_x1084 = _mls_x1115;
    _mls_x1085 = _mls_x1066;
    _mls_x1086 = _mls_x1071;
    _mls_x1087 = _mls_x1116;
    goto _mls_reflectray_caller_post_caller_post_case0_sr_post;
  } else {
    auto _mls_x1109 = _mls_trace_caller_post_default_pre(_mls_x1106, _mls_x1108);
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x1109)) {
      auto _mls_x1110 = _mlsValue::cast<_mls_Tuple2>(_mls_x1109)->_mls_field0;
      auto _mls_x1111 = _mlsValue::cast<_mls_Tuple2>(_mls_x1109)->_mls_field1;
      auto _mls_x1112 = _mls_trace_caller_post_default_case0_sr_post(_mls_x1110, _mls_x1111);
      _mls_x1072 = _mls_x1066;
      _mls_x1073 = _mls_x1067;
      _mls_x1074 = _mls_x1068;
      _mls_x1075 = _mls_x1112;
      _mls_x1076 = _mls_x1069;
      _mls_x1077 = _mls_x1070;
      _mls_x1078 = _mls_x1071;
      goto _mls_reflectray_caller_post_caller_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  }
  return _mls_retval;
  _mls_reflectray_caller_post_caller_post1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1075)) {
      auto _mls_x1117 = _mlsValue::cast<_mls_Tuple3>(_mls_x1075)->_mls_field0;
      auto _mls_x1118 = _mlsValue::cast<_mls_Tuple3>(_mls_x1075)->_mls_field1;
      auto _mls_x1119 = _mlsValue::cast<_mls_Tuple3>(_mls_x1075)->_mls_field2;
      _mls_x1079 = _mls_x1073;
      _mls_x1080 = _mls_x1076;
      _mls_x1081 = _mls_x1074;
      _mls_x1082 = _mls_x1117;
      _mls_x1083 = _mls_x1077;
      _mls_x1084 = _mls_x1118;
      _mls_x1085 = _mls_x1072;
      _mls_x1086 = _mls_x1078;
      _mls_x1087 = _mls_x1119;
      goto _mls_reflectray_caller_post_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_reflectray_caller_post_caller_post_case0_sr_post:
  {
    if (_mlsValue::isIntLit(_mls_x1082, 1)) {
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1079)) {
        auto [_mls_x1121, _mls_x1122, _mls_x1123, _mls_x1124, _mls_x1125, _mls_x1126] = _mls_shade_case0_pre(_mls_x1087, _mls_x1084, _mls_x1080, _mls_x1083, _mls_x1079, _mls_x1086);
        auto _mls_x1127 = _mls_shade_caller_post(_mls_x1122, _mls_x1124, _mls_x1123, _mls_x1126, _mls_x1121, _mls_x1125);
        _mls_x727 = _mls_x1080;
        _mls_x730 = _mls_x1085;
        _mls_x731 = _mls_x1081;
        _mls_x729 = _mls_x1127;
        goto _mls_j1;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      auto _mls_x1120 = _mls_is_zerovector(_mls_x1080);
      if (_mlsValue::isIntLit(_mls_x1120, 1)) {
        _mls_retval = _mls_x1081;
      } else {
        _mls_x722 = _mls_x1085;
        _mls_x723 = _mls_x1081;
        _mls_x724 = _mlsValue::create<_mls_Float>(0.078);
        _mls_x725 = _mlsValue::create<_mls_Float>(0.361);
        _mls_x726 = _mlsValue::create<_mls_Float>(0.753);
        goto _mls_j_default_case0_sr_post;
      }
    }
    return _mls_retval;
  }
  _mls_j1:
  {
    auto _mls_x728 = _mls_is_zerovector(_mls_x727);
    if (_mlsValue::isIntLit(_mls_x728, 1)) {
      _mls_retval = _mls_x731;
    } else {
      _mls_x719 = _mls_x729;
      _mls_x720 = _mls_x730;
      _mls_x721 = _mls_x731;
      goto _mls_j_default;
    }
    return _mls_retval;
  }
  _mls_j_default_case0_sr_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x722)) {
      auto _mls_x735 = _mlsValue::cast<_mls_Tuple3>(_mls_x722)->_mls_field0;
      auto _mls_x736 = _mlsValue::cast<_mls_Tuple3>(_mls_x722)->_mls_field1;
      auto _mls_x737 = _mlsValue::cast<_mls_Tuple3>(_mls_x722)->_mls_field2;
      auto _mls_x738 = _mls_vecmult_case0_sr_post_case0_sr_post(_mls_x737, _mls_x725, _mls_x736, _mls_x726, _mls_x724, _mls_x735);
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x723)) {
        auto _mls_x739 = _mls_vecadd_case0(_mls_x723, _mls_x738);
        _mls_retval = _mls_x739;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_default:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x719)) {
      auto _mls_x732 = _mlsValue::cast<_mls_Tuple3>(_mls_x719)->_mls_field0;
      auto _mls_x733 = _mlsValue::cast<_mls_Tuple3>(_mls_x719)->_mls_field1;
      auto _mls_x734 = _mlsValue::cast<_mls_Tuple3>(_mls_x719)->_mls_field2;
      _mls_x722 = _mls_x720;
      _mls_x723 = _mls_x721;
      _mls_x724 = _mls_x732;
      _mls_x725 = _mls_x733;
      _mls_x726 = _mls_x734;
      goto _mls_j_default_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_reflectray_caller_post_caller_post1(_mlsValue _mls_x1072, _mlsValue _mls_x1073, _mlsValue _mls_x1074, _mlsValue _mls_x1075, _mlsValue _mls_x1076, _mlsValue _mls_x1077, _mlsValue _mls_x1078) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1079, _mls_x1080, _mls_x1081, _mls_x1082, _mls_x1083, _mls_x1084, _mls_x1085, _mls_x1086, _mls_x1087;
  _mlsValue _mls_x727, _mls_x730, _mls_x731, _mls_x729;
  _mlsValue _mls_x722, _mls_x723, _mls_x724, _mls_x725, _mls_x726;
  _mlsValue _mls_x719, _mls_x720, _mls_x721;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1075)) {
    auto _mls_x1117 = _mlsValue::cast<_mls_Tuple3>(_mls_x1075)->_mls_field0;
    auto _mls_x1118 = _mlsValue::cast<_mls_Tuple3>(_mls_x1075)->_mls_field1;
    auto _mls_x1119 = _mlsValue::cast<_mls_Tuple3>(_mls_x1075)->_mls_field2;
    _mls_x1079 = _mls_x1073;
    _mls_x1080 = _mls_x1076;
    _mls_x1081 = _mls_x1074;
    _mls_x1082 = _mls_x1117;
    _mls_x1083 = _mls_x1077;
    _mls_x1084 = _mls_x1118;
    _mls_x1085 = _mls_x1072;
    _mls_x1086 = _mls_x1078;
    _mls_x1087 = _mls_x1119;
    goto _mls_reflectray_caller_post_caller_post_case0_sr_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_reflectray_caller_post_caller_post_case0_sr_post:
  {
    if (_mlsValue::isIntLit(_mls_x1082, 1)) {
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1079)) {
        auto [_mls_x1121, _mls_x1122, _mls_x1123, _mls_x1124, _mls_x1125, _mls_x1126] = _mls_shade_case0_pre(_mls_x1087, _mls_x1084, _mls_x1080, _mls_x1083, _mls_x1079, _mls_x1086);
        auto _mls_x1127 = _mls_shade_caller_post(_mls_x1122, _mls_x1124, _mls_x1123, _mls_x1126, _mls_x1121, _mls_x1125);
        _mls_x727 = _mls_x1080;
        _mls_x730 = _mls_x1085;
        _mls_x731 = _mls_x1081;
        _mls_x729 = _mls_x1127;
        goto _mls_j1;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      auto _mls_x1120 = _mls_is_zerovector(_mls_x1080);
      if (_mlsValue::isIntLit(_mls_x1120, 1)) {
        _mls_retval = _mls_x1081;
      } else {
        _mls_x722 = _mls_x1085;
        _mls_x723 = _mls_x1081;
        _mls_x724 = _mlsValue::create<_mls_Float>(0.078);
        _mls_x725 = _mlsValue::create<_mls_Float>(0.361);
        _mls_x726 = _mlsValue::create<_mls_Float>(0.753);
        goto _mls_j_default_case0_sr_post;
      }
    }
    return _mls_retval;
  }
  _mls_j1:
  {
    auto _mls_x728 = _mls_is_zerovector(_mls_x727);
    if (_mlsValue::isIntLit(_mls_x728, 1)) {
      _mls_retval = _mls_x731;
    } else {
      _mls_x719 = _mls_x729;
      _mls_x720 = _mls_x730;
      _mls_x721 = _mls_x731;
      goto _mls_j_default;
    }
    return _mls_retval;
  }
  _mls_j_default_case0_sr_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x722)) {
      auto _mls_x735 = _mlsValue::cast<_mls_Tuple3>(_mls_x722)->_mls_field0;
      auto _mls_x736 = _mlsValue::cast<_mls_Tuple3>(_mls_x722)->_mls_field1;
      auto _mls_x737 = _mlsValue::cast<_mls_Tuple3>(_mls_x722)->_mls_field2;
      auto _mls_x738 = _mls_vecmult_case0_sr_post_case0_sr_post(_mls_x737, _mls_x725, _mls_x736, _mls_x726, _mls_x724, _mls_x735);
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x723)) {
        auto _mls_x739 = _mls_vecadd_case0(_mls_x723, _mls_x738);
        _mls_retval = _mls_x739;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_default:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x719)) {
      auto _mls_x732 = _mlsValue::cast<_mls_Tuple3>(_mls_x719)->_mls_field0;
      auto _mls_x733 = _mlsValue::cast<_mls_Tuple3>(_mls_x719)->_mls_field1;
      auto _mls_x734 = _mlsValue::cast<_mls_Tuple3>(_mls_x719)->_mls_field2;
      _mls_x722 = _mls_x720;
      _mls_x723 = _mls_x721;
      _mls_x724 = _mls_x732;
      _mls_x725 = _mls_x733;
      _mls_x726 = _mls_x734;
      goto _mls_j_default_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_reflectray_caller_post_caller_post_case0_sr_post(_mlsValue _mls_x1079, _mlsValue _mls_x1080, _mlsValue _mls_x1081, _mlsValue _mls_x1082, _mlsValue _mls_x1083, _mlsValue _mls_x1084, _mlsValue _mls_x1085, _mlsValue _mls_x1086, _mlsValue _mls_x1087) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x727, _mls_x730, _mls_x731, _mls_x729;
  _mlsValue _mls_x722, _mls_x723, _mls_x724, _mls_x725, _mls_x726;
  _mlsValue _mls_x719, _mls_x720, _mls_x721;
  if (_mlsValue::isIntLit(_mls_x1082, 1)) {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1079)) {
      auto [_mls_x1121, _mls_x1122, _mls_x1123, _mls_x1124, _mls_x1125, _mls_x1126] = _mls_shade_case0_pre(_mls_x1087, _mls_x1084, _mls_x1080, _mls_x1083, _mls_x1079, _mls_x1086);
      auto _mls_x1127 = _mls_shade_caller_post(_mls_x1122, _mls_x1124, _mls_x1123, _mls_x1126, _mls_x1121, _mls_x1125);
      _mls_x727 = _mls_x1080;
      _mls_x730 = _mls_x1085;
      _mls_x731 = _mls_x1081;
      _mls_x729 = _mls_x1127;
      goto _mls_j1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    auto _mls_x1120 = _mls_is_zerovector(_mls_x1080);
    if (_mlsValue::isIntLit(_mls_x1120, 1)) {
      _mls_retval = _mls_x1081;
    } else {
      _mls_x722 = _mls_x1085;
      _mls_x723 = _mls_x1081;
      _mls_x724 = _mlsValue::create<_mls_Float>(0.078);
      _mls_x725 = _mlsValue::create<_mls_Float>(0.361);
      _mls_x726 = _mlsValue::create<_mls_Float>(0.753);
      goto _mls_j_default_case0_sr_post;
    }
  }
  return _mls_retval;
  _mls_j1:
  {
    auto _mls_x728 = _mls_is_zerovector(_mls_x727);
    if (_mlsValue::isIntLit(_mls_x728, 1)) {
      _mls_retval = _mls_x731;
    } else {
      _mls_x719 = _mls_x729;
      _mls_x720 = _mls_x730;
      _mls_x721 = _mls_x731;
      goto _mls_j_default;
    }
    return _mls_retval;
  }
  _mls_j_default_case0_sr_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x722)) {
      auto _mls_x735 = _mlsValue::cast<_mls_Tuple3>(_mls_x722)->_mls_field0;
      auto _mls_x736 = _mlsValue::cast<_mls_Tuple3>(_mls_x722)->_mls_field1;
      auto _mls_x737 = _mlsValue::cast<_mls_Tuple3>(_mls_x722)->_mls_field2;
      auto _mls_x738 = _mls_vecmult_case0_sr_post_case0_sr_post(_mls_x737, _mls_x725, _mls_x736, _mls_x726, _mls_x724, _mls_x735);
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x723)) {
        auto _mls_x739 = _mls_vecadd_case0(_mls_x723, _mls_x738);
        _mls_retval = _mls_x739;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_default:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x719)) {
      auto _mls_x732 = _mlsValue::cast<_mls_Tuple3>(_mls_x719)->_mls_field0;
      auto _mls_x733 = _mlsValue::cast<_mls_Tuple3>(_mls_x719)->_mls_field1;
      auto _mls_x734 = _mlsValue::cast<_mls_Tuple3>(_mls_x719)->_mls_field2;
      _mls_x722 = _mls_x720;
      _mls_x723 = _mls_x721;
      _mls_x724 = _mls_x732;
      _mls_x725 = _mls_x733;
      _mls_x726 = _mls_x734;
      goto _mls_j_default_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_reflectsurf(_mlsValue _mls_ss3) {
  _mlsValue _mls_retval;
  auto _mls_x284 = _mlsValue::create<_mls_Lambda_lscomp5>();
  auto _mls_x285 = _mlsMethodCall<_mls_Callable>(_mls_x284)->_mls_apply1(_mls_ss3);
  auto _mls_x286 = _mlsValue::create<_mls_Nil>();
  auto _mls_x287 = _mlsValue::create<_mls_Cons>(_mlsValue::create<_mls_Float>(0.0), _mls_x286);
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x285)) {
    _mls_retval = _mlsValue::create<_mls_Float>(0.0);
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x285)) {
    auto _mls_x1128 = _mlsValue::cast<_mls_Cons>(_mls_x285)->_mls_head;
    auto _mls_x1129 = _mlsValue::cast<_mls_Cons>(_mls_x285)->_mls_tail;
    auto _mls_x1130 = _mls_append_case1_sr_post(_mls_x1129, _mls_x287, _mls_x1128);
    auto _mls_x1131 = _mlsValue::cast<_mls_Cons>(_mls_x1130)->_mls_head;
    _mls_retval = _mls_x1131;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_refractray_case0_caller_post(_mlsValue _mls_x1133, _mlsValue _mls_x1135, _mlsValue _mls_x1136, _mlsValue _mls_x1137) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x818, _mls_x819, _mls_x820, _mls_x821;
  _mlsValue _mls_x811, _mls_x812, _mls_x813, _mls_x814;
  _mlsValue _mls_x815, _mls_x816, _mls_x817;
  _mlsValue _mls_x810;
  auto _mls_x1132 = (-_mls_x1133);
  auto _mls_x1134 = (_mlsValue::create<_mls_Float>(1.0) / _mls_x1135);
  _mls_x818 = _mls_x1134;
  _mls_x819 = _mls_x1132;
  _mls_x820 = _mls_x1136;
  _mls_x821 = _mls_x1137;
  goto _mls_j_case0_sr_post;
  return _mls_retval;
  _mls_j_case0_sr_post:
  {
    auto [_mls_x822, _mls_x823, _mls_x824, _mls_x825, _mls_x826] = _mls_j_case0_sr_post_pre(_mls_x818, _mls_x819, _mls_x820, _mls_x821);
    if (_mlsValue::isIntLit(_mls_x824, 1)) {
      goto _mls_j_case0_sr_post_case0;
    } else {
      _mls_x811 = _mls_x826;
      _mls_x812 = _mls_x825;
      _mls_x813 = _mls_x823;
      _mls_x814 = _mls_x822;
      goto _mls_j_case0_sr_post_default;
    }
    return _mls_retval;
  }
  _mls_j_case0_sr_post_case0:
  {
    auto _mls_x827 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
    auto _mls_x828 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(1), _mls_x827);
    _mls_retval = _mls_x828;
    return _mls_retval;
  }
  _mls_j_case0_sr_post_default:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x811)) {
      auto _mls_x829 = _mlsValue::cast<_mls_Tuple3>(_mls_x811)->_mls_field0;
      auto _mls_x830 = _mlsValue::cast<_mls_Tuple3>(_mls_x811)->_mls_field1;
      auto _mls_x831 = _mlsValue::cast<_mls_Tuple3>(_mls_x811)->_mls_field2;
      auto _mls_x832 = _mls_vecscale_case0_sr_post(_mls_x812, _mls_x829, _mls_x830, _mls_x831);
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x813)) {
        _mls_x815 = _mls_x813;
        _mls_x816 = _mls_x814;
        _mls_x817 = _mls_x832;
        goto _mls_j_case0_sr_post_caller_post_case0;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_case0_sr_post_caller_post_case0:
  {
    auto _mls_x833 = _mlsValue::cast<_mls_Tuple3>(_mls_x815)->_mls_field0;
    auto _mls_x834 = _mlsValue::cast<_mls_Tuple3>(_mls_x815)->_mls_field1;
    auto _mls_x835 = _mlsValue::cast<_mls_Tuple3>(_mls_x815)->_mls_field2;
    auto _mls_x836 = _mls_vecscale_case0_sr_post(_mls_x816, _mls_x833, _mls_x834, _mls_x835);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x817)) {
      auto _mls_x837 = _mlsValue::cast<_mls_Tuple3>(_mls_x817)->_mls_field0;
      auto _mls_x838 = _mlsValue::cast<_mls_Tuple3>(_mls_x817)->_mls_field1;
      auto _mls_x839 = _mlsValue::cast<_mls_Tuple3>(_mls_x817)->_mls_field2;
      auto _mls_x840 = _mls_vecadd_case0_sr_post(_mls_x836, _mls_x837, _mls_x838, _mls_x839);
      _mls_x810 = _mls_x840;
      goto _mls_j_caller_post_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post_post1:
  {
    auto _mls_x809 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x810);
    _mls_retval = _mls_x809;
    return _mls_retval;
  }
}
_mlsValue _mls_refractray_case0_case0_sr_post(_mlsValue _mls_x1144, _mlsValue _mls_x1140, _mlsValue _mls_x1145, _mlsValue _mls_x1141, _mlsValue _mls_x1139, _mlsValue _mls_x1138, _mlsValue _mls_x1143) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1133, _mls_x1135, _mls_x1136, _mls_x1137;
  _mlsValue _mls_x818, _mls_x819, _mls_x820, _mls_x821;
  _mlsValue _mls_x811, _mls_x812, _mls_x813, _mls_x814;
  _mlsValue _mls_x815, _mls_x816, _mls_x817;
  _mlsValue _mls_x810;
  auto _mls_x1142 = _mls_vecscale_case0_sr_post(_mls_x1138, _mls_x1139, _mls_x1140, _mls_x1141);
  _mls_x1133 = _mls_x1143;
  _mls_x1135 = _mls_x1144;
  _mls_x1136 = _mls_x1142;
  _mls_x1137 = _mls_x1145;
  goto _mls_refractray_case0_caller_post;
  return _mls_retval;
  _mls_refractray_case0_caller_post:
  {
    auto _mls_x1132 = (-_mls_x1133);
    auto _mls_x1134 = (_mlsValue::create<_mls_Float>(1.0) / _mls_x1135);
    _mls_x818 = _mls_x1134;
    _mls_x819 = _mls_x1132;
    _mls_x820 = _mls_x1136;
    _mls_x821 = _mls_x1137;
    goto _mls_j_case0_sr_post;
    return _mls_retval;
  }
  _mls_j_case0_sr_post:
  {
    auto [_mls_x822, _mls_x823, _mls_x824, _mls_x825, _mls_x826] = _mls_j_case0_sr_post_pre(_mls_x818, _mls_x819, _mls_x820, _mls_x821);
    if (_mlsValue::isIntLit(_mls_x824, 1)) {
      goto _mls_j_case0_sr_post_case0;
    } else {
      _mls_x811 = _mls_x826;
      _mls_x812 = _mls_x825;
      _mls_x813 = _mls_x823;
      _mls_x814 = _mls_x822;
      goto _mls_j_case0_sr_post_default;
    }
    return _mls_retval;
  }
  _mls_j_case0_sr_post_case0:
  {
    auto _mls_x827 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
    auto _mls_x828 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(1), _mls_x827);
    _mls_retval = _mls_x828;
    return _mls_retval;
  }
  _mls_j_case0_sr_post_default:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x811)) {
      auto _mls_x829 = _mlsValue::cast<_mls_Tuple3>(_mls_x811)->_mls_field0;
      auto _mls_x830 = _mlsValue::cast<_mls_Tuple3>(_mls_x811)->_mls_field1;
      auto _mls_x831 = _mlsValue::cast<_mls_Tuple3>(_mls_x811)->_mls_field2;
      auto _mls_x832 = _mls_vecscale_case0_sr_post(_mls_x812, _mls_x829, _mls_x830, _mls_x831);
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x813)) {
        _mls_x815 = _mls_x813;
        _mls_x816 = _mls_x814;
        _mls_x817 = _mls_x832;
        goto _mls_j_case0_sr_post_caller_post_case0;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_case0_sr_post_caller_post_case0:
  {
    auto _mls_x833 = _mlsValue::cast<_mls_Tuple3>(_mls_x815)->_mls_field0;
    auto _mls_x834 = _mlsValue::cast<_mls_Tuple3>(_mls_x815)->_mls_field1;
    auto _mls_x835 = _mlsValue::cast<_mls_Tuple3>(_mls_x815)->_mls_field2;
    auto _mls_x836 = _mls_vecscale_case0_sr_post(_mls_x816, _mls_x833, _mls_x834, _mls_x835);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x817)) {
      auto _mls_x837 = _mlsValue::cast<_mls_Tuple3>(_mls_x817)->_mls_field0;
      auto _mls_x838 = _mlsValue::cast<_mls_Tuple3>(_mls_x817)->_mls_field1;
      auto _mls_x839 = _mlsValue::cast<_mls_Tuple3>(_mls_x817)->_mls_field2;
      auto _mls_x840 = _mls_vecadd_case0_sr_post(_mls_x836, _mls_x837, _mls_x838, _mls_x839);
      _mls_x810 = _mls_x840;
      goto _mls_j_caller_post_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post_post1:
  {
    auto _mls_x809 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x810);
    _mls_retval = _mls_x809;
    return _mls_retval;
  }
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_refractray_case0_pre(_mlsValue _mls_x1148, _mlsValue _mls_x1147, _mlsValue _mls_x1149, _mlsValue _mls_x1150) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x1146 = (-_mlsValue::create<_mls_Float>(1.0));
  _mls_retval = std::make_tuple(_mls_x1147, _mls_x1148, _mls_x1149, _mls_x1150, _mls_x1146);
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_refractray_pre(_mlsValue _mls_x1156, _mlsValue _mls_x1151, _mlsValue _mls_x1152) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x1153 = _mls_vecdot(_mls_x1151, _mls_x1152);
  auto _mls_x1154 = (-_mls_x1153);
  auto _mls_x1155 = (_mls_x1154 < _mlsValue::create<_mls_Float>(0.0));
  _mls_retval = std::make_tuple(_mls_x1151, _mls_x1154, _mls_x1156, _mls_x1152, _mls_x1155);
  return _mls_retval;
}
_mlsValue _mls_refractsurf(_mlsValue _mls_ss4) {
  _mlsValue _mls_retval;
  auto _mls_x299 = _mlsValue::create<_mls_Lambda_lscomp7>();
  auto _mls_x300 = _mlsMethodCall<_mls_Callable>(_mls_x299)->_mls_apply1(_mls_ss4);
  auto _mls_x301 = _mlsValue::create<_mls_Nil>();
  auto _mls_x302 = _mlsValue::create<_mls_Cons>(_mlsValue::create<_mls_Float>(1.0), _mls_x301);
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x300)) {
    _mls_retval = _mlsValue::create<_mls_Float>(1.0);
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x300)) {
    auto _mls_x1157 = _mlsValue::cast<_mls_Cons>(_mls_x300)->_mls_head;
    auto _mls_x1158 = _mlsValue::cast<_mls_Cons>(_mls_x300)->_mls_tail;
    auto _mls_x1159 = _mls_append_case1_sr_post(_mls_x1158, _mls_x302, _mls_x1157);
    auto _mls_x1160 = _mlsValue::cast<_mls_Cons>(_mls_x1159)->_mls_head;
    _mls_retval = _mls_x1160;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_repeatRun(_mlsValue _mls_n, _mlsValue _mls_i1) {
  _mlsValue _mls_retval;
  auto _mls_x305 = _mls_run(_mls_n);
  auto _mls_x306 = (_mls_i1 == _mlsValue::fromIntLit(1));
  if (_mlsValue::isIntLit(_mls_x306, 1)) {
    _mls_retval = _mls_x305;
  } else {
    auto _mls_x307 = (_mls_i1 - _mlsValue::fromIntLit(1));
    auto _mls_x308 = _mls_repeatRun(_mls_n, _mls_x307);
    _mls_retval = _mls_x308;
  }
  return _mls_retval;
}
_mlsValue _mls_run(_mlsValue _mls_winsize2) {
  _mlsValue _mls_retval;
  auto _mls_x309 = _mls_ray(_mls_winsize2);
  auto _mls_x310 = _mlsValue::create<_mls_Lambda_snd>();
  auto _mls_x311 = _mls_map(_mls_x310, _mls_x309);
  _mls_retval = _mls_x311;
  return _mls_retval;
}
_mlsValue _mls_s2() {
  _mlsValue _mls_retval;
  auto _mls_x312 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.035), _mlsValue::create<_mls_Float>(0.0325), _mlsValue::create<_mls_Float>(0.025));
  auto _mls_x313 = _mlsValue::create<_mls_Ambient>(_mls_x312);
  auto _mls_x314 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.5), _mlsValue::create<_mls_Float>(0.45), _mlsValue::create<_mls_Float>(0.35));
  auto _mls_x315 = _mlsValue::create<_mls_Diffuse>(_mls_x314);
  auto _mls_x316 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.8), _mlsValue::create<_mls_Float>(0.8), _mlsValue::create<_mls_Float>(0.8));
  auto _mls_x317 = _mlsValue::create<_mls_Specular>(_mls_x316);
  auto _mls_x318 = _mlsValue::create<_mls_Specpow>(_mlsValue::create<_mls_Float>(3.0));
  auto _mls_x319 = _mlsValue::create<_mls_Reflect>(_mlsValue::create<_mls_Float>(0.5));
  auto _mls_x320 = _mlsValue::create<_mls_Nil>();
  auto _mls_x321 = _mlsValue::create<_mls_Cons>(_mls_x319, _mls_x320);
  auto _mls_x322 = _mlsValue::create<_mls_Cons>(_mls_x318, _mls_x321);
  auto _mls_x323 = _mlsValue::create<_mls_Cons>(_mls_x317, _mls_x322);
  auto _mls_x324 = _mlsValue::create<_mls_Cons>(_mls_x315, _mls_x323);
  auto _mls_x325 = _mlsValue::create<_mls_Cons>(_mls_x313, _mls_x324);
  _mls_retval = _mls_x325;
  return _mls_retval;
}
_mlsValue _mls_shade(_mlsValue _mls_x1221, _mlsValue _mls_x1218, _mlsValue _mls_x1222, _mlsValue _mls_x1217, _mlsValue _mls_x1219, _mlsValue _mls_x1220) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1161, _mls_x1162, _mls_x1163, _mls_x1164, _mls_x1165;
  _mlsValue _mls_x1166, _mls_x1167, _mls_x1168, _mls_x1169, _mls_x1170, _mls_x1171, _mls_x1172;
  _mlsValue _mls_x1173, _mls_x1174, _mls_x1175, _mls_x1176, _mls_x1177, _mls_x1178, _mls_x1179, _mls_x1180, _mls_x1181;
  _mlsValue _mls_x1182, _mls_x1183, _mls_x1184, _mls_x1185, _mls_x1186, _mls_x1187, _mls_x1188, _mls_x1189;
  _mlsValue _mls_x1190, _mls_x1191, _mls_x1192, _mls_x1193, _mls_x1194, _mls_x1195, _mls_x1196, _mls_x1197;
  _mlsValue _mls_x1198, _mls_x1199, _mls_x1200, _mls_x1201, _mls_x1202, _mls_x1203, _mls_x1204, _mls_x1205, _mls_x1206;
  _mlsValue _mls_x1207, _mls_x1208, _mls_x1209, _mls_x1210, _mls_x1211, _mls_x1212, _mls_x1213, _mls_x1214, _mls_x1215, _mls_x1216;
  _mlsValue _mls_refl1, _mls_hitpos1, _mls_tmp3, _mls_surf, _mls_trintensity, _mls_contrib1, _mls_lights1;
  _mlsValue _mls_x760, _mls_x761, _mls_x762, _mls_x763, _mls_x764, _mls_x765, _mls_x766, _mls_x767, _mls_x768;
  _mlsValue _mls_x769, _mls_x770, _mls_x771, _mls_x772, _mls_x773, _mls_x774, _mls_x775, _mls_x776, _mls_x777, _mls_x778, _mls_x779;
  _mlsValue _mls_refl, _mls_hitpos, _mls_trcol, _mls_tmp2, _mls_contrib, _mls_lights;
  _mlsValue _mls_x780, _mls_x781, _mls_x782, _mls_x783, _mls_x784, _mls_x785, _mls_x786;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1217)) {
    auto [_mls_x1223, _mls_x1224, _mls_x1225, _mls_x1226, _mls_x1227, _mls_x1228] = _mls_shade_case0_pre(_mls_x1218, _mls_x1219, _mls_x1220, _mls_x1221, _mls_x1217, _mls_x1222);
    auto _mls_x1229 = _mls_vecadd(_mls_x1227, _mls_x1226);
    _mls_x1161 = _mls_x1225;
    _mls_x1162 = _mls_x1223;
    _mls_x1163 = _mls_x1224;
    _mls_x1164 = _mls_x1228;
    _mls_x1165 = _mls_x1229;
    goto _mls_shade_caller_post_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_shade_caller_post_post:
  {
    auto _mls_x1230 = _mls_spheresurf(_mls_x1163);
    auto [_mls_x1231, _mls_x1232, _mls_x1233] = _mls_ambientsurf_pre(_mls_x1230);
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1231)) {
      auto _mls_x1238 = _mlsValue::cast<_mls_Tuple3>(_mls_x1232)->_mls_field0;
      auto _mls_x1239 = _mlsValue::cast<_mls_Tuple3>(_mls_x1232)->_mls_field1;
      auto _mls_x1240 = _mlsValue::cast<_mls_Tuple3>(_mls_x1232)->_mls_field2;
      auto _mls_x1241 = _mls_vecmult_case0_sr_post_case0_sr_post(_mls_x1240, _mlsValue::create<_mls_Float>(1.0), _mls_x1239, _mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0), _mls_x1238);
      _mls_x1166 = _mls_x1241;
      _mls_x1167 = _mls_x1230;
      _mls_x1168 = _mls_x1161;
      _mls_x1169 = _mls_x1162;
      _mls_x1170 = _mls_x1163;
      _mls_x1171 = _mls_x1164;
      _mls_x1172 = _mls_x1165;
      goto _mls_shade_caller_post_caller_post;
    } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1231)) {
      auto _mls_x1234 = _mlsValue::cast<_mls_Cons>(_mls_x1231)->_mls_head;
      auto _mls_x1235 = _mlsValue::cast<_mls_Cons>(_mls_x1231)->_mls_tail;
      auto _mls_x1236 = _mls_ambientsurf_case1_sr_post(_mls_x1235, _mls_x1233, _mls_x1234);
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1236)) {
        auto _mls_x1237 = _mls_vecmult_case0_sr_post_case0(_mls_x1236, _mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0));
        _mls_x1166 = _mls_x1237;
        _mls_x1167 = _mls_x1230;
        _mls_x1168 = _mls_x1161;
        _mls_x1169 = _mls_x1162;
        _mls_x1170 = _mls_x1163;
        _mls_x1171 = _mls_x1164;
        _mls_x1172 = _mls_x1165;
        goto _mls_shade_caller_post_caller_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Sphere>(_mls_x1170)) {
      auto _mls_x1242 = _mlsValue::cast<_mls_Sphere>(_mls_x1170)->_mls_pos;
      auto _mls_x1243 = _mlsValue::cast<_mls_Sphere>(_mls_x1170)->_mls_radius;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1172)) {
        auto _mls_x1244 = _mls_spherenormal_case0_sr_post_case0(_mls_x1172, _mls_x1242, _mls_x1243);
        auto [_mls_x1245, _mls_x1246, _mls_x1247, _mls_x1248, _mls_x1249, _mls_x1250, _mls_x1251, _mls_x1252] = _mls_shade_caller_post_caller_post_caller_post_pre(_mls_x1166, _mls_x1171, _mls_x1172, _mls_x1169, _mls_x1167, _mls_x1244, _mls_x1168);
        if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1250)) {
          auto _mls_x1253 = _mls_vecdot_case0(_mls_x1250, _mls_x1245);
          _mls_x1173 = _mls_x1245;
          _mls_x1174 = _mls_x1246;
          _mls_x1175 = _mls_x1247;
          _mls_x1176 = _mls_x1248;
          _mls_x1177 = _mls_x1249;
          _mls_x1178 = _mls_x1250;
          _mls_x1179 = _mls_x1251;
          _mls_x1180 = _mls_x1252;
          _mls_x1181 = _mls_x1253;
          goto _mls_shade_caller_post_caller_post_caller_post_caller_post;
        } else {
          _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post:
  {
    auto _mls_x1254 = (_mls_x1179 * _mls_x1181);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1173)) {
      auto _mls_x1255 = _mlsValue::cast<_mls_Tuple3>(_mls_x1173)->_mls_field0;
      auto _mls_x1256 = _mlsValue::cast<_mls_Tuple3>(_mls_x1173)->_mls_field1;
      auto _mls_x1257 = _mlsValue::cast<_mls_Tuple3>(_mls_x1173)->_mls_field2;
      auto _mls_x1258 = _mls_vecscale_case0_sr_post(_mls_x1254, _mls_x1255, _mls_x1256, _mls_x1257);
      _mls_x1182 = _mls_x1173;
      _mls_x1183 = _mls_x1174;
      _mls_x1184 = _mls_x1175;
      _mls_x1185 = _mls_x1258;
      _mls_x1186 = _mls_x1176;
      _mls_x1187 = _mls_x1177;
      _mls_x1188 = _mls_x1178;
      _mls_x1189 = _mls_x1180;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1188)) {
      auto _mls_x1259 = _mls_vecadd_case0(_mls_x1188, _mls_x1185);
      _mls_x1190 = _mls_x1187;
      _mls_x1191 = _mls_x1186;
      _mls_x1192 = _mls_x1182;
      _mls_x1193 = _mls_x1189;
      _mls_x1194 = _mls_x1259;
      _mls_x1195 = _mls_x1184;
      _mls_x1196 = _mls_x1188;
      _mls_x1197 = _mls_x1183;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    auto _mls_x1260 = _mlsValue::create<_mls_Lambda_lambda>(_mls_x1194, _mls_x1195, _mls_x1190, _mls_x1192);
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1193)) {
      auto _mls_x1262 = _mls_map_case0(_mls_x1193, _mls_x1260);
      _mls_x1198 = _mls_x1190;
      _mls_x1199 = _mls_x1191;
      _mls_x1200 = _mls_x1192;
      _mls_x1201 = _mls_x1193;
      _mls_x1202 = _mls_x1262;
      _mls_x1203 = _mls_x1194;
      _mls_x1204 = _mls_x1195;
      _mls_x1205 = _mls_x1196;
      _mls_x1206 = _mls_x1197;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post1;
    } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1193)) {
      auto _mls_x1261 = _mls_map_case1();
      _mls_x1198 = _mls_x1190;
      _mls_x1199 = _mls_x1191;
      _mls_x1200 = _mls_x1192;
      _mls_x1201 = _mls_x1193;
      _mls_x1202 = _mls_x1261;
      _mls_x1203 = _mls_x1194;
      _mls_x1204 = _mls_x1195;
      _mls_x1205 = _mls_x1196;
      _mls_x1206 = _mls_x1197;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post1:
  {
    auto _mls_x1263 = _mls_vecsum(_mls_x1202);
    auto _mls_x1264 = _mls_transmitsurf(_mls_x1198);
    auto _mls_x1265 = _mls_vecadd(_mls_x1206, _mls_x1263);
    auto [_mls_x1266, _mls_x1267, _mls_x1268] = _mls_bodysurf_pre(_mls_x1198);
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1266)) {
      _mls_x1207 = _mls_x1198;
      _mls_x1208 = _mls_x1201;
      _mls_x1209 = _mls_x1265;
      _mls_x1210 = _mls_x1203;
      _mls_x1211 = _mls_x1267;
      _mls_x1212 = _mls_x1204;
      _mls_x1213 = _mls_x1199;
      _mls_x1214 = _mls_x1205;
      _mls_x1215 = _mls_x1200;
      _mls_x1216 = _mls_x1264;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1266)) {
      auto _mls_x1269 = _mls_bodysurf_case1(_mls_x1266, _mls_x1268);
      _mls_x1207 = _mls_x1198;
      _mls_x1208 = _mls_x1201;
      _mls_x1209 = _mls_x1265;
      _mls_x1210 = _mls_x1203;
      _mls_x1211 = _mls_x1269;
      _mls_x1212 = _mls_x1204;
      _mls_x1213 = _mls_x1199;
      _mls_x1214 = _mls_x1205;
      _mls_x1215 = _mls_x1200;
      _mls_x1216 = _mls_x1264;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    auto _mls_x1270 = _mls_vecscale(_mls_x1211, _mls_x1216);
    auto _mls_x1271 = (_mls_x1216 < _mlsValue::create<_mls_Float>(1.0E-6));
    if (_mlsValue::isIntLit(_mls_x1271, 1)) {
      auto _mls_x1274 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x1209);
      _mls_refl1 = _mls_x1210;
      _mls_hitpos1 = _mls_x1212;
      _mls_tmp3 = _mls_x1274;
      _mls_surf = _mls_x1207;
      _mls_trintensity = _mls_x1270;
      _mls_contrib1 = _mls_x1213;
      _mls_lights1 = _mls_x1208;
      goto _mls_j4;
    } else {
      auto _mls_x1272 = _mls_refractsurf(_mls_x1207);
      auto _mls_x1273 = _mls_transmitray(_mls_x1208, _mls_x1209, _mls_x1212, _mls_x1214, _mls_x1272, _mls_x1270, _mls_x1213, _mls_x1215);
      _mls_refl1 = _mls_x1210;
      _mls_hitpos1 = _mls_x1212;
      _mls_tmp3 = _mls_x1273;
      _mls_surf = _mls_x1207;
      _mls_trintensity = _mls_x1270;
      _mls_contrib1 = _mls_x1213;
      _mls_lights1 = _mls_x1208;
      goto _mls_j4;
    }
    return _mls_retval;
  }
  _mls_j4:
  {
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_tmp3)) {
      auto _mls_x184 = _mlsValue::cast<_mls_Tuple2>(_mls_tmp3)->_mls_field0;
      auto _mls_x185 = _mlsValue::cast<_mls_Tuple2>(_mls_tmp3)->_mls_field1;
      auto [_mls_x787, _mls_x788, _mls_x789] = _mls_specularsurf_pre(_mls_surf);
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x787)) {
        auto _mls_x793 = _mls_reflectsurf(_mls_surf);
        auto _mls_x794 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field0;
        auto _mls_x795 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field1;
        auto _mls_x796 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field2;
        _mls_x769 = _mls_refl1;
        _mls_x770 = _mls_x184;
        _mls_x771 = _mls_x796;
        _mls_x772 = _mls_hitpos1;
        _mls_x773 = _mls_x185;
        _mls_x774 = _mls_x795;
        _mls_x775 = _mls_lights1;
        _mls_x776 = _mls_trintensity;
        _mls_x777 = _mls_contrib1;
        _mls_x778 = _mls_x794;
        _mls_x779 = _mls_x793;
        goto _mls_j_caller_post_case0_sr_post;
      } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x787)) {
        auto _mls_x790 = _mlsValue::cast<_mls_Cons>(_mls_x787)->_mls_head;
        auto _mls_x791 = _mlsValue::cast<_mls_Cons>(_mls_x787)->_mls_tail;
        auto _mls_x792 = _mls_specularsurf_case1_sr_post(_mls_x791, _mls_x789, _mls_x790);
        _mls_x760 = _mls_trintensity;
        _mls_x761 = _mls_refl1;
        _mls_x762 = _mls_lights1;
        _mls_x763 = _mls_surf;
        _mls_x764 = _mls_x185;
        _mls_x765 = _mls_x184;
        _mls_x766 = _mls_x792;
        _mls_x767 = _mls_hitpos1;
        _mls_x768 = _mls_contrib1;
        goto _mls_j_caller_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post:
  {
    auto _mls_x797 = _mls_reflectsurf(_mls_x763);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x766)) {
      auto _mls_x798 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field0;
      auto _mls_x799 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field1;
      auto _mls_x800 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field2;
      _mls_x769 = _mls_x761;
      _mls_x770 = _mls_x765;
      _mls_x771 = _mls_x800;
      _mls_x772 = _mls_x767;
      _mls_x773 = _mls_x764;
      _mls_x774 = _mls_x799;
      _mls_x775 = _mls_x762;
      _mls_x776 = _mls_x760;
      _mls_x777 = _mls_x768;
      _mls_x778 = _mls_x798;
      _mls_x779 = _mls_x797;
      goto _mls_j_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post_case0_sr_post:
  {
    auto _mls_x801 = _mls_vecscale_case0_sr_post(_mls_x779, _mls_x778, _mls_x774, _mls_x771);
    if (_mlsValue::isIntLit(_mls_x770, 1)) {
      _mls_x780 = _mls_x772;
      _mls_x781 = _mls_x775;
      _mls_x782 = _mls_x769;
      _mls_x783 = _mls_x777;
      _mls_x784 = _mls_x801;
      _mls_x785 = _mls_x773;
      _mls_x786 = _mls_x776;
      goto _mls_j_caller_post_case0;
    } else {
      _mls_refl = _mls_x769;
      _mls_hitpos = _mls_x772;
      _mls_trcol = _mls_x773;
      _mls_tmp2 = _mls_x801;
      _mls_contrib = _mls_x777;
      _mls_lights = _mls_x775;
      goto _mls_j3;
    }
    return _mls_retval;
  }
  _mls_j3:
  {
    auto _mls_x190 = _mls_is_zerovector(_mls_tmp2);
    if (_mlsValue::isIntLit(_mls_x190, 1)) {
      _mls_retval = _mls_trcol;
    } else {
      auto _mls_x191 = _mls_reflectray(_mls_hitpos, _mls_refl, _mls_lights, _mls_tmp2, _mls_contrib, _mls_trcol);
      _mls_retval = _mls_x191;
    }
    return _mls_retval;
  }
  _mls_j_caller_post_case0:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x786)) {
      auto _mls_x802 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field0;
      auto _mls_x803 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field1;
      auto _mls_x804 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field2;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x784)) {
        auto _mls_x805 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field0;
        auto _mls_x806 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field1;
        auto _mls_x807 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field2;
        auto _mls_x808 = _mls_vecadd_case0_sr_post_case0_sr_post(_mls_x802, _mls_x804, _mls_x805, _mls_x807, _mls_x803, _mls_x806);
        _mls_refl = _mls_x782;
        _mls_hitpos = _mls_x780;
        _mls_trcol = _mls_x785;
        _mls_tmp2 = _mls_x808;
        _mls_contrib = _mls_x783;
        _mls_lights = _mls_x781;
        goto _mls_j3;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_shade_caller_post(_mlsValue _mls_x1280, _mlsValue _mls_x1276, _mlsValue _mls_x1278, _mlsValue _mls_x1281, _mlsValue _mls_x1279, _mlsValue _mls_x1275) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1161, _mls_x1162, _mls_x1163, _mls_x1164, _mls_x1165;
  _mlsValue _mls_x1166, _mls_x1167, _mls_x1168, _mls_x1169, _mls_x1170, _mls_x1171, _mls_x1172;
  _mlsValue _mls_x1173, _mls_x1174, _mls_x1175, _mls_x1176, _mls_x1177, _mls_x1178, _mls_x1179, _mls_x1180, _mls_x1181;
  _mlsValue _mls_x1182, _mls_x1183, _mls_x1184, _mls_x1185, _mls_x1186, _mls_x1187, _mls_x1188, _mls_x1189;
  _mlsValue _mls_x1190, _mls_x1191, _mls_x1192, _mls_x1193, _mls_x1194, _mls_x1195, _mls_x1196, _mls_x1197;
  _mlsValue _mls_x1198, _mls_x1199, _mls_x1200, _mls_x1201, _mls_x1202, _mls_x1203, _mls_x1204, _mls_x1205, _mls_x1206;
  _mlsValue _mls_x1207, _mls_x1208, _mls_x1209, _mls_x1210, _mls_x1211, _mls_x1212, _mls_x1213, _mls_x1214, _mls_x1215, _mls_x1216;
  _mlsValue _mls_refl1, _mls_hitpos1, _mls_tmp3, _mls_surf, _mls_trintensity, _mls_contrib1, _mls_lights1;
  _mlsValue _mls_x760, _mls_x761, _mls_x762, _mls_x763, _mls_x764, _mls_x765, _mls_x766, _mls_x767, _mls_x768;
  _mlsValue _mls_x769, _mls_x770, _mls_x771, _mls_x772, _mls_x773, _mls_x774, _mls_x775, _mls_x776, _mls_x777, _mls_x778, _mls_x779;
  _mlsValue _mls_refl, _mls_hitpos, _mls_trcol, _mls_tmp2, _mls_contrib, _mls_lights;
  _mlsValue _mls_x780, _mls_x781, _mls_x782, _mls_x783, _mls_x784, _mls_x785, _mls_x786;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1275)) {
    auto _mls_x1277 = _mls_vecadd_case0(_mls_x1275, _mls_x1276);
    _mls_x1161 = _mls_x1278;
    _mls_x1162 = _mls_x1279;
    _mls_x1163 = _mls_x1280;
    _mls_x1164 = _mls_x1281;
    _mls_x1165 = _mls_x1277;
    goto _mls_shade_caller_post_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_shade_caller_post_post:
  {
    auto _mls_x1230 = _mls_spheresurf(_mls_x1163);
    auto [_mls_x1231, _mls_x1232, _mls_x1233] = _mls_ambientsurf_pre(_mls_x1230);
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1231)) {
      auto _mls_x1238 = _mlsValue::cast<_mls_Tuple3>(_mls_x1232)->_mls_field0;
      auto _mls_x1239 = _mlsValue::cast<_mls_Tuple3>(_mls_x1232)->_mls_field1;
      auto _mls_x1240 = _mlsValue::cast<_mls_Tuple3>(_mls_x1232)->_mls_field2;
      auto _mls_x1241 = _mls_vecmult_case0_sr_post_case0_sr_post(_mls_x1240, _mlsValue::create<_mls_Float>(1.0), _mls_x1239, _mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0), _mls_x1238);
      _mls_x1166 = _mls_x1241;
      _mls_x1167 = _mls_x1230;
      _mls_x1168 = _mls_x1161;
      _mls_x1169 = _mls_x1162;
      _mls_x1170 = _mls_x1163;
      _mls_x1171 = _mls_x1164;
      _mls_x1172 = _mls_x1165;
      goto _mls_shade_caller_post_caller_post;
    } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1231)) {
      auto _mls_x1234 = _mlsValue::cast<_mls_Cons>(_mls_x1231)->_mls_head;
      auto _mls_x1235 = _mlsValue::cast<_mls_Cons>(_mls_x1231)->_mls_tail;
      auto _mls_x1236 = _mls_ambientsurf_case1_sr_post(_mls_x1235, _mls_x1233, _mls_x1234);
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1236)) {
        auto _mls_x1237 = _mls_vecmult_case0_sr_post_case0(_mls_x1236, _mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0));
        _mls_x1166 = _mls_x1237;
        _mls_x1167 = _mls_x1230;
        _mls_x1168 = _mls_x1161;
        _mls_x1169 = _mls_x1162;
        _mls_x1170 = _mls_x1163;
        _mls_x1171 = _mls_x1164;
        _mls_x1172 = _mls_x1165;
        goto _mls_shade_caller_post_caller_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Sphere>(_mls_x1170)) {
      auto _mls_x1242 = _mlsValue::cast<_mls_Sphere>(_mls_x1170)->_mls_pos;
      auto _mls_x1243 = _mlsValue::cast<_mls_Sphere>(_mls_x1170)->_mls_radius;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1172)) {
        auto _mls_x1244 = _mls_spherenormal_case0_sr_post_case0(_mls_x1172, _mls_x1242, _mls_x1243);
        auto [_mls_x1245, _mls_x1246, _mls_x1247, _mls_x1248, _mls_x1249, _mls_x1250, _mls_x1251, _mls_x1252] = _mls_shade_caller_post_caller_post_caller_post_pre(_mls_x1166, _mls_x1171, _mls_x1172, _mls_x1169, _mls_x1167, _mls_x1244, _mls_x1168);
        if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1250)) {
          auto _mls_x1253 = _mls_vecdot_case0(_mls_x1250, _mls_x1245);
          _mls_x1173 = _mls_x1245;
          _mls_x1174 = _mls_x1246;
          _mls_x1175 = _mls_x1247;
          _mls_x1176 = _mls_x1248;
          _mls_x1177 = _mls_x1249;
          _mls_x1178 = _mls_x1250;
          _mls_x1179 = _mls_x1251;
          _mls_x1180 = _mls_x1252;
          _mls_x1181 = _mls_x1253;
          goto _mls_shade_caller_post_caller_post_caller_post_caller_post;
        } else {
          _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post:
  {
    auto _mls_x1254 = (_mls_x1179 * _mls_x1181);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1173)) {
      auto _mls_x1255 = _mlsValue::cast<_mls_Tuple3>(_mls_x1173)->_mls_field0;
      auto _mls_x1256 = _mlsValue::cast<_mls_Tuple3>(_mls_x1173)->_mls_field1;
      auto _mls_x1257 = _mlsValue::cast<_mls_Tuple3>(_mls_x1173)->_mls_field2;
      auto _mls_x1258 = _mls_vecscale_case0_sr_post(_mls_x1254, _mls_x1255, _mls_x1256, _mls_x1257);
      _mls_x1182 = _mls_x1173;
      _mls_x1183 = _mls_x1174;
      _mls_x1184 = _mls_x1175;
      _mls_x1185 = _mls_x1258;
      _mls_x1186 = _mls_x1176;
      _mls_x1187 = _mls_x1177;
      _mls_x1188 = _mls_x1178;
      _mls_x1189 = _mls_x1180;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1188)) {
      auto _mls_x1259 = _mls_vecadd_case0(_mls_x1188, _mls_x1185);
      _mls_x1190 = _mls_x1187;
      _mls_x1191 = _mls_x1186;
      _mls_x1192 = _mls_x1182;
      _mls_x1193 = _mls_x1189;
      _mls_x1194 = _mls_x1259;
      _mls_x1195 = _mls_x1184;
      _mls_x1196 = _mls_x1188;
      _mls_x1197 = _mls_x1183;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    auto _mls_x1260 = _mlsValue::create<_mls_Lambda_lambda>(_mls_x1194, _mls_x1195, _mls_x1190, _mls_x1192);
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1193)) {
      auto _mls_x1262 = _mls_map_case0(_mls_x1193, _mls_x1260);
      _mls_x1198 = _mls_x1190;
      _mls_x1199 = _mls_x1191;
      _mls_x1200 = _mls_x1192;
      _mls_x1201 = _mls_x1193;
      _mls_x1202 = _mls_x1262;
      _mls_x1203 = _mls_x1194;
      _mls_x1204 = _mls_x1195;
      _mls_x1205 = _mls_x1196;
      _mls_x1206 = _mls_x1197;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post1;
    } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1193)) {
      auto _mls_x1261 = _mls_map_case1();
      _mls_x1198 = _mls_x1190;
      _mls_x1199 = _mls_x1191;
      _mls_x1200 = _mls_x1192;
      _mls_x1201 = _mls_x1193;
      _mls_x1202 = _mls_x1261;
      _mls_x1203 = _mls_x1194;
      _mls_x1204 = _mls_x1195;
      _mls_x1205 = _mls_x1196;
      _mls_x1206 = _mls_x1197;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post1:
  {
    auto _mls_x1263 = _mls_vecsum(_mls_x1202);
    auto _mls_x1264 = _mls_transmitsurf(_mls_x1198);
    auto _mls_x1265 = _mls_vecadd(_mls_x1206, _mls_x1263);
    auto [_mls_x1266, _mls_x1267, _mls_x1268] = _mls_bodysurf_pre(_mls_x1198);
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1266)) {
      _mls_x1207 = _mls_x1198;
      _mls_x1208 = _mls_x1201;
      _mls_x1209 = _mls_x1265;
      _mls_x1210 = _mls_x1203;
      _mls_x1211 = _mls_x1267;
      _mls_x1212 = _mls_x1204;
      _mls_x1213 = _mls_x1199;
      _mls_x1214 = _mls_x1205;
      _mls_x1215 = _mls_x1200;
      _mls_x1216 = _mls_x1264;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1266)) {
      auto _mls_x1269 = _mls_bodysurf_case1(_mls_x1266, _mls_x1268);
      _mls_x1207 = _mls_x1198;
      _mls_x1208 = _mls_x1201;
      _mls_x1209 = _mls_x1265;
      _mls_x1210 = _mls_x1203;
      _mls_x1211 = _mls_x1269;
      _mls_x1212 = _mls_x1204;
      _mls_x1213 = _mls_x1199;
      _mls_x1214 = _mls_x1205;
      _mls_x1215 = _mls_x1200;
      _mls_x1216 = _mls_x1264;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    auto _mls_x1270 = _mls_vecscale(_mls_x1211, _mls_x1216);
    auto _mls_x1271 = (_mls_x1216 < _mlsValue::create<_mls_Float>(1.0E-6));
    if (_mlsValue::isIntLit(_mls_x1271, 1)) {
      auto _mls_x1274 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x1209);
      _mls_refl1 = _mls_x1210;
      _mls_hitpos1 = _mls_x1212;
      _mls_tmp3 = _mls_x1274;
      _mls_surf = _mls_x1207;
      _mls_trintensity = _mls_x1270;
      _mls_contrib1 = _mls_x1213;
      _mls_lights1 = _mls_x1208;
      goto _mls_j4;
    } else {
      auto _mls_x1272 = _mls_refractsurf(_mls_x1207);
      auto _mls_x1273 = _mls_transmitray(_mls_x1208, _mls_x1209, _mls_x1212, _mls_x1214, _mls_x1272, _mls_x1270, _mls_x1213, _mls_x1215);
      _mls_refl1 = _mls_x1210;
      _mls_hitpos1 = _mls_x1212;
      _mls_tmp3 = _mls_x1273;
      _mls_surf = _mls_x1207;
      _mls_trintensity = _mls_x1270;
      _mls_contrib1 = _mls_x1213;
      _mls_lights1 = _mls_x1208;
      goto _mls_j4;
    }
    return _mls_retval;
  }
  _mls_j4:
  {
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_tmp3)) {
      auto _mls_x184 = _mlsValue::cast<_mls_Tuple2>(_mls_tmp3)->_mls_field0;
      auto _mls_x185 = _mlsValue::cast<_mls_Tuple2>(_mls_tmp3)->_mls_field1;
      auto [_mls_x787, _mls_x788, _mls_x789] = _mls_specularsurf_pre(_mls_surf);
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x787)) {
        auto _mls_x793 = _mls_reflectsurf(_mls_surf);
        auto _mls_x794 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field0;
        auto _mls_x795 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field1;
        auto _mls_x796 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field2;
        _mls_x769 = _mls_refl1;
        _mls_x770 = _mls_x184;
        _mls_x771 = _mls_x796;
        _mls_x772 = _mls_hitpos1;
        _mls_x773 = _mls_x185;
        _mls_x774 = _mls_x795;
        _mls_x775 = _mls_lights1;
        _mls_x776 = _mls_trintensity;
        _mls_x777 = _mls_contrib1;
        _mls_x778 = _mls_x794;
        _mls_x779 = _mls_x793;
        goto _mls_j_caller_post_case0_sr_post;
      } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x787)) {
        auto _mls_x790 = _mlsValue::cast<_mls_Cons>(_mls_x787)->_mls_head;
        auto _mls_x791 = _mlsValue::cast<_mls_Cons>(_mls_x787)->_mls_tail;
        auto _mls_x792 = _mls_specularsurf_case1_sr_post(_mls_x791, _mls_x789, _mls_x790);
        _mls_x760 = _mls_trintensity;
        _mls_x761 = _mls_refl1;
        _mls_x762 = _mls_lights1;
        _mls_x763 = _mls_surf;
        _mls_x764 = _mls_x185;
        _mls_x765 = _mls_x184;
        _mls_x766 = _mls_x792;
        _mls_x767 = _mls_hitpos1;
        _mls_x768 = _mls_contrib1;
        goto _mls_j_caller_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post:
  {
    auto _mls_x797 = _mls_reflectsurf(_mls_x763);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x766)) {
      auto _mls_x798 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field0;
      auto _mls_x799 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field1;
      auto _mls_x800 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field2;
      _mls_x769 = _mls_x761;
      _mls_x770 = _mls_x765;
      _mls_x771 = _mls_x800;
      _mls_x772 = _mls_x767;
      _mls_x773 = _mls_x764;
      _mls_x774 = _mls_x799;
      _mls_x775 = _mls_x762;
      _mls_x776 = _mls_x760;
      _mls_x777 = _mls_x768;
      _mls_x778 = _mls_x798;
      _mls_x779 = _mls_x797;
      goto _mls_j_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post_case0_sr_post:
  {
    auto _mls_x801 = _mls_vecscale_case0_sr_post(_mls_x779, _mls_x778, _mls_x774, _mls_x771);
    if (_mlsValue::isIntLit(_mls_x770, 1)) {
      _mls_x780 = _mls_x772;
      _mls_x781 = _mls_x775;
      _mls_x782 = _mls_x769;
      _mls_x783 = _mls_x777;
      _mls_x784 = _mls_x801;
      _mls_x785 = _mls_x773;
      _mls_x786 = _mls_x776;
      goto _mls_j_caller_post_case0;
    } else {
      _mls_refl = _mls_x769;
      _mls_hitpos = _mls_x772;
      _mls_trcol = _mls_x773;
      _mls_tmp2 = _mls_x801;
      _mls_contrib = _mls_x777;
      _mls_lights = _mls_x775;
      goto _mls_j3;
    }
    return _mls_retval;
  }
  _mls_j3:
  {
    auto _mls_x190 = _mls_is_zerovector(_mls_tmp2);
    if (_mlsValue::isIntLit(_mls_x190, 1)) {
      _mls_retval = _mls_trcol;
    } else {
      auto _mls_x191 = _mls_reflectray(_mls_hitpos, _mls_refl, _mls_lights, _mls_tmp2, _mls_contrib, _mls_trcol);
      _mls_retval = _mls_x191;
    }
    return _mls_retval;
  }
  _mls_j_caller_post_case0:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x786)) {
      auto _mls_x802 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field0;
      auto _mls_x803 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field1;
      auto _mls_x804 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field2;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x784)) {
        auto _mls_x805 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field0;
        auto _mls_x806 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field1;
        auto _mls_x807 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field2;
        auto _mls_x808 = _mls_vecadd_case0_sr_post_case0_sr_post(_mls_x802, _mls_x804, _mls_x805, _mls_x807, _mls_x803, _mls_x806);
        _mls_refl = _mls_x782;
        _mls_hitpos = _mls_x780;
        _mls_trcol = _mls_x785;
        _mls_tmp2 = _mls_x808;
        _mls_contrib = _mls_x783;
        _mls_lights = _mls_x781;
        goto _mls_j3;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_shade_caller_post_caller_post(_mlsValue _mls_x1166, _mlsValue _mls_x1167, _mlsValue _mls_x1168, _mlsValue _mls_x1169, _mlsValue _mls_x1170, _mlsValue _mls_x1171, _mlsValue _mls_x1172) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1173, _mls_x1174, _mls_x1175, _mls_x1176, _mls_x1177, _mls_x1178, _mls_x1179, _mls_x1180, _mls_x1181;
  _mlsValue _mls_x1182, _mls_x1183, _mls_x1184, _mls_x1185, _mls_x1186, _mls_x1187, _mls_x1188, _mls_x1189;
  _mlsValue _mls_x1190, _mls_x1191, _mls_x1192, _mls_x1193, _mls_x1194, _mls_x1195, _mls_x1196, _mls_x1197;
  _mlsValue _mls_x1198, _mls_x1199, _mls_x1200, _mls_x1201, _mls_x1202, _mls_x1203, _mls_x1204, _mls_x1205, _mls_x1206;
  _mlsValue _mls_x1207, _mls_x1208, _mls_x1209, _mls_x1210, _mls_x1211, _mls_x1212, _mls_x1213, _mls_x1214, _mls_x1215, _mls_x1216;
  _mlsValue _mls_refl1, _mls_hitpos1, _mls_tmp3, _mls_surf, _mls_trintensity, _mls_contrib1, _mls_lights1;
  _mlsValue _mls_x760, _mls_x761, _mls_x762, _mls_x763, _mls_x764, _mls_x765, _mls_x766, _mls_x767, _mls_x768;
  _mlsValue _mls_x769, _mls_x770, _mls_x771, _mls_x772, _mls_x773, _mls_x774, _mls_x775, _mls_x776, _mls_x777, _mls_x778, _mls_x779;
  _mlsValue _mls_refl, _mls_hitpos, _mls_trcol, _mls_tmp2, _mls_contrib, _mls_lights;
  _mlsValue _mls_x780, _mls_x781, _mls_x782, _mls_x783, _mls_x784, _mls_x785, _mls_x786;
  if (_mlsValue::isValueOf<_mls_Sphere>(_mls_x1170)) {
    auto _mls_x1242 = _mlsValue::cast<_mls_Sphere>(_mls_x1170)->_mls_pos;
    auto _mls_x1243 = _mlsValue::cast<_mls_Sphere>(_mls_x1170)->_mls_radius;
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1172)) {
      auto _mls_x1244 = _mls_spherenormal_case0_sr_post_case0(_mls_x1172, _mls_x1242, _mls_x1243);
      auto [_mls_x1245, _mls_x1246, _mls_x1247, _mls_x1248, _mls_x1249, _mls_x1250, _mls_x1251, _mls_x1252] = _mls_shade_caller_post_caller_post_caller_post_pre(_mls_x1166, _mls_x1171, _mls_x1172, _mls_x1169, _mls_x1167, _mls_x1244, _mls_x1168);
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1250)) {
        auto _mls_x1253 = _mls_vecdot_case0(_mls_x1250, _mls_x1245);
        _mls_x1173 = _mls_x1245;
        _mls_x1174 = _mls_x1246;
        _mls_x1175 = _mls_x1247;
        _mls_x1176 = _mls_x1248;
        _mls_x1177 = _mls_x1249;
        _mls_x1178 = _mls_x1250;
        _mls_x1179 = _mls_x1251;
        _mls_x1180 = _mls_x1252;
        _mls_x1181 = _mls_x1253;
        goto _mls_shade_caller_post_caller_post_caller_post_caller_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_shade_caller_post_caller_post_caller_post_caller_post:
  {
    auto _mls_x1254 = (_mls_x1179 * _mls_x1181);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1173)) {
      auto _mls_x1255 = _mlsValue::cast<_mls_Tuple3>(_mls_x1173)->_mls_field0;
      auto _mls_x1256 = _mlsValue::cast<_mls_Tuple3>(_mls_x1173)->_mls_field1;
      auto _mls_x1257 = _mlsValue::cast<_mls_Tuple3>(_mls_x1173)->_mls_field2;
      auto _mls_x1258 = _mls_vecscale_case0_sr_post(_mls_x1254, _mls_x1255, _mls_x1256, _mls_x1257);
      _mls_x1182 = _mls_x1173;
      _mls_x1183 = _mls_x1174;
      _mls_x1184 = _mls_x1175;
      _mls_x1185 = _mls_x1258;
      _mls_x1186 = _mls_x1176;
      _mls_x1187 = _mls_x1177;
      _mls_x1188 = _mls_x1178;
      _mls_x1189 = _mls_x1180;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1188)) {
      auto _mls_x1259 = _mls_vecadd_case0(_mls_x1188, _mls_x1185);
      _mls_x1190 = _mls_x1187;
      _mls_x1191 = _mls_x1186;
      _mls_x1192 = _mls_x1182;
      _mls_x1193 = _mls_x1189;
      _mls_x1194 = _mls_x1259;
      _mls_x1195 = _mls_x1184;
      _mls_x1196 = _mls_x1188;
      _mls_x1197 = _mls_x1183;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    auto _mls_x1260 = _mlsValue::create<_mls_Lambda_lambda>(_mls_x1194, _mls_x1195, _mls_x1190, _mls_x1192);
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1193)) {
      auto _mls_x1262 = _mls_map_case0(_mls_x1193, _mls_x1260);
      _mls_x1198 = _mls_x1190;
      _mls_x1199 = _mls_x1191;
      _mls_x1200 = _mls_x1192;
      _mls_x1201 = _mls_x1193;
      _mls_x1202 = _mls_x1262;
      _mls_x1203 = _mls_x1194;
      _mls_x1204 = _mls_x1195;
      _mls_x1205 = _mls_x1196;
      _mls_x1206 = _mls_x1197;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post1;
    } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1193)) {
      auto _mls_x1261 = _mls_map_case1();
      _mls_x1198 = _mls_x1190;
      _mls_x1199 = _mls_x1191;
      _mls_x1200 = _mls_x1192;
      _mls_x1201 = _mls_x1193;
      _mls_x1202 = _mls_x1261;
      _mls_x1203 = _mls_x1194;
      _mls_x1204 = _mls_x1195;
      _mls_x1205 = _mls_x1196;
      _mls_x1206 = _mls_x1197;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post1:
  {
    auto _mls_x1263 = _mls_vecsum(_mls_x1202);
    auto _mls_x1264 = _mls_transmitsurf(_mls_x1198);
    auto _mls_x1265 = _mls_vecadd(_mls_x1206, _mls_x1263);
    auto [_mls_x1266, _mls_x1267, _mls_x1268] = _mls_bodysurf_pre(_mls_x1198);
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1266)) {
      _mls_x1207 = _mls_x1198;
      _mls_x1208 = _mls_x1201;
      _mls_x1209 = _mls_x1265;
      _mls_x1210 = _mls_x1203;
      _mls_x1211 = _mls_x1267;
      _mls_x1212 = _mls_x1204;
      _mls_x1213 = _mls_x1199;
      _mls_x1214 = _mls_x1205;
      _mls_x1215 = _mls_x1200;
      _mls_x1216 = _mls_x1264;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1266)) {
      auto _mls_x1269 = _mls_bodysurf_case1(_mls_x1266, _mls_x1268);
      _mls_x1207 = _mls_x1198;
      _mls_x1208 = _mls_x1201;
      _mls_x1209 = _mls_x1265;
      _mls_x1210 = _mls_x1203;
      _mls_x1211 = _mls_x1269;
      _mls_x1212 = _mls_x1204;
      _mls_x1213 = _mls_x1199;
      _mls_x1214 = _mls_x1205;
      _mls_x1215 = _mls_x1200;
      _mls_x1216 = _mls_x1264;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    auto _mls_x1270 = _mls_vecscale(_mls_x1211, _mls_x1216);
    auto _mls_x1271 = (_mls_x1216 < _mlsValue::create<_mls_Float>(1.0E-6));
    if (_mlsValue::isIntLit(_mls_x1271, 1)) {
      auto _mls_x1274 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x1209);
      _mls_refl1 = _mls_x1210;
      _mls_hitpos1 = _mls_x1212;
      _mls_tmp3 = _mls_x1274;
      _mls_surf = _mls_x1207;
      _mls_trintensity = _mls_x1270;
      _mls_contrib1 = _mls_x1213;
      _mls_lights1 = _mls_x1208;
      goto _mls_j4;
    } else {
      auto _mls_x1272 = _mls_refractsurf(_mls_x1207);
      auto _mls_x1273 = _mls_transmitray(_mls_x1208, _mls_x1209, _mls_x1212, _mls_x1214, _mls_x1272, _mls_x1270, _mls_x1213, _mls_x1215);
      _mls_refl1 = _mls_x1210;
      _mls_hitpos1 = _mls_x1212;
      _mls_tmp3 = _mls_x1273;
      _mls_surf = _mls_x1207;
      _mls_trintensity = _mls_x1270;
      _mls_contrib1 = _mls_x1213;
      _mls_lights1 = _mls_x1208;
      goto _mls_j4;
    }
    return _mls_retval;
  }
  _mls_j4:
  {
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_tmp3)) {
      auto _mls_x184 = _mlsValue::cast<_mls_Tuple2>(_mls_tmp3)->_mls_field0;
      auto _mls_x185 = _mlsValue::cast<_mls_Tuple2>(_mls_tmp3)->_mls_field1;
      auto [_mls_x787, _mls_x788, _mls_x789] = _mls_specularsurf_pre(_mls_surf);
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x787)) {
        auto _mls_x793 = _mls_reflectsurf(_mls_surf);
        auto _mls_x794 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field0;
        auto _mls_x795 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field1;
        auto _mls_x796 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field2;
        _mls_x769 = _mls_refl1;
        _mls_x770 = _mls_x184;
        _mls_x771 = _mls_x796;
        _mls_x772 = _mls_hitpos1;
        _mls_x773 = _mls_x185;
        _mls_x774 = _mls_x795;
        _mls_x775 = _mls_lights1;
        _mls_x776 = _mls_trintensity;
        _mls_x777 = _mls_contrib1;
        _mls_x778 = _mls_x794;
        _mls_x779 = _mls_x793;
        goto _mls_j_caller_post_case0_sr_post;
      } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x787)) {
        auto _mls_x790 = _mlsValue::cast<_mls_Cons>(_mls_x787)->_mls_head;
        auto _mls_x791 = _mlsValue::cast<_mls_Cons>(_mls_x787)->_mls_tail;
        auto _mls_x792 = _mls_specularsurf_case1_sr_post(_mls_x791, _mls_x789, _mls_x790);
        _mls_x760 = _mls_trintensity;
        _mls_x761 = _mls_refl1;
        _mls_x762 = _mls_lights1;
        _mls_x763 = _mls_surf;
        _mls_x764 = _mls_x185;
        _mls_x765 = _mls_x184;
        _mls_x766 = _mls_x792;
        _mls_x767 = _mls_hitpos1;
        _mls_x768 = _mls_contrib1;
        goto _mls_j_caller_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post:
  {
    auto _mls_x797 = _mls_reflectsurf(_mls_x763);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x766)) {
      auto _mls_x798 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field0;
      auto _mls_x799 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field1;
      auto _mls_x800 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field2;
      _mls_x769 = _mls_x761;
      _mls_x770 = _mls_x765;
      _mls_x771 = _mls_x800;
      _mls_x772 = _mls_x767;
      _mls_x773 = _mls_x764;
      _mls_x774 = _mls_x799;
      _mls_x775 = _mls_x762;
      _mls_x776 = _mls_x760;
      _mls_x777 = _mls_x768;
      _mls_x778 = _mls_x798;
      _mls_x779 = _mls_x797;
      goto _mls_j_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post_case0_sr_post:
  {
    auto _mls_x801 = _mls_vecscale_case0_sr_post(_mls_x779, _mls_x778, _mls_x774, _mls_x771);
    if (_mlsValue::isIntLit(_mls_x770, 1)) {
      _mls_x780 = _mls_x772;
      _mls_x781 = _mls_x775;
      _mls_x782 = _mls_x769;
      _mls_x783 = _mls_x777;
      _mls_x784 = _mls_x801;
      _mls_x785 = _mls_x773;
      _mls_x786 = _mls_x776;
      goto _mls_j_caller_post_case0;
    } else {
      _mls_refl = _mls_x769;
      _mls_hitpos = _mls_x772;
      _mls_trcol = _mls_x773;
      _mls_tmp2 = _mls_x801;
      _mls_contrib = _mls_x777;
      _mls_lights = _mls_x775;
      goto _mls_j3;
    }
    return _mls_retval;
  }
  _mls_j3:
  {
    auto _mls_x190 = _mls_is_zerovector(_mls_tmp2);
    if (_mlsValue::isIntLit(_mls_x190, 1)) {
      _mls_retval = _mls_trcol;
    } else {
      auto _mls_x191 = _mls_reflectray(_mls_hitpos, _mls_refl, _mls_lights, _mls_tmp2, _mls_contrib, _mls_trcol);
      _mls_retval = _mls_x191;
    }
    return _mls_retval;
  }
  _mls_j_caller_post_case0:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x786)) {
      auto _mls_x802 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field0;
      auto _mls_x803 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field1;
      auto _mls_x804 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field2;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x784)) {
        auto _mls_x805 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field0;
        auto _mls_x806 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field1;
        auto _mls_x807 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field2;
        auto _mls_x808 = _mls_vecadd_case0_sr_post_case0_sr_post(_mls_x802, _mls_x804, _mls_x805, _mls_x807, _mls_x803, _mls_x806);
        _mls_refl = _mls_x782;
        _mls_hitpos = _mls_x780;
        _mls_trcol = _mls_x785;
        _mls_tmp2 = _mls_x808;
        _mls_contrib = _mls_x783;
        _mls_lights = _mls_x781;
        goto _mls_j3;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_shade_caller_post_caller_post_caller_post_caller_post(_mlsValue _mls_x1173, _mlsValue _mls_x1174, _mlsValue _mls_x1175, _mlsValue _mls_x1176, _mlsValue _mls_x1177, _mlsValue _mls_x1178, _mlsValue _mls_x1179, _mlsValue _mls_x1180, _mlsValue _mls_x1181) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1182, _mls_x1183, _mls_x1184, _mls_x1185, _mls_x1186, _mls_x1187, _mls_x1188, _mls_x1189;
  _mlsValue _mls_x1190, _mls_x1191, _mls_x1192, _mls_x1193, _mls_x1194, _mls_x1195, _mls_x1196, _mls_x1197;
  _mlsValue _mls_x1198, _mls_x1199, _mls_x1200, _mls_x1201, _mls_x1202, _mls_x1203, _mls_x1204, _mls_x1205, _mls_x1206;
  _mlsValue _mls_x1207, _mls_x1208, _mls_x1209, _mls_x1210, _mls_x1211, _mls_x1212, _mls_x1213, _mls_x1214, _mls_x1215, _mls_x1216;
  _mlsValue _mls_refl1, _mls_hitpos1, _mls_tmp3, _mls_surf, _mls_trintensity, _mls_contrib1, _mls_lights1;
  _mlsValue _mls_x760, _mls_x761, _mls_x762, _mls_x763, _mls_x764, _mls_x765, _mls_x766, _mls_x767, _mls_x768;
  _mlsValue _mls_x769, _mls_x770, _mls_x771, _mls_x772, _mls_x773, _mls_x774, _mls_x775, _mls_x776, _mls_x777, _mls_x778, _mls_x779;
  _mlsValue _mls_refl, _mls_hitpos, _mls_trcol, _mls_tmp2, _mls_contrib, _mls_lights;
  _mlsValue _mls_x780, _mls_x781, _mls_x782, _mls_x783, _mls_x784, _mls_x785, _mls_x786;
  auto _mls_x1254 = (_mls_x1179 * _mls_x1181);
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1173)) {
    auto _mls_x1255 = _mlsValue::cast<_mls_Tuple3>(_mls_x1173)->_mls_field0;
    auto _mls_x1256 = _mlsValue::cast<_mls_Tuple3>(_mls_x1173)->_mls_field1;
    auto _mls_x1257 = _mlsValue::cast<_mls_Tuple3>(_mls_x1173)->_mls_field2;
    auto _mls_x1258 = _mls_vecscale_case0_sr_post(_mls_x1254, _mls_x1255, _mls_x1256, _mls_x1257);
    _mls_x1182 = _mls_x1173;
    _mls_x1183 = _mls_x1174;
    _mls_x1184 = _mls_x1175;
    _mls_x1185 = _mls_x1258;
    _mls_x1186 = _mls_x1176;
    _mls_x1187 = _mls_x1177;
    _mls_x1188 = _mls_x1178;
    _mls_x1189 = _mls_x1180;
    goto _mls_shade_caller_post_caller_post_caller_post_caller_post1;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_shade_caller_post_caller_post_caller_post_caller_post1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1188)) {
      auto _mls_x1259 = _mls_vecadd_case0(_mls_x1188, _mls_x1185);
      _mls_x1190 = _mls_x1187;
      _mls_x1191 = _mls_x1186;
      _mls_x1192 = _mls_x1182;
      _mls_x1193 = _mls_x1189;
      _mls_x1194 = _mls_x1259;
      _mls_x1195 = _mls_x1184;
      _mls_x1196 = _mls_x1188;
      _mls_x1197 = _mls_x1183;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    auto _mls_x1260 = _mlsValue::create<_mls_Lambda_lambda>(_mls_x1194, _mls_x1195, _mls_x1190, _mls_x1192);
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1193)) {
      auto _mls_x1262 = _mls_map_case0(_mls_x1193, _mls_x1260);
      _mls_x1198 = _mls_x1190;
      _mls_x1199 = _mls_x1191;
      _mls_x1200 = _mls_x1192;
      _mls_x1201 = _mls_x1193;
      _mls_x1202 = _mls_x1262;
      _mls_x1203 = _mls_x1194;
      _mls_x1204 = _mls_x1195;
      _mls_x1205 = _mls_x1196;
      _mls_x1206 = _mls_x1197;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post1;
    } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1193)) {
      auto _mls_x1261 = _mls_map_case1();
      _mls_x1198 = _mls_x1190;
      _mls_x1199 = _mls_x1191;
      _mls_x1200 = _mls_x1192;
      _mls_x1201 = _mls_x1193;
      _mls_x1202 = _mls_x1261;
      _mls_x1203 = _mls_x1194;
      _mls_x1204 = _mls_x1195;
      _mls_x1205 = _mls_x1196;
      _mls_x1206 = _mls_x1197;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post1:
  {
    auto _mls_x1263 = _mls_vecsum(_mls_x1202);
    auto _mls_x1264 = _mls_transmitsurf(_mls_x1198);
    auto _mls_x1265 = _mls_vecadd(_mls_x1206, _mls_x1263);
    auto [_mls_x1266, _mls_x1267, _mls_x1268] = _mls_bodysurf_pre(_mls_x1198);
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1266)) {
      _mls_x1207 = _mls_x1198;
      _mls_x1208 = _mls_x1201;
      _mls_x1209 = _mls_x1265;
      _mls_x1210 = _mls_x1203;
      _mls_x1211 = _mls_x1267;
      _mls_x1212 = _mls_x1204;
      _mls_x1213 = _mls_x1199;
      _mls_x1214 = _mls_x1205;
      _mls_x1215 = _mls_x1200;
      _mls_x1216 = _mls_x1264;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1266)) {
      auto _mls_x1269 = _mls_bodysurf_case1(_mls_x1266, _mls_x1268);
      _mls_x1207 = _mls_x1198;
      _mls_x1208 = _mls_x1201;
      _mls_x1209 = _mls_x1265;
      _mls_x1210 = _mls_x1203;
      _mls_x1211 = _mls_x1269;
      _mls_x1212 = _mls_x1204;
      _mls_x1213 = _mls_x1199;
      _mls_x1214 = _mls_x1205;
      _mls_x1215 = _mls_x1200;
      _mls_x1216 = _mls_x1264;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    auto _mls_x1270 = _mls_vecscale(_mls_x1211, _mls_x1216);
    auto _mls_x1271 = (_mls_x1216 < _mlsValue::create<_mls_Float>(1.0E-6));
    if (_mlsValue::isIntLit(_mls_x1271, 1)) {
      auto _mls_x1274 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x1209);
      _mls_refl1 = _mls_x1210;
      _mls_hitpos1 = _mls_x1212;
      _mls_tmp3 = _mls_x1274;
      _mls_surf = _mls_x1207;
      _mls_trintensity = _mls_x1270;
      _mls_contrib1 = _mls_x1213;
      _mls_lights1 = _mls_x1208;
      goto _mls_j4;
    } else {
      auto _mls_x1272 = _mls_refractsurf(_mls_x1207);
      auto _mls_x1273 = _mls_transmitray(_mls_x1208, _mls_x1209, _mls_x1212, _mls_x1214, _mls_x1272, _mls_x1270, _mls_x1213, _mls_x1215);
      _mls_refl1 = _mls_x1210;
      _mls_hitpos1 = _mls_x1212;
      _mls_tmp3 = _mls_x1273;
      _mls_surf = _mls_x1207;
      _mls_trintensity = _mls_x1270;
      _mls_contrib1 = _mls_x1213;
      _mls_lights1 = _mls_x1208;
      goto _mls_j4;
    }
    return _mls_retval;
  }
  _mls_j4:
  {
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_tmp3)) {
      auto _mls_x184 = _mlsValue::cast<_mls_Tuple2>(_mls_tmp3)->_mls_field0;
      auto _mls_x185 = _mlsValue::cast<_mls_Tuple2>(_mls_tmp3)->_mls_field1;
      auto [_mls_x787, _mls_x788, _mls_x789] = _mls_specularsurf_pre(_mls_surf);
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x787)) {
        auto _mls_x793 = _mls_reflectsurf(_mls_surf);
        auto _mls_x794 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field0;
        auto _mls_x795 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field1;
        auto _mls_x796 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field2;
        _mls_x769 = _mls_refl1;
        _mls_x770 = _mls_x184;
        _mls_x771 = _mls_x796;
        _mls_x772 = _mls_hitpos1;
        _mls_x773 = _mls_x185;
        _mls_x774 = _mls_x795;
        _mls_x775 = _mls_lights1;
        _mls_x776 = _mls_trintensity;
        _mls_x777 = _mls_contrib1;
        _mls_x778 = _mls_x794;
        _mls_x779 = _mls_x793;
        goto _mls_j_caller_post_case0_sr_post;
      } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x787)) {
        auto _mls_x790 = _mlsValue::cast<_mls_Cons>(_mls_x787)->_mls_head;
        auto _mls_x791 = _mlsValue::cast<_mls_Cons>(_mls_x787)->_mls_tail;
        auto _mls_x792 = _mls_specularsurf_case1_sr_post(_mls_x791, _mls_x789, _mls_x790);
        _mls_x760 = _mls_trintensity;
        _mls_x761 = _mls_refl1;
        _mls_x762 = _mls_lights1;
        _mls_x763 = _mls_surf;
        _mls_x764 = _mls_x185;
        _mls_x765 = _mls_x184;
        _mls_x766 = _mls_x792;
        _mls_x767 = _mls_hitpos1;
        _mls_x768 = _mls_contrib1;
        goto _mls_j_caller_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post:
  {
    auto _mls_x797 = _mls_reflectsurf(_mls_x763);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x766)) {
      auto _mls_x798 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field0;
      auto _mls_x799 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field1;
      auto _mls_x800 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field2;
      _mls_x769 = _mls_x761;
      _mls_x770 = _mls_x765;
      _mls_x771 = _mls_x800;
      _mls_x772 = _mls_x767;
      _mls_x773 = _mls_x764;
      _mls_x774 = _mls_x799;
      _mls_x775 = _mls_x762;
      _mls_x776 = _mls_x760;
      _mls_x777 = _mls_x768;
      _mls_x778 = _mls_x798;
      _mls_x779 = _mls_x797;
      goto _mls_j_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post_case0_sr_post:
  {
    auto _mls_x801 = _mls_vecscale_case0_sr_post(_mls_x779, _mls_x778, _mls_x774, _mls_x771);
    if (_mlsValue::isIntLit(_mls_x770, 1)) {
      _mls_x780 = _mls_x772;
      _mls_x781 = _mls_x775;
      _mls_x782 = _mls_x769;
      _mls_x783 = _mls_x777;
      _mls_x784 = _mls_x801;
      _mls_x785 = _mls_x773;
      _mls_x786 = _mls_x776;
      goto _mls_j_caller_post_case0;
    } else {
      _mls_refl = _mls_x769;
      _mls_hitpos = _mls_x772;
      _mls_trcol = _mls_x773;
      _mls_tmp2 = _mls_x801;
      _mls_contrib = _mls_x777;
      _mls_lights = _mls_x775;
      goto _mls_j3;
    }
    return _mls_retval;
  }
  _mls_j3:
  {
    auto _mls_x190 = _mls_is_zerovector(_mls_tmp2);
    if (_mlsValue::isIntLit(_mls_x190, 1)) {
      _mls_retval = _mls_trcol;
    } else {
      auto _mls_x191 = _mls_reflectray(_mls_hitpos, _mls_refl, _mls_lights, _mls_tmp2, _mls_contrib, _mls_trcol);
      _mls_retval = _mls_x191;
    }
    return _mls_retval;
  }
  _mls_j_caller_post_case0:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x786)) {
      auto _mls_x802 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field0;
      auto _mls_x803 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field1;
      auto _mls_x804 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field2;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x784)) {
        auto _mls_x805 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field0;
        auto _mls_x806 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field1;
        auto _mls_x807 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field2;
        auto _mls_x808 = _mls_vecadd_case0_sr_post_case0_sr_post(_mls_x802, _mls_x804, _mls_x805, _mls_x807, _mls_x803, _mls_x806);
        _mls_refl = _mls_x782;
        _mls_hitpos = _mls_x780;
        _mls_trcol = _mls_x785;
        _mls_tmp2 = _mls_x808;
        _mls_contrib = _mls_x783;
        _mls_lights = _mls_x781;
        goto _mls_j3;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_shade_caller_post_caller_post_caller_post_caller_post1(_mlsValue _mls_x1182, _mlsValue _mls_x1183, _mlsValue _mls_x1184, _mlsValue _mls_x1185, _mlsValue _mls_x1186, _mlsValue _mls_x1187, _mlsValue _mls_x1188, _mlsValue _mls_x1189) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1190, _mls_x1191, _mls_x1192, _mls_x1193, _mls_x1194, _mls_x1195, _mls_x1196, _mls_x1197;
  _mlsValue _mls_x1198, _mls_x1199, _mls_x1200, _mls_x1201, _mls_x1202, _mls_x1203, _mls_x1204, _mls_x1205, _mls_x1206;
  _mlsValue _mls_x1207, _mls_x1208, _mls_x1209, _mls_x1210, _mls_x1211, _mls_x1212, _mls_x1213, _mls_x1214, _mls_x1215, _mls_x1216;
  _mlsValue _mls_refl1, _mls_hitpos1, _mls_tmp3, _mls_surf, _mls_trintensity, _mls_contrib1, _mls_lights1;
  _mlsValue _mls_x760, _mls_x761, _mls_x762, _mls_x763, _mls_x764, _mls_x765, _mls_x766, _mls_x767, _mls_x768;
  _mlsValue _mls_x769, _mls_x770, _mls_x771, _mls_x772, _mls_x773, _mls_x774, _mls_x775, _mls_x776, _mls_x777, _mls_x778, _mls_x779;
  _mlsValue _mls_refl, _mls_hitpos, _mls_trcol, _mls_tmp2, _mls_contrib, _mls_lights;
  _mlsValue _mls_x780, _mls_x781, _mls_x782, _mls_x783, _mls_x784, _mls_x785, _mls_x786;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1188)) {
    auto _mls_x1259 = _mls_vecadd_case0(_mls_x1188, _mls_x1185);
    _mls_x1190 = _mls_x1187;
    _mls_x1191 = _mls_x1186;
    _mls_x1192 = _mls_x1182;
    _mls_x1193 = _mls_x1189;
    _mls_x1194 = _mls_x1259;
    _mls_x1195 = _mls_x1184;
    _mls_x1196 = _mls_x1188;
    _mls_x1197 = _mls_x1183;
    goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    auto _mls_x1260 = _mlsValue::create<_mls_Lambda_lambda>(_mls_x1194, _mls_x1195, _mls_x1190, _mls_x1192);
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1193)) {
      auto _mls_x1262 = _mls_map_case0(_mls_x1193, _mls_x1260);
      _mls_x1198 = _mls_x1190;
      _mls_x1199 = _mls_x1191;
      _mls_x1200 = _mls_x1192;
      _mls_x1201 = _mls_x1193;
      _mls_x1202 = _mls_x1262;
      _mls_x1203 = _mls_x1194;
      _mls_x1204 = _mls_x1195;
      _mls_x1205 = _mls_x1196;
      _mls_x1206 = _mls_x1197;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post1;
    } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1193)) {
      auto _mls_x1261 = _mls_map_case1();
      _mls_x1198 = _mls_x1190;
      _mls_x1199 = _mls_x1191;
      _mls_x1200 = _mls_x1192;
      _mls_x1201 = _mls_x1193;
      _mls_x1202 = _mls_x1261;
      _mls_x1203 = _mls_x1194;
      _mls_x1204 = _mls_x1195;
      _mls_x1205 = _mls_x1196;
      _mls_x1206 = _mls_x1197;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post1:
  {
    auto _mls_x1263 = _mls_vecsum(_mls_x1202);
    auto _mls_x1264 = _mls_transmitsurf(_mls_x1198);
    auto _mls_x1265 = _mls_vecadd(_mls_x1206, _mls_x1263);
    auto [_mls_x1266, _mls_x1267, _mls_x1268] = _mls_bodysurf_pre(_mls_x1198);
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1266)) {
      _mls_x1207 = _mls_x1198;
      _mls_x1208 = _mls_x1201;
      _mls_x1209 = _mls_x1265;
      _mls_x1210 = _mls_x1203;
      _mls_x1211 = _mls_x1267;
      _mls_x1212 = _mls_x1204;
      _mls_x1213 = _mls_x1199;
      _mls_x1214 = _mls_x1205;
      _mls_x1215 = _mls_x1200;
      _mls_x1216 = _mls_x1264;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1266)) {
      auto _mls_x1269 = _mls_bodysurf_case1(_mls_x1266, _mls_x1268);
      _mls_x1207 = _mls_x1198;
      _mls_x1208 = _mls_x1201;
      _mls_x1209 = _mls_x1265;
      _mls_x1210 = _mls_x1203;
      _mls_x1211 = _mls_x1269;
      _mls_x1212 = _mls_x1204;
      _mls_x1213 = _mls_x1199;
      _mls_x1214 = _mls_x1205;
      _mls_x1215 = _mls_x1200;
      _mls_x1216 = _mls_x1264;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    auto _mls_x1270 = _mls_vecscale(_mls_x1211, _mls_x1216);
    auto _mls_x1271 = (_mls_x1216 < _mlsValue::create<_mls_Float>(1.0E-6));
    if (_mlsValue::isIntLit(_mls_x1271, 1)) {
      auto _mls_x1274 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x1209);
      _mls_refl1 = _mls_x1210;
      _mls_hitpos1 = _mls_x1212;
      _mls_tmp3 = _mls_x1274;
      _mls_surf = _mls_x1207;
      _mls_trintensity = _mls_x1270;
      _mls_contrib1 = _mls_x1213;
      _mls_lights1 = _mls_x1208;
      goto _mls_j4;
    } else {
      auto _mls_x1272 = _mls_refractsurf(_mls_x1207);
      auto _mls_x1273 = _mls_transmitray(_mls_x1208, _mls_x1209, _mls_x1212, _mls_x1214, _mls_x1272, _mls_x1270, _mls_x1213, _mls_x1215);
      _mls_refl1 = _mls_x1210;
      _mls_hitpos1 = _mls_x1212;
      _mls_tmp3 = _mls_x1273;
      _mls_surf = _mls_x1207;
      _mls_trintensity = _mls_x1270;
      _mls_contrib1 = _mls_x1213;
      _mls_lights1 = _mls_x1208;
      goto _mls_j4;
    }
    return _mls_retval;
  }
  _mls_j4:
  {
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_tmp3)) {
      auto _mls_x184 = _mlsValue::cast<_mls_Tuple2>(_mls_tmp3)->_mls_field0;
      auto _mls_x185 = _mlsValue::cast<_mls_Tuple2>(_mls_tmp3)->_mls_field1;
      auto [_mls_x787, _mls_x788, _mls_x789] = _mls_specularsurf_pre(_mls_surf);
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x787)) {
        auto _mls_x793 = _mls_reflectsurf(_mls_surf);
        auto _mls_x794 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field0;
        auto _mls_x795 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field1;
        auto _mls_x796 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field2;
        _mls_x769 = _mls_refl1;
        _mls_x770 = _mls_x184;
        _mls_x771 = _mls_x796;
        _mls_x772 = _mls_hitpos1;
        _mls_x773 = _mls_x185;
        _mls_x774 = _mls_x795;
        _mls_x775 = _mls_lights1;
        _mls_x776 = _mls_trintensity;
        _mls_x777 = _mls_contrib1;
        _mls_x778 = _mls_x794;
        _mls_x779 = _mls_x793;
        goto _mls_j_caller_post_case0_sr_post;
      } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x787)) {
        auto _mls_x790 = _mlsValue::cast<_mls_Cons>(_mls_x787)->_mls_head;
        auto _mls_x791 = _mlsValue::cast<_mls_Cons>(_mls_x787)->_mls_tail;
        auto _mls_x792 = _mls_specularsurf_case1_sr_post(_mls_x791, _mls_x789, _mls_x790);
        _mls_x760 = _mls_trintensity;
        _mls_x761 = _mls_refl1;
        _mls_x762 = _mls_lights1;
        _mls_x763 = _mls_surf;
        _mls_x764 = _mls_x185;
        _mls_x765 = _mls_x184;
        _mls_x766 = _mls_x792;
        _mls_x767 = _mls_hitpos1;
        _mls_x768 = _mls_contrib1;
        goto _mls_j_caller_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post:
  {
    auto _mls_x797 = _mls_reflectsurf(_mls_x763);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x766)) {
      auto _mls_x798 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field0;
      auto _mls_x799 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field1;
      auto _mls_x800 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field2;
      _mls_x769 = _mls_x761;
      _mls_x770 = _mls_x765;
      _mls_x771 = _mls_x800;
      _mls_x772 = _mls_x767;
      _mls_x773 = _mls_x764;
      _mls_x774 = _mls_x799;
      _mls_x775 = _mls_x762;
      _mls_x776 = _mls_x760;
      _mls_x777 = _mls_x768;
      _mls_x778 = _mls_x798;
      _mls_x779 = _mls_x797;
      goto _mls_j_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post_case0_sr_post:
  {
    auto _mls_x801 = _mls_vecscale_case0_sr_post(_mls_x779, _mls_x778, _mls_x774, _mls_x771);
    if (_mlsValue::isIntLit(_mls_x770, 1)) {
      _mls_x780 = _mls_x772;
      _mls_x781 = _mls_x775;
      _mls_x782 = _mls_x769;
      _mls_x783 = _mls_x777;
      _mls_x784 = _mls_x801;
      _mls_x785 = _mls_x773;
      _mls_x786 = _mls_x776;
      goto _mls_j_caller_post_case0;
    } else {
      _mls_refl = _mls_x769;
      _mls_hitpos = _mls_x772;
      _mls_trcol = _mls_x773;
      _mls_tmp2 = _mls_x801;
      _mls_contrib = _mls_x777;
      _mls_lights = _mls_x775;
      goto _mls_j3;
    }
    return _mls_retval;
  }
  _mls_j3:
  {
    auto _mls_x190 = _mls_is_zerovector(_mls_tmp2);
    if (_mlsValue::isIntLit(_mls_x190, 1)) {
      _mls_retval = _mls_trcol;
    } else {
      auto _mls_x191 = _mls_reflectray(_mls_hitpos, _mls_refl, _mls_lights, _mls_tmp2, _mls_contrib, _mls_trcol);
      _mls_retval = _mls_x191;
    }
    return _mls_retval;
  }
  _mls_j_caller_post_case0:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x786)) {
      auto _mls_x802 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field0;
      auto _mls_x803 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field1;
      auto _mls_x804 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field2;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x784)) {
        auto _mls_x805 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field0;
        auto _mls_x806 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field1;
        auto _mls_x807 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field2;
        auto _mls_x808 = _mls_vecadd_case0_sr_post_case0_sr_post(_mls_x802, _mls_x804, _mls_x805, _mls_x807, _mls_x803, _mls_x806);
        _mls_refl = _mls_x782;
        _mls_hitpos = _mls_x780;
        _mls_trcol = _mls_x785;
        _mls_tmp2 = _mls_x808;
        _mls_contrib = _mls_x783;
        _mls_lights = _mls_x781;
        goto _mls_j3;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post(_mlsValue _mls_x1190, _mlsValue _mls_x1191, _mlsValue _mls_x1192, _mlsValue _mls_x1193, _mlsValue _mls_x1194, _mlsValue _mls_x1195, _mlsValue _mls_x1196, _mlsValue _mls_x1197) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1198, _mls_x1199, _mls_x1200, _mls_x1201, _mls_x1202, _mls_x1203, _mls_x1204, _mls_x1205, _mls_x1206;
  _mlsValue _mls_x1207, _mls_x1208, _mls_x1209, _mls_x1210, _mls_x1211, _mls_x1212, _mls_x1213, _mls_x1214, _mls_x1215, _mls_x1216;
  _mlsValue _mls_refl1, _mls_hitpos1, _mls_tmp3, _mls_surf, _mls_trintensity, _mls_contrib1, _mls_lights1;
  _mlsValue _mls_x760, _mls_x761, _mls_x762, _mls_x763, _mls_x764, _mls_x765, _mls_x766, _mls_x767, _mls_x768;
  _mlsValue _mls_x769, _mls_x770, _mls_x771, _mls_x772, _mls_x773, _mls_x774, _mls_x775, _mls_x776, _mls_x777, _mls_x778, _mls_x779;
  _mlsValue _mls_refl, _mls_hitpos, _mls_trcol, _mls_tmp2, _mls_contrib, _mls_lights;
  _mlsValue _mls_x780, _mls_x781, _mls_x782, _mls_x783, _mls_x784, _mls_x785, _mls_x786;
  auto _mls_x1260 = _mlsValue::create<_mls_Lambda_lambda>(_mls_x1194, _mls_x1195, _mls_x1190, _mls_x1192);
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1193)) {
    auto _mls_x1262 = _mls_map_case0(_mls_x1193, _mls_x1260);
    _mls_x1198 = _mls_x1190;
    _mls_x1199 = _mls_x1191;
    _mls_x1200 = _mls_x1192;
    _mls_x1201 = _mls_x1193;
    _mls_x1202 = _mls_x1262;
    _mls_x1203 = _mls_x1194;
    _mls_x1204 = _mls_x1195;
    _mls_x1205 = _mls_x1196;
    _mls_x1206 = _mls_x1197;
    goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post1;
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1193)) {
    auto _mls_x1261 = _mls_map_case1();
    _mls_x1198 = _mls_x1190;
    _mls_x1199 = _mls_x1191;
    _mls_x1200 = _mls_x1192;
    _mls_x1201 = _mls_x1193;
    _mls_x1202 = _mls_x1261;
    _mls_x1203 = _mls_x1194;
    _mls_x1204 = _mls_x1195;
    _mls_x1205 = _mls_x1196;
    _mls_x1206 = _mls_x1197;
    goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post1;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post1:
  {
    auto _mls_x1263 = _mls_vecsum(_mls_x1202);
    auto _mls_x1264 = _mls_transmitsurf(_mls_x1198);
    auto _mls_x1265 = _mls_vecadd(_mls_x1206, _mls_x1263);
    auto [_mls_x1266, _mls_x1267, _mls_x1268] = _mls_bodysurf_pre(_mls_x1198);
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1266)) {
      _mls_x1207 = _mls_x1198;
      _mls_x1208 = _mls_x1201;
      _mls_x1209 = _mls_x1265;
      _mls_x1210 = _mls_x1203;
      _mls_x1211 = _mls_x1267;
      _mls_x1212 = _mls_x1204;
      _mls_x1213 = _mls_x1199;
      _mls_x1214 = _mls_x1205;
      _mls_x1215 = _mls_x1200;
      _mls_x1216 = _mls_x1264;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1266)) {
      auto _mls_x1269 = _mls_bodysurf_case1(_mls_x1266, _mls_x1268);
      _mls_x1207 = _mls_x1198;
      _mls_x1208 = _mls_x1201;
      _mls_x1209 = _mls_x1265;
      _mls_x1210 = _mls_x1203;
      _mls_x1211 = _mls_x1269;
      _mls_x1212 = _mls_x1204;
      _mls_x1213 = _mls_x1199;
      _mls_x1214 = _mls_x1205;
      _mls_x1215 = _mls_x1200;
      _mls_x1216 = _mls_x1264;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    auto _mls_x1270 = _mls_vecscale(_mls_x1211, _mls_x1216);
    auto _mls_x1271 = (_mls_x1216 < _mlsValue::create<_mls_Float>(1.0E-6));
    if (_mlsValue::isIntLit(_mls_x1271, 1)) {
      auto _mls_x1274 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x1209);
      _mls_refl1 = _mls_x1210;
      _mls_hitpos1 = _mls_x1212;
      _mls_tmp3 = _mls_x1274;
      _mls_surf = _mls_x1207;
      _mls_trintensity = _mls_x1270;
      _mls_contrib1 = _mls_x1213;
      _mls_lights1 = _mls_x1208;
      goto _mls_j4;
    } else {
      auto _mls_x1272 = _mls_refractsurf(_mls_x1207);
      auto _mls_x1273 = _mls_transmitray(_mls_x1208, _mls_x1209, _mls_x1212, _mls_x1214, _mls_x1272, _mls_x1270, _mls_x1213, _mls_x1215);
      _mls_refl1 = _mls_x1210;
      _mls_hitpos1 = _mls_x1212;
      _mls_tmp3 = _mls_x1273;
      _mls_surf = _mls_x1207;
      _mls_trintensity = _mls_x1270;
      _mls_contrib1 = _mls_x1213;
      _mls_lights1 = _mls_x1208;
      goto _mls_j4;
    }
    return _mls_retval;
  }
  _mls_j4:
  {
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_tmp3)) {
      auto _mls_x184 = _mlsValue::cast<_mls_Tuple2>(_mls_tmp3)->_mls_field0;
      auto _mls_x185 = _mlsValue::cast<_mls_Tuple2>(_mls_tmp3)->_mls_field1;
      auto [_mls_x787, _mls_x788, _mls_x789] = _mls_specularsurf_pre(_mls_surf);
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x787)) {
        auto _mls_x793 = _mls_reflectsurf(_mls_surf);
        auto _mls_x794 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field0;
        auto _mls_x795 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field1;
        auto _mls_x796 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field2;
        _mls_x769 = _mls_refl1;
        _mls_x770 = _mls_x184;
        _mls_x771 = _mls_x796;
        _mls_x772 = _mls_hitpos1;
        _mls_x773 = _mls_x185;
        _mls_x774 = _mls_x795;
        _mls_x775 = _mls_lights1;
        _mls_x776 = _mls_trintensity;
        _mls_x777 = _mls_contrib1;
        _mls_x778 = _mls_x794;
        _mls_x779 = _mls_x793;
        goto _mls_j_caller_post_case0_sr_post;
      } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x787)) {
        auto _mls_x790 = _mlsValue::cast<_mls_Cons>(_mls_x787)->_mls_head;
        auto _mls_x791 = _mlsValue::cast<_mls_Cons>(_mls_x787)->_mls_tail;
        auto _mls_x792 = _mls_specularsurf_case1_sr_post(_mls_x791, _mls_x789, _mls_x790);
        _mls_x760 = _mls_trintensity;
        _mls_x761 = _mls_refl1;
        _mls_x762 = _mls_lights1;
        _mls_x763 = _mls_surf;
        _mls_x764 = _mls_x185;
        _mls_x765 = _mls_x184;
        _mls_x766 = _mls_x792;
        _mls_x767 = _mls_hitpos1;
        _mls_x768 = _mls_contrib1;
        goto _mls_j_caller_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post:
  {
    auto _mls_x797 = _mls_reflectsurf(_mls_x763);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x766)) {
      auto _mls_x798 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field0;
      auto _mls_x799 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field1;
      auto _mls_x800 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field2;
      _mls_x769 = _mls_x761;
      _mls_x770 = _mls_x765;
      _mls_x771 = _mls_x800;
      _mls_x772 = _mls_x767;
      _mls_x773 = _mls_x764;
      _mls_x774 = _mls_x799;
      _mls_x775 = _mls_x762;
      _mls_x776 = _mls_x760;
      _mls_x777 = _mls_x768;
      _mls_x778 = _mls_x798;
      _mls_x779 = _mls_x797;
      goto _mls_j_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post_case0_sr_post:
  {
    auto _mls_x801 = _mls_vecscale_case0_sr_post(_mls_x779, _mls_x778, _mls_x774, _mls_x771);
    if (_mlsValue::isIntLit(_mls_x770, 1)) {
      _mls_x780 = _mls_x772;
      _mls_x781 = _mls_x775;
      _mls_x782 = _mls_x769;
      _mls_x783 = _mls_x777;
      _mls_x784 = _mls_x801;
      _mls_x785 = _mls_x773;
      _mls_x786 = _mls_x776;
      goto _mls_j_caller_post_case0;
    } else {
      _mls_refl = _mls_x769;
      _mls_hitpos = _mls_x772;
      _mls_trcol = _mls_x773;
      _mls_tmp2 = _mls_x801;
      _mls_contrib = _mls_x777;
      _mls_lights = _mls_x775;
      goto _mls_j3;
    }
    return _mls_retval;
  }
  _mls_j3:
  {
    auto _mls_x190 = _mls_is_zerovector(_mls_tmp2);
    if (_mlsValue::isIntLit(_mls_x190, 1)) {
      _mls_retval = _mls_trcol;
    } else {
      auto _mls_x191 = _mls_reflectray(_mls_hitpos, _mls_refl, _mls_lights, _mls_tmp2, _mls_contrib, _mls_trcol);
      _mls_retval = _mls_x191;
    }
    return _mls_retval;
  }
  _mls_j_caller_post_case0:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x786)) {
      auto _mls_x802 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field0;
      auto _mls_x803 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field1;
      auto _mls_x804 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field2;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x784)) {
        auto _mls_x805 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field0;
        auto _mls_x806 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field1;
        auto _mls_x807 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field2;
        auto _mls_x808 = _mls_vecadd_case0_sr_post_case0_sr_post(_mls_x802, _mls_x804, _mls_x805, _mls_x807, _mls_x803, _mls_x806);
        _mls_refl = _mls_x782;
        _mls_hitpos = _mls_x780;
        _mls_trcol = _mls_x785;
        _mls_tmp2 = _mls_x808;
        _mls_contrib = _mls_x783;
        _mls_lights = _mls_x781;
        goto _mls_j3;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post1(_mlsValue _mls_x1198, _mlsValue _mls_x1199, _mlsValue _mls_x1200, _mlsValue _mls_x1201, _mlsValue _mls_x1202, _mlsValue _mls_x1203, _mlsValue _mls_x1204, _mlsValue _mls_x1205, _mlsValue _mls_x1206) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1207, _mls_x1208, _mls_x1209, _mls_x1210, _mls_x1211, _mls_x1212, _mls_x1213, _mls_x1214, _mls_x1215, _mls_x1216;
  _mlsValue _mls_refl1, _mls_hitpos1, _mls_tmp3, _mls_surf, _mls_trintensity, _mls_contrib1, _mls_lights1;
  _mlsValue _mls_x760, _mls_x761, _mls_x762, _mls_x763, _mls_x764, _mls_x765, _mls_x766, _mls_x767, _mls_x768;
  _mlsValue _mls_x769, _mls_x770, _mls_x771, _mls_x772, _mls_x773, _mls_x774, _mls_x775, _mls_x776, _mls_x777, _mls_x778, _mls_x779;
  _mlsValue _mls_refl, _mls_hitpos, _mls_trcol, _mls_tmp2, _mls_contrib, _mls_lights;
  _mlsValue _mls_x780, _mls_x781, _mls_x782, _mls_x783, _mls_x784, _mls_x785, _mls_x786;
  auto _mls_x1263 = _mls_vecsum(_mls_x1202);
  auto _mls_x1264 = _mls_transmitsurf(_mls_x1198);
  auto _mls_x1265 = _mls_vecadd(_mls_x1206, _mls_x1263);
  auto [_mls_x1266, _mls_x1267, _mls_x1268] = _mls_bodysurf_pre(_mls_x1198);
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1266)) {
    _mls_x1207 = _mls_x1198;
    _mls_x1208 = _mls_x1201;
    _mls_x1209 = _mls_x1265;
    _mls_x1210 = _mls_x1203;
    _mls_x1211 = _mls_x1267;
    _mls_x1212 = _mls_x1204;
    _mls_x1213 = _mls_x1199;
    _mls_x1214 = _mls_x1205;
    _mls_x1215 = _mls_x1200;
    _mls_x1216 = _mls_x1264;
    goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1266)) {
    auto _mls_x1269 = _mls_bodysurf_case1(_mls_x1266, _mls_x1268);
    _mls_x1207 = _mls_x1198;
    _mls_x1208 = _mls_x1201;
    _mls_x1209 = _mls_x1265;
    _mls_x1210 = _mls_x1203;
    _mls_x1211 = _mls_x1269;
    _mls_x1212 = _mls_x1204;
    _mls_x1213 = _mls_x1199;
    _mls_x1214 = _mls_x1205;
    _mls_x1215 = _mls_x1200;
    _mls_x1216 = _mls_x1264;
    goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    auto _mls_x1270 = _mls_vecscale(_mls_x1211, _mls_x1216);
    auto _mls_x1271 = (_mls_x1216 < _mlsValue::create<_mls_Float>(1.0E-6));
    if (_mlsValue::isIntLit(_mls_x1271, 1)) {
      auto _mls_x1274 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x1209);
      _mls_refl1 = _mls_x1210;
      _mls_hitpos1 = _mls_x1212;
      _mls_tmp3 = _mls_x1274;
      _mls_surf = _mls_x1207;
      _mls_trintensity = _mls_x1270;
      _mls_contrib1 = _mls_x1213;
      _mls_lights1 = _mls_x1208;
      goto _mls_j4;
    } else {
      auto _mls_x1272 = _mls_refractsurf(_mls_x1207);
      auto _mls_x1273 = _mls_transmitray(_mls_x1208, _mls_x1209, _mls_x1212, _mls_x1214, _mls_x1272, _mls_x1270, _mls_x1213, _mls_x1215);
      _mls_refl1 = _mls_x1210;
      _mls_hitpos1 = _mls_x1212;
      _mls_tmp3 = _mls_x1273;
      _mls_surf = _mls_x1207;
      _mls_trintensity = _mls_x1270;
      _mls_contrib1 = _mls_x1213;
      _mls_lights1 = _mls_x1208;
      goto _mls_j4;
    }
    return _mls_retval;
  }
  _mls_j4:
  {
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_tmp3)) {
      auto _mls_x184 = _mlsValue::cast<_mls_Tuple2>(_mls_tmp3)->_mls_field0;
      auto _mls_x185 = _mlsValue::cast<_mls_Tuple2>(_mls_tmp3)->_mls_field1;
      auto [_mls_x787, _mls_x788, _mls_x789] = _mls_specularsurf_pre(_mls_surf);
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x787)) {
        auto _mls_x793 = _mls_reflectsurf(_mls_surf);
        auto _mls_x794 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field0;
        auto _mls_x795 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field1;
        auto _mls_x796 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field2;
        _mls_x769 = _mls_refl1;
        _mls_x770 = _mls_x184;
        _mls_x771 = _mls_x796;
        _mls_x772 = _mls_hitpos1;
        _mls_x773 = _mls_x185;
        _mls_x774 = _mls_x795;
        _mls_x775 = _mls_lights1;
        _mls_x776 = _mls_trintensity;
        _mls_x777 = _mls_contrib1;
        _mls_x778 = _mls_x794;
        _mls_x779 = _mls_x793;
        goto _mls_j_caller_post_case0_sr_post;
      } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x787)) {
        auto _mls_x790 = _mlsValue::cast<_mls_Cons>(_mls_x787)->_mls_head;
        auto _mls_x791 = _mlsValue::cast<_mls_Cons>(_mls_x787)->_mls_tail;
        auto _mls_x792 = _mls_specularsurf_case1_sr_post(_mls_x791, _mls_x789, _mls_x790);
        _mls_x760 = _mls_trintensity;
        _mls_x761 = _mls_refl1;
        _mls_x762 = _mls_lights1;
        _mls_x763 = _mls_surf;
        _mls_x764 = _mls_x185;
        _mls_x765 = _mls_x184;
        _mls_x766 = _mls_x792;
        _mls_x767 = _mls_hitpos1;
        _mls_x768 = _mls_contrib1;
        goto _mls_j_caller_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post:
  {
    auto _mls_x797 = _mls_reflectsurf(_mls_x763);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x766)) {
      auto _mls_x798 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field0;
      auto _mls_x799 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field1;
      auto _mls_x800 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field2;
      _mls_x769 = _mls_x761;
      _mls_x770 = _mls_x765;
      _mls_x771 = _mls_x800;
      _mls_x772 = _mls_x767;
      _mls_x773 = _mls_x764;
      _mls_x774 = _mls_x799;
      _mls_x775 = _mls_x762;
      _mls_x776 = _mls_x760;
      _mls_x777 = _mls_x768;
      _mls_x778 = _mls_x798;
      _mls_x779 = _mls_x797;
      goto _mls_j_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post_case0_sr_post:
  {
    auto _mls_x801 = _mls_vecscale_case0_sr_post(_mls_x779, _mls_x778, _mls_x774, _mls_x771);
    if (_mlsValue::isIntLit(_mls_x770, 1)) {
      _mls_x780 = _mls_x772;
      _mls_x781 = _mls_x775;
      _mls_x782 = _mls_x769;
      _mls_x783 = _mls_x777;
      _mls_x784 = _mls_x801;
      _mls_x785 = _mls_x773;
      _mls_x786 = _mls_x776;
      goto _mls_j_caller_post_case0;
    } else {
      _mls_refl = _mls_x769;
      _mls_hitpos = _mls_x772;
      _mls_trcol = _mls_x773;
      _mls_tmp2 = _mls_x801;
      _mls_contrib = _mls_x777;
      _mls_lights = _mls_x775;
      goto _mls_j3;
    }
    return _mls_retval;
  }
  _mls_j3:
  {
    auto _mls_x190 = _mls_is_zerovector(_mls_tmp2);
    if (_mlsValue::isIntLit(_mls_x190, 1)) {
      _mls_retval = _mls_trcol;
    } else {
      auto _mls_x191 = _mls_reflectray(_mls_hitpos, _mls_refl, _mls_lights, _mls_tmp2, _mls_contrib, _mls_trcol);
      _mls_retval = _mls_x191;
    }
    return _mls_retval;
  }
  _mls_j_caller_post_case0:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x786)) {
      auto _mls_x802 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field0;
      auto _mls_x803 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field1;
      auto _mls_x804 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field2;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x784)) {
        auto _mls_x805 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field0;
        auto _mls_x806 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field1;
        auto _mls_x807 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field2;
        auto _mls_x808 = _mls_vecadd_case0_sr_post_case0_sr_post(_mls_x802, _mls_x804, _mls_x805, _mls_x807, _mls_x803, _mls_x806);
        _mls_refl = _mls_x782;
        _mls_hitpos = _mls_x780;
        _mls_trcol = _mls_x785;
        _mls_tmp2 = _mls_x808;
        _mls_contrib = _mls_x783;
        _mls_lights = _mls_x781;
        goto _mls_j3;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post(_mlsValue _mls_x1207, _mlsValue _mls_x1208, _mlsValue _mls_x1209, _mlsValue _mls_x1210, _mlsValue _mls_x1211, _mlsValue _mls_x1212, _mlsValue _mls_x1213, _mlsValue _mls_x1214, _mlsValue _mls_x1215, _mlsValue _mls_x1216) {
  _mlsValue _mls_retval;
  _mlsValue _mls_refl1, _mls_hitpos1, _mls_tmp3, _mls_surf, _mls_trintensity, _mls_contrib1, _mls_lights1;
  _mlsValue _mls_x760, _mls_x761, _mls_x762, _mls_x763, _mls_x764, _mls_x765, _mls_x766, _mls_x767, _mls_x768;
  _mlsValue _mls_x769, _mls_x770, _mls_x771, _mls_x772, _mls_x773, _mls_x774, _mls_x775, _mls_x776, _mls_x777, _mls_x778, _mls_x779;
  _mlsValue _mls_refl, _mls_hitpos, _mls_trcol, _mls_tmp2, _mls_contrib, _mls_lights;
  _mlsValue _mls_x780, _mls_x781, _mls_x782, _mls_x783, _mls_x784, _mls_x785, _mls_x786;
  auto _mls_x1270 = _mls_vecscale(_mls_x1211, _mls_x1216);
  auto _mls_x1271 = (_mls_x1216 < _mlsValue::create<_mls_Float>(1.0E-6));
  if (_mlsValue::isIntLit(_mls_x1271, 1)) {
    auto _mls_x1274 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x1209);
    _mls_refl1 = _mls_x1210;
    _mls_hitpos1 = _mls_x1212;
    _mls_tmp3 = _mls_x1274;
    _mls_surf = _mls_x1207;
    _mls_trintensity = _mls_x1270;
    _mls_contrib1 = _mls_x1213;
    _mls_lights1 = _mls_x1208;
    goto _mls_j4;
  } else {
    auto _mls_x1272 = _mls_refractsurf(_mls_x1207);
    auto _mls_x1273 = _mls_transmitray(_mls_x1208, _mls_x1209, _mls_x1212, _mls_x1214, _mls_x1272, _mls_x1270, _mls_x1213, _mls_x1215);
    _mls_refl1 = _mls_x1210;
    _mls_hitpos1 = _mls_x1212;
    _mls_tmp3 = _mls_x1273;
    _mls_surf = _mls_x1207;
    _mls_trintensity = _mls_x1270;
    _mls_contrib1 = _mls_x1213;
    _mls_lights1 = _mls_x1208;
    goto _mls_j4;
  }
  return _mls_retval;
  _mls_j4:
  {
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_tmp3)) {
      auto _mls_x184 = _mlsValue::cast<_mls_Tuple2>(_mls_tmp3)->_mls_field0;
      auto _mls_x185 = _mlsValue::cast<_mls_Tuple2>(_mls_tmp3)->_mls_field1;
      auto [_mls_x787, _mls_x788, _mls_x789] = _mls_specularsurf_pre(_mls_surf);
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x787)) {
        auto _mls_x793 = _mls_reflectsurf(_mls_surf);
        auto _mls_x794 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field0;
        auto _mls_x795 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field1;
        auto _mls_x796 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field2;
        _mls_x769 = _mls_refl1;
        _mls_x770 = _mls_x184;
        _mls_x771 = _mls_x796;
        _mls_x772 = _mls_hitpos1;
        _mls_x773 = _mls_x185;
        _mls_x774 = _mls_x795;
        _mls_x775 = _mls_lights1;
        _mls_x776 = _mls_trintensity;
        _mls_x777 = _mls_contrib1;
        _mls_x778 = _mls_x794;
        _mls_x779 = _mls_x793;
        goto _mls_j_caller_post_case0_sr_post;
      } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x787)) {
        auto _mls_x790 = _mlsValue::cast<_mls_Cons>(_mls_x787)->_mls_head;
        auto _mls_x791 = _mlsValue::cast<_mls_Cons>(_mls_x787)->_mls_tail;
        auto _mls_x792 = _mls_specularsurf_case1_sr_post(_mls_x791, _mls_x789, _mls_x790);
        _mls_x760 = _mls_trintensity;
        _mls_x761 = _mls_refl1;
        _mls_x762 = _mls_lights1;
        _mls_x763 = _mls_surf;
        _mls_x764 = _mls_x185;
        _mls_x765 = _mls_x184;
        _mls_x766 = _mls_x792;
        _mls_x767 = _mls_hitpos1;
        _mls_x768 = _mls_contrib1;
        goto _mls_j_caller_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post:
  {
    auto _mls_x797 = _mls_reflectsurf(_mls_x763);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x766)) {
      auto _mls_x798 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field0;
      auto _mls_x799 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field1;
      auto _mls_x800 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field2;
      _mls_x769 = _mls_x761;
      _mls_x770 = _mls_x765;
      _mls_x771 = _mls_x800;
      _mls_x772 = _mls_x767;
      _mls_x773 = _mls_x764;
      _mls_x774 = _mls_x799;
      _mls_x775 = _mls_x762;
      _mls_x776 = _mls_x760;
      _mls_x777 = _mls_x768;
      _mls_x778 = _mls_x798;
      _mls_x779 = _mls_x797;
      goto _mls_j_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post_case0_sr_post:
  {
    auto _mls_x801 = _mls_vecscale_case0_sr_post(_mls_x779, _mls_x778, _mls_x774, _mls_x771);
    if (_mlsValue::isIntLit(_mls_x770, 1)) {
      _mls_x780 = _mls_x772;
      _mls_x781 = _mls_x775;
      _mls_x782 = _mls_x769;
      _mls_x783 = _mls_x777;
      _mls_x784 = _mls_x801;
      _mls_x785 = _mls_x773;
      _mls_x786 = _mls_x776;
      goto _mls_j_caller_post_case0;
    } else {
      _mls_refl = _mls_x769;
      _mls_hitpos = _mls_x772;
      _mls_trcol = _mls_x773;
      _mls_tmp2 = _mls_x801;
      _mls_contrib = _mls_x777;
      _mls_lights = _mls_x775;
      goto _mls_j3;
    }
    return _mls_retval;
  }
  _mls_j3:
  {
    auto _mls_x190 = _mls_is_zerovector(_mls_tmp2);
    if (_mlsValue::isIntLit(_mls_x190, 1)) {
      _mls_retval = _mls_trcol;
    } else {
      auto _mls_x191 = _mls_reflectray(_mls_hitpos, _mls_refl, _mls_lights, _mls_tmp2, _mls_contrib, _mls_trcol);
      _mls_retval = _mls_x191;
    }
    return _mls_retval;
  }
  _mls_j_caller_post_case0:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x786)) {
      auto _mls_x802 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field0;
      auto _mls_x803 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field1;
      auto _mls_x804 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field2;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x784)) {
        auto _mls_x805 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field0;
        auto _mls_x806 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field1;
        auto _mls_x807 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field2;
        auto _mls_x808 = _mls_vecadd_case0_sr_post_case0_sr_post(_mls_x802, _mls_x804, _mls_x805, _mls_x807, _mls_x803, _mls_x806);
        _mls_refl = _mls_x782;
        _mls_hitpos = _mls_x780;
        _mls_trcol = _mls_x785;
        _mls_tmp2 = _mls_x808;
        _mls_contrib = _mls_x783;
        _mls_lights = _mls_x781;
        goto _mls_j3;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_shade_caller_post_caller_post_caller_post_pre(_mlsValue _mls_x1284, _mlsValue _mls_x1289, _mlsValue _mls_x1285, _mlsValue _mls_x1288, _mlsValue _mls_x1287, _mlsValue _mls_x1283, _mlsValue _mls_x1286) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x1282 = (-_mlsValue::create<_mls_Float>(2.0));
  _mls_retval = std::make_tuple(_mls_x1283, _mls_x1284, _mls_x1285, _mls_x1286, _mls_x1287, _mls_x1288, _mls_x1282, _mls_x1289);
  return _mls_retval;
}
_mlsValue _mls_shade_caller_post_post(_mlsValue _mls_x1161, _mlsValue _mls_x1162, _mlsValue _mls_x1163, _mlsValue _mls_x1164, _mlsValue _mls_x1165) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1166, _mls_x1167, _mls_x1168, _mls_x1169, _mls_x1170, _mls_x1171, _mls_x1172;
  _mlsValue _mls_x1173, _mls_x1174, _mls_x1175, _mls_x1176, _mls_x1177, _mls_x1178, _mls_x1179, _mls_x1180, _mls_x1181;
  _mlsValue _mls_x1182, _mls_x1183, _mls_x1184, _mls_x1185, _mls_x1186, _mls_x1187, _mls_x1188, _mls_x1189;
  _mlsValue _mls_x1190, _mls_x1191, _mls_x1192, _mls_x1193, _mls_x1194, _mls_x1195, _mls_x1196, _mls_x1197;
  _mlsValue _mls_x1198, _mls_x1199, _mls_x1200, _mls_x1201, _mls_x1202, _mls_x1203, _mls_x1204, _mls_x1205, _mls_x1206;
  _mlsValue _mls_x1207, _mls_x1208, _mls_x1209, _mls_x1210, _mls_x1211, _mls_x1212, _mls_x1213, _mls_x1214, _mls_x1215, _mls_x1216;
  _mlsValue _mls_refl1, _mls_hitpos1, _mls_tmp3, _mls_surf, _mls_trintensity, _mls_contrib1, _mls_lights1;
  _mlsValue _mls_x760, _mls_x761, _mls_x762, _mls_x763, _mls_x764, _mls_x765, _mls_x766, _mls_x767, _mls_x768;
  _mlsValue _mls_x769, _mls_x770, _mls_x771, _mls_x772, _mls_x773, _mls_x774, _mls_x775, _mls_x776, _mls_x777, _mls_x778, _mls_x779;
  _mlsValue _mls_refl, _mls_hitpos, _mls_trcol, _mls_tmp2, _mls_contrib, _mls_lights;
  _mlsValue _mls_x780, _mls_x781, _mls_x782, _mls_x783, _mls_x784, _mls_x785, _mls_x786;
  auto _mls_x1230 = _mls_spheresurf(_mls_x1163);
  auto [_mls_x1231, _mls_x1232, _mls_x1233] = _mls_ambientsurf_pre(_mls_x1230);
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1231)) {
    auto _mls_x1238 = _mlsValue::cast<_mls_Tuple3>(_mls_x1232)->_mls_field0;
    auto _mls_x1239 = _mlsValue::cast<_mls_Tuple3>(_mls_x1232)->_mls_field1;
    auto _mls_x1240 = _mlsValue::cast<_mls_Tuple3>(_mls_x1232)->_mls_field2;
    auto _mls_x1241 = _mls_vecmult_case0_sr_post_case0_sr_post(_mls_x1240, _mlsValue::create<_mls_Float>(1.0), _mls_x1239, _mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0), _mls_x1238);
    _mls_x1166 = _mls_x1241;
    _mls_x1167 = _mls_x1230;
    _mls_x1168 = _mls_x1161;
    _mls_x1169 = _mls_x1162;
    _mls_x1170 = _mls_x1163;
    _mls_x1171 = _mls_x1164;
    _mls_x1172 = _mls_x1165;
    goto _mls_shade_caller_post_caller_post;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1231)) {
    auto _mls_x1234 = _mlsValue::cast<_mls_Cons>(_mls_x1231)->_mls_head;
    auto _mls_x1235 = _mlsValue::cast<_mls_Cons>(_mls_x1231)->_mls_tail;
    auto _mls_x1236 = _mls_ambientsurf_case1_sr_post(_mls_x1235, _mls_x1233, _mls_x1234);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1236)) {
      auto _mls_x1237 = _mls_vecmult_case0_sr_post_case0(_mls_x1236, _mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0));
      _mls_x1166 = _mls_x1237;
      _mls_x1167 = _mls_x1230;
      _mls_x1168 = _mls_x1161;
      _mls_x1169 = _mls_x1162;
      _mls_x1170 = _mls_x1163;
      _mls_x1171 = _mls_x1164;
      _mls_x1172 = _mls_x1165;
      goto _mls_shade_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_shade_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Sphere>(_mls_x1170)) {
      auto _mls_x1242 = _mlsValue::cast<_mls_Sphere>(_mls_x1170)->_mls_pos;
      auto _mls_x1243 = _mlsValue::cast<_mls_Sphere>(_mls_x1170)->_mls_radius;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1172)) {
        auto _mls_x1244 = _mls_spherenormal_case0_sr_post_case0(_mls_x1172, _mls_x1242, _mls_x1243);
        auto [_mls_x1245, _mls_x1246, _mls_x1247, _mls_x1248, _mls_x1249, _mls_x1250, _mls_x1251, _mls_x1252] = _mls_shade_caller_post_caller_post_caller_post_pre(_mls_x1166, _mls_x1171, _mls_x1172, _mls_x1169, _mls_x1167, _mls_x1244, _mls_x1168);
        if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1250)) {
          auto _mls_x1253 = _mls_vecdot_case0(_mls_x1250, _mls_x1245);
          _mls_x1173 = _mls_x1245;
          _mls_x1174 = _mls_x1246;
          _mls_x1175 = _mls_x1247;
          _mls_x1176 = _mls_x1248;
          _mls_x1177 = _mls_x1249;
          _mls_x1178 = _mls_x1250;
          _mls_x1179 = _mls_x1251;
          _mls_x1180 = _mls_x1252;
          _mls_x1181 = _mls_x1253;
          goto _mls_shade_caller_post_caller_post_caller_post_caller_post;
        } else {
          _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post:
  {
    auto _mls_x1254 = (_mls_x1179 * _mls_x1181);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1173)) {
      auto _mls_x1255 = _mlsValue::cast<_mls_Tuple3>(_mls_x1173)->_mls_field0;
      auto _mls_x1256 = _mlsValue::cast<_mls_Tuple3>(_mls_x1173)->_mls_field1;
      auto _mls_x1257 = _mlsValue::cast<_mls_Tuple3>(_mls_x1173)->_mls_field2;
      auto _mls_x1258 = _mls_vecscale_case0_sr_post(_mls_x1254, _mls_x1255, _mls_x1256, _mls_x1257);
      _mls_x1182 = _mls_x1173;
      _mls_x1183 = _mls_x1174;
      _mls_x1184 = _mls_x1175;
      _mls_x1185 = _mls_x1258;
      _mls_x1186 = _mls_x1176;
      _mls_x1187 = _mls_x1177;
      _mls_x1188 = _mls_x1178;
      _mls_x1189 = _mls_x1180;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1188)) {
      auto _mls_x1259 = _mls_vecadd_case0(_mls_x1188, _mls_x1185);
      _mls_x1190 = _mls_x1187;
      _mls_x1191 = _mls_x1186;
      _mls_x1192 = _mls_x1182;
      _mls_x1193 = _mls_x1189;
      _mls_x1194 = _mls_x1259;
      _mls_x1195 = _mls_x1184;
      _mls_x1196 = _mls_x1188;
      _mls_x1197 = _mls_x1183;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    auto _mls_x1260 = _mlsValue::create<_mls_Lambda_lambda>(_mls_x1194, _mls_x1195, _mls_x1190, _mls_x1192);
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1193)) {
      auto _mls_x1262 = _mls_map_case0(_mls_x1193, _mls_x1260);
      _mls_x1198 = _mls_x1190;
      _mls_x1199 = _mls_x1191;
      _mls_x1200 = _mls_x1192;
      _mls_x1201 = _mls_x1193;
      _mls_x1202 = _mls_x1262;
      _mls_x1203 = _mls_x1194;
      _mls_x1204 = _mls_x1195;
      _mls_x1205 = _mls_x1196;
      _mls_x1206 = _mls_x1197;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post1;
    } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1193)) {
      auto _mls_x1261 = _mls_map_case1();
      _mls_x1198 = _mls_x1190;
      _mls_x1199 = _mls_x1191;
      _mls_x1200 = _mls_x1192;
      _mls_x1201 = _mls_x1193;
      _mls_x1202 = _mls_x1261;
      _mls_x1203 = _mls_x1194;
      _mls_x1204 = _mls_x1195;
      _mls_x1205 = _mls_x1196;
      _mls_x1206 = _mls_x1197;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post1:
  {
    auto _mls_x1263 = _mls_vecsum(_mls_x1202);
    auto _mls_x1264 = _mls_transmitsurf(_mls_x1198);
    auto _mls_x1265 = _mls_vecadd(_mls_x1206, _mls_x1263);
    auto [_mls_x1266, _mls_x1267, _mls_x1268] = _mls_bodysurf_pre(_mls_x1198);
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1266)) {
      _mls_x1207 = _mls_x1198;
      _mls_x1208 = _mls_x1201;
      _mls_x1209 = _mls_x1265;
      _mls_x1210 = _mls_x1203;
      _mls_x1211 = _mls_x1267;
      _mls_x1212 = _mls_x1204;
      _mls_x1213 = _mls_x1199;
      _mls_x1214 = _mls_x1205;
      _mls_x1215 = _mls_x1200;
      _mls_x1216 = _mls_x1264;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1266)) {
      auto _mls_x1269 = _mls_bodysurf_case1(_mls_x1266, _mls_x1268);
      _mls_x1207 = _mls_x1198;
      _mls_x1208 = _mls_x1201;
      _mls_x1209 = _mls_x1265;
      _mls_x1210 = _mls_x1203;
      _mls_x1211 = _mls_x1269;
      _mls_x1212 = _mls_x1204;
      _mls_x1213 = _mls_x1199;
      _mls_x1214 = _mls_x1205;
      _mls_x1215 = _mls_x1200;
      _mls_x1216 = _mls_x1264;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    auto _mls_x1270 = _mls_vecscale(_mls_x1211, _mls_x1216);
    auto _mls_x1271 = (_mls_x1216 < _mlsValue::create<_mls_Float>(1.0E-6));
    if (_mlsValue::isIntLit(_mls_x1271, 1)) {
      auto _mls_x1274 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x1209);
      _mls_refl1 = _mls_x1210;
      _mls_hitpos1 = _mls_x1212;
      _mls_tmp3 = _mls_x1274;
      _mls_surf = _mls_x1207;
      _mls_trintensity = _mls_x1270;
      _mls_contrib1 = _mls_x1213;
      _mls_lights1 = _mls_x1208;
      goto _mls_j4;
    } else {
      auto _mls_x1272 = _mls_refractsurf(_mls_x1207);
      auto _mls_x1273 = _mls_transmitray(_mls_x1208, _mls_x1209, _mls_x1212, _mls_x1214, _mls_x1272, _mls_x1270, _mls_x1213, _mls_x1215);
      _mls_refl1 = _mls_x1210;
      _mls_hitpos1 = _mls_x1212;
      _mls_tmp3 = _mls_x1273;
      _mls_surf = _mls_x1207;
      _mls_trintensity = _mls_x1270;
      _mls_contrib1 = _mls_x1213;
      _mls_lights1 = _mls_x1208;
      goto _mls_j4;
    }
    return _mls_retval;
  }
  _mls_j4:
  {
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_tmp3)) {
      auto _mls_x184 = _mlsValue::cast<_mls_Tuple2>(_mls_tmp3)->_mls_field0;
      auto _mls_x185 = _mlsValue::cast<_mls_Tuple2>(_mls_tmp3)->_mls_field1;
      auto [_mls_x787, _mls_x788, _mls_x789] = _mls_specularsurf_pre(_mls_surf);
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x787)) {
        auto _mls_x793 = _mls_reflectsurf(_mls_surf);
        auto _mls_x794 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field0;
        auto _mls_x795 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field1;
        auto _mls_x796 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field2;
        _mls_x769 = _mls_refl1;
        _mls_x770 = _mls_x184;
        _mls_x771 = _mls_x796;
        _mls_x772 = _mls_hitpos1;
        _mls_x773 = _mls_x185;
        _mls_x774 = _mls_x795;
        _mls_x775 = _mls_lights1;
        _mls_x776 = _mls_trintensity;
        _mls_x777 = _mls_contrib1;
        _mls_x778 = _mls_x794;
        _mls_x779 = _mls_x793;
        goto _mls_j_caller_post_case0_sr_post;
      } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x787)) {
        auto _mls_x790 = _mlsValue::cast<_mls_Cons>(_mls_x787)->_mls_head;
        auto _mls_x791 = _mlsValue::cast<_mls_Cons>(_mls_x787)->_mls_tail;
        auto _mls_x792 = _mls_specularsurf_case1_sr_post(_mls_x791, _mls_x789, _mls_x790);
        _mls_x760 = _mls_trintensity;
        _mls_x761 = _mls_refl1;
        _mls_x762 = _mls_lights1;
        _mls_x763 = _mls_surf;
        _mls_x764 = _mls_x185;
        _mls_x765 = _mls_x184;
        _mls_x766 = _mls_x792;
        _mls_x767 = _mls_hitpos1;
        _mls_x768 = _mls_contrib1;
        goto _mls_j_caller_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post:
  {
    auto _mls_x797 = _mls_reflectsurf(_mls_x763);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x766)) {
      auto _mls_x798 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field0;
      auto _mls_x799 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field1;
      auto _mls_x800 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field2;
      _mls_x769 = _mls_x761;
      _mls_x770 = _mls_x765;
      _mls_x771 = _mls_x800;
      _mls_x772 = _mls_x767;
      _mls_x773 = _mls_x764;
      _mls_x774 = _mls_x799;
      _mls_x775 = _mls_x762;
      _mls_x776 = _mls_x760;
      _mls_x777 = _mls_x768;
      _mls_x778 = _mls_x798;
      _mls_x779 = _mls_x797;
      goto _mls_j_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post_case0_sr_post:
  {
    auto _mls_x801 = _mls_vecscale_case0_sr_post(_mls_x779, _mls_x778, _mls_x774, _mls_x771);
    if (_mlsValue::isIntLit(_mls_x770, 1)) {
      _mls_x780 = _mls_x772;
      _mls_x781 = _mls_x775;
      _mls_x782 = _mls_x769;
      _mls_x783 = _mls_x777;
      _mls_x784 = _mls_x801;
      _mls_x785 = _mls_x773;
      _mls_x786 = _mls_x776;
      goto _mls_j_caller_post_case0;
    } else {
      _mls_refl = _mls_x769;
      _mls_hitpos = _mls_x772;
      _mls_trcol = _mls_x773;
      _mls_tmp2 = _mls_x801;
      _mls_contrib = _mls_x777;
      _mls_lights = _mls_x775;
      goto _mls_j3;
    }
    return _mls_retval;
  }
  _mls_j3:
  {
    auto _mls_x190 = _mls_is_zerovector(_mls_tmp2);
    if (_mlsValue::isIntLit(_mls_x190, 1)) {
      _mls_retval = _mls_trcol;
    } else {
      auto _mls_x191 = _mls_reflectray(_mls_hitpos, _mls_refl, _mls_lights, _mls_tmp2, _mls_contrib, _mls_trcol);
      _mls_retval = _mls_x191;
    }
    return _mls_retval;
  }
  _mls_j_caller_post_case0:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x786)) {
      auto _mls_x802 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field0;
      auto _mls_x803 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field1;
      auto _mls_x804 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field2;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x784)) {
        auto _mls_x805 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field0;
        auto _mls_x806 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field1;
        auto _mls_x807 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field2;
        auto _mls_x808 = _mls_vecadd_case0_sr_post_case0_sr_post(_mls_x802, _mls_x804, _mls_x805, _mls_x807, _mls_x803, _mls_x806);
        _mls_refl = _mls_x782;
        _mls_hitpos = _mls_x780;
        _mls_trcol = _mls_x785;
        _mls_tmp2 = _mls_x808;
        _mls_contrib = _mls_x783;
        _mls_lights = _mls_x781;
        goto _mls_j3;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_shade_case0(_mlsValue _mls_x1295, _mlsValue _mls_x1290, _mlsValue _mls_x1292, _mlsValue _mls_x1293, _mlsValue _mls_x1291, _mlsValue _mls_x1294) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1161, _mls_x1162, _mls_x1163, _mls_x1164, _mls_x1165;
  _mlsValue _mls_x1166, _mls_x1167, _mls_x1168, _mls_x1169, _mls_x1170, _mls_x1171, _mls_x1172;
  _mlsValue _mls_x1173, _mls_x1174, _mls_x1175, _mls_x1176, _mls_x1177, _mls_x1178, _mls_x1179, _mls_x1180, _mls_x1181;
  _mlsValue _mls_x1182, _mls_x1183, _mls_x1184, _mls_x1185, _mls_x1186, _mls_x1187, _mls_x1188, _mls_x1189;
  _mlsValue _mls_x1190, _mls_x1191, _mls_x1192, _mls_x1193, _mls_x1194, _mls_x1195, _mls_x1196, _mls_x1197;
  _mlsValue _mls_x1198, _mls_x1199, _mls_x1200, _mls_x1201, _mls_x1202, _mls_x1203, _mls_x1204, _mls_x1205, _mls_x1206;
  _mlsValue _mls_x1207, _mls_x1208, _mls_x1209, _mls_x1210, _mls_x1211, _mls_x1212, _mls_x1213, _mls_x1214, _mls_x1215, _mls_x1216;
  _mlsValue _mls_refl1, _mls_hitpos1, _mls_tmp3, _mls_surf, _mls_trintensity, _mls_contrib1, _mls_lights1;
  _mlsValue _mls_x760, _mls_x761, _mls_x762, _mls_x763, _mls_x764, _mls_x765, _mls_x766, _mls_x767, _mls_x768;
  _mlsValue _mls_x769, _mls_x770, _mls_x771, _mls_x772, _mls_x773, _mls_x774, _mls_x775, _mls_x776, _mls_x777, _mls_x778, _mls_x779;
  _mlsValue _mls_refl, _mls_hitpos, _mls_trcol, _mls_tmp2, _mls_contrib, _mls_lights;
  _mlsValue _mls_x780, _mls_x781, _mls_x782, _mls_x783, _mls_x784, _mls_x785, _mls_x786;
  auto [_mls_x1296, _mls_x1297, _mls_x1298, _mls_x1299, _mls_x1300, _mls_x1301] = _mls_shade_case0_pre(_mls_x1290, _mls_x1291, _mls_x1292, _mls_x1293, _mls_x1294, _mls_x1295);
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1300)) {
    auto _mls_x1302 = _mls_vecadd_case0(_mls_x1300, _mls_x1299);
    _mls_x1161 = _mls_x1298;
    _mls_x1162 = _mls_x1296;
    _mls_x1163 = _mls_x1297;
    _mls_x1164 = _mls_x1301;
    _mls_x1165 = _mls_x1302;
    goto _mls_shade_caller_post_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_shade_caller_post_post:
  {
    auto _mls_x1230 = _mls_spheresurf(_mls_x1163);
    auto [_mls_x1231, _mls_x1232, _mls_x1233] = _mls_ambientsurf_pre(_mls_x1230);
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1231)) {
      auto _mls_x1238 = _mlsValue::cast<_mls_Tuple3>(_mls_x1232)->_mls_field0;
      auto _mls_x1239 = _mlsValue::cast<_mls_Tuple3>(_mls_x1232)->_mls_field1;
      auto _mls_x1240 = _mlsValue::cast<_mls_Tuple3>(_mls_x1232)->_mls_field2;
      auto _mls_x1241 = _mls_vecmult_case0_sr_post_case0_sr_post(_mls_x1240, _mlsValue::create<_mls_Float>(1.0), _mls_x1239, _mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0), _mls_x1238);
      _mls_x1166 = _mls_x1241;
      _mls_x1167 = _mls_x1230;
      _mls_x1168 = _mls_x1161;
      _mls_x1169 = _mls_x1162;
      _mls_x1170 = _mls_x1163;
      _mls_x1171 = _mls_x1164;
      _mls_x1172 = _mls_x1165;
      goto _mls_shade_caller_post_caller_post;
    } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1231)) {
      auto _mls_x1234 = _mlsValue::cast<_mls_Cons>(_mls_x1231)->_mls_head;
      auto _mls_x1235 = _mlsValue::cast<_mls_Cons>(_mls_x1231)->_mls_tail;
      auto _mls_x1236 = _mls_ambientsurf_case1_sr_post(_mls_x1235, _mls_x1233, _mls_x1234);
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1236)) {
        auto _mls_x1237 = _mls_vecmult_case0_sr_post_case0(_mls_x1236, _mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0));
        _mls_x1166 = _mls_x1237;
        _mls_x1167 = _mls_x1230;
        _mls_x1168 = _mls_x1161;
        _mls_x1169 = _mls_x1162;
        _mls_x1170 = _mls_x1163;
        _mls_x1171 = _mls_x1164;
        _mls_x1172 = _mls_x1165;
        goto _mls_shade_caller_post_caller_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Sphere>(_mls_x1170)) {
      auto _mls_x1242 = _mlsValue::cast<_mls_Sphere>(_mls_x1170)->_mls_pos;
      auto _mls_x1243 = _mlsValue::cast<_mls_Sphere>(_mls_x1170)->_mls_radius;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1172)) {
        auto _mls_x1244 = _mls_spherenormal_case0_sr_post_case0(_mls_x1172, _mls_x1242, _mls_x1243);
        auto [_mls_x1245, _mls_x1246, _mls_x1247, _mls_x1248, _mls_x1249, _mls_x1250, _mls_x1251, _mls_x1252] = _mls_shade_caller_post_caller_post_caller_post_pre(_mls_x1166, _mls_x1171, _mls_x1172, _mls_x1169, _mls_x1167, _mls_x1244, _mls_x1168);
        if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1250)) {
          auto _mls_x1253 = _mls_vecdot_case0(_mls_x1250, _mls_x1245);
          _mls_x1173 = _mls_x1245;
          _mls_x1174 = _mls_x1246;
          _mls_x1175 = _mls_x1247;
          _mls_x1176 = _mls_x1248;
          _mls_x1177 = _mls_x1249;
          _mls_x1178 = _mls_x1250;
          _mls_x1179 = _mls_x1251;
          _mls_x1180 = _mls_x1252;
          _mls_x1181 = _mls_x1253;
          goto _mls_shade_caller_post_caller_post_caller_post_caller_post;
        } else {
          _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post:
  {
    auto _mls_x1254 = (_mls_x1179 * _mls_x1181);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1173)) {
      auto _mls_x1255 = _mlsValue::cast<_mls_Tuple3>(_mls_x1173)->_mls_field0;
      auto _mls_x1256 = _mlsValue::cast<_mls_Tuple3>(_mls_x1173)->_mls_field1;
      auto _mls_x1257 = _mlsValue::cast<_mls_Tuple3>(_mls_x1173)->_mls_field2;
      auto _mls_x1258 = _mls_vecscale_case0_sr_post(_mls_x1254, _mls_x1255, _mls_x1256, _mls_x1257);
      _mls_x1182 = _mls_x1173;
      _mls_x1183 = _mls_x1174;
      _mls_x1184 = _mls_x1175;
      _mls_x1185 = _mls_x1258;
      _mls_x1186 = _mls_x1176;
      _mls_x1187 = _mls_x1177;
      _mls_x1188 = _mls_x1178;
      _mls_x1189 = _mls_x1180;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1188)) {
      auto _mls_x1259 = _mls_vecadd_case0(_mls_x1188, _mls_x1185);
      _mls_x1190 = _mls_x1187;
      _mls_x1191 = _mls_x1186;
      _mls_x1192 = _mls_x1182;
      _mls_x1193 = _mls_x1189;
      _mls_x1194 = _mls_x1259;
      _mls_x1195 = _mls_x1184;
      _mls_x1196 = _mls_x1188;
      _mls_x1197 = _mls_x1183;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    auto _mls_x1260 = _mlsValue::create<_mls_Lambda_lambda>(_mls_x1194, _mls_x1195, _mls_x1190, _mls_x1192);
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1193)) {
      auto _mls_x1262 = _mls_map_case0(_mls_x1193, _mls_x1260);
      _mls_x1198 = _mls_x1190;
      _mls_x1199 = _mls_x1191;
      _mls_x1200 = _mls_x1192;
      _mls_x1201 = _mls_x1193;
      _mls_x1202 = _mls_x1262;
      _mls_x1203 = _mls_x1194;
      _mls_x1204 = _mls_x1195;
      _mls_x1205 = _mls_x1196;
      _mls_x1206 = _mls_x1197;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post1;
    } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1193)) {
      auto _mls_x1261 = _mls_map_case1();
      _mls_x1198 = _mls_x1190;
      _mls_x1199 = _mls_x1191;
      _mls_x1200 = _mls_x1192;
      _mls_x1201 = _mls_x1193;
      _mls_x1202 = _mls_x1261;
      _mls_x1203 = _mls_x1194;
      _mls_x1204 = _mls_x1195;
      _mls_x1205 = _mls_x1196;
      _mls_x1206 = _mls_x1197;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post1:
  {
    auto _mls_x1263 = _mls_vecsum(_mls_x1202);
    auto _mls_x1264 = _mls_transmitsurf(_mls_x1198);
    auto _mls_x1265 = _mls_vecadd(_mls_x1206, _mls_x1263);
    auto [_mls_x1266, _mls_x1267, _mls_x1268] = _mls_bodysurf_pre(_mls_x1198);
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1266)) {
      _mls_x1207 = _mls_x1198;
      _mls_x1208 = _mls_x1201;
      _mls_x1209 = _mls_x1265;
      _mls_x1210 = _mls_x1203;
      _mls_x1211 = _mls_x1267;
      _mls_x1212 = _mls_x1204;
      _mls_x1213 = _mls_x1199;
      _mls_x1214 = _mls_x1205;
      _mls_x1215 = _mls_x1200;
      _mls_x1216 = _mls_x1264;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1266)) {
      auto _mls_x1269 = _mls_bodysurf_case1(_mls_x1266, _mls_x1268);
      _mls_x1207 = _mls_x1198;
      _mls_x1208 = _mls_x1201;
      _mls_x1209 = _mls_x1265;
      _mls_x1210 = _mls_x1203;
      _mls_x1211 = _mls_x1269;
      _mls_x1212 = _mls_x1204;
      _mls_x1213 = _mls_x1199;
      _mls_x1214 = _mls_x1205;
      _mls_x1215 = _mls_x1200;
      _mls_x1216 = _mls_x1264;
      goto _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_shade_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    auto _mls_x1270 = _mls_vecscale(_mls_x1211, _mls_x1216);
    auto _mls_x1271 = (_mls_x1216 < _mlsValue::create<_mls_Float>(1.0E-6));
    if (_mlsValue::isIntLit(_mls_x1271, 1)) {
      auto _mls_x1274 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x1209);
      _mls_refl1 = _mls_x1210;
      _mls_hitpos1 = _mls_x1212;
      _mls_tmp3 = _mls_x1274;
      _mls_surf = _mls_x1207;
      _mls_trintensity = _mls_x1270;
      _mls_contrib1 = _mls_x1213;
      _mls_lights1 = _mls_x1208;
      goto _mls_j4;
    } else {
      auto _mls_x1272 = _mls_refractsurf(_mls_x1207);
      auto _mls_x1273 = _mls_transmitray(_mls_x1208, _mls_x1209, _mls_x1212, _mls_x1214, _mls_x1272, _mls_x1270, _mls_x1213, _mls_x1215);
      _mls_refl1 = _mls_x1210;
      _mls_hitpos1 = _mls_x1212;
      _mls_tmp3 = _mls_x1273;
      _mls_surf = _mls_x1207;
      _mls_trintensity = _mls_x1270;
      _mls_contrib1 = _mls_x1213;
      _mls_lights1 = _mls_x1208;
      goto _mls_j4;
    }
    return _mls_retval;
  }
  _mls_j4:
  {
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_tmp3)) {
      auto _mls_x184 = _mlsValue::cast<_mls_Tuple2>(_mls_tmp3)->_mls_field0;
      auto _mls_x185 = _mlsValue::cast<_mls_Tuple2>(_mls_tmp3)->_mls_field1;
      auto [_mls_x787, _mls_x788, _mls_x789] = _mls_specularsurf_pre(_mls_surf);
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x787)) {
        auto _mls_x793 = _mls_reflectsurf(_mls_surf);
        auto _mls_x794 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field0;
        auto _mls_x795 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field1;
        auto _mls_x796 = _mlsValue::cast<_mls_Tuple3>(_mls_x788)->_mls_field2;
        _mls_x769 = _mls_refl1;
        _mls_x770 = _mls_x184;
        _mls_x771 = _mls_x796;
        _mls_x772 = _mls_hitpos1;
        _mls_x773 = _mls_x185;
        _mls_x774 = _mls_x795;
        _mls_x775 = _mls_lights1;
        _mls_x776 = _mls_trintensity;
        _mls_x777 = _mls_contrib1;
        _mls_x778 = _mls_x794;
        _mls_x779 = _mls_x793;
        goto _mls_j_caller_post_case0_sr_post;
      } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x787)) {
        auto _mls_x790 = _mlsValue::cast<_mls_Cons>(_mls_x787)->_mls_head;
        auto _mls_x791 = _mlsValue::cast<_mls_Cons>(_mls_x787)->_mls_tail;
        auto _mls_x792 = _mls_specularsurf_case1_sr_post(_mls_x791, _mls_x789, _mls_x790);
        _mls_x760 = _mls_trintensity;
        _mls_x761 = _mls_refl1;
        _mls_x762 = _mls_lights1;
        _mls_x763 = _mls_surf;
        _mls_x764 = _mls_x185;
        _mls_x765 = _mls_x184;
        _mls_x766 = _mls_x792;
        _mls_x767 = _mls_hitpos1;
        _mls_x768 = _mls_contrib1;
        goto _mls_j_caller_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post:
  {
    auto _mls_x797 = _mls_reflectsurf(_mls_x763);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x766)) {
      auto _mls_x798 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field0;
      auto _mls_x799 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field1;
      auto _mls_x800 = _mlsValue::cast<_mls_Tuple3>(_mls_x766)->_mls_field2;
      _mls_x769 = _mls_x761;
      _mls_x770 = _mls_x765;
      _mls_x771 = _mls_x800;
      _mls_x772 = _mls_x767;
      _mls_x773 = _mls_x764;
      _mls_x774 = _mls_x799;
      _mls_x775 = _mls_x762;
      _mls_x776 = _mls_x760;
      _mls_x777 = _mls_x768;
      _mls_x778 = _mls_x798;
      _mls_x779 = _mls_x797;
      goto _mls_j_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post_case0_sr_post:
  {
    auto _mls_x801 = _mls_vecscale_case0_sr_post(_mls_x779, _mls_x778, _mls_x774, _mls_x771);
    if (_mlsValue::isIntLit(_mls_x770, 1)) {
      _mls_x780 = _mls_x772;
      _mls_x781 = _mls_x775;
      _mls_x782 = _mls_x769;
      _mls_x783 = _mls_x777;
      _mls_x784 = _mls_x801;
      _mls_x785 = _mls_x773;
      _mls_x786 = _mls_x776;
      goto _mls_j_caller_post_case0;
    } else {
      _mls_refl = _mls_x769;
      _mls_hitpos = _mls_x772;
      _mls_trcol = _mls_x773;
      _mls_tmp2 = _mls_x801;
      _mls_contrib = _mls_x777;
      _mls_lights = _mls_x775;
      goto _mls_j3;
    }
    return _mls_retval;
  }
  _mls_j3:
  {
    auto _mls_x190 = _mls_is_zerovector(_mls_tmp2);
    if (_mlsValue::isIntLit(_mls_x190, 1)) {
      _mls_retval = _mls_trcol;
    } else {
      auto _mls_x191 = _mls_reflectray(_mls_hitpos, _mls_refl, _mls_lights, _mls_tmp2, _mls_contrib, _mls_trcol);
      _mls_retval = _mls_x191;
    }
    return _mls_retval;
  }
  _mls_j_caller_post_case0:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x786)) {
      auto _mls_x802 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field0;
      auto _mls_x803 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field1;
      auto _mls_x804 = _mlsValue::cast<_mls_Tuple3>(_mls_x786)->_mls_field2;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x784)) {
        auto _mls_x805 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field0;
        auto _mls_x806 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field1;
        auto _mls_x807 = _mlsValue::cast<_mls_Tuple3>(_mls_x784)->_mls_field2;
        auto _mls_x808 = _mls_vecadd_case0_sr_post_case0_sr_post(_mls_x802, _mls_x804, _mls_x805, _mls_x807, _mls_x803, _mls_x806);
        _mls_refl = _mls_x782;
        _mls_hitpos = _mls_x780;
        _mls_trcol = _mls_x785;
        _mls_tmp2 = _mls_x808;
        _mls_contrib = _mls_x783;
        _mls_lights = _mls_x781;
        goto _mls_j3;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_shade_case0_pre(_mlsValue _mls_x1309, _mlsValue _mls_x1307, _mlsValue _mls_x1310, _mlsValue _mls_x1312, _mlsValue _mls_x1304, _mlsValue _mls_x1311) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x1303 = _mlsValue::cast<_mls_Tuple3>(_mls_x1304)->_mls_field0;
  auto _mls_x1305 = _mlsValue::cast<_mls_Tuple3>(_mls_x1304)->_mls_field1;
  auto _mls_x1306 = _mlsValue::cast<_mls_Tuple3>(_mls_x1304)->_mls_field2;
  auto _mls_x1308 = _mls_vecscale_case0_sr_post(_mls_x1307, _mls_x1303, _mls_x1305, _mls_x1306);
  _mls_retval = std::make_tuple(_mls_x1304, _mls_x1309, _mls_x1310, _mls_x1308, _mls_x1311, _mls_x1312);
  return _mls_retval;
}
_mlsValue _mls_shadowed_caller_post_caller_post_caller_post_case0(_mlsValue _mls_x1314) {
  _mlsValue _mls_retval;
  auto _mls_x1313 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x1314);
  _mls_retval = _mls_x1313;
  return _mls_retval;
}
_mlsValue _mls_shadowed_caller_post_caller_post_caller_post_default(_mlsValue _mls_x1316) {
  _mlsValue _mls_retval;
  auto _mls_x1315 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(1), _mls_x1316);
  _mls_retval = _mls_x1315;
  return _mls_retval;
}
_mlsValue _mls_shadowed_caller_post_caller_post_case0(_mlsValue _mls_x1320, _mlsValue _mls_x1321) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1317, _mls_x1318;
  _mlsValue _mls_x1314;
  _mlsValue _mls_x1316;
  auto _mls_x1319 = _mlsValue::cast<_mls_Tuple3>(_mls_x1320)->_mls_field0;
  _mls_x1317 = _mls_x1319;
  _mls_x1318 = _mls_x1321;
  goto _mls_shadowed_caller_post_caller_post_case0_sr_post;
  return _mls_retval;
  _mls_shadowed_caller_post_caller_post_case0_sr_post:
  {
    if (_mlsValue::isIntLit(_mls_x1317, 1)) {
      _mls_x1316 = _mls_x1318;
      goto _mls_shadowed_caller_post_caller_post_caller_post_default;
    } else {
      _mls_x1314 = _mls_x1318;
      goto _mls_shadowed_caller_post_caller_post_caller_post_case0;
    }
    return _mls_retval;
  }
  _mls_shadowed_caller_post_caller_post_caller_post_case0:
  {
    auto _mls_x1313 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x1314);
    _mls_retval = _mls_x1313;
    return _mls_retval;
  }
  _mls_shadowed_caller_post_caller_post_caller_post_default:
  {
    auto _mls_x1315 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(1), _mls_x1316);
    _mls_retval = _mls_x1315;
    return _mls_retval;
  }
}
_mlsValue _mls_shadowed_caller_post_caller_post_case0_sr_post(_mlsValue _mls_x1317, _mlsValue _mls_x1318) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1314;
  _mlsValue _mls_x1316;
  if (_mlsValue::isIntLit(_mls_x1317, 1)) {
    _mls_x1316 = _mls_x1318;
    goto _mls_shadowed_caller_post_caller_post_caller_post_default;
  } else {
    _mls_x1314 = _mls_x1318;
    goto _mls_shadowed_caller_post_caller_post_caller_post_case0;
  }
  return _mls_retval;
  _mls_shadowed_caller_post_caller_post_caller_post_case0:
  {
    auto _mls_x1313 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x1314);
    _mls_retval = _mls_x1313;
    return _mls_retval;
  }
  _mls_shadowed_caller_post_caller_post_caller_post_default:
  {
    auto _mls_x1315 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(1), _mls_x1316);
    _mls_retval = _mls_x1315;
    return _mls_retval;
  }
}
_mlsValue _mls_shadowed_caller_post_post(_mlsValue _mls_x1322, _mlsValue _mls_x1323, _mlsValue _mls_x1324, _mlsValue _mls_x1332) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1320, _mls_x1321;
  _mlsValue _mls_x1317, _mls_x1318;
  _mlsValue _mls_x1314;
  _mlsValue _mls_x1316;
  auto [_mls_x1325, _mls_x1326, _mls_x1327] = _mls_trace_pre(_mls_x1322, _mls_x1323, _mls_x1324);
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1325)) {
    auto _mls_x1333 = _mls_trace_caller_post_case0(_mls_x1326);
    auto _mls_x1334 = _mlsValue::cast<_mls_Tuple3>(_mls_x1333)->_mls_field0;
    _mls_x1317 = _mls_x1334;
    _mls_x1318 = _mls_x1332;
    goto _mls_shadowed_caller_post_caller_post_case0_sr_post;
  } else {
    auto _mls_x1328 = _mls_trace_caller_post_default_pre(_mls_x1325, _mls_x1327);
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x1328)) {
      auto _mls_x1329 = _mlsValue::cast<_mls_Tuple2>(_mls_x1328)->_mls_field0;
      auto _mls_x1330 = _mlsValue::cast<_mls_Tuple2>(_mls_x1328)->_mls_field1;
      auto _mls_x1331 = _mls_trace_caller_post_default_case0_sr_post(_mls_x1329, _mls_x1330);
      _mls_x1320 = _mls_x1331;
      _mls_x1321 = _mls_x1332;
      goto _mls_shadowed_caller_post_caller_post_case0;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  }
  return _mls_retval;
  _mls_shadowed_caller_post_caller_post_case0:
  {
    auto _mls_x1319 = _mlsValue::cast<_mls_Tuple3>(_mls_x1320)->_mls_field0;
    _mls_x1317 = _mls_x1319;
    _mls_x1318 = _mls_x1321;
    goto _mls_shadowed_caller_post_caller_post_case0_sr_post;
    return _mls_retval;
  }
  _mls_shadowed_caller_post_caller_post_case0_sr_post:
  {
    if (_mlsValue::isIntLit(_mls_x1317, 1)) {
      _mls_x1316 = _mls_x1318;
      goto _mls_shadowed_caller_post_caller_post_caller_post_default;
    } else {
      _mls_x1314 = _mls_x1318;
      goto _mls_shadowed_caller_post_caller_post_caller_post_case0;
    }
    return _mls_retval;
  }
  _mls_shadowed_caller_post_caller_post_caller_post_case0:
  {
    auto _mls_x1313 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x1314);
    _mls_retval = _mls_x1313;
    return _mls_retval;
  }
  _mls_shadowed_caller_post_caller_post_caller_post_default:
  {
    auto _mls_x1315 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(1), _mls_x1316);
    _mls_retval = _mls_x1315;
    return _mls_retval;
  }
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_shadowed_case0_pre(_mlsValue _mls_x1335, _mlsValue _mls_x1343, _mlsValue _mls_x1337, _mlsValue _mls_x1342) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x1336 = _mls_vecscale_case0(_mls_x1335, _mlsValue::create<_mls_Float>(1.0E-6));
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1337)) {
    auto _mls_x1338 = _mlsValue::cast<_mls_Tuple3>(_mls_x1337)->_mls_field0;
    auto _mls_x1339 = _mlsValue::cast<_mls_Tuple3>(_mls_x1337)->_mls_field1;
    auto _mls_x1340 = _mlsValue::cast<_mls_Tuple3>(_mls_x1337)->_mls_field2;
    auto _mls_x1341 = _mls_vecadd_case0_sr_post(_mls_x1336, _mls_x1338, _mls_x1339, _mls_x1340);
    _mls_retval = std::make_tuple(_mls_x1342, _mls_x1341, _mls_x1335, _mls_x1343);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_snd(_mlsValue _mls_x357) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x357)) {
    auto _mls_x358 = _mlsValue::cast<_mls_Tuple2>(_mls_x357)->_mls_field1;
    _mls_retval = _mls_x358;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_specpowsurf(_mlsValue _mls_ss5) {
  _mlsValue _mls_retval;
  auto _mls_x359 = _mlsValue::create<_mls_Lambda_lscomp6>();
  auto _mls_x360 = _mlsMethodCall<_mls_Callable>(_mls_x359)->_mls_apply1(_mls_ss5);
  auto _mls_x361 = _mlsValue::create<_mls_Nil>();
  auto _mls_x362 = _mlsValue::create<_mls_Cons>(_mlsValue::create<_mls_Float>(8.0), _mls_x361);
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x360)) {
    _mls_retval = _mlsValue::create<_mls_Float>(8.0);
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x360)) {
    auto _mls_x1344 = _mlsValue::cast<_mls_Cons>(_mls_x360)->_mls_head;
    auto _mls_x1345 = _mlsValue::cast<_mls_Cons>(_mls_x360)->_mls_tail;
    auto _mls_x1346 = _mls_append_case1_sr_post(_mls_x1345, _mls_x362, _mls_x1344);
    auto _mls_x1347 = _mlsValue::cast<_mls_Cons>(_mls_x1346)->_mls_head;
    _mls_retval = _mls_x1347;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_specularsurf(_mlsValue _mls_x1351) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1348, _mls_x1349, _mls_x1350;
  auto [_mls_x1352, _mls_x1353, _mls_x1354] = _mls_specularsurf_pre(_mls_x1351);
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1352)) {
    _mls_retval = _mls_x1353;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1352)) {
    auto _mls_x1355 = _mlsValue::cast<_mls_Cons>(_mls_x1352)->_mls_head;
    auto _mls_x1356 = _mlsValue::cast<_mls_Cons>(_mls_x1352)->_mls_tail;
    _mls_x1348 = _mls_x1356;
    _mls_x1349 = _mls_x1354;
    _mls_x1350 = _mls_x1355;
    goto _mls_specularsurf_case1_sr_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_specularsurf_case1_sr_post:
  {
    auto _mls_x1357 = _mls_append_case1_sr_post(_mls_x1348, _mls_x1349, _mls_x1350);
    auto _mls_x1358 = _mlsValue::cast<_mls_Cons>(_mls_x1357)->_mls_head;
    _mls_retval = _mls_x1358;
    return _mls_retval;
  }
}
_mlsValue _mls_specularsurf_case1_sr_post(_mlsValue _mls_x1348, _mlsValue _mls_x1349, _mlsValue _mls_x1350) {
  _mlsValue _mls_retval;
  auto _mls_x1357 = _mls_append_case1_sr_post(_mls_x1348, _mls_x1349, _mls_x1350);
  auto _mls_x1358 = _mlsValue::cast<_mls_Cons>(_mls_x1357)->_mls_head;
  _mls_retval = _mls_x1358;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_specularsurf_pre(_mlsValue _mls_x1360) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x1359 = _mlsValue::create<_mls_Lambda_lscomp8>();
  auto _mls_x1361 = _mlsMethodCall<_mls_Callable>(_mls_x1359)->_mls_apply1(_mls_x1360);
  auto _mls_x1362 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
  auto _mls_x1363 = _mlsValue::create<_mls_Nil>();
  auto _mls_x1364 = _mlsValue::create<_mls_Cons>(_mls_x1362, _mls_x1363);
  _mls_retval = std::make_tuple(_mls_x1361, _mls_x1362, _mls_x1364);
  return _mls_retval;
}
_mlsValue _mls_sphereintersect(_mlsValue _mls_pos4, _mlsValue _mls_dir2, _mlsValue _mls_sp1) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1365, _mls_x1366, _mls_x1367, _mls_x1368, _mls_x1369, _mls_x1370;
  _mlsValue _mls_x1371, _mls_x1372, _mls_x1373;
  if (_mlsValue::isValueOf<_mls_Sphere>(_mls_sp1)) {
    auto _mls_x372 = _mlsValue::cast<_mls_Sphere>(_mls_sp1)->_mls_pos;
    auto _mls_x373 = _mlsValue::cast<_mls_Sphere>(_mls_sp1)->_mls_radius;
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_pos4)) {
      auto _mls_x1374 = _mlsValue::cast<_mls_Tuple3>(_mls_pos4)->_mls_field0;
      auto _mls_x1375 = _mlsValue::cast<_mls_Tuple3>(_mls_pos4)->_mls_field1;
      auto _mls_x1376 = _mlsValue::cast<_mls_Tuple3>(_mls_pos4)->_mls_field2;
      _mls_x1365 = _mls_dir2;
      _mls_x1366 = _mls_x372;
      _mls_x1367 = _mls_x373;
      _mls_x1368 = _mls_x1376;
      _mls_x1369 = _mls_x1374;
      _mls_x1370 = _mls_x1375;
      goto _mls_sphereintersect_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_sphereintersect_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1366)) {
      auto _mls_x1377 = _mlsValue::cast<_mls_Tuple3>(_mls_x1366)->_mls_field0;
      auto _mls_x1378 = _mlsValue::cast<_mls_Tuple3>(_mls_x1366)->_mls_field1;
      auto _mls_x1379 = _mlsValue::cast<_mls_Tuple3>(_mls_x1366)->_mls_field2;
      auto _mls_x1380 = _mls_vecsub_case0_case0_sr_post(_mls_x1370, _mls_x1377, _mls_x1379, _mls_x1378, _mls_x1369, _mls_x1368);
      auto _mls_x1381 = _mls_vecdot(_mls_x1380, _mls_x1365);
      auto _mls_x1382 = _mls_vecdot(_mls_x1380, _mls_x1380);
      _mls_x1371 = _mls_x1381;
      _mls_x1372 = _mls_x1382;
      _mls_x1373 = _mls_x1367;
      goto _mls_sphereintersect_caller_post_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_sphereintersect_caller_post_post:
  {
    auto _mls_x1383 = (_mls_x1371 * _mls_x1371);
    auto _mls_x1384 = (_mls_x1383 - _mls_x1372);
    auto _mls_x1385 = (_mls_x1373 * _mls_x1373);
    auto _mls_x1386 = (_mls_x1384 + _mls_x1385);
    auto _mls_x1387 = (-_mls_x1371);
    auto _mls_x1388 = _mls_builtin_sqrt(_mls_x1386);
    auto _mls_x1389 = (_mls_x1387 - _mls_x1388);
    auto _mls_x1390 = (-_mls_x1371);
    auto _mls_x1391 = _mls_builtin_sqrt(_mls_x1386);
    auto _mls_x1392 = (_mls_x1390 + _mls_x1391);
    auto _mls_x1393 = (_mls_x1386 < _mlsValue::create<_mls_Float>(0.0));
    if (_mlsValue::isIntLit(_mls_x1393, 1)) {
      auto _mls_x1399 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mlsValue::create<_mls_Float>(0.0));
      _mls_retval = _mls_x1399;
    } else {
      auto _mls_x1394 = (_mls_x1389 < _mlsValue::create<_mls_Float>(0.0));
      if (_mlsValue::isIntLit(_mls_x1394, 1)) {
        auto _mls_x1396 = (_mls_x1392 < _mlsValue::create<_mls_Float>(0.0));
        if (_mlsValue::isIntLit(_mls_x1396, 1)) {
          auto _mls_x1398 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mlsValue::create<_mls_Float>(0.0));
          _mls_retval = _mls_x1398;
        } else {
          auto _mls_x1397 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(1), _mls_x1392);
          _mls_retval = _mls_x1397;
        }
      } else {
        auto _mls_x1395 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(1), _mls_x1389);
        _mls_retval = _mls_x1395;
      }
    }
    return _mls_retval;
  }
}
_mlsValue _mls_sphereintersect_caller_post(_mlsValue _mls_x1365, _mlsValue _mls_x1366, _mlsValue _mls_x1367, _mlsValue _mls_x1368, _mlsValue _mls_x1369, _mlsValue _mls_x1370) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1371, _mls_x1372, _mls_x1373;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1366)) {
    auto _mls_x1377 = _mlsValue::cast<_mls_Tuple3>(_mls_x1366)->_mls_field0;
    auto _mls_x1378 = _mlsValue::cast<_mls_Tuple3>(_mls_x1366)->_mls_field1;
    auto _mls_x1379 = _mlsValue::cast<_mls_Tuple3>(_mls_x1366)->_mls_field2;
    auto _mls_x1380 = _mls_vecsub_case0_case0_sr_post(_mls_x1370, _mls_x1377, _mls_x1379, _mls_x1378, _mls_x1369, _mls_x1368);
    auto _mls_x1381 = _mls_vecdot(_mls_x1380, _mls_x1365);
    auto _mls_x1382 = _mls_vecdot(_mls_x1380, _mls_x1380);
    _mls_x1371 = _mls_x1381;
    _mls_x1372 = _mls_x1382;
    _mls_x1373 = _mls_x1367;
    goto _mls_sphereintersect_caller_post_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_sphereintersect_caller_post_post:
  {
    auto _mls_x1383 = (_mls_x1371 * _mls_x1371);
    auto _mls_x1384 = (_mls_x1383 - _mls_x1372);
    auto _mls_x1385 = (_mls_x1373 * _mls_x1373);
    auto _mls_x1386 = (_mls_x1384 + _mls_x1385);
    auto _mls_x1387 = (-_mls_x1371);
    auto _mls_x1388 = _mls_builtin_sqrt(_mls_x1386);
    auto _mls_x1389 = (_mls_x1387 - _mls_x1388);
    auto _mls_x1390 = (-_mls_x1371);
    auto _mls_x1391 = _mls_builtin_sqrt(_mls_x1386);
    auto _mls_x1392 = (_mls_x1390 + _mls_x1391);
    auto _mls_x1393 = (_mls_x1386 < _mlsValue::create<_mls_Float>(0.0));
    if (_mlsValue::isIntLit(_mls_x1393, 1)) {
      auto _mls_x1399 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mlsValue::create<_mls_Float>(0.0));
      _mls_retval = _mls_x1399;
    } else {
      auto _mls_x1394 = (_mls_x1389 < _mlsValue::create<_mls_Float>(0.0));
      if (_mlsValue::isIntLit(_mls_x1394, 1)) {
        auto _mls_x1396 = (_mls_x1392 < _mlsValue::create<_mls_Float>(0.0));
        if (_mlsValue::isIntLit(_mls_x1396, 1)) {
          auto _mls_x1398 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mlsValue::create<_mls_Float>(0.0));
          _mls_retval = _mls_x1398;
        } else {
          auto _mls_x1397 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(1), _mls_x1392);
          _mls_retval = _mls_x1397;
        }
      } else {
        auto _mls_x1395 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(1), _mls_x1389);
        _mls_retval = _mls_x1395;
      }
    }
    return _mls_retval;
  }
}
_mlsValue _mls_sphereintersect_caller_post_post(_mlsValue _mls_x1371, _mlsValue _mls_x1372, _mlsValue _mls_x1373) {
  _mlsValue _mls_retval;
  auto _mls_x1383 = (_mls_x1371 * _mls_x1371);
  auto _mls_x1384 = (_mls_x1383 - _mls_x1372);
  auto _mls_x1385 = (_mls_x1373 * _mls_x1373);
  auto _mls_x1386 = (_mls_x1384 + _mls_x1385);
  auto _mls_x1387 = (-_mls_x1371);
  auto _mls_x1388 = _mls_builtin_sqrt(_mls_x1386);
  auto _mls_x1389 = (_mls_x1387 - _mls_x1388);
  auto _mls_x1390 = (-_mls_x1371);
  auto _mls_x1391 = _mls_builtin_sqrt(_mls_x1386);
  auto _mls_x1392 = (_mls_x1390 + _mls_x1391);
  auto _mls_x1393 = (_mls_x1386 < _mlsValue::create<_mls_Float>(0.0));
  if (_mlsValue::isIntLit(_mls_x1393, 1)) {
    auto _mls_x1399 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mlsValue::create<_mls_Float>(0.0));
    _mls_retval = _mls_x1399;
  } else {
    auto _mls_x1394 = (_mls_x1389 < _mlsValue::create<_mls_Float>(0.0));
    if (_mlsValue::isIntLit(_mls_x1394, 1)) {
      auto _mls_x1396 = (_mls_x1392 < _mlsValue::create<_mls_Float>(0.0));
      if (_mlsValue::isIntLit(_mls_x1396, 1)) {
        auto _mls_x1398 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mlsValue::create<_mls_Float>(0.0));
        _mls_retval = _mls_x1398;
      } else {
        auto _mls_x1397 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(1), _mls_x1392);
        _mls_retval = _mls_x1397;
      }
    } else {
      auto _mls_x1395 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(1), _mls_x1389);
      _mls_retval = _mls_x1395;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_spherenormal_caller_post(_mlsValue _mls_x1401, _mlsValue _mls_x1402) {
  _mlsValue _mls_retval;
  auto _mls_x1400 = (_mlsValue::create<_mls_Float>(1.0) / _mls_x1401);
  auto _mls_x1403 = _mls_vecscale(_mls_x1402, _mls_x1400);
  _mls_retval = _mls_x1403;
  return _mls_retval;
}
_mlsValue _mls_spherenormal_case0_sr_post_case0(_mlsValue _mls_x1404, _mlsValue _mls_x1405, _mlsValue _mls_x1411) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1401, _mls_x1402;
  auto [_mls_x1406, _mls_x1407, _mls_x1408, _mls_x1409] = _mls_vecsub_case0_pre(_mls_x1404, _mls_x1405);
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1406)) {
    auto _mls_x1410 = _mls_vecsub_case0_sr_post_case0(_mls_x1406, _mls_x1408, _mls_x1407, _mls_x1409);
    _mls_x1401 = _mls_x1411;
    _mls_x1402 = _mls_x1410;
    goto _mls_spherenormal_caller_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_spherenormal_caller_post:
  {
    auto _mls_x1400 = (_mlsValue::create<_mls_Float>(1.0) / _mls_x1401);
    auto _mls_x1403 = _mls_vecscale(_mls_x1402, _mls_x1400);
    _mls_retval = _mls_x1403;
    return _mls_retval;
  }
}
_mlsValue _mls_spheresurf(_mlsValue _mls_s) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Sphere>(_mls_s)) {
    auto _mls_x399 = _mlsValue::cast<_mls_Sphere>(_mls_s)->_mls_surface;
    _mls_retval = _mls_x399;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_tail1(_mlsValue _mls_xs4) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs4)) {
    auto _mls_x400 = _mlsValue::cast<_mls_Cons>(_mls_xs4)->_mls_tail;
    _mls_retval = _mls_x400;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_testlights() {
  _mlsValue _mls_retval;
  auto _mls_x401 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(4.0), _mlsValue::create<_mls_Float>(3.0), _mlsValue::create<_mls_Float>(2.0));
  auto _mls_x402 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.288675), _mlsValue::create<_mls_Float>(0.288675), _mlsValue::create<_mls_Float>(0.288675));
  auto _mls_x403 = _mlsValue::create<_mls_Point>(_mls_x401, _mls_x402);
  auto _mls_x404 = (-_mlsValue::create<_mls_Float>(4.0));
  auto _mls_x405 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(1.0), _mls_x404, _mlsValue::create<_mls_Float>(4.0));
  auto _mls_x406 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.288675), _mlsValue::create<_mls_Float>(0.288675), _mlsValue::create<_mls_Float>(0.288675));
  auto _mls_x407 = _mlsValue::create<_mls_Point>(_mls_x405, _mls_x406);
  auto _mls_x408 = (-_mlsValue::create<_mls_Float>(3.0));
  auto _mls_x409 = _mlsValue::create<_mls_Tuple3>(_mls_x408, _mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(5.0));
  auto _mls_x410 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.288675), _mlsValue::create<_mls_Float>(0.288675), _mlsValue::create<_mls_Float>(0.288675));
  auto _mls_x411 = _mlsValue::create<_mls_Point>(_mls_x409, _mls_x410);
  auto _mls_x412 = _mlsValue::create<_mls_Nil>();
  auto _mls_x413 = _mlsValue::create<_mls_Cons>(_mls_x411, _mls_x412);
  auto _mls_x414 = _mlsValue::create<_mls_Cons>(_mls_x407, _mls_x413);
  auto _mls_x415 = _mlsValue::create<_mls_Cons>(_mls_x403, _mls_x414);
  _mls_retval = _mls_x415;
  return _mls_retval;
}
_mlsValue _mls_testspheres() {
  _mlsValue _mls_retval;
  auto _mls_x416 = _mls_s2();
  auto _mls_x417 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
  auto _mls_x418 = _mlsValue::create<_mls_Sphere>(_mls_x417, _mlsValue::create<_mls_Float>(0.5), _mls_x416);
  auto _mls_x419 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.272166), _mlsValue::create<_mls_Float>(0.272166), _mlsValue::create<_mls_Float>(0.544331));
  auto _mls_x420 = _mlsValue::create<_mls_Sphere>(_mls_x419, _mlsValue::create<_mls_Float>(0.166667), _mls_x416);
  auto _mls_x421 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.643951), _mlsValue::create<_mls_Float>(0.172546), _mlsValue::create<_mls_Float>(0.0));
  auto _mls_x422 = _mlsValue::create<_mls_Sphere>(_mls_x421, _mlsValue::create<_mls_Float>(0.166667), _mls_x416);
  auto _mls_x423 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.172546), _mlsValue::create<_mls_Float>(0.643951), _mlsValue::create<_mls_Float>(0.0));
  auto _mls_x424 = _mlsValue::create<_mls_Sphere>(_mls_x423, _mlsValue::create<_mls_Float>(0.166667), _mls_x416);
  auto _mls_x425 = (-_mlsValue::create<_mls_Float>(0.371785));
  auto _mls_x426 = _mlsValue::create<_mls_Tuple3>(_mls_x425, _mlsValue::create<_mls_Float>(0.0996195), _mlsValue::create<_mls_Float>(0.544331));
  auto _mls_x427 = _mlsValue::create<_mls_Sphere>(_mls_x426, _mlsValue::create<_mls_Float>(0.166667), _mls_x416);
  auto _mls_x428 = (-_mlsValue::create<_mls_Float>(0.471405));
  auto _mls_x429 = _mlsValue::create<_mls_Tuple3>(_mls_x428, _mlsValue::create<_mls_Float>(0.471405), _mlsValue::create<_mls_Float>(0.0));
  auto _mls_x430 = _mlsValue::create<_mls_Sphere>(_mls_x429, _mlsValue::create<_mls_Float>(0.166667), _mls_x416);
  auto _mls_x431 = (-_mlsValue::create<_mls_Float>(0.643951));
  auto _mls_x432 = (-_mlsValue::create<_mls_Float>(0.172546));
  auto _mls_x433 = _mlsValue::create<_mls_Tuple3>(_mls_x431, _mls_x432, _mlsValue::create<_mls_Float>(0.0));
  auto _mls_x434 = _mlsValue::create<_mls_Sphere>(_mls_x433, _mlsValue::create<_mls_Float>(0.166667), _mls_x416);
  auto _mls_x435 = (-_mlsValue::create<_mls_Float>(0.371785));
  auto _mls_x436 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0996195), _mls_x435, _mlsValue::create<_mls_Float>(0.544331));
  auto _mls_x437 = _mlsValue::create<_mls_Sphere>(_mls_x436, _mlsValue::create<_mls_Float>(0.166667), _mls_x416);
  auto _mls_x438 = (-_mlsValue::create<_mls_Float>(0.172546));
  auto _mls_x439 = (-_mlsValue::create<_mls_Float>(0.643951));
  auto _mls_x440 = _mlsValue::create<_mls_Tuple3>(_mls_x438, _mls_x439, _mlsValue::create<_mls_Float>(0.0));
  auto _mls_x441 = _mlsValue::create<_mls_Sphere>(_mls_x440, _mlsValue::create<_mls_Float>(0.166667), _mls_x416);
  auto _mls_x442 = (-_mlsValue::create<_mls_Float>(0.471405));
  auto _mls_x443 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.471405), _mls_x442, _mlsValue::create<_mls_Float>(0.0));
  auto _mls_x444 = _mlsValue::create<_mls_Sphere>(_mls_x443, _mlsValue::create<_mls_Float>(0.166667), _mls_x416);
  auto _mls_x445 = _mlsValue::create<_mls_Nil>();
  auto _mls_x446 = _mlsValue::create<_mls_Cons>(_mls_x444, _mls_x445);
  auto _mls_x447 = _mlsValue::create<_mls_Cons>(_mls_x441, _mls_x446);
  auto _mls_x448 = _mlsValue::create<_mls_Cons>(_mls_x437, _mls_x447);
  auto _mls_x449 = _mlsValue::create<_mls_Cons>(_mls_x434, _mls_x448);
  auto _mls_x450 = _mlsValue::create<_mls_Cons>(_mls_x430, _mls_x449);
  auto _mls_x451 = _mlsValue::create<_mls_Cons>(_mls_x427, _mls_x450);
  auto _mls_x452 = _mlsValue::create<_mls_Cons>(_mls_x424, _mls_x451);
  auto _mls_x453 = _mlsValue::create<_mls_Cons>(_mls_x422, _mls_x452);
  auto _mls_x454 = _mlsValue::create<_mls_Cons>(_mls_x420, _mls_x453);
  auto _mls_x455 = _mlsValue::create<_mls_Cons>(_mls_x418, _mls_x454);
  _mls_retval = _mls_x455;
  return _mls_retval;
}
_mlsValue _mls_trace_caller_post_case0(_mlsValue _mls_x1412) {
  _mlsValue _mls_retval;
  auto _mls_x1413 = _mls_head1(_mls_x1412);
  auto _mls_x1414 = _mlsValue::create<_mls_Tuple3>(_mlsValue::fromIntLit(0), _mlsValue::create<_mls_Float>(1.0E8), _mls_x1413);
  _mls_retval = _mls_x1414;
  return _mls_retval;
}
_mlsValue _mls_trace_caller_post_default(_mlsValue _mls_x1417, _mlsValue _mls_x1418) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1415, _mls_x1416;
  auto _mls_x1419 = _mls_trace_caller_post_default_pre(_mls_x1417, _mls_x1418);
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x1419)) {
    auto _mls_x1420 = _mlsValue::cast<_mls_Tuple2>(_mls_x1419)->_mls_field0;
    auto _mls_x1421 = _mlsValue::cast<_mls_Tuple2>(_mls_x1419)->_mls_field1;
    _mls_x1415 = _mls_x1420;
    _mls_x1416 = _mls_x1421;
    goto _mls_trace_caller_post_default_case0_sr_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_trace_caller_post_default_case0_sr_post:
  {
    auto _mls_x1422 = _mlsValue::create<_mls_Tuple3>(_mlsValue::fromIntLit(1), _mls_x1415, _mls_x1416);
    _mls_retval = _mls_x1422;
    return _mls_retval;
  }
}
_mlsValue _mls_trace_caller_post_default_case0_sr_post(_mlsValue _mls_x1415, _mlsValue _mls_x1416) {
  _mlsValue _mls_retval;
  auto _mls_x1422 = _mlsValue::create<_mls_Tuple3>(_mlsValue::fromIntLit(1), _mls_x1415, _mls_x1416);
  _mls_retval = _mls_x1422;
  return _mls_retval;
}
_mlsValue _mls_trace_caller_post_default_pre(_mlsValue _mls_x1423, _mlsValue _mls_x1426) {
  _mlsValue _mls_retval;
  auto _mls_x1424 = _mls_head1(_mls_x1423);
  auto _mls_x1425 = _mls_tail1(_mls_x1423);
  auto _mls_x1427 = _mls_foldr(_mls_x1426, _mls_x1424, _mls_x1425);
  _mls_retval = _mls_x1427;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_trace_pre(_mlsValue _mls_x1432, _mlsValue _mls_x1431, _mlsValue _mls_x1430) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x1428 = _mlsValue::create<_mls_Lambda_f1>();
  auto _mls_x1429 = _mlsValue::create<_mls_Lambda_sphmap>(_mls_x1430, _mls_x1431);
  auto _mls_x1433 = _mlsMethodCall<_mls_Callable>(_mls_x1429)->_mls_apply1(_mls_x1432);
  _mls_retval = std::make_tuple(_mls_x1433, _mls_x1432, _mls_x1428);
  return _mls_retval;
}
_mlsValue _mls_tracepixel(_mlsValue _mls_spheres1, _mlsValue _mls_lights4, _mlsValue _mls_x469, _mlsValue _mls_y2, _mlsValue _mls_firstray, _mlsValue _mls_scrnx, _mlsValue _mls_scrny) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1434, _mls_x1435, _mls_x1436, _mls_x1437, _mls_x1438, _mls_x1439;
  _mlsValue _mls_x1440, _mls_x1441, _mls_x1442, _mls_x1443;
  _mlsValue _mls_x1444, _mls_x1445, _mls_x1446, _mls_x1447;
  _mlsValue _mls_x1448, _mls_x1449, _mls_x1450, _mls_x1451;
  auto _mls_x468 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(2.1), _mlsValue::create<_mls_Float>(1.3), _mlsValue::create<_mls_Float>(1.7));
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_scrnx)) {
    auto _mls_x1452 = _mlsValue::cast<_mls_Tuple3>(_mls_scrnx)->_mls_field0;
    auto _mls_x1453 = _mlsValue::cast<_mls_Tuple3>(_mls_scrnx)->_mls_field1;
    auto _mls_x1454 = _mlsValue::cast<_mls_Tuple3>(_mls_scrnx)->_mls_field2;
    auto _mls_x1455 = _mls_vecscale_case0_sr_post(_mls_x469, _mls_x1452, _mls_x1453, _mls_x1454);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_firstray)) {
      auto _mls_x1456 = _mlsValue::cast<_mls_Tuple3>(_mls_firstray)->_mls_field0;
      auto _mls_x1457 = _mlsValue::cast<_mls_Tuple3>(_mls_firstray)->_mls_field1;
      auto _mls_x1458 = _mlsValue::cast<_mls_Tuple3>(_mls_firstray)->_mls_field2;
      auto _mls_x1459 = _mlsValue::cast<_mls_Tuple3>(_mls_x1455)->_mls_field0;
      auto _mls_x1460 = _mlsValue::cast<_mls_Tuple3>(_mls_x1455)->_mls_field1;
      auto _mls_x1461 = _mlsValue::cast<_mls_Tuple3>(_mls_x1455)->_mls_field2;
      auto _mls_x1462 = _mls_vecadd_case0_sr_post_case0_sr_post(_mls_x1456, _mls_x1458, _mls_x1459, _mls_x1461, _mls_x1457, _mls_x1460);
      _mls_x1434 = _mls_scrny;
      _mls_x1435 = _mls_y2;
      _mls_x1436 = _mls_lights4;
      _mls_x1437 = _mls_x468;
      _mls_x1438 = _mls_spheres1;
      _mls_x1439 = _mls_x1462;
      goto _mls_tracepixel_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_tracepixel_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1434)) {
      auto _mls_x1463 = _mlsValue::cast<_mls_Tuple3>(_mls_x1434)->_mls_field0;
      auto _mls_x1464 = _mlsValue::cast<_mls_Tuple3>(_mls_x1434)->_mls_field1;
      auto _mls_x1465 = _mlsValue::cast<_mls_Tuple3>(_mls_x1434)->_mls_field2;
      auto _mls_x1466 = _mls_vecscale_case0_sr_post(_mls_x1435, _mls_x1463, _mls_x1464, _mls_x1465);
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1439)) {
        auto _mls_x1467 = _mlsValue::cast<_mls_Tuple3>(_mls_x1439)->_mls_field0;
        auto _mls_x1468 = _mlsValue::cast<_mls_Tuple3>(_mls_x1439)->_mls_field1;
        auto _mls_x1469 = _mlsValue::cast<_mls_Tuple3>(_mls_x1439)->_mls_field2;
        auto _mls_x1470 = _mls_vecadd_case0_sr_post(_mls_x1466, _mls_x1467, _mls_x1468, _mls_x1469);
        _mls_x1440 = _mls_x1470;
        _mls_x1441 = _mls_x1438;
        _mls_x1442 = _mls_x1437;
        _mls_x1443 = _mls_x1436;
        goto _mls_tracepixel_caller_post_caller_post_caller_post_caller_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_tracepixel_caller_post_caller_post_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1440)) {
      auto _mls_x1471 = _mlsValue::cast<_mls_Tuple3>(_mls_x1440)->_mls_field0;
      auto _mls_x1472 = _mlsValue::cast<_mls_Tuple3>(_mls_x1440)->_mls_field1;
      auto _mls_x1473 = _mlsValue::cast<_mls_Tuple3>(_mls_x1440)->_mls_field2;
      auto _mls_x1474 = _mls_vecnorm_case0_sr_post(_mls_x1471, _mls_x1472, _mls_x1473);
      _mls_x1444 = _mls_x1474;
      _mls_x1445 = _mls_x1441;
      _mls_x1446 = _mls_x1442;
      _mls_x1447 = _mls_x1443;
      goto _mls_tracepixel_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_tracepixel_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x1444)) {
      auto _mls_x1475 = _mlsValue::cast<_mls_Tuple2>(_mls_x1444)->_mls_field0;
      auto [_mls_x1476, _mls_x1477, _mls_x1478] = _mls_trace_pre(_mls_x1445, _mls_x1446, _mls_x1475);
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1476)) {
        auto _mls_x1480 = _mls_trace_caller_post_case0(_mls_x1477);
        _mls_x1448 = _mls_x1480;
        _mls_x1449 = _mls_x1447;
        _mls_x1450 = _mls_x1446;
        _mls_x1451 = _mls_x1475;
        goto _mls_tracepixel_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
      } else {
        auto _mls_x1479 = _mls_trace_caller_post_default(_mls_x1476, _mls_x1478);
        _mls_x1448 = _mls_x1479;
        _mls_x1449 = _mls_x1447;
        _mls_x1450 = _mls_x1446;
        _mls_x1451 = _mls_x1475;
        goto _mls_tracepixel_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_tracepixel_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1448)) {
      auto _mls_x1481 = _mlsValue::cast<_mls_Tuple3>(_mls_x1448)->_mls_field0;
      auto _mls_x1482 = _mlsValue::cast<_mls_Tuple3>(_mls_x1448)->_mls_field1;
      auto _mls_x1483 = _mlsValue::cast<_mls_Tuple3>(_mls_x1448)->_mls_field2;
      if (_mlsValue::isIntLit(_mls_x1481, 1)) {
        auto _mls_x1485 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0));
        auto _mls_x1486 = _mls_shade(_mls_x1449, _mls_x1483, _mls_x1450, _mls_x1451, _mls_x1482, _mls_x1485);
        _mls_retval = _mls_x1486;
      } else {
        auto _mls_x1484 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.078), _mlsValue::create<_mls_Float>(0.361), _mlsValue::create<_mls_Float>(0.753));
        _mls_retval = _mls_x1484;
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_tracepixel_caller_post_caller_post(_mlsValue _mls_x1434, _mlsValue _mls_x1435, _mlsValue _mls_x1436, _mlsValue _mls_x1437, _mlsValue _mls_x1438, _mlsValue _mls_x1439) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1440, _mls_x1441, _mls_x1442, _mls_x1443;
  _mlsValue _mls_x1444, _mls_x1445, _mls_x1446, _mls_x1447;
  _mlsValue _mls_x1448, _mls_x1449, _mls_x1450, _mls_x1451;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1434)) {
    auto _mls_x1463 = _mlsValue::cast<_mls_Tuple3>(_mls_x1434)->_mls_field0;
    auto _mls_x1464 = _mlsValue::cast<_mls_Tuple3>(_mls_x1434)->_mls_field1;
    auto _mls_x1465 = _mlsValue::cast<_mls_Tuple3>(_mls_x1434)->_mls_field2;
    auto _mls_x1466 = _mls_vecscale_case0_sr_post(_mls_x1435, _mls_x1463, _mls_x1464, _mls_x1465);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1439)) {
      auto _mls_x1467 = _mlsValue::cast<_mls_Tuple3>(_mls_x1439)->_mls_field0;
      auto _mls_x1468 = _mlsValue::cast<_mls_Tuple3>(_mls_x1439)->_mls_field1;
      auto _mls_x1469 = _mlsValue::cast<_mls_Tuple3>(_mls_x1439)->_mls_field2;
      auto _mls_x1470 = _mls_vecadd_case0_sr_post(_mls_x1466, _mls_x1467, _mls_x1468, _mls_x1469);
      _mls_x1440 = _mls_x1470;
      _mls_x1441 = _mls_x1438;
      _mls_x1442 = _mls_x1437;
      _mls_x1443 = _mls_x1436;
      goto _mls_tracepixel_caller_post_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_tracepixel_caller_post_caller_post_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1440)) {
      auto _mls_x1471 = _mlsValue::cast<_mls_Tuple3>(_mls_x1440)->_mls_field0;
      auto _mls_x1472 = _mlsValue::cast<_mls_Tuple3>(_mls_x1440)->_mls_field1;
      auto _mls_x1473 = _mlsValue::cast<_mls_Tuple3>(_mls_x1440)->_mls_field2;
      auto _mls_x1474 = _mls_vecnorm_case0_sr_post(_mls_x1471, _mls_x1472, _mls_x1473);
      _mls_x1444 = _mls_x1474;
      _mls_x1445 = _mls_x1441;
      _mls_x1446 = _mls_x1442;
      _mls_x1447 = _mls_x1443;
      goto _mls_tracepixel_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_tracepixel_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x1444)) {
      auto _mls_x1475 = _mlsValue::cast<_mls_Tuple2>(_mls_x1444)->_mls_field0;
      auto [_mls_x1476, _mls_x1477, _mls_x1478] = _mls_trace_pre(_mls_x1445, _mls_x1446, _mls_x1475);
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1476)) {
        auto _mls_x1480 = _mls_trace_caller_post_case0(_mls_x1477);
        _mls_x1448 = _mls_x1480;
        _mls_x1449 = _mls_x1447;
        _mls_x1450 = _mls_x1446;
        _mls_x1451 = _mls_x1475;
        goto _mls_tracepixel_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
      } else {
        auto _mls_x1479 = _mls_trace_caller_post_default(_mls_x1476, _mls_x1478);
        _mls_x1448 = _mls_x1479;
        _mls_x1449 = _mls_x1447;
        _mls_x1450 = _mls_x1446;
        _mls_x1451 = _mls_x1475;
        goto _mls_tracepixel_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_tracepixel_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1448)) {
      auto _mls_x1481 = _mlsValue::cast<_mls_Tuple3>(_mls_x1448)->_mls_field0;
      auto _mls_x1482 = _mlsValue::cast<_mls_Tuple3>(_mls_x1448)->_mls_field1;
      auto _mls_x1483 = _mlsValue::cast<_mls_Tuple3>(_mls_x1448)->_mls_field2;
      if (_mlsValue::isIntLit(_mls_x1481, 1)) {
        auto _mls_x1485 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0));
        auto _mls_x1486 = _mls_shade(_mls_x1449, _mls_x1483, _mls_x1450, _mls_x1451, _mls_x1482, _mls_x1485);
        _mls_retval = _mls_x1486;
      } else {
        auto _mls_x1484 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.078), _mlsValue::create<_mls_Float>(0.361), _mlsValue::create<_mls_Float>(0.753));
        _mls_retval = _mls_x1484;
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_tracepixel_caller_post_caller_post_caller_post_caller_post(_mlsValue _mls_x1440, _mlsValue _mls_x1441, _mlsValue _mls_x1442, _mlsValue _mls_x1443) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1444, _mls_x1445, _mls_x1446, _mls_x1447;
  _mlsValue _mls_x1448, _mls_x1449, _mls_x1450, _mls_x1451;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1440)) {
    auto _mls_x1471 = _mlsValue::cast<_mls_Tuple3>(_mls_x1440)->_mls_field0;
    auto _mls_x1472 = _mlsValue::cast<_mls_Tuple3>(_mls_x1440)->_mls_field1;
    auto _mls_x1473 = _mlsValue::cast<_mls_Tuple3>(_mls_x1440)->_mls_field2;
    auto _mls_x1474 = _mls_vecnorm_case0_sr_post(_mls_x1471, _mls_x1472, _mls_x1473);
    _mls_x1444 = _mls_x1474;
    _mls_x1445 = _mls_x1441;
    _mls_x1446 = _mls_x1442;
    _mls_x1447 = _mls_x1443;
    goto _mls_tracepixel_caller_post_caller_post_caller_post_caller_post_caller_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_tracepixel_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x1444)) {
      auto _mls_x1475 = _mlsValue::cast<_mls_Tuple2>(_mls_x1444)->_mls_field0;
      auto [_mls_x1476, _mls_x1477, _mls_x1478] = _mls_trace_pre(_mls_x1445, _mls_x1446, _mls_x1475);
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1476)) {
        auto _mls_x1480 = _mls_trace_caller_post_case0(_mls_x1477);
        _mls_x1448 = _mls_x1480;
        _mls_x1449 = _mls_x1447;
        _mls_x1450 = _mls_x1446;
        _mls_x1451 = _mls_x1475;
        goto _mls_tracepixel_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
      } else {
        auto _mls_x1479 = _mls_trace_caller_post_default(_mls_x1476, _mls_x1478);
        _mls_x1448 = _mls_x1479;
        _mls_x1449 = _mls_x1447;
        _mls_x1450 = _mls_x1446;
        _mls_x1451 = _mls_x1475;
        goto _mls_tracepixel_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_tracepixel_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1448)) {
      auto _mls_x1481 = _mlsValue::cast<_mls_Tuple3>(_mls_x1448)->_mls_field0;
      auto _mls_x1482 = _mlsValue::cast<_mls_Tuple3>(_mls_x1448)->_mls_field1;
      auto _mls_x1483 = _mlsValue::cast<_mls_Tuple3>(_mls_x1448)->_mls_field2;
      if (_mlsValue::isIntLit(_mls_x1481, 1)) {
        auto _mls_x1485 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0));
        auto _mls_x1486 = _mls_shade(_mls_x1449, _mls_x1483, _mls_x1450, _mls_x1451, _mls_x1482, _mls_x1485);
        _mls_retval = _mls_x1486;
      } else {
        auto _mls_x1484 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.078), _mlsValue::create<_mls_Float>(0.361), _mlsValue::create<_mls_Float>(0.753));
        _mls_retval = _mls_x1484;
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_tracepixel_caller_post_caller_post_caller_post_caller_post_caller_post(_mlsValue _mls_x1444, _mlsValue _mls_x1445, _mlsValue _mls_x1446, _mlsValue _mls_x1447) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1448, _mls_x1449, _mls_x1450, _mls_x1451;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x1444)) {
    auto _mls_x1475 = _mlsValue::cast<_mls_Tuple2>(_mls_x1444)->_mls_field0;
    auto [_mls_x1476, _mls_x1477, _mls_x1478] = _mls_trace_pre(_mls_x1445, _mls_x1446, _mls_x1475);
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1476)) {
      auto _mls_x1480 = _mls_trace_caller_post_case0(_mls_x1477);
      _mls_x1448 = _mls_x1480;
      _mls_x1449 = _mls_x1447;
      _mls_x1450 = _mls_x1446;
      _mls_x1451 = _mls_x1475;
      goto _mls_tracepixel_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
    } else {
      auto _mls_x1479 = _mls_trace_caller_post_default(_mls_x1476, _mls_x1478);
      _mls_x1448 = _mls_x1479;
      _mls_x1449 = _mls_x1447;
      _mls_x1450 = _mls_x1446;
      _mls_x1451 = _mls_x1475;
      goto _mls_tracepixel_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_tracepixel_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1448)) {
      auto _mls_x1481 = _mlsValue::cast<_mls_Tuple3>(_mls_x1448)->_mls_field0;
      auto _mls_x1482 = _mlsValue::cast<_mls_Tuple3>(_mls_x1448)->_mls_field1;
      auto _mls_x1483 = _mlsValue::cast<_mls_Tuple3>(_mls_x1448)->_mls_field2;
      if (_mlsValue::isIntLit(_mls_x1481, 1)) {
        auto _mls_x1485 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0));
        auto _mls_x1486 = _mls_shade(_mls_x1449, _mls_x1483, _mls_x1450, _mls_x1451, _mls_x1482, _mls_x1485);
        _mls_retval = _mls_x1486;
      } else {
        auto _mls_x1484 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.078), _mlsValue::create<_mls_Float>(0.361), _mlsValue::create<_mls_Float>(0.753));
        _mls_retval = _mls_x1484;
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_tracepixel_caller_post_caller_post_caller_post_caller_post_caller_post_caller_post(_mlsValue _mls_x1448, _mlsValue _mls_x1449, _mlsValue _mls_x1450, _mlsValue _mls_x1451) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1448)) {
    auto _mls_x1481 = _mlsValue::cast<_mls_Tuple3>(_mls_x1448)->_mls_field0;
    auto _mls_x1482 = _mlsValue::cast<_mls_Tuple3>(_mls_x1448)->_mls_field1;
    auto _mls_x1483 = _mlsValue::cast<_mls_Tuple3>(_mls_x1448)->_mls_field2;
    if (_mlsValue::isIntLit(_mls_x1481, 1)) {
      auto _mls_x1485 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0));
      auto _mls_x1486 = _mls_shade(_mls_x1449, _mls_x1483, _mls_x1450, _mls_x1451, _mls_x1482, _mls_x1485);
      _mls_retval = _mls_x1486;
    } else {
      auto _mls_x1484 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.078), _mlsValue::create<_mls_Float>(0.361), _mlsValue::create<_mls_Float>(0.753));
      _mls_retval = _mls_x1484;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_transmitray(_mlsValue _mls_lights5, _mlsValue _mls_colour3, _mlsValue _mls_pos7, _mlsValue _mls_dir4, _mlsValue _mls_index, _mlsValue _mls_intens3, _mlsValue _mls_contrib4, _mlsValue _mls_norm1) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1487, _mls_x1488, _mls_x1489, _mls_x1490, _mls_x1491, _mls_x1492, _mls_x1493, _mls_x1494, _mls_x1495;
  _mlsValue _mls_x1496, _mls_x1497, _mls_x1498, _mls_x1499, _mls_x1500, _mls_x1501, _mls_x1502, _mls_x1503, _mls_x1504;
  _mlsValue _mls_x1505, _mls_x1506, _mls_x1507, _mls_x1508, _mls_x1509, _mls_x1510;
  _mlsValue _mls_x1511, _mls_x1512, _mls_x1513, _mls_x1514, _mls_x1515, _mls_x1516;
  _mlsValue _mls_x1517, _mls_x1518, _mls_x1519, _mls_x1520, _mls_x1521, _mls_x1522, _mls_x1523;
  _mlsValue _mls_x1524, _mls_x1525, _mls_x1526, _mls_x1527, _mls_x1528, _mls_x1529;
  _mlsValue _mls_x1530, _mls_x1531, _mls_x1532, _mls_x1533, _mls_x1534, _mls_x1535, _mls_x1536;
  _mlsValue _mls_x1537, _mls_x1538, _mls_x1539, _mls_x1540, _mls_x1541, _mls_x1542, _mls_x1543, _mls_x1544, _mls_x1545;
  _mlsValue _mls_x745, _mls_x747, _mls_x748, _mls_x749;
  _mlsValue _mls_x740;
  _mlsValue _mls_x741, _mls_x742, _mls_x743;
  _mlsValue _mls_x744;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_intens3)) {
    auto _mls_x1546 = _mlsValue::cast<_mls_Tuple3>(_mls_intens3)->_mls_field0;
    auto _mls_x1547 = _mlsValue::cast<_mls_Tuple3>(_mls_intens3)->_mls_field1;
    auto _mls_x1548 = _mlsValue::cast<_mls_Tuple3>(_mls_intens3)->_mls_field2;
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_contrib4)) {
      auto _mls_x1549 = _mlsValue::cast<_mls_Tuple3>(_mls_contrib4)->_mls_field0;
      auto _mls_x1550 = _mlsValue::cast<_mls_Tuple3>(_mls_contrib4)->_mls_field1;
      auto _mls_x1551 = _mlsValue::cast<_mls_Tuple3>(_mls_contrib4)->_mls_field2;
      auto _mls_x1552 = _mls_vecmult_case0_sr_post_case0_sr_post(_mls_x1551, _mls_x1547, _mls_x1550, _mls_x1548, _mls_x1546, _mls_x1549);
      auto [_mls_x1553, _mls_x1554, _mls_x1555, _mls_x1556, _mls_x1557] = _mls_refractray_pre(_mls_index, _mls_dir4, _mls_norm1);
      if (_mlsValue::isIntLit(_mls_x1557, 1)) {
        _mls_x1487 = _mls_lights5;
        _mls_x1488 = _mls_x1556;
        _mls_x1489 = _mls_x1552;
        _mls_x1490 = _mls_x1553;
        _mls_x1491 = _mls_colour3;
        _mls_x1492 = _mls_x1554;
        _mls_x1493 = _mls_intens3;
        _mls_x1494 = _mls_x1555;
        _mls_x1495 = _mls_pos7;
        goto _mls_transmitray_caller_post_case0;
      } else {
        _mls_x1496 = _mls_lights5;
        _mls_x1497 = _mls_x1556;
        _mls_x1498 = _mls_x1552;
        _mls_x1499 = _mls_x1553;
        _mls_x1500 = _mls_colour3;
        _mls_x1501 = _mls_x1554;
        _mls_x1502 = _mls_intens3;
        _mls_x1503 = _mls_x1555;
        _mls_x1504 = _mls_pos7;
        goto _mls_transmitray_caller_post_default;
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_transmitray_caller_post_case0:
  {
    auto [_mls_x1558, _mls_x1559, _mls_x1560, _mls_x1561, _mls_x1562] = _mls_refractray_case0_pre(_mls_x1488, _mls_x1492, _mls_x1494, _mls_x1490);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1559)) {
      auto _mls_x1563 = _mlsValue::cast<_mls_Tuple3>(_mls_x1559)->_mls_field0;
      auto _mls_x1564 = _mlsValue::cast<_mls_Tuple3>(_mls_x1559)->_mls_field1;
      auto _mls_x1565 = _mlsValue::cast<_mls_Tuple3>(_mls_x1559)->_mls_field2;
      auto _mls_x1566 = _mls_refractray_case0_case0_sr_post(_mls_x1560, _mls_x1564, _mls_x1561, _mls_x1565, _mls_x1563, _mls_x1562, _mls_x1558);
      _mls_x1505 = _mls_x1495;
      _mls_x1506 = _mls_x1489;
      _mls_x1507 = _mls_x1487;
      _mls_x1508 = _mls_x1493;
      _mls_x1509 = _mls_x1566;
      _mls_x1510 = _mls_x1491;
      goto _mls_transmitray_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_transmitray_caller_post_default:
  {
    auto [_mls_x1567, _mls_x1568, _mls_x1569, _mls_x1570, _mls_x1571] = _mls_j_case0_sr_post_pre(_mls_x1503, _mls_x1501, _mls_x1497, _mls_x1499);
    if (_mlsValue::isIntLit(_mls_x1569, 1)) {
      auto _mls_x1576 = _mls_j_case0_sr_post_case0();
      auto _mls_x1577 = _mlsValue::cast<_mls_Tuple2>(_mls_x1576)->_mls_field1;
      _mls_x1511 = _mls_x1504;
      _mls_x1512 = _mls_x1500;
      _mls_x1513 = _mls_x1498;
      _mls_x1514 = _mls_x1496;
      _mls_x1515 = _mls_x1577;
      _mls_x1516 = _mls_x1502;
      goto _mls_transmitray_caller_post_case0_sr_post;
    } else {
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1571)) {
        auto _mls_x1572 = _mlsValue::cast<_mls_Tuple3>(_mls_x1571)->_mls_field0;
        auto _mls_x1573 = _mlsValue::cast<_mls_Tuple3>(_mls_x1571)->_mls_field1;
        auto _mls_x1574 = _mlsValue::cast<_mls_Tuple3>(_mls_x1571)->_mls_field2;
        auto _mls_x1575 = _mls_j_case0_sr_post_default_case0_sr_post(_mls_x1567, _mls_x1574, _mls_x1570, _mls_x1568, _mls_x1572, _mls_x1573);
        _mls_x1505 = _mls_x1504;
        _mls_x1506 = _mls_x1498;
        _mls_x1507 = _mls_x1496;
        _mls_x1508 = _mls_x1502;
        _mls_x1509 = _mls_x1575;
        _mls_x1510 = _mls_x1500;
        goto _mls_transmitray_caller_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    }
    return _mls_retval;
  }
  _mls_transmitray_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x1509)) {
      auto _mls_x1578 = _mlsValue::cast<_mls_Tuple2>(_mls_x1509)->_mls_field1;
      _mls_x1511 = _mls_x1505;
      _mls_x1512 = _mls_x1510;
      _mls_x1513 = _mls_x1506;
      _mls_x1514 = _mls_x1507;
      _mls_x1515 = _mls_x1578;
      _mls_x1516 = _mls_x1508;
      goto _mls_transmitray_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_transmitray_caller_post_case0_sr_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1515)) {
      auto _mls_x1579 = _mlsValue::cast<_mls_Tuple3>(_mls_x1515)->_mls_field0;
      auto _mls_x1580 = _mlsValue::cast<_mls_Tuple3>(_mls_x1515)->_mls_field1;
      auto _mls_x1581 = _mlsValue::cast<_mls_Tuple3>(_mls_x1515)->_mls_field2;
      auto _mls_x1582 = _mls_vecscale_case0_sr_post(_mlsValue::create<_mls_Float>(1.0E-6), _mls_x1579, _mls_x1580, _mls_x1581);
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1511)) {
        _mls_x1517 = _mls_x1513;
        _mls_x1518 = _mls_x1515;
        _mls_x1519 = _mls_x1582;
        _mls_x1520 = _mls_x1511;
        _mls_x1521 = _mls_x1512;
        _mls_x1522 = _mls_x1514;
        _mls_x1523 = _mls_x1516;
        goto _mls_transmitray_caller_post_caller_post_case0;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_transmitray_caller_post_caller_post_case0:
  {
    auto _mls_x1583 = _mlsValue::cast<_mls_Tuple3>(_mls_x1520)->_mls_field0;
    auto _mls_x1584 = _mlsValue::cast<_mls_Tuple3>(_mls_x1520)->_mls_field1;
    auto _mls_x1585 = _mlsValue::cast<_mls_Tuple3>(_mls_x1520)->_mls_field2;
    auto _mls_x1586 = _mls_vecadd_case0_sr_post(_mls_x1519, _mls_x1583, _mls_x1584, _mls_x1585);
    _mls_x1524 = _mls_x1517;
    _mls_x1525 = _mls_x1518;
    _mls_x1526 = _mls_x1521;
    _mls_x1527 = _mls_x1522;
    _mls_x1528 = _mls_x1523;
    _mls_x1529 = _mls_x1586;
    goto _mls_transmitray_caller_post_caller_post_caller_post;
    return _mls_retval;
  }
  _mls_transmitray_caller_post_caller_post_caller_post:
  {
    auto _mls_x1587 = _mls_testspheres();
    auto [_mls_x1588, _mls_x1589, _mls_x1590] = _mls_trace_pre(_mls_x1587, _mls_x1529, _mls_x1525);
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1588)) {
      auto _mls_x1595 = _mls_trace_caller_post_case0(_mls_x1589);
      auto _mls_x1596 = _mlsValue::cast<_mls_Tuple3>(_mls_x1595)->_mls_field0;
      auto _mls_x1597 = _mlsValue::cast<_mls_Tuple3>(_mls_x1595)->_mls_field1;
      auto _mls_x1598 = _mlsValue::cast<_mls_Tuple3>(_mls_x1595)->_mls_field2;
      _mls_x1537 = _mls_x1527;
      _mls_x1538 = _mls_x1596;
      _mls_x1539 = _mls_x1524;
      _mls_x1540 = _mls_x1598;
      _mls_x1541 = _mls_x1526;
      _mls_x1542 = _mls_x1529;
      _mls_x1543 = _mls_x1597;
      _mls_x1544 = _mls_x1525;
      _mls_x1545 = _mls_x1528;
      goto _mls_transmitray_caller_post_caller_post_caller_post_case0_sr_post;
    } else {
      auto _mls_x1591 = _mls_trace_caller_post_default_pre(_mls_x1588, _mls_x1590);
      if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x1591)) {
        auto _mls_x1592 = _mlsValue::cast<_mls_Tuple2>(_mls_x1591)->_mls_field0;
        auto _mls_x1593 = _mlsValue::cast<_mls_Tuple2>(_mls_x1591)->_mls_field1;
        auto _mls_x1594 = _mls_trace_caller_post_default_case0_sr_post(_mls_x1592, _mls_x1593);
        _mls_x1530 = _mls_x1524;
        _mls_x1531 = _mls_x1594;
        _mls_x1532 = _mls_x1525;
        _mls_x1533 = _mls_x1526;
        _mls_x1534 = _mls_x1527;
        _mls_x1535 = _mls_x1528;
        _mls_x1536 = _mls_x1529;
        goto _mls_transmitray_caller_post_caller_post_caller_post1;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    }
    return _mls_retval;
  }
  _mls_transmitray_caller_post_caller_post_caller_post1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1531)) {
      auto _mls_x1599 = _mlsValue::cast<_mls_Tuple3>(_mls_x1531)->_mls_field0;
      auto _mls_x1600 = _mlsValue::cast<_mls_Tuple3>(_mls_x1531)->_mls_field1;
      auto _mls_x1601 = _mlsValue::cast<_mls_Tuple3>(_mls_x1531)->_mls_field2;
      _mls_x1537 = _mls_x1534;
      _mls_x1538 = _mls_x1599;
      _mls_x1539 = _mls_x1530;
      _mls_x1540 = _mls_x1601;
      _mls_x1541 = _mls_x1533;
      _mls_x1542 = _mls_x1536;
      _mls_x1543 = _mls_x1600;
      _mls_x1544 = _mls_x1532;
      _mls_x1545 = _mls_x1535;
      goto _mls_transmitray_caller_post_caller_post_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_transmitray_caller_post_caller_post_caller_post_case0_sr_post:
  {
    if (_mlsValue::isIntLit(_mls_x1538, 1)) {
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1544)) {
        auto _mls_x1604 = _mls_shade_case0(_mls_x1542, _mls_x1540, _mls_x1539, _mls_x1537, _mls_x1543, _mls_x1544);
        _mls_x745 = _mls_x1539;
        _mls_x747 = _mls_x1604;
        _mls_x748 = _mls_x1545;
        _mls_x749 = _mls_x1541;
        goto _mls_j2;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      auto _mls_x1602 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.078), _mlsValue::create<_mls_Float>(0.361), _mlsValue::create<_mls_Float>(0.753));
      auto _mls_x1603 = _mls_is_zerovector(_mls_x1539);
      if (_mlsValue::isIntLit(_mls_x1603, 1)) {
        _mls_x740 = _mls_x1541;
        goto _mls_j_case0;
      } else {
        _mls_x741 = _mls_x1602;
        _mls_x742 = _mls_x1545;
        _mls_x743 = _mls_x1541;
        goto _mls_j_default1;
      }
    }
    return _mls_retval;
  }
  _mls_j2:
  {
    auto _mls_x746 = _mls_is_zerovector(_mls_x745);
    if (_mlsValue::isIntLit(_mls_x746, 1)) {
      _mls_x740 = _mls_x749;
      goto _mls_j_case0;
    } else {
      _mls_x741 = _mls_x747;
      _mls_x742 = _mls_x748;
      _mls_x743 = _mls_x749;
      goto _mls_j_default1;
    }
    return _mls_retval;
  }
  _mls_j_case0:
  {
    auto _mls_x750 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x740);
    _mls_retval = _mls_x750;
    return _mls_retval;
  }
  _mls_j_default1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x741)) {
      auto _mls_x751 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field0;
      auto _mls_x752 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field1;
      auto _mls_x753 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field2;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x742)) {
        auto _mls_x754 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field0;
        auto _mls_x755 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field1;
        auto _mls_x756 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field2;
        auto _mls_x757 = _mls_vecmult_case0_sr_post_case0_sr_post(_mls_x756, _mls_x752, _mls_x755, _mls_x753, _mls_x751, _mls_x754);
        auto _mls_x758 = _mls_vecadd_case0(_mls_x757, _mls_x743);
        _mls_x744 = _mls_x758;
        goto _mls_j_caller_post_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post_post:
  {
    auto _mls_x759 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x744);
    _mls_retval = _mls_x759;
    return _mls_retval;
  }
}
_mlsValue _mls_transmitray_caller_post(_mlsValue _mls_x1505, _mlsValue _mls_x1506, _mlsValue _mls_x1507, _mlsValue _mls_x1508, _mlsValue _mls_x1509, _mlsValue _mls_x1510) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1511, _mls_x1512, _mls_x1513, _mls_x1514, _mls_x1515, _mls_x1516;
  _mlsValue _mls_x1517, _mls_x1518, _mls_x1519, _mls_x1520, _mls_x1521, _mls_x1522, _mls_x1523;
  _mlsValue _mls_x1524, _mls_x1525, _mls_x1526, _mls_x1527, _mls_x1528, _mls_x1529;
  _mlsValue _mls_x1530, _mls_x1531, _mls_x1532, _mls_x1533, _mls_x1534, _mls_x1535, _mls_x1536;
  _mlsValue _mls_x1537, _mls_x1538, _mls_x1539, _mls_x1540, _mls_x1541, _mls_x1542, _mls_x1543, _mls_x1544, _mls_x1545;
  _mlsValue _mls_x745, _mls_x747, _mls_x748, _mls_x749;
  _mlsValue _mls_x740;
  _mlsValue _mls_x741, _mls_x742, _mls_x743;
  _mlsValue _mls_x744;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x1509)) {
    auto _mls_x1578 = _mlsValue::cast<_mls_Tuple2>(_mls_x1509)->_mls_field1;
    _mls_x1511 = _mls_x1505;
    _mls_x1512 = _mls_x1510;
    _mls_x1513 = _mls_x1506;
    _mls_x1514 = _mls_x1507;
    _mls_x1515 = _mls_x1578;
    _mls_x1516 = _mls_x1508;
    goto _mls_transmitray_caller_post_case0_sr_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_transmitray_caller_post_case0_sr_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1515)) {
      auto _mls_x1579 = _mlsValue::cast<_mls_Tuple3>(_mls_x1515)->_mls_field0;
      auto _mls_x1580 = _mlsValue::cast<_mls_Tuple3>(_mls_x1515)->_mls_field1;
      auto _mls_x1581 = _mlsValue::cast<_mls_Tuple3>(_mls_x1515)->_mls_field2;
      auto _mls_x1582 = _mls_vecscale_case0_sr_post(_mlsValue::create<_mls_Float>(1.0E-6), _mls_x1579, _mls_x1580, _mls_x1581);
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1511)) {
        _mls_x1517 = _mls_x1513;
        _mls_x1518 = _mls_x1515;
        _mls_x1519 = _mls_x1582;
        _mls_x1520 = _mls_x1511;
        _mls_x1521 = _mls_x1512;
        _mls_x1522 = _mls_x1514;
        _mls_x1523 = _mls_x1516;
        goto _mls_transmitray_caller_post_caller_post_case0;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_transmitray_caller_post_caller_post_case0:
  {
    auto _mls_x1583 = _mlsValue::cast<_mls_Tuple3>(_mls_x1520)->_mls_field0;
    auto _mls_x1584 = _mlsValue::cast<_mls_Tuple3>(_mls_x1520)->_mls_field1;
    auto _mls_x1585 = _mlsValue::cast<_mls_Tuple3>(_mls_x1520)->_mls_field2;
    auto _mls_x1586 = _mls_vecadd_case0_sr_post(_mls_x1519, _mls_x1583, _mls_x1584, _mls_x1585);
    _mls_x1524 = _mls_x1517;
    _mls_x1525 = _mls_x1518;
    _mls_x1526 = _mls_x1521;
    _mls_x1527 = _mls_x1522;
    _mls_x1528 = _mls_x1523;
    _mls_x1529 = _mls_x1586;
    goto _mls_transmitray_caller_post_caller_post_caller_post;
    return _mls_retval;
  }
  _mls_transmitray_caller_post_caller_post_caller_post:
  {
    auto _mls_x1587 = _mls_testspheres();
    auto [_mls_x1588, _mls_x1589, _mls_x1590] = _mls_trace_pre(_mls_x1587, _mls_x1529, _mls_x1525);
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1588)) {
      auto _mls_x1595 = _mls_trace_caller_post_case0(_mls_x1589);
      auto _mls_x1596 = _mlsValue::cast<_mls_Tuple3>(_mls_x1595)->_mls_field0;
      auto _mls_x1597 = _mlsValue::cast<_mls_Tuple3>(_mls_x1595)->_mls_field1;
      auto _mls_x1598 = _mlsValue::cast<_mls_Tuple3>(_mls_x1595)->_mls_field2;
      _mls_x1537 = _mls_x1527;
      _mls_x1538 = _mls_x1596;
      _mls_x1539 = _mls_x1524;
      _mls_x1540 = _mls_x1598;
      _mls_x1541 = _mls_x1526;
      _mls_x1542 = _mls_x1529;
      _mls_x1543 = _mls_x1597;
      _mls_x1544 = _mls_x1525;
      _mls_x1545 = _mls_x1528;
      goto _mls_transmitray_caller_post_caller_post_caller_post_case0_sr_post;
    } else {
      auto _mls_x1591 = _mls_trace_caller_post_default_pre(_mls_x1588, _mls_x1590);
      if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x1591)) {
        auto _mls_x1592 = _mlsValue::cast<_mls_Tuple2>(_mls_x1591)->_mls_field0;
        auto _mls_x1593 = _mlsValue::cast<_mls_Tuple2>(_mls_x1591)->_mls_field1;
        auto _mls_x1594 = _mls_trace_caller_post_default_case0_sr_post(_mls_x1592, _mls_x1593);
        _mls_x1530 = _mls_x1524;
        _mls_x1531 = _mls_x1594;
        _mls_x1532 = _mls_x1525;
        _mls_x1533 = _mls_x1526;
        _mls_x1534 = _mls_x1527;
        _mls_x1535 = _mls_x1528;
        _mls_x1536 = _mls_x1529;
        goto _mls_transmitray_caller_post_caller_post_caller_post1;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    }
    return _mls_retval;
  }
  _mls_transmitray_caller_post_caller_post_caller_post1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1531)) {
      auto _mls_x1599 = _mlsValue::cast<_mls_Tuple3>(_mls_x1531)->_mls_field0;
      auto _mls_x1600 = _mlsValue::cast<_mls_Tuple3>(_mls_x1531)->_mls_field1;
      auto _mls_x1601 = _mlsValue::cast<_mls_Tuple3>(_mls_x1531)->_mls_field2;
      _mls_x1537 = _mls_x1534;
      _mls_x1538 = _mls_x1599;
      _mls_x1539 = _mls_x1530;
      _mls_x1540 = _mls_x1601;
      _mls_x1541 = _mls_x1533;
      _mls_x1542 = _mls_x1536;
      _mls_x1543 = _mls_x1600;
      _mls_x1544 = _mls_x1532;
      _mls_x1545 = _mls_x1535;
      goto _mls_transmitray_caller_post_caller_post_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_transmitray_caller_post_caller_post_caller_post_case0_sr_post:
  {
    if (_mlsValue::isIntLit(_mls_x1538, 1)) {
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1544)) {
        auto _mls_x1604 = _mls_shade_case0(_mls_x1542, _mls_x1540, _mls_x1539, _mls_x1537, _mls_x1543, _mls_x1544);
        _mls_x745 = _mls_x1539;
        _mls_x747 = _mls_x1604;
        _mls_x748 = _mls_x1545;
        _mls_x749 = _mls_x1541;
        goto _mls_j2;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      auto _mls_x1602 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.078), _mlsValue::create<_mls_Float>(0.361), _mlsValue::create<_mls_Float>(0.753));
      auto _mls_x1603 = _mls_is_zerovector(_mls_x1539);
      if (_mlsValue::isIntLit(_mls_x1603, 1)) {
        _mls_x740 = _mls_x1541;
        goto _mls_j_case0;
      } else {
        _mls_x741 = _mls_x1602;
        _mls_x742 = _mls_x1545;
        _mls_x743 = _mls_x1541;
        goto _mls_j_default1;
      }
    }
    return _mls_retval;
  }
  _mls_j2:
  {
    auto _mls_x746 = _mls_is_zerovector(_mls_x745);
    if (_mlsValue::isIntLit(_mls_x746, 1)) {
      _mls_x740 = _mls_x749;
      goto _mls_j_case0;
    } else {
      _mls_x741 = _mls_x747;
      _mls_x742 = _mls_x748;
      _mls_x743 = _mls_x749;
      goto _mls_j_default1;
    }
    return _mls_retval;
  }
  _mls_j_case0:
  {
    auto _mls_x750 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x740);
    _mls_retval = _mls_x750;
    return _mls_retval;
  }
  _mls_j_default1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x741)) {
      auto _mls_x751 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field0;
      auto _mls_x752 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field1;
      auto _mls_x753 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field2;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x742)) {
        auto _mls_x754 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field0;
        auto _mls_x755 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field1;
        auto _mls_x756 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field2;
        auto _mls_x757 = _mls_vecmult_case0_sr_post_case0_sr_post(_mls_x756, _mls_x752, _mls_x755, _mls_x753, _mls_x751, _mls_x754);
        auto _mls_x758 = _mls_vecadd_case0(_mls_x757, _mls_x743);
        _mls_x744 = _mls_x758;
        goto _mls_j_caller_post_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post_post:
  {
    auto _mls_x759 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x744);
    _mls_retval = _mls_x759;
    return _mls_retval;
  }
}
_mlsValue _mls_transmitray_caller_post_caller_post_caller_post(_mlsValue _mls_x1524, _mlsValue _mls_x1525, _mlsValue _mls_x1526, _mlsValue _mls_x1527, _mlsValue _mls_x1528, _mlsValue _mls_x1529) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1530, _mls_x1531, _mls_x1532, _mls_x1533, _mls_x1534, _mls_x1535, _mls_x1536;
  _mlsValue _mls_x1537, _mls_x1538, _mls_x1539, _mls_x1540, _mls_x1541, _mls_x1542, _mls_x1543, _mls_x1544, _mls_x1545;
  _mlsValue _mls_x745, _mls_x747, _mls_x748, _mls_x749;
  _mlsValue _mls_x740;
  _mlsValue _mls_x741, _mls_x742, _mls_x743;
  _mlsValue _mls_x744;
  auto _mls_x1587 = _mls_testspheres();
  auto [_mls_x1588, _mls_x1589, _mls_x1590] = _mls_trace_pre(_mls_x1587, _mls_x1529, _mls_x1525);
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1588)) {
    auto _mls_x1595 = _mls_trace_caller_post_case0(_mls_x1589);
    auto _mls_x1596 = _mlsValue::cast<_mls_Tuple3>(_mls_x1595)->_mls_field0;
    auto _mls_x1597 = _mlsValue::cast<_mls_Tuple3>(_mls_x1595)->_mls_field1;
    auto _mls_x1598 = _mlsValue::cast<_mls_Tuple3>(_mls_x1595)->_mls_field2;
    _mls_x1537 = _mls_x1527;
    _mls_x1538 = _mls_x1596;
    _mls_x1539 = _mls_x1524;
    _mls_x1540 = _mls_x1598;
    _mls_x1541 = _mls_x1526;
    _mls_x1542 = _mls_x1529;
    _mls_x1543 = _mls_x1597;
    _mls_x1544 = _mls_x1525;
    _mls_x1545 = _mls_x1528;
    goto _mls_transmitray_caller_post_caller_post_caller_post_case0_sr_post;
  } else {
    auto _mls_x1591 = _mls_trace_caller_post_default_pre(_mls_x1588, _mls_x1590);
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x1591)) {
      auto _mls_x1592 = _mlsValue::cast<_mls_Tuple2>(_mls_x1591)->_mls_field0;
      auto _mls_x1593 = _mlsValue::cast<_mls_Tuple2>(_mls_x1591)->_mls_field1;
      auto _mls_x1594 = _mls_trace_caller_post_default_case0_sr_post(_mls_x1592, _mls_x1593);
      _mls_x1530 = _mls_x1524;
      _mls_x1531 = _mls_x1594;
      _mls_x1532 = _mls_x1525;
      _mls_x1533 = _mls_x1526;
      _mls_x1534 = _mls_x1527;
      _mls_x1535 = _mls_x1528;
      _mls_x1536 = _mls_x1529;
      goto _mls_transmitray_caller_post_caller_post_caller_post1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  }
  return _mls_retval;
  _mls_transmitray_caller_post_caller_post_caller_post1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1531)) {
      auto _mls_x1599 = _mlsValue::cast<_mls_Tuple3>(_mls_x1531)->_mls_field0;
      auto _mls_x1600 = _mlsValue::cast<_mls_Tuple3>(_mls_x1531)->_mls_field1;
      auto _mls_x1601 = _mlsValue::cast<_mls_Tuple3>(_mls_x1531)->_mls_field2;
      _mls_x1537 = _mls_x1534;
      _mls_x1538 = _mls_x1599;
      _mls_x1539 = _mls_x1530;
      _mls_x1540 = _mls_x1601;
      _mls_x1541 = _mls_x1533;
      _mls_x1542 = _mls_x1536;
      _mls_x1543 = _mls_x1600;
      _mls_x1544 = _mls_x1532;
      _mls_x1545 = _mls_x1535;
      goto _mls_transmitray_caller_post_caller_post_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_transmitray_caller_post_caller_post_caller_post_case0_sr_post:
  {
    if (_mlsValue::isIntLit(_mls_x1538, 1)) {
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1544)) {
        auto _mls_x1604 = _mls_shade_case0(_mls_x1542, _mls_x1540, _mls_x1539, _mls_x1537, _mls_x1543, _mls_x1544);
        _mls_x745 = _mls_x1539;
        _mls_x747 = _mls_x1604;
        _mls_x748 = _mls_x1545;
        _mls_x749 = _mls_x1541;
        goto _mls_j2;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      auto _mls_x1602 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.078), _mlsValue::create<_mls_Float>(0.361), _mlsValue::create<_mls_Float>(0.753));
      auto _mls_x1603 = _mls_is_zerovector(_mls_x1539);
      if (_mlsValue::isIntLit(_mls_x1603, 1)) {
        _mls_x740 = _mls_x1541;
        goto _mls_j_case0;
      } else {
        _mls_x741 = _mls_x1602;
        _mls_x742 = _mls_x1545;
        _mls_x743 = _mls_x1541;
        goto _mls_j_default1;
      }
    }
    return _mls_retval;
  }
  _mls_j2:
  {
    auto _mls_x746 = _mls_is_zerovector(_mls_x745);
    if (_mlsValue::isIntLit(_mls_x746, 1)) {
      _mls_x740 = _mls_x749;
      goto _mls_j_case0;
    } else {
      _mls_x741 = _mls_x747;
      _mls_x742 = _mls_x748;
      _mls_x743 = _mls_x749;
      goto _mls_j_default1;
    }
    return _mls_retval;
  }
  _mls_j_case0:
  {
    auto _mls_x750 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x740);
    _mls_retval = _mls_x750;
    return _mls_retval;
  }
  _mls_j_default1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x741)) {
      auto _mls_x751 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field0;
      auto _mls_x752 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field1;
      auto _mls_x753 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field2;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x742)) {
        auto _mls_x754 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field0;
        auto _mls_x755 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field1;
        auto _mls_x756 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field2;
        auto _mls_x757 = _mls_vecmult_case0_sr_post_case0_sr_post(_mls_x756, _mls_x752, _mls_x755, _mls_x753, _mls_x751, _mls_x754);
        auto _mls_x758 = _mls_vecadd_case0(_mls_x757, _mls_x743);
        _mls_x744 = _mls_x758;
        goto _mls_j_caller_post_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post_post:
  {
    auto _mls_x759 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x744);
    _mls_retval = _mls_x759;
    return _mls_retval;
  }
}
_mlsValue _mls_transmitray_caller_post_caller_post_caller_post1(_mlsValue _mls_x1530, _mlsValue _mls_x1531, _mlsValue _mls_x1532, _mlsValue _mls_x1533, _mlsValue _mls_x1534, _mlsValue _mls_x1535, _mlsValue _mls_x1536) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1537, _mls_x1538, _mls_x1539, _mls_x1540, _mls_x1541, _mls_x1542, _mls_x1543, _mls_x1544, _mls_x1545;
  _mlsValue _mls_x745, _mls_x747, _mls_x748, _mls_x749;
  _mlsValue _mls_x740;
  _mlsValue _mls_x741, _mls_x742, _mls_x743;
  _mlsValue _mls_x744;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1531)) {
    auto _mls_x1599 = _mlsValue::cast<_mls_Tuple3>(_mls_x1531)->_mls_field0;
    auto _mls_x1600 = _mlsValue::cast<_mls_Tuple3>(_mls_x1531)->_mls_field1;
    auto _mls_x1601 = _mlsValue::cast<_mls_Tuple3>(_mls_x1531)->_mls_field2;
    _mls_x1537 = _mls_x1534;
    _mls_x1538 = _mls_x1599;
    _mls_x1539 = _mls_x1530;
    _mls_x1540 = _mls_x1601;
    _mls_x1541 = _mls_x1533;
    _mls_x1542 = _mls_x1536;
    _mls_x1543 = _mls_x1600;
    _mls_x1544 = _mls_x1532;
    _mls_x1545 = _mls_x1535;
    goto _mls_transmitray_caller_post_caller_post_caller_post_case0_sr_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_transmitray_caller_post_caller_post_caller_post_case0_sr_post:
  {
    if (_mlsValue::isIntLit(_mls_x1538, 1)) {
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1544)) {
        auto _mls_x1604 = _mls_shade_case0(_mls_x1542, _mls_x1540, _mls_x1539, _mls_x1537, _mls_x1543, _mls_x1544);
        _mls_x745 = _mls_x1539;
        _mls_x747 = _mls_x1604;
        _mls_x748 = _mls_x1545;
        _mls_x749 = _mls_x1541;
        goto _mls_j2;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      auto _mls_x1602 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.078), _mlsValue::create<_mls_Float>(0.361), _mlsValue::create<_mls_Float>(0.753));
      auto _mls_x1603 = _mls_is_zerovector(_mls_x1539);
      if (_mlsValue::isIntLit(_mls_x1603, 1)) {
        _mls_x740 = _mls_x1541;
        goto _mls_j_case0;
      } else {
        _mls_x741 = _mls_x1602;
        _mls_x742 = _mls_x1545;
        _mls_x743 = _mls_x1541;
        goto _mls_j_default1;
      }
    }
    return _mls_retval;
  }
  _mls_j2:
  {
    auto _mls_x746 = _mls_is_zerovector(_mls_x745);
    if (_mlsValue::isIntLit(_mls_x746, 1)) {
      _mls_x740 = _mls_x749;
      goto _mls_j_case0;
    } else {
      _mls_x741 = _mls_x747;
      _mls_x742 = _mls_x748;
      _mls_x743 = _mls_x749;
      goto _mls_j_default1;
    }
    return _mls_retval;
  }
  _mls_j_case0:
  {
    auto _mls_x750 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x740);
    _mls_retval = _mls_x750;
    return _mls_retval;
  }
  _mls_j_default1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x741)) {
      auto _mls_x751 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field0;
      auto _mls_x752 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field1;
      auto _mls_x753 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field2;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x742)) {
        auto _mls_x754 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field0;
        auto _mls_x755 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field1;
        auto _mls_x756 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field2;
        auto _mls_x757 = _mls_vecmult_case0_sr_post_case0_sr_post(_mls_x756, _mls_x752, _mls_x755, _mls_x753, _mls_x751, _mls_x754);
        auto _mls_x758 = _mls_vecadd_case0(_mls_x757, _mls_x743);
        _mls_x744 = _mls_x758;
        goto _mls_j_caller_post_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post_post:
  {
    auto _mls_x759 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x744);
    _mls_retval = _mls_x759;
    return _mls_retval;
  }
}
_mlsValue _mls_transmitray_caller_post_caller_post_caller_post_case0_sr_post(_mlsValue _mls_x1537, _mlsValue _mls_x1538, _mlsValue _mls_x1539, _mlsValue _mls_x1540, _mlsValue _mls_x1541, _mlsValue _mls_x1542, _mlsValue _mls_x1543, _mlsValue _mls_x1544, _mlsValue _mls_x1545) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x745, _mls_x747, _mls_x748, _mls_x749;
  _mlsValue _mls_x740;
  _mlsValue _mls_x741, _mls_x742, _mls_x743;
  _mlsValue _mls_x744;
  if (_mlsValue::isIntLit(_mls_x1538, 1)) {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1544)) {
      auto _mls_x1604 = _mls_shade_case0(_mls_x1542, _mls_x1540, _mls_x1539, _mls_x1537, _mls_x1543, _mls_x1544);
      _mls_x745 = _mls_x1539;
      _mls_x747 = _mls_x1604;
      _mls_x748 = _mls_x1545;
      _mls_x749 = _mls_x1541;
      goto _mls_j2;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    auto _mls_x1602 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.078), _mlsValue::create<_mls_Float>(0.361), _mlsValue::create<_mls_Float>(0.753));
    auto _mls_x1603 = _mls_is_zerovector(_mls_x1539);
    if (_mlsValue::isIntLit(_mls_x1603, 1)) {
      _mls_x740 = _mls_x1541;
      goto _mls_j_case0;
    } else {
      _mls_x741 = _mls_x1602;
      _mls_x742 = _mls_x1545;
      _mls_x743 = _mls_x1541;
      goto _mls_j_default1;
    }
  }
  return _mls_retval;
  _mls_j2:
  {
    auto _mls_x746 = _mls_is_zerovector(_mls_x745);
    if (_mlsValue::isIntLit(_mls_x746, 1)) {
      _mls_x740 = _mls_x749;
      goto _mls_j_case0;
    } else {
      _mls_x741 = _mls_x747;
      _mls_x742 = _mls_x748;
      _mls_x743 = _mls_x749;
      goto _mls_j_default1;
    }
    return _mls_retval;
  }
  _mls_j_case0:
  {
    auto _mls_x750 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x740);
    _mls_retval = _mls_x750;
    return _mls_retval;
  }
  _mls_j_default1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x741)) {
      auto _mls_x751 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field0;
      auto _mls_x752 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field1;
      auto _mls_x753 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field2;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x742)) {
        auto _mls_x754 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field0;
        auto _mls_x755 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field1;
        auto _mls_x756 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field2;
        auto _mls_x757 = _mls_vecmult_case0_sr_post_case0_sr_post(_mls_x756, _mls_x752, _mls_x755, _mls_x753, _mls_x751, _mls_x754);
        auto _mls_x758 = _mls_vecadd_case0(_mls_x757, _mls_x743);
        _mls_x744 = _mls_x758;
        goto _mls_j_caller_post_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post_post:
  {
    auto _mls_x759 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x744);
    _mls_retval = _mls_x759;
    return _mls_retval;
  }
}
_mlsValue _mls_transmitray_caller_post_caller_post_case0(_mlsValue _mls_x1517, _mlsValue _mls_x1518, _mlsValue _mls_x1519, _mlsValue _mls_x1520, _mlsValue _mls_x1521, _mlsValue _mls_x1522, _mlsValue _mls_x1523) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1524, _mls_x1525, _mls_x1526, _mls_x1527, _mls_x1528, _mls_x1529;
  _mlsValue _mls_x1530, _mls_x1531, _mls_x1532, _mls_x1533, _mls_x1534, _mls_x1535, _mls_x1536;
  _mlsValue _mls_x1537, _mls_x1538, _mls_x1539, _mls_x1540, _mls_x1541, _mls_x1542, _mls_x1543, _mls_x1544, _mls_x1545;
  _mlsValue _mls_x745, _mls_x747, _mls_x748, _mls_x749;
  _mlsValue _mls_x740;
  _mlsValue _mls_x741, _mls_x742, _mls_x743;
  _mlsValue _mls_x744;
  auto _mls_x1583 = _mlsValue::cast<_mls_Tuple3>(_mls_x1520)->_mls_field0;
  auto _mls_x1584 = _mlsValue::cast<_mls_Tuple3>(_mls_x1520)->_mls_field1;
  auto _mls_x1585 = _mlsValue::cast<_mls_Tuple3>(_mls_x1520)->_mls_field2;
  auto _mls_x1586 = _mls_vecadd_case0_sr_post(_mls_x1519, _mls_x1583, _mls_x1584, _mls_x1585);
  _mls_x1524 = _mls_x1517;
  _mls_x1525 = _mls_x1518;
  _mls_x1526 = _mls_x1521;
  _mls_x1527 = _mls_x1522;
  _mls_x1528 = _mls_x1523;
  _mls_x1529 = _mls_x1586;
  goto _mls_transmitray_caller_post_caller_post_caller_post;
  return _mls_retval;
  _mls_transmitray_caller_post_caller_post_caller_post:
  {
    auto _mls_x1587 = _mls_testspheres();
    auto [_mls_x1588, _mls_x1589, _mls_x1590] = _mls_trace_pre(_mls_x1587, _mls_x1529, _mls_x1525);
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1588)) {
      auto _mls_x1595 = _mls_trace_caller_post_case0(_mls_x1589);
      auto _mls_x1596 = _mlsValue::cast<_mls_Tuple3>(_mls_x1595)->_mls_field0;
      auto _mls_x1597 = _mlsValue::cast<_mls_Tuple3>(_mls_x1595)->_mls_field1;
      auto _mls_x1598 = _mlsValue::cast<_mls_Tuple3>(_mls_x1595)->_mls_field2;
      _mls_x1537 = _mls_x1527;
      _mls_x1538 = _mls_x1596;
      _mls_x1539 = _mls_x1524;
      _mls_x1540 = _mls_x1598;
      _mls_x1541 = _mls_x1526;
      _mls_x1542 = _mls_x1529;
      _mls_x1543 = _mls_x1597;
      _mls_x1544 = _mls_x1525;
      _mls_x1545 = _mls_x1528;
      goto _mls_transmitray_caller_post_caller_post_caller_post_case0_sr_post;
    } else {
      auto _mls_x1591 = _mls_trace_caller_post_default_pre(_mls_x1588, _mls_x1590);
      if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x1591)) {
        auto _mls_x1592 = _mlsValue::cast<_mls_Tuple2>(_mls_x1591)->_mls_field0;
        auto _mls_x1593 = _mlsValue::cast<_mls_Tuple2>(_mls_x1591)->_mls_field1;
        auto _mls_x1594 = _mls_trace_caller_post_default_case0_sr_post(_mls_x1592, _mls_x1593);
        _mls_x1530 = _mls_x1524;
        _mls_x1531 = _mls_x1594;
        _mls_x1532 = _mls_x1525;
        _mls_x1533 = _mls_x1526;
        _mls_x1534 = _mls_x1527;
        _mls_x1535 = _mls_x1528;
        _mls_x1536 = _mls_x1529;
        goto _mls_transmitray_caller_post_caller_post_caller_post1;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    }
    return _mls_retval;
  }
  _mls_transmitray_caller_post_caller_post_caller_post1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1531)) {
      auto _mls_x1599 = _mlsValue::cast<_mls_Tuple3>(_mls_x1531)->_mls_field0;
      auto _mls_x1600 = _mlsValue::cast<_mls_Tuple3>(_mls_x1531)->_mls_field1;
      auto _mls_x1601 = _mlsValue::cast<_mls_Tuple3>(_mls_x1531)->_mls_field2;
      _mls_x1537 = _mls_x1534;
      _mls_x1538 = _mls_x1599;
      _mls_x1539 = _mls_x1530;
      _mls_x1540 = _mls_x1601;
      _mls_x1541 = _mls_x1533;
      _mls_x1542 = _mls_x1536;
      _mls_x1543 = _mls_x1600;
      _mls_x1544 = _mls_x1532;
      _mls_x1545 = _mls_x1535;
      goto _mls_transmitray_caller_post_caller_post_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_transmitray_caller_post_caller_post_caller_post_case0_sr_post:
  {
    if (_mlsValue::isIntLit(_mls_x1538, 1)) {
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1544)) {
        auto _mls_x1604 = _mls_shade_case0(_mls_x1542, _mls_x1540, _mls_x1539, _mls_x1537, _mls_x1543, _mls_x1544);
        _mls_x745 = _mls_x1539;
        _mls_x747 = _mls_x1604;
        _mls_x748 = _mls_x1545;
        _mls_x749 = _mls_x1541;
        goto _mls_j2;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      auto _mls_x1602 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.078), _mlsValue::create<_mls_Float>(0.361), _mlsValue::create<_mls_Float>(0.753));
      auto _mls_x1603 = _mls_is_zerovector(_mls_x1539);
      if (_mlsValue::isIntLit(_mls_x1603, 1)) {
        _mls_x740 = _mls_x1541;
        goto _mls_j_case0;
      } else {
        _mls_x741 = _mls_x1602;
        _mls_x742 = _mls_x1545;
        _mls_x743 = _mls_x1541;
        goto _mls_j_default1;
      }
    }
    return _mls_retval;
  }
  _mls_j2:
  {
    auto _mls_x746 = _mls_is_zerovector(_mls_x745);
    if (_mlsValue::isIntLit(_mls_x746, 1)) {
      _mls_x740 = _mls_x749;
      goto _mls_j_case0;
    } else {
      _mls_x741 = _mls_x747;
      _mls_x742 = _mls_x748;
      _mls_x743 = _mls_x749;
      goto _mls_j_default1;
    }
    return _mls_retval;
  }
  _mls_j_case0:
  {
    auto _mls_x750 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x740);
    _mls_retval = _mls_x750;
    return _mls_retval;
  }
  _mls_j_default1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x741)) {
      auto _mls_x751 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field0;
      auto _mls_x752 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field1;
      auto _mls_x753 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field2;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x742)) {
        auto _mls_x754 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field0;
        auto _mls_x755 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field1;
        auto _mls_x756 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field2;
        auto _mls_x757 = _mls_vecmult_case0_sr_post_case0_sr_post(_mls_x756, _mls_x752, _mls_x755, _mls_x753, _mls_x751, _mls_x754);
        auto _mls_x758 = _mls_vecadd_case0(_mls_x757, _mls_x743);
        _mls_x744 = _mls_x758;
        goto _mls_j_caller_post_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post_post:
  {
    auto _mls_x759 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x744);
    _mls_retval = _mls_x759;
    return _mls_retval;
  }
}
_mlsValue _mls_transmitray_caller_post_case0(_mlsValue _mls_x1487, _mlsValue _mls_x1488, _mlsValue _mls_x1489, _mlsValue _mls_x1490, _mlsValue _mls_x1491, _mlsValue _mls_x1492, _mlsValue _mls_x1493, _mlsValue _mls_x1494, _mlsValue _mls_x1495) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1505, _mls_x1506, _mls_x1507, _mls_x1508, _mls_x1509, _mls_x1510;
  _mlsValue _mls_x1511, _mls_x1512, _mls_x1513, _mls_x1514, _mls_x1515, _mls_x1516;
  _mlsValue _mls_x1517, _mls_x1518, _mls_x1519, _mls_x1520, _mls_x1521, _mls_x1522, _mls_x1523;
  _mlsValue _mls_x1524, _mls_x1525, _mls_x1526, _mls_x1527, _mls_x1528, _mls_x1529;
  _mlsValue _mls_x1530, _mls_x1531, _mls_x1532, _mls_x1533, _mls_x1534, _mls_x1535, _mls_x1536;
  _mlsValue _mls_x1537, _mls_x1538, _mls_x1539, _mls_x1540, _mls_x1541, _mls_x1542, _mls_x1543, _mls_x1544, _mls_x1545;
  _mlsValue _mls_x745, _mls_x747, _mls_x748, _mls_x749;
  _mlsValue _mls_x740;
  _mlsValue _mls_x741, _mls_x742, _mls_x743;
  _mlsValue _mls_x744;
  auto [_mls_x1558, _mls_x1559, _mls_x1560, _mls_x1561, _mls_x1562] = _mls_refractray_case0_pre(_mls_x1488, _mls_x1492, _mls_x1494, _mls_x1490);
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1559)) {
    auto _mls_x1563 = _mlsValue::cast<_mls_Tuple3>(_mls_x1559)->_mls_field0;
    auto _mls_x1564 = _mlsValue::cast<_mls_Tuple3>(_mls_x1559)->_mls_field1;
    auto _mls_x1565 = _mlsValue::cast<_mls_Tuple3>(_mls_x1559)->_mls_field2;
    auto _mls_x1566 = _mls_refractray_case0_case0_sr_post(_mls_x1560, _mls_x1564, _mls_x1561, _mls_x1565, _mls_x1563, _mls_x1562, _mls_x1558);
    _mls_x1505 = _mls_x1495;
    _mls_x1506 = _mls_x1489;
    _mls_x1507 = _mls_x1487;
    _mls_x1508 = _mls_x1493;
    _mls_x1509 = _mls_x1566;
    _mls_x1510 = _mls_x1491;
    goto _mls_transmitray_caller_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_transmitray_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x1509)) {
      auto _mls_x1578 = _mlsValue::cast<_mls_Tuple2>(_mls_x1509)->_mls_field1;
      _mls_x1511 = _mls_x1505;
      _mls_x1512 = _mls_x1510;
      _mls_x1513 = _mls_x1506;
      _mls_x1514 = _mls_x1507;
      _mls_x1515 = _mls_x1578;
      _mls_x1516 = _mls_x1508;
      goto _mls_transmitray_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_transmitray_caller_post_case0_sr_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1515)) {
      auto _mls_x1579 = _mlsValue::cast<_mls_Tuple3>(_mls_x1515)->_mls_field0;
      auto _mls_x1580 = _mlsValue::cast<_mls_Tuple3>(_mls_x1515)->_mls_field1;
      auto _mls_x1581 = _mlsValue::cast<_mls_Tuple3>(_mls_x1515)->_mls_field2;
      auto _mls_x1582 = _mls_vecscale_case0_sr_post(_mlsValue::create<_mls_Float>(1.0E-6), _mls_x1579, _mls_x1580, _mls_x1581);
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1511)) {
        _mls_x1517 = _mls_x1513;
        _mls_x1518 = _mls_x1515;
        _mls_x1519 = _mls_x1582;
        _mls_x1520 = _mls_x1511;
        _mls_x1521 = _mls_x1512;
        _mls_x1522 = _mls_x1514;
        _mls_x1523 = _mls_x1516;
        goto _mls_transmitray_caller_post_caller_post_case0;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_transmitray_caller_post_caller_post_case0:
  {
    auto _mls_x1583 = _mlsValue::cast<_mls_Tuple3>(_mls_x1520)->_mls_field0;
    auto _mls_x1584 = _mlsValue::cast<_mls_Tuple3>(_mls_x1520)->_mls_field1;
    auto _mls_x1585 = _mlsValue::cast<_mls_Tuple3>(_mls_x1520)->_mls_field2;
    auto _mls_x1586 = _mls_vecadd_case0_sr_post(_mls_x1519, _mls_x1583, _mls_x1584, _mls_x1585);
    _mls_x1524 = _mls_x1517;
    _mls_x1525 = _mls_x1518;
    _mls_x1526 = _mls_x1521;
    _mls_x1527 = _mls_x1522;
    _mls_x1528 = _mls_x1523;
    _mls_x1529 = _mls_x1586;
    goto _mls_transmitray_caller_post_caller_post_caller_post;
    return _mls_retval;
  }
  _mls_transmitray_caller_post_caller_post_caller_post:
  {
    auto _mls_x1587 = _mls_testspheres();
    auto [_mls_x1588, _mls_x1589, _mls_x1590] = _mls_trace_pre(_mls_x1587, _mls_x1529, _mls_x1525);
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1588)) {
      auto _mls_x1595 = _mls_trace_caller_post_case0(_mls_x1589);
      auto _mls_x1596 = _mlsValue::cast<_mls_Tuple3>(_mls_x1595)->_mls_field0;
      auto _mls_x1597 = _mlsValue::cast<_mls_Tuple3>(_mls_x1595)->_mls_field1;
      auto _mls_x1598 = _mlsValue::cast<_mls_Tuple3>(_mls_x1595)->_mls_field2;
      _mls_x1537 = _mls_x1527;
      _mls_x1538 = _mls_x1596;
      _mls_x1539 = _mls_x1524;
      _mls_x1540 = _mls_x1598;
      _mls_x1541 = _mls_x1526;
      _mls_x1542 = _mls_x1529;
      _mls_x1543 = _mls_x1597;
      _mls_x1544 = _mls_x1525;
      _mls_x1545 = _mls_x1528;
      goto _mls_transmitray_caller_post_caller_post_caller_post_case0_sr_post;
    } else {
      auto _mls_x1591 = _mls_trace_caller_post_default_pre(_mls_x1588, _mls_x1590);
      if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x1591)) {
        auto _mls_x1592 = _mlsValue::cast<_mls_Tuple2>(_mls_x1591)->_mls_field0;
        auto _mls_x1593 = _mlsValue::cast<_mls_Tuple2>(_mls_x1591)->_mls_field1;
        auto _mls_x1594 = _mls_trace_caller_post_default_case0_sr_post(_mls_x1592, _mls_x1593);
        _mls_x1530 = _mls_x1524;
        _mls_x1531 = _mls_x1594;
        _mls_x1532 = _mls_x1525;
        _mls_x1533 = _mls_x1526;
        _mls_x1534 = _mls_x1527;
        _mls_x1535 = _mls_x1528;
        _mls_x1536 = _mls_x1529;
        goto _mls_transmitray_caller_post_caller_post_caller_post1;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    }
    return _mls_retval;
  }
  _mls_transmitray_caller_post_caller_post_caller_post1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1531)) {
      auto _mls_x1599 = _mlsValue::cast<_mls_Tuple3>(_mls_x1531)->_mls_field0;
      auto _mls_x1600 = _mlsValue::cast<_mls_Tuple3>(_mls_x1531)->_mls_field1;
      auto _mls_x1601 = _mlsValue::cast<_mls_Tuple3>(_mls_x1531)->_mls_field2;
      _mls_x1537 = _mls_x1534;
      _mls_x1538 = _mls_x1599;
      _mls_x1539 = _mls_x1530;
      _mls_x1540 = _mls_x1601;
      _mls_x1541 = _mls_x1533;
      _mls_x1542 = _mls_x1536;
      _mls_x1543 = _mls_x1600;
      _mls_x1544 = _mls_x1532;
      _mls_x1545 = _mls_x1535;
      goto _mls_transmitray_caller_post_caller_post_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_transmitray_caller_post_caller_post_caller_post_case0_sr_post:
  {
    if (_mlsValue::isIntLit(_mls_x1538, 1)) {
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1544)) {
        auto _mls_x1604 = _mls_shade_case0(_mls_x1542, _mls_x1540, _mls_x1539, _mls_x1537, _mls_x1543, _mls_x1544);
        _mls_x745 = _mls_x1539;
        _mls_x747 = _mls_x1604;
        _mls_x748 = _mls_x1545;
        _mls_x749 = _mls_x1541;
        goto _mls_j2;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      auto _mls_x1602 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.078), _mlsValue::create<_mls_Float>(0.361), _mlsValue::create<_mls_Float>(0.753));
      auto _mls_x1603 = _mls_is_zerovector(_mls_x1539);
      if (_mlsValue::isIntLit(_mls_x1603, 1)) {
        _mls_x740 = _mls_x1541;
        goto _mls_j_case0;
      } else {
        _mls_x741 = _mls_x1602;
        _mls_x742 = _mls_x1545;
        _mls_x743 = _mls_x1541;
        goto _mls_j_default1;
      }
    }
    return _mls_retval;
  }
  _mls_j2:
  {
    auto _mls_x746 = _mls_is_zerovector(_mls_x745);
    if (_mlsValue::isIntLit(_mls_x746, 1)) {
      _mls_x740 = _mls_x749;
      goto _mls_j_case0;
    } else {
      _mls_x741 = _mls_x747;
      _mls_x742 = _mls_x748;
      _mls_x743 = _mls_x749;
      goto _mls_j_default1;
    }
    return _mls_retval;
  }
  _mls_j_case0:
  {
    auto _mls_x750 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x740);
    _mls_retval = _mls_x750;
    return _mls_retval;
  }
  _mls_j_default1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x741)) {
      auto _mls_x751 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field0;
      auto _mls_x752 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field1;
      auto _mls_x753 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field2;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x742)) {
        auto _mls_x754 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field0;
        auto _mls_x755 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field1;
        auto _mls_x756 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field2;
        auto _mls_x757 = _mls_vecmult_case0_sr_post_case0_sr_post(_mls_x756, _mls_x752, _mls_x755, _mls_x753, _mls_x751, _mls_x754);
        auto _mls_x758 = _mls_vecadd_case0(_mls_x757, _mls_x743);
        _mls_x744 = _mls_x758;
        goto _mls_j_caller_post_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post_post:
  {
    auto _mls_x759 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x744);
    _mls_retval = _mls_x759;
    return _mls_retval;
  }
}
_mlsValue _mls_transmitray_caller_post_case0_sr_post(_mlsValue _mls_x1511, _mlsValue _mls_x1512, _mlsValue _mls_x1513, _mlsValue _mls_x1514, _mlsValue _mls_x1515, _mlsValue _mls_x1516) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1517, _mls_x1518, _mls_x1519, _mls_x1520, _mls_x1521, _mls_x1522, _mls_x1523;
  _mlsValue _mls_x1524, _mls_x1525, _mls_x1526, _mls_x1527, _mls_x1528, _mls_x1529;
  _mlsValue _mls_x1530, _mls_x1531, _mls_x1532, _mls_x1533, _mls_x1534, _mls_x1535, _mls_x1536;
  _mlsValue _mls_x1537, _mls_x1538, _mls_x1539, _mls_x1540, _mls_x1541, _mls_x1542, _mls_x1543, _mls_x1544, _mls_x1545;
  _mlsValue _mls_x745, _mls_x747, _mls_x748, _mls_x749;
  _mlsValue _mls_x740;
  _mlsValue _mls_x741, _mls_x742, _mls_x743;
  _mlsValue _mls_x744;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1515)) {
    auto _mls_x1579 = _mlsValue::cast<_mls_Tuple3>(_mls_x1515)->_mls_field0;
    auto _mls_x1580 = _mlsValue::cast<_mls_Tuple3>(_mls_x1515)->_mls_field1;
    auto _mls_x1581 = _mlsValue::cast<_mls_Tuple3>(_mls_x1515)->_mls_field2;
    auto _mls_x1582 = _mls_vecscale_case0_sr_post(_mlsValue::create<_mls_Float>(1.0E-6), _mls_x1579, _mls_x1580, _mls_x1581);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1511)) {
      _mls_x1517 = _mls_x1513;
      _mls_x1518 = _mls_x1515;
      _mls_x1519 = _mls_x1582;
      _mls_x1520 = _mls_x1511;
      _mls_x1521 = _mls_x1512;
      _mls_x1522 = _mls_x1514;
      _mls_x1523 = _mls_x1516;
      goto _mls_transmitray_caller_post_caller_post_case0;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_transmitray_caller_post_caller_post_case0:
  {
    auto _mls_x1583 = _mlsValue::cast<_mls_Tuple3>(_mls_x1520)->_mls_field0;
    auto _mls_x1584 = _mlsValue::cast<_mls_Tuple3>(_mls_x1520)->_mls_field1;
    auto _mls_x1585 = _mlsValue::cast<_mls_Tuple3>(_mls_x1520)->_mls_field2;
    auto _mls_x1586 = _mls_vecadd_case0_sr_post(_mls_x1519, _mls_x1583, _mls_x1584, _mls_x1585);
    _mls_x1524 = _mls_x1517;
    _mls_x1525 = _mls_x1518;
    _mls_x1526 = _mls_x1521;
    _mls_x1527 = _mls_x1522;
    _mls_x1528 = _mls_x1523;
    _mls_x1529 = _mls_x1586;
    goto _mls_transmitray_caller_post_caller_post_caller_post;
    return _mls_retval;
  }
  _mls_transmitray_caller_post_caller_post_caller_post:
  {
    auto _mls_x1587 = _mls_testspheres();
    auto [_mls_x1588, _mls_x1589, _mls_x1590] = _mls_trace_pre(_mls_x1587, _mls_x1529, _mls_x1525);
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1588)) {
      auto _mls_x1595 = _mls_trace_caller_post_case0(_mls_x1589);
      auto _mls_x1596 = _mlsValue::cast<_mls_Tuple3>(_mls_x1595)->_mls_field0;
      auto _mls_x1597 = _mlsValue::cast<_mls_Tuple3>(_mls_x1595)->_mls_field1;
      auto _mls_x1598 = _mlsValue::cast<_mls_Tuple3>(_mls_x1595)->_mls_field2;
      _mls_x1537 = _mls_x1527;
      _mls_x1538 = _mls_x1596;
      _mls_x1539 = _mls_x1524;
      _mls_x1540 = _mls_x1598;
      _mls_x1541 = _mls_x1526;
      _mls_x1542 = _mls_x1529;
      _mls_x1543 = _mls_x1597;
      _mls_x1544 = _mls_x1525;
      _mls_x1545 = _mls_x1528;
      goto _mls_transmitray_caller_post_caller_post_caller_post_case0_sr_post;
    } else {
      auto _mls_x1591 = _mls_trace_caller_post_default_pre(_mls_x1588, _mls_x1590);
      if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x1591)) {
        auto _mls_x1592 = _mlsValue::cast<_mls_Tuple2>(_mls_x1591)->_mls_field0;
        auto _mls_x1593 = _mlsValue::cast<_mls_Tuple2>(_mls_x1591)->_mls_field1;
        auto _mls_x1594 = _mls_trace_caller_post_default_case0_sr_post(_mls_x1592, _mls_x1593);
        _mls_x1530 = _mls_x1524;
        _mls_x1531 = _mls_x1594;
        _mls_x1532 = _mls_x1525;
        _mls_x1533 = _mls_x1526;
        _mls_x1534 = _mls_x1527;
        _mls_x1535 = _mls_x1528;
        _mls_x1536 = _mls_x1529;
        goto _mls_transmitray_caller_post_caller_post_caller_post1;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    }
    return _mls_retval;
  }
  _mls_transmitray_caller_post_caller_post_caller_post1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1531)) {
      auto _mls_x1599 = _mlsValue::cast<_mls_Tuple3>(_mls_x1531)->_mls_field0;
      auto _mls_x1600 = _mlsValue::cast<_mls_Tuple3>(_mls_x1531)->_mls_field1;
      auto _mls_x1601 = _mlsValue::cast<_mls_Tuple3>(_mls_x1531)->_mls_field2;
      _mls_x1537 = _mls_x1534;
      _mls_x1538 = _mls_x1599;
      _mls_x1539 = _mls_x1530;
      _mls_x1540 = _mls_x1601;
      _mls_x1541 = _mls_x1533;
      _mls_x1542 = _mls_x1536;
      _mls_x1543 = _mls_x1600;
      _mls_x1544 = _mls_x1532;
      _mls_x1545 = _mls_x1535;
      goto _mls_transmitray_caller_post_caller_post_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_transmitray_caller_post_caller_post_caller_post_case0_sr_post:
  {
    if (_mlsValue::isIntLit(_mls_x1538, 1)) {
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1544)) {
        auto _mls_x1604 = _mls_shade_case0(_mls_x1542, _mls_x1540, _mls_x1539, _mls_x1537, _mls_x1543, _mls_x1544);
        _mls_x745 = _mls_x1539;
        _mls_x747 = _mls_x1604;
        _mls_x748 = _mls_x1545;
        _mls_x749 = _mls_x1541;
        goto _mls_j2;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      auto _mls_x1602 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.078), _mlsValue::create<_mls_Float>(0.361), _mlsValue::create<_mls_Float>(0.753));
      auto _mls_x1603 = _mls_is_zerovector(_mls_x1539);
      if (_mlsValue::isIntLit(_mls_x1603, 1)) {
        _mls_x740 = _mls_x1541;
        goto _mls_j_case0;
      } else {
        _mls_x741 = _mls_x1602;
        _mls_x742 = _mls_x1545;
        _mls_x743 = _mls_x1541;
        goto _mls_j_default1;
      }
    }
    return _mls_retval;
  }
  _mls_j2:
  {
    auto _mls_x746 = _mls_is_zerovector(_mls_x745);
    if (_mlsValue::isIntLit(_mls_x746, 1)) {
      _mls_x740 = _mls_x749;
      goto _mls_j_case0;
    } else {
      _mls_x741 = _mls_x747;
      _mls_x742 = _mls_x748;
      _mls_x743 = _mls_x749;
      goto _mls_j_default1;
    }
    return _mls_retval;
  }
  _mls_j_case0:
  {
    auto _mls_x750 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x740);
    _mls_retval = _mls_x750;
    return _mls_retval;
  }
  _mls_j_default1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x741)) {
      auto _mls_x751 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field0;
      auto _mls_x752 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field1;
      auto _mls_x753 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field2;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x742)) {
        auto _mls_x754 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field0;
        auto _mls_x755 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field1;
        auto _mls_x756 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field2;
        auto _mls_x757 = _mls_vecmult_case0_sr_post_case0_sr_post(_mls_x756, _mls_x752, _mls_x755, _mls_x753, _mls_x751, _mls_x754);
        auto _mls_x758 = _mls_vecadd_case0(_mls_x757, _mls_x743);
        _mls_x744 = _mls_x758;
        goto _mls_j_caller_post_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post_post:
  {
    auto _mls_x759 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x744);
    _mls_retval = _mls_x759;
    return _mls_retval;
  }
}
_mlsValue _mls_transmitray_caller_post_default(_mlsValue _mls_x1496, _mlsValue _mls_x1497, _mlsValue _mls_x1498, _mlsValue _mls_x1499, _mlsValue _mls_x1500, _mlsValue _mls_x1501, _mlsValue _mls_x1502, _mlsValue _mls_x1503, _mlsValue _mls_x1504) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1505, _mls_x1506, _mls_x1507, _mls_x1508, _mls_x1509, _mls_x1510;
  _mlsValue _mls_x1511, _mls_x1512, _mls_x1513, _mls_x1514, _mls_x1515, _mls_x1516;
  _mlsValue _mls_x1517, _mls_x1518, _mls_x1519, _mls_x1520, _mls_x1521, _mls_x1522, _mls_x1523;
  _mlsValue _mls_x1524, _mls_x1525, _mls_x1526, _mls_x1527, _mls_x1528, _mls_x1529;
  _mlsValue _mls_x1530, _mls_x1531, _mls_x1532, _mls_x1533, _mls_x1534, _mls_x1535, _mls_x1536;
  _mlsValue _mls_x1537, _mls_x1538, _mls_x1539, _mls_x1540, _mls_x1541, _mls_x1542, _mls_x1543, _mls_x1544, _mls_x1545;
  _mlsValue _mls_x745, _mls_x747, _mls_x748, _mls_x749;
  _mlsValue _mls_x740;
  _mlsValue _mls_x741, _mls_x742, _mls_x743;
  _mlsValue _mls_x744;
  auto [_mls_x1567, _mls_x1568, _mls_x1569, _mls_x1570, _mls_x1571] = _mls_j_case0_sr_post_pre(_mls_x1503, _mls_x1501, _mls_x1497, _mls_x1499);
  if (_mlsValue::isIntLit(_mls_x1569, 1)) {
    auto _mls_x1576 = _mls_j_case0_sr_post_case0();
    auto _mls_x1577 = _mlsValue::cast<_mls_Tuple2>(_mls_x1576)->_mls_field1;
    _mls_x1511 = _mls_x1504;
    _mls_x1512 = _mls_x1500;
    _mls_x1513 = _mls_x1498;
    _mls_x1514 = _mls_x1496;
    _mls_x1515 = _mls_x1577;
    _mls_x1516 = _mls_x1502;
    goto _mls_transmitray_caller_post_case0_sr_post;
  } else {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1571)) {
      auto _mls_x1572 = _mlsValue::cast<_mls_Tuple3>(_mls_x1571)->_mls_field0;
      auto _mls_x1573 = _mlsValue::cast<_mls_Tuple3>(_mls_x1571)->_mls_field1;
      auto _mls_x1574 = _mlsValue::cast<_mls_Tuple3>(_mls_x1571)->_mls_field2;
      auto _mls_x1575 = _mls_j_case0_sr_post_default_case0_sr_post(_mls_x1567, _mls_x1574, _mls_x1570, _mls_x1568, _mls_x1572, _mls_x1573);
      _mls_x1505 = _mls_x1504;
      _mls_x1506 = _mls_x1498;
      _mls_x1507 = _mls_x1496;
      _mls_x1508 = _mls_x1502;
      _mls_x1509 = _mls_x1575;
      _mls_x1510 = _mls_x1500;
      goto _mls_transmitray_caller_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  }
  return _mls_retval;
  _mls_transmitray_caller_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x1509)) {
      auto _mls_x1578 = _mlsValue::cast<_mls_Tuple2>(_mls_x1509)->_mls_field1;
      _mls_x1511 = _mls_x1505;
      _mls_x1512 = _mls_x1510;
      _mls_x1513 = _mls_x1506;
      _mls_x1514 = _mls_x1507;
      _mls_x1515 = _mls_x1578;
      _mls_x1516 = _mls_x1508;
      goto _mls_transmitray_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_transmitray_caller_post_case0_sr_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1515)) {
      auto _mls_x1579 = _mlsValue::cast<_mls_Tuple3>(_mls_x1515)->_mls_field0;
      auto _mls_x1580 = _mlsValue::cast<_mls_Tuple3>(_mls_x1515)->_mls_field1;
      auto _mls_x1581 = _mlsValue::cast<_mls_Tuple3>(_mls_x1515)->_mls_field2;
      auto _mls_x1582 = _mls_vecscale_case0_sr_post(_mlsValue::create<_mls_Float>(1.0E-6), _mls_x1579, _mls_x1580, _mls_x1581);
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1511)) {
        _mls_x1517 = _mls_x1513;
        _mls_x1518 = _mls_x1515;
        _mls_x1519 = _mls_x1582;
        _mls_x1520 = _mls_x1511;
        _mls_x1521 = _mls_x1512;
        _mls_x1522 = _mls_x1514;
        _mls_x1523 = _mls_x1516;
        goto _mls_transmitray_caller_post_caller_post_case0;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_transmitray_caller_post_caller_post_case0:
  {
    auto _mls_x1583 = _mlsValue::cast<_mls_Tuple3>(_mls_x1520)->_mls_field0;
    auto _mls_x1584 = _mlsValue::cast<_mls_Tuple3>(_mls_x1520)->_mls_field1;
    auto _mls_x1585 = _mlsValue::cast<_mls_Tuple3>(_mls_x1520)->_mls_field2;
    auto _mls_x1586 = _mls_vecadd_case0_sr_post(_mls_x1519, _mls_x1583, _mls_x1584, _mls_x1585);
    _mls_x1524 = _mls_x1517;
    _mls_x1525 = _mls_x1518;
    _mls_x1526 = _mls_x1521;
    _mls_x1527 = _mls_x1522;
    _mls_x1528 = _mls_x1523;
    _mls_x1529 = _mls_x1586;
    goto _mls_transmitray_caller_post_caller_post_caller_post;
    return _mls_retval;
  }
  _mls_transmitray_caller_post_caller_post_caller_post:
  {
    auto _mls_x1587 = _mls_testspheres();
    auto [_mls_x1588, _mls_x1589, _mls_x1590] = _mls_trace_pre(_mls_x1587, _mls_x1529, _mls_x1525);
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1588)) {
      auto _mls_x1595 = _mls_trace_caller_post_case0(_mls_x1589);
      auto _mls_x1596 = _mlsValue::cast<_mls_Tuple3>(_mls_x1595)->_mls_field0;
      auto _mls_x1597 = _mlsValue::cast<_mls_Tuple3>(_mls_x1595)->_mls_field1;
      auto _mls_x1598 = _mlsValue::cast<_mls_Tuple3>(_mls_x1595)->_mls_field2;
      _mls_x1537 = _mls_x1527;
      _mls_x1538 = _mls_x1596;
      _mls_x1539 = _mls_x1524;
      _mls_x1540 = _mls_x1598;
      _mls_x1541 = _mls_x1526;
      _mls_x1542 = _mls_x1529;
      _mls_x1543 = _mls_x1597;
      _mls_x1544 = _mls_x1525;
      _mls_x1545 = _mls_x1528;
      goto _mls_transmitray_caller_post_caller_post_caller_post_case0_sr_post;
    } else {
      auto _mls_x1591 = _mls_trace_caller_post_default_pre(_mls_x1588, _mls_x1590);
      if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x1591)) {
        auto _mls_x1592 = _mlsValue::cast<_mls_Tuple2>(_mls_x1591)->_mls_field0;
        auto _mls_x1593 = _mlsValue::cast<_mls_Tuple2>(_mls_x1591)->_mls_field1;
        auto _mls_x1594 = _mls_trace_caller_post_default_case0_sr_post(_mls_x1592, _mls_x1593);
        _mls_x1530 = _mls_x1524;
        _mls_x1531 = _mls_x1594;
        _mls_x1532 = _mls_x1525;
        _mls_x1533 = _mls_x1526;
        _mls_x1534 = _mls_x1527;
        _mls_x1535 = _mls_x1528;
        _mls_x1536 = _mls_x1529;
        goto _mls_transmitray_caller_post_caller_post_caller_post1;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    }
    return _mls_retval;
  }
  _mls_transmitray_caller_post_caller_post_caller_post1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1531)) {
      auto _mls_x1599 = _mlsValue::cast<_mls_Tuple3>(_mls_x1531)->_mls_field0;
      auto _mls_x1600 = _mlsValue::cast<_mls_Tuple3>(_mls_x1531)->_mls_field1;
      auto _mls_x1601 = _mlsValue::cast<_mls_Tuple3>(_mls_x1531)->_mls_field2;
      _mls_x1537 = _mls_x1534;
      _mls_x1538 = _mls_x1599;
      _mls_x1539 = _mls_x1530;
      _mls_x1540 = _mls_x1601;
      _mls_x1541 = _mls_x1533;
      _mls_x1542 = _mls_x1536;
      _mls_x1543 = _mls_x1600;
      _mls_x1544 = _mls_x1532;
      _mls_x1545 = _mls_x1535;
      goto _mls_transmitray_caller_post_caller_post_caller_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_transmitray_caller_post_caller_post_caller_post_case0_sr_post:
  {
    if (_mlsValue::isIntLit(_mls_x1538, 1)) {
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1544)) {
        auto _mls_x1604 = _mls_shade_case0(_mls_x1542, _mls_x1540, _mls_x1539, _mls_x1537, _mls_x1543, _mls_x1544);
        _mls_x745 = _mls_x1539;
        _mls_x747 = _mls_x1604;
        _mls_x748 = _mls_x1545;
        _mls_x749 = _mls_x1541;
        goto _mls_j2;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      auto _mls_x1602 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.078), _mlsValue::create<_mls_Float>(0.361), _mlsValue::create<_mls_Float>(0.753));
      auto _mls_x1603 = _mls_is_zerovector(_mls_x1539);
      if (_mlsValue::isIntLit(_mls_x1603, 1)) {
        _mls_x740 = _mls_x1541;
        goto _mls_j_case0;
      } else {
        _mls_x741 = _mls_x1602;
        _mls_x742 = _mls_x1545;
        _mls_x743 = _mls_x1541;
        goto _mls_j_default1;
      }
    }
    return _mls_retval;
  }
  _mls_j2:
  {
    auto _mls_x746 = _mls_is_zerovector(_mls_x745);
    if (_mlsValue::isIntLit(_mls_x746, 1)) {
      _mls_x740 = _mls_x749;
      goto _mls_j_case0;
    } else {
      _mls_x741 = _mls_x747;
      _mls_x742 = _mls_x748;
      _mls_x743 = _mls_x749;
      goto _mls_j_default1;
    }
    return _mls_retval;
  }
  _mls_j_case0:
  {
    auto _mls_x750 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x740);
    _mls_retval = _mls_x750;
    return _mls_retval;
  }
  _mls_j_default1:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x741)) {
      auto _mls_x751 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field0;
      auto _mls_x752 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field1;
      auto _mls_x753 = _mlsValue::cast<_mls_Tuple3>(_mls_x741)->_mls_field2;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x742)) {
        auto _mls_x754 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field0;
        auto _mls_x755 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field1;
        auto _mls_x756 = _mlsValue::cast<_mls_Tuple3>(_mls_x742)->_mls_field2;
        auto _mls_x757 = _mls_vecmult_case0_sr_post_case0_sr_post(_mls_x756, _mls_x752, _mls_x755, _mls_x753, _mls_x751, _mls_x754);
        auto _mls_x758 = _mls_vecadd_case0(_mls_x757, _mls_x743);
        _mls_x744 = _mls_x758;
        goto _mls_j_caller_post_post;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_j_caller_post_post:
  {
    auto _mls_x759 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x744);
    _mls_retval = _mls_x759;
    return _mls_retval;
  }
}
_mlsValue _mls_transmitsurf(_mlsValue _mls_ss7) {
  _mlsValue _mls_retval;
  auto _mls_x495 = _mlsValue::create<_mls_Lambda_lscomp>();
  auto _mls_x496 = _mlsMethodCall<_mls_Callable>(_mls_x495)->_mls_apply1(_mls_ss7);
  auto _mls_x497 = _mlsValue::create<_mls_Nil>();
  auto _mls_x498 = _mlsValue::create<_mls_Cons>(_mlsValue::create<_mls_Float>(0.0), _mls_x497);
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x496)) {
    _mls_retval = _mlsValue::create<_mls_Float>(0.0);
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x496)) {
    auto _mls_x1605 = _mlsValue::cast<_mls_Cons>(_mls_x496)->_mls_head;
    auto _mls_x1606 = _mlsValue::cast<_mls_Cons>(_mls_x496)->_mls_tail;
    auto _mls_x1607 = _mls_append_case1_sr_post(_mls_x1606, _mls_x498, _mls_x1605);
    auto _mls_x1608 = _mlsValue::cast<_mls_Cons>(_mls_x1607)->_mls_head;
    _mls_retval = _mls_x1608;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_vecadd(_mlsValue _mls_x1625, _mlsValue _mls_x1626) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1609, _mls_x1610;
  _mlsValue _mls_x1611, _mls_x1612, _mls_x1613, _mls_x1614;
  _mlsValue _mls_x1615, _mls_x1616, _mls_x1617, _mls_x1618;
  _mlsValue _mls_x1619, _mls_x1620, _mls_x1621, _mls_x1622, _mls_x1623, _mls_x1624;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1625)) {
    _mls_x1609 = _mls_x1625;
    _mls_x1610 = _mls_x1626;
    goto _mls_vecadd_case0;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_vecadd_case0:
  {
    auto _mls_x1627 = _mlsValue::cast<_mls_Tuple3>(_mls_x1609)->_mls_field0;
    auto _mls_x1628 = _mlsValue::cast<_mls_Tuple3>(_mls_x1609)->_mls_field1;
    auto _mls_x1629 = _mlsValue::cast<_mls_Tuple3>(_mls_x1609)->_mls_field2;
    _mls_x1611 = _mls_x1610;
    _mls_x1612 = _mls_x1627;
    _mls_x1613 = _mls_x1628;
    _mls_x1614 = _mls_x1629;
    goto _mls_vecadd_case0_sr_post;
    return _mls_retval;
  }
  _mls_vecadd_case0_sr_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1611)) {
      _mls_x1615 = _mls_x1611;
      _mls_x1616 = _mls_x1612;
      _mls_x1617 = _mls_x1613;
      _mls_x1618 = _mls_x1614;
      goto _mls_vecadd_case0_sr_post_case0;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_vecadd_case0_sr_post_case0:
  {
    auto _mls_x1630 = _mlsValue::cast<_mls_Tuple3>(_mls_x1615)->_mls_field0;
    auto _mls_x1631 = _mlsValue::cast<_mls_Tuple3>(_mls_x1615)->_mls_field1;
    auto _mls_x1632 = _mlsValue::cast<_mls_Tuple3>(_mls_x1615)->_mls_field2;
    _mls_x1619 = _mls_x1616;
    _mls_x1620 = _mls_x1618;
    _mls_x1621 = _mls_x1630;
    _mls_x1622 = _mls_x1632;
    _mls_x1623 = _mls_x1617;
    _mls_x1624 = _mls_x1631;
    goto _mls_vecadd_case0_sr_post_case0_sr_post;
    return _mls_retval;
  }
  _mls_vecadd_case0_sr_post_case0_sr_post:
  {
    auto _mls_x1633 = (_mls_x1619 + _mls_x1621);
    auto _mls_x1634 = (_mls_x1623 + _mls_x1624);
    auto _mls_x1635 = (_mls_x1620 + _mls_x1622);
    auto _mls_x1636 = _mlsValue::create<_mls_Tuple3>(_mls_x1633, _mls_x1634, _mls_x1635);
    _mls_retval = _mls_x1636;
    return _mls_retval;
  }
}
_mlsValue _mls_vecadd_case0(_mlsValue _mls_x1609, _mlsValue _mls_x1610) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1611, _mls_x1612, _mls_x1613, _mls_x1614;
  _mlsValue _mls_x1615, _mls_x1616, _mls_x1617, _mls_x1618;
  _mlsValue _mls_x1619, _mls_x1620, _mls_x1621, _mls_x1622, _mls_x1623, _mls_x1624;
  auto _mls_x1627 = _mlsValue::cast<_mls_Tuple3>(_mls_x1609)->_mls_field0;
  auto _mls_x1628 = _mlsValue::cast<_mls_Tuple3>(_mls_x1609)->_mls_field1;
  auto _mls_x1629 = _mlsValue::cast<_mls_Tuple3>(_mls_x1609)->_mls_field2;
  _mls_x1611 = _mls_x1610;
  _mls_x1612 = _mls_x1627;
  _mls_x1613 = _mls_x1628;
  _mls_x1614 = _mls_x1629;
  goto _mls_vecadd_case0_sr_post;
  return _mls_retval;
  _mls_vecadd_case0_sr_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1611)) {
      _mls_x1615 = _mls_x1611;
      _mls_x1616 = _mls_x1612;
      _mls_x1617 = _mls_x1613;
      _mls_x1618 = _mls_x1614;
      goto _mls_vecadd_case0_sr_post_case0;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_vecadd_case0_sr_post_case0:
  {
    auto _mls_x1630 = _mlsValue::cast<_mls_Tuple3>(_mls_x1615)->_mls_field0;
    auto _mls_x1631 = _mlsValue::cast<_mls_Tuple3>(_mls_x1615)->_mls_field1;
    auto _mls_x1632 = _mlsValue::cast<_mls_Tuple3>(_mls_x1615)->_mls_field2;
    _mls_x1619 = _mls_x1616;
    _mls_x1620 = _mls_x1618;
    _mls_x1621 = _mls_x1630;
    _mls_x1622 = _mls_x1632;
    _mls_x1623 = _mls_x1617;
    _mls_x1624 = _mls_x1631;
    goto _mls_vecadd_case0_sr_post_case0_sr_post;
    return _mls_retval;
  }
  _mls_vecadd_case0_sr_post_case0_sr_post:
  {
    auto _mls_x1633 = (_mls_x1619 + _mls_x1621);
    auto _mls_x1634 = (_mls_x1623 + _mls_x1624);
    auto _mls_x1635 = (_mls_x1620 + _mls_x1622);
    auto _mls_x1636 = _mlsValue::create<_mls_Tuple3>(_mls_x1633, _mls_x1634, _mls_x1635);
    _mls_retval = _mls_x1636;
    return _mls_retval;
  }
}
_mlsValue _mls_vecadd_case0_sr_post(_mlsValue _mls_x1611, _mlsValue _mls_x1612, _mlsValue _mls_x1613, _mlsValue _mls_x1614) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1615, _mls_x1616, _mls_x1617, _mls_x1618;
  _mlsValue _mls_x1619, _mls_x1620, _mls_x1621, _mls_x1622, _mls_x1623, _mls_x1624;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1611)) {
    _mls_x1615 = _mls_x1611;
    _mls_x1616 = _mls_x1612;
    _mls_x1617 = _mls_x1613;
    _mls_x1618 = _mls_x1614;
    goto _mls_vecadd_case0_sr_post_case0;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_vecadd_case0_sr_post_case0:
  {
    auto _mls_x1630 = _mlsValue::cast<_mls_Tuple3>(_mls_x1615)->_mls_field0;
    auto _mls_x1631 = _mlsValue::cast<_mls_Tuple3>(_mls_x1615)->_mls_field1;
    auto _mls_x1632 = _mlsValue::cast<_mls_Tuple3>(_mls_x1615)->_mls_field2;
    _mls_x1619 = _mls_x1616;
    _mls_x1620 = _mls_x1618;
    _mls_x1621 = _mls_x1630;
    _mls_x1622 = _mls_x1632;
    _mls_x1623 = _mls_x1617;
    _mls_x1624 = _mls_x1631;
    goto _mls_vecadd_case0_sr_post_case0_sr_post;
    return _mls_retval;
  }
  _mls_vecadd_case0_sr_post_case0_sr_post:
  {
    auto _mls_x1633 = (_mls_x1619 + _mls_x1621);
    auto _mls_x1634 = (_mls_x1623 + _mls_x1624);
    auto _mls_x1635 = (_mls_x1620 + _mls_x1622);
    auto _mls_x1636 = _mlsValue::create<_mls_Tuple3>(_mls_x1633, _mls_x1634, _mls_x1635);
    _mls_retval = _mls_x1636;
    return _mls_retval;
  }
}
_mlsValue _mls_vecadd_case0_sr_post_case0(_mlsValue _mls_x1615, _mlsValue _mls_x1616, _mlsValue _mls_x1617, _mlsValue _mls_x1618) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1619, _mls_x1620, _mls_x1621, _mls_x1622, _mls_x1623, _mls_x1624;
  auto _mls_x1630 = _mlsValue::cast<_mls_Tuple3>(_mls_x1615)->_mls_field0;
  auto _mls_x1631 = _mlsValue::cast<_mls_Tuple3>(_mls_x1615)->_mls_field1;
  auto _mls_x1632 = _mlsValue::cast<_mls_Tuple3>(_mls_x1615)->_mls_field2;
  _mls_x1619 = _mls_x1616;
  _mls_x1620 = _mls_x1618;
  _mls_x1621 = _mls_x1630;
  _mls_x1622 = _mls_x1632;
  _mls_x1623 = _mls_x1617;
  _mls_x1624 = _mls_x1631;
  goto _mls_vecadd_case0_sr_post_case0_sr_post;
  return _mls_retval;
  _mls_vecadd_case0_sr_post_case0_sr_post:
  {
    auto _mls_x1633 = (_mls_x1619 + _mls_x1621);
    auto _mls_x1634 = (_mls_x1623 + _mls_x1624);
    auto _mls_x1635 = (_mls_x1620 + _mls_x1622);
    auto _mls_x1636 = _mlsValue::create<_mls_Tuple3>(_mls_x1633, _mls_x1634, _mls_x1635);
    _mls_retval = _mls_x1636;
    return _mls_retval;
  }
}
_mlsValue _mls_vecadd_case0_sr_post_case0_sr_post(_mlsValue _mls_x1619, _mlsValue _mls_x1620, _mlsValue _mls_x1621, _mlsValue _mls_x1622, _mlsValue _mls_x1623, _mlsValue _mls_x1624) {
  _mlsValue _mls_retval;
  auto _mls_x1633 = (_mls_x1619 + _mls_x1621);
  auto _mls_x1634 = (_mls_x1623 + _mls_x1624);
  auto _mls_x1635 = (_mls_x1620 + _mls_x1622);
  auto _mls_x1636 = _mlsValue::create<_mls_Tuple3>(_mls_x1633, _mls_x1634, _mls_x1635);
  _mls_retval = _mls_x1636;
  return _mls_retval;
}
_mlsValue _mls_veccross_case0(_mlsValue _mls_x1648, _mlsValue _mls_x1651) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1637, _mls_x1638, _mls_x1639, _mls_x1640;
  _mlsValue _mls_x1641, _mls_x1642, _mls_x1643, _mls_x1644, _mls_x1645, _mls_x1646;
  auto _mls_x1647 = _mlsValue::cast<_mls_Tuple3>(_mls_x1648)->_mls_field0;
  auto _mls_x1649 = _mlsValue::cast<_mls_Tuple3>(_mls_x1648)->_mls_field1;
  auto _mls_x1650 = _mlsValue::cast<_mls_Tuple3>(_mls_x1648)->_mls_field2;
  _mls_x1637 = _mls_x1651;
  _mls_x1638 = _mls_x1649;
  _mls_x1639 = _mls_x1650;
  _mls_x1640 = _mls_x1647;
  goto _mls_veccross_case0_sr_post;
  return _mls_retval;
  _mls_veccross_case0_sr_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1637)) {
      auto _mls_x1652 = _mlsValue::cast<_mls_Tuple3>(_mls_x1637)->_mls_field0;
      auto _mls_x1653 = _mlsValue::cast<_mls_Tuple3>(_mls_x1637)->_mls_field1;
      auto _mls_x1654 = _mlsValue::cast<_mls_Tuple3>(_mls_x1637)->_mls_field2;
      _mls_x1641 = _mls_x1638;
      _mls_x1642 = _mls_x1640;
      _mls_x1643 = _mls_x1639;
      _mls_x1644 = _mls_x1654;
      _mls_x1645 = _mls_x1652;
      _mls_x1646 = _mls_x1653;
      goto _mls_veccross_case0_sr_post_case0_sr_post;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_veccross_case0_sr_post_case0_sr_post:
  {
    auto _mls_x1655 = (_mls_x1641 * _mls_x1644);
    auto _mls_x1656 = (_mls_x1646 * _mls_x1643);
    auto _mls_x1657 = (_mls_x1655 - _mls_x1656);
    auto _mls_x1658 = (_mls_x1643 * _mls_x1645);
    auto _mls_x1659 = (_mls_x1644 * _mls_x1642);
    auto _mls_x1660 = (_mls_x1658 - _mls_x1659);
    auto _mls_x1661 = (_mls_x1642 * _mls_x1646);
    auto _mls_x1662 = (_mls_x1645 * _mls_x1641);
    auto _mls_x1663 = (_mls_x1661 - _mls_x1662);
    auto _mls_x1664 = _mlsValue::create<_mls_Tuple3>(_mls_x1657, _mls_x1660, _mls_x1663);
    _mls_retval = _mls_x1664;
    return _mls_retval;
  }
}
_mlsValue _mls_veccross_case0_sr_post(_mlsValue _mls_x1637, _mlsValue _mls_x1638, _mlsValue _mls_x1639, _mlsValue _mls_x1640) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1641, _mls_x1642, _mls_x1643, _mls_x1644, _mls_x1645, _mls_x1646;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1637)) {
    auto _mls_x1652 = _mlsValue::cast<_mls_Tuple3>(_mls_x1637)->_mls_field0;
    auto _mls_x1653 = _mlsValue::cast<_mls_Tuple3>(_mls_x1637)->_mls_field1;
    auto _mls_x1654 = _mlsValue::cast<_mls_Tuple3>(_mls_x1637)->_mls_field2;
    _mls_x1641 = _mls_x1638;
    _mls_x1642 = _mls_x1640;
    _mls_x1643 = _mls_x1639;
    _mls_x1644 = _mls_x1654;
    _mls_x1645 = _mls_x1652;
    _mls_x1646 = _mls_x1653;
    goto _mls_veccross_case0_sr_post_case0_sr_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_veccross_case0_sr_post_case0_sr_post:
  {
    auto _mls_x1655 = (_mls_x1641 * _mls_x1644);
    auto _mls_x1656 = (_mls_x1646 * _mls_x1643);
    auto _mls_x1657 = (_mls_x1655 - _mls_x1656);
    auto _mls_x1658 = (_mls_x1643 * _mls_x1645);
    auto _mls_x1659 = (_mls_x1644 * _mls_x1642);
    auto _mls_x1660 = (_mls_x1658 - _mls_x1659);
    auto _mls_x1661 = (_mls_x1642 * _mls_x1646);
    auto _mls_x1662 = (_mls_x1645 * _mls_x1641);
    auto _mls_x1663 = (_mls_x1661 - _mls_x1662);
    auto _mls_x1664 = _mlsValue::create<_mls_Tuple3>(_mls_x1657, _mls_x1660, _mls_x1663);
    _mls_retval = _mls_x1664;
    return _mls_retval;
  }
}
_mlsValue _mls_veccross_case0_sr_post_case0_sr_post(_mlsValue _mls_x1641, _mlsValue _mls_x1642, _mlsValue _mls_x1643, _mlsValue _mls_x1644, _mlsValue _mls_x1645, _mlsValue _mls_x1646) {
  _mlsValue _mls_retval;
  auto _mls_x1655 = (_mls_x1641 * _mls_x1644);
  auto _mls_x1656 = (_mls_x1646 * _mls_x1643);
  auto _mls_x1657 = (_mls_x1655 - _mls_x1656);
  auto _mls_x1658 = (_mls_x1643 * _mls_x1645);
  auto _mls_x1659 = (_mls_x1644 * _mls_x1642);
  auto _mls_x1660 = (_mls_x1658 - _mls_x1659);
  auto _mls_x1661 = (_mls_x1642 * _mls_x1646);
  auto _mls_x1662 = (_mls_x1645 * _mls_x1641);
  auto _mls_x1663 = (_mls_x1661 - _mls_x1662);
  auto _mls_x1664 = _mlsValue::create<_mls_Tuple3>(_mls_x1657, _mls_x1660, _mls_x1663);
  _mls_retval = _mls_x1664;
  return _mls_retval;
}
_mlsValue _mls_vecdot(_mlsValue _mls_x1669, _mlsValue _mls_x1673) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1665, _mls_x1666, _mls_x1667, _mls_x1668;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1669)) {
    auto _mls_x1670 = _mlsValue::cast<_mls_Tuple3>(_mls_x1669)->_mls_field0;
    auto _mls_x1671 = _mlsValue::cast<_mls_Tuple3>(_mls_x1669)->_mls_field1;
    auto _mls_x1672 = _mlsValue::cast<_mls_Tuple3>(_mls_x1669)->_mls_field2;
    _mls_x1665 = _mls_x1673;
    _mls_x1666 = _mls_x1670;
    _mls_x1667 = _mls_x1671;
    _mls_x1668 = _mls_x1672;
    goto _mls_vecdot_case0_sr_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_vecdot_case0_sr_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1665)) {
      auto _mls_x1674 = _mlsValue::cast<_mls_Tuple3>(_mls_x1665)->_mls_field0;
      auto _mls_x1675 = _mlsValue::cast<_mls_Tuple3>(_mls_x1665)->_mls_field1;
      auto _mls_x1676 = _mlsValue::cast<_mls_Tuple3>(_mls_x1665)->_mls_field2;
      auto _mls_x1677 = (_mls_x1666 * _mls_x1674);
      auto _mls_x1678 = (_mls_x1667 * _mls_x1675);
      auto _mls_x1679 = (_mls_x1677 + _mls_x1678);
      auto _mls_x1680 = (_mls_x1668 * _mls_x1676);
      auto _mls_x1681 = (_mls_x1679 + _mls_x1680);
      _mls_retval = _mls_x1681;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_vecdot_case0(_mlsValue _mls_x1683, _mlsValue _mls_x1686) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1665, _mls_x1666, _mls_x1667, _mls_x1668;
  auto _mls_x1682 = _mlsValue::cast<_mls_Tuple3>(_mls_x1683)->_mls_field0;
  auto _mls_x1684 = _mlsValue::cast<_mls_Tuple3>(_mls_x1683)->_mls_field1;
  auto _mls_x1685 = _mlsValue::cast<_mls_Tuple3>(_mls_x1683)->_mls_field2;
  _mls_x1665 = _mls_x1686;
  _mls_x1666 = _mls_x1682;
  _mls_x1667 = _mls_x1684;
  _mls_x1668 = _mls_x1685;
  goto _mls_vecdot_case0_sr_post;
  return _mls_retval;
  _mls_vecdot_case0_sr_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1665)) {
      auto _mls_x1674 = _mlsValue::cast<_mls_Tuple3>(_mls_x1665)->_mls_field0;
      auto _mls_x1675 = _mlsValue::cast<_mls_Tuple3>(_mls_x1665)->_mls_field1;
      auto _mls_x1676 = _mlsValue::cast<_mls_Tuple3>(_mls_x1665)->_mls_field2;
      auto _mls_x1677 = (_mls_x1666 * _mls_x1674);
      auto _mls_x1678 = (_mls_x1667 * _mls_x1675);
      auto _mls_x1679 = (_mls_x1677 + _mls_x1678);
      auto _mls_x1680 = (_mls_x1668 * _mls_x1676);
      auto _mls_x1681 = (_mls_x1679 + _mls_x1680);
      _mls_retval = _mls_x1681;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_vecdot_case0_sr_post(_mlsValue _mls_x1665, _mlsValue _mls_x1666, _mlsValue _mls_x1667, _mlsValue _mls_x1668) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1665)) {
    auto _mls_x1674 = _mlsValue::cast<_mls_Tuple3>(_mls_x1665)->_mls_field0;
    auto _mls_x1675 = _mlsValue::cast<_mls_Tuple3>(_mls_x1665)->_mls_field1;
    auto _mls_x1676 = _mlsValue::cast<_mls_Tuple3>(_mls_x1665)->_mls_field2;
    auto _mls_x1677 = (_mls_x1666 * _mls_x1674);
    auto _mls_x1678 = (_mls_x1667 * _mls_x1675);
    auto _mls_x1679 = (_mls_x1677 + _mls_x1678);
    auto _mls_x1680 = (_mls_x1668 * _mls_x1676);
    auto _mls_x1681 = (_mls_x1679 + _mls_x1680);
    _mls_retval = _mls_x1681;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_vecmult(_mlsValue _mls_x1703, _mlsValue _mls_x1704) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1687, _mls_x1688;
  _mlsValue _mls_x1689, _mls_x1690, _mls_x1691, _mls_x1692;
  _mlsValue _mls_x1693, _mls_x1694, _mls_x1695, _mls_x1696;
  _mlsValue _mls_x1697, _mls_x1698, _mls_x1699, _mls_x1700, _mls_x1701, _mls_x1702;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1703)) {
    _mls_x1687 = _mls_x1703;
    _mls_x1688 = _mls_x1704;
    goto _mls_vecmult_case0;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_vecmult_case0:
  {
    auto _mls_x1705 = _mlsValue::cast<_mls_Tuple3>(_mls_x1687)->_mls_field0;
    auto _mls_x1706 = _mlsValue::cast<_mls_Tuple3>(_mls_x1687)->_mls_field1;
    auto _mls_x1707 = _mlsValue::cast<_mls_Tuple3>(_mls_x1687)->_mls_field2;
    _mls_x1689 = _mls_x1688;
    _mls_x1690 = _mls_x1705;
    _mls_x1691 = _mls_x1706;
    _mls_x1692 = _mls_x1707;
    goto _mls_vecmult_case0_sr_post;
    return _mls_retval;
  }
  _mls_vecmult_case0_sr_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1689)) {
      _mls_x1693 = _mls_x1689;
      _mls_x1694 = _mls_x1690;
      _mls_x1695 = _mls_x1691;
      _mls_x1696 = _mls_x1692;
      goto _mls_vecmult_case0_sr_post_case0;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_vecmult_case0_sr_post_case0:
  {
    auto _mls_x1708 = _mlsValue::cast<_mls_Tuple3>(_mls_x1693)->_mls_field0;
    auto _mls_x1709 = _mlsValue::cast<_mls_Tuple3>(_mls_x1693)->_mls_field1;
    auto _mls_x1710 = _mlsValue::cast<_mls_Tuple3>(_mls_x1693)->_mls_field2;
    _mls_x1697 = _mls_x1710;
    _mls_x1698 = _mls_x1695;
    _mls_x1699 = _mls_x1709;
    _mls_x1700 = _mls_x1696;
    _mls_x1701 = _mls_x1694;
    _mls_x1702 = _mls_x1708;
    goto _mls_vecmult_case0_sr_post_case0_sr_post;
    return _mls_retval;
  }
  _mls_vecmult_case0_sr_post_case0_sr_post:
  {
    auto _mls_x1711 = (_mls_x1701 * _mls_x1702);
    auto _mls_x1712 = (_mls_x1698 * _mls_x1699);
    auto _mls_x1713 = (_mls_x1700 * _mls_x1697);
    auto _mls_x1714 = _mlsValue::create<_mls_Tuple3>(_mls_x1711, _mls_x1712, _mls_x1713);
    _mls_retval = _mls_x1714;
    return _mls_retval;
  }
}
_mlsValue _mls_vecmult_case0(_mlsValue _mls_x1687, _mlsValue _mls_x1688) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1689, _mls_x1690, _mls_x1691, _mls_x1692;
  _mlsValue _mls_x1693, _mls_x1694, _mls_x1695, _mls_x1696;
  _mlsValue _mls_x1697, _mls_x1698, _mls_x1699, _mls_x1700, _mls_x1701, _mls_x1702;
  auto _mls_x1705 = _mlsValue::cast<_mls_Tuple3>(_mls_x1687)->_mls_field0;
  auto _mls_x1706 = _mlsValue::cast<_mls_Tuple3>(_mls_x1687)->_mls_field1;
  auto _mls_x1707 = _mlsValue::cast<_mls_Tuple3>(_mls_x1687)->_mls_field2;
  _mls_x1689 = _mls_x1688;
  _mls_x1690 = _mls_x1705;
  _mls_x1691 = _mls_x1706;
  _mls_x1692 = _mls_x1707;
  goto _mls_vecmult_case0_sr_post;
  return _mls_retval;
  _mls_vecmult_case0_sr_post:
  {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1689)) {
      _mls_x1693 = _mls_x1689;
      _mls_x1694 = _mls_x1690;
      _mls_x1695 = _mls_x1691;
      _mls_x1696 = _mls_x1692;
      goto _mls_vecmult_case0_sr_post_case0;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_vecmult_case0_sr_post_case0:
  {
    auto _mls_x1708 = _mlsValue::cast<_mls_Tuple3>(_mls_x1693)->_mls_field0;
    auto _mls_x1709 = _mlsValue::cast<_mls_Tuple3>(_mls_x1693)->_mls_field1;
    auto _mls_x1710 = _mlsValue::cast<_mls_Tuple3>(_mls_x1693)->_mls_field2;
    _mls_x1697 = _mls_x1710;
    _mls_x1698 = _mls_x1695;
    _mls_x1699 = _mls_x1709;
    _mls_x1700 = _mls_x1696;
    _mls_x1701 = _mls_x1694;
    _mls_x1702 = _mls_x1708;
    goto _mls_vecmult_case0_sr_post_case0_sr_post;
    return _mls_retval;
  }
  _mls_vecmult_case0_sr_post_case0_sr_post:
  {
    auto _mls_x1711 = (_mls_x1701 * _mls_x1702);
    auto _mls_x1712 = (_mls_x1698 * _mls_x1699);
    auto _mls_x1713 = (_mls_x1700 * _mls_x1697);
    auto _mls_x1714 = _mlsValue::create<_mls_Tuple3>(_mls_x1711, _mls_x1712, _mls_x1713);
    _mls_retval = _mls_x1714;
    return _mls_retval;
  }
}
_mlsValue _mls_vecmult_case0_sr_post(_mlsValue _mls_x1689, _mlsValue _mls_x1690, _mlsValue _mls_x1691, _mlsValue _mls_x1692) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1693, _mls_x1694, _mls_x1695, _mls_x1696;
  _mlsValue _mls_x1697, _mls_x1698, _mls_x1699, _mls_x1700, _mls_x1701, _mls_x1702;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1689)) {
    _mls_x1693 = _mls_x1689;
    _mls_x1694 = _mls_x1690;
    _mls_x1695 = _mls_x1691;
    _mls_x1696 = _mls_x1692;
    goto _mls_vecmult_case0_sr_post_case0;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_vecmult_case0_sr_post_case0:
  {
    auto _mls_x1708 = _mlsValue::cast<_mls_Tuple3>(_mls_x1693)->_mls_field0;
    auto _mls_x1709 = _mlsValue::cast<_mls_Tuple3>(_mls_x1693)->_mls_field1;
    auto _mls_x1710 = _mlsValue::cast<_mls_Tuple3>(_mls_x1693)->_mls_field2;
    _mls_x1697 = _mls_x1710;
    _mls_x1698 = _mls_x1695;
    _mls_x1699 = _mls_x1709;
    _mls_x1700 = _mls_x1696;
    _mls_x1701 = _mls_x1694;
    _mls_x1702 = _mls_x1708;
    goto _mls_vecmult_case0_sr_post_case0_sr_post;
    return _mls_retval;
  }
  _mls_vecmult_case0_sr_post_case0_sr_post:
  {
    auto _mls_x1711 = (_mls_x1701 * _mls_x1702);
    auto _mls_x1712 = (_mls_x1698 * _mls_x1699);
    auto _mls_x1713 = (_mls_x1700 * _mls_x1697);
    auto _mls_x1714 = _mlsValue::create<_mls_Tuple3>(_mls_x1711, _mls_x1712, _mls_x1713);
    _mls_retval = _mls_x1714;
    return _mls_retval;
  }
}
_mlsValue _mls_vecmult_case0_sr_post_case0(_mlsValue _mls_x1693, _mlsValue _mls_x1694, _mlsValue _mls_x1695, _mlsValue _mls_x1696) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1697, _mls_x1698, _mls_x1699, _mls_x1700, _mls_x1701, _mls_x1702;
  auto _mls_x1708 = _mlsValue::cast<_mls_Tuple3>(_mls_x1693)->_mls_field0;
  auto _mls_x1709 = _mlsValue::cast<_mls_Tuple3>(_mls_x1693)->_mls_field1;
  auto _mls_x1710 = _mlsValue::cast<_mls_Tuple3>(_mls_x1693)->_mls_field2;
  _mls_x1697 = _mls_x1710;
  _mls_x1698 = _mls_x1695;
  _mls_x1699 = _mls_x1709;
  _mls_x1700 = _mls_x1696;
  _mls_x1701 = _mls_x1694;
  _mls_x1702 = _mls_x1708;
  goto _mls_vecmult_case0_sr_post_case0_sr_post;
  return _mls_retval;
  _mls_vecmult_case0_sr_post_case0_sr_post:
  {
    auto _mls_x1711 = (_mls_x1701 * _mls_x1702);
    auto _mls_x1712 = (_mls_x1698 * _mls_x1699);
    auto _mls_x1713 = (_mls_x1700 * _mls_x1697);
    auto _mls_x1714 = _mlsValue::create<_mls_Tuple3>(_mls_x1711, _mls_x1712, _mls_x1713);
    _mls_retval = _mls_x1714;
    return _mls_retval;
  }
}
_mlsValue _mls_vecmult_case0_sr_post_case0_sr_post(_mlsValue _mls_x1697, _mlsValue _mls_x1698, _mlsValue _mls_x1699, _mlsValue _mls_x1700, _mlsValue _mls_x1701, _mlsValue _mls_x1702) {
  _mlsValue _mls_retval;
  auto _mls_x1711 = (_mls_x1701 * _mls_x1702);
  auto _mls_x1712 = (_mls_x1698 * _mls_x1699);
  auto _mls_x1713 = (_mls_x1700 * _mls_x1697);
  auto _mls_x1714 = _mlsValue::create<_mls_Tuple3>(_mls_x1711, _mls_x1712, _mls_x1713);
  _mls_retval = _mls_x1714;
  return _mls_retval;
}
_mlsValue _mls_vecnorm_case0(_mlsValue _mls_x1719) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1715, _mls_x1716, _mls_x1717;
  auto _mls_x1718 = _mlsValue::cast<_mls_Tuple3>(_mls_x1719)->_mls_field0;
  auto _mls_x1720 = _mlsValue::cast<_mls_Tuple3>(_mls_x1719)->_mls_field1;
  auto _mls_x1721 = _mlsValue::cast<_mls_Tuple3>(_mls_x1719)->_mls_field2;
  _mls_x1715 = _mls_x1718;
  _mls_x1716 = _mls_x1720;
  _mls_x1717 = _mls_x1721;
  goto _mls_vecnorm_case0_sr_post;
  return _mls_retval;
  _mls_vecnorm_case0_sr_post:
  {
    auto _mls_x1722 = (_mls_x1715 * _mls_x1715);
    auto _mls_x1723 = (_mls_x1716 * _mls_x1716);
    auto _mls_x1724 = (_mls_x1722 + _mls_x1723);
    auto _mls_x1725 = (_mls_x1717 * _mls_x1717);
    auto _mls_x1726 = (_mls_x1724 + _mls_x1725);
    auto _mls_x1727 = _mls_builtin_sqrt(_mls_x1726);
    auto _mls_x1728 = (_mls_x1715 / _mls_x1727);
    auto _mls_x1729 = (_mls_x1716 / _mls_x1727);
    auto _mls_x1730 = (_mls_x1717 / _mls_x1727);
    auto _mls_x1731 = _mlsValue::create<_mls_Tuple3>(_mls_x1728, _mls_x1729, _mls_x1730);
    auto _mls_x1732 = _mlsValue::create<_mls_Tuple2>(_mls_x1731, _mls_x1727);
    _mls_retval = _mls_x1732;
    return _mls_retval;
  }
}
_mlsValue _mls_vecnorm_case0_sr_post(_mlsValue _mls_x1715, _mlsValue _mls_x1716, _mlsValue _mls_x1717) {
  _mlsValue _mls_retval;
  auto _mls_x1722 = (_mls_x1715 * _mls_x1715);
  auto _mls_x1723 = (_mls_x1716 * _mls_x1716);
  auto _mls_x1724 = (_mls_x1722 + _mls_x1723);
  auto _mls_x1725 = (_mls_x1717 * _mls_x1717);
  auto _mls_x1726 = (_mls_x1724 + _mls_x1725);
  auto _mls_x1727 = _mls_builtin_sqrt(_mls_x1726);
  auto _mls_x1728 = (_mls_x1715 / _mls_x1727);
  auto _mls_x1729 = (_mls_x1716 / _mls_x1727);
  auto _mls_x1730 = (_mls_x1717 / _mls_x1727);
  auto _mls_x1731 = _mlsValue::create<_mls_Tuple3>(_mls_x1728, _mls_x1729, _mls_x1730);
  auto _mls_x1732 = _mlsValue::create<_mls_Tuple2>(_mls_x1731, _mls_x1727);
  _mls_retval = _mls_x1732;
  return _mls_retval;
}
_mlsValue _mls_vecscale(_mlsValue _mls_x1737, _mlsValue _mls_x1741) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1733, _mls_x1734, _mls_x1735, _mls_x1736;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1737)) {
    auto _mls_x1738 = _mlsValue::cast<_mls_Tuple3>(_mls_x1737)->_mls_field0;
    auto _mls_x1739 = _mlsValue::cast<_mls_Tuple3>(_mls_x1737)->_mls_field1;
    auto _mls_x1740 = _mlsValue::cast<_mls_Tuple3>(_mls_x1737)->_mls_field2;
    _mls_x1733 = _mls_x1741;
    _mls_x1734 = _mls_x1738;
    _mls_x1735 = _mls_x1739;
    _mls_x1736 = _mls_x1740;
    goto _mls_vecscale_case0_sr_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_vecscale_case0_sr_post:
  {
    auto _mls_x1742 = (_mls_x1733 * _mls_x1734);
    auto _mls_x1743 = (_mls_x1733 * _mls_x1735);
    auto _mls_x1744 = (_mls_x1733 * _mls_x1736);
    auto _mls_x1745 = _mlsValue::create<_mls_Tuple3>(_mls_x1742, _mls_x1743, _mls_x1744);
    _mls_retval = _mls_x1745;
    return _mls_retval;
  }
}
_mlsValue _mls_vecscale_case0(_mlsValue _mls_x1747, _mlsValue _mls_x1750) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1733, _mls_x1734, _mls_x1735, _mls_x1736;
  auto _mls_x1746 = _mlsValue::cast<_mls_Tuple3>(_mls_x1747)->_mls_field0;
  auto _mls_x1748 = _mlsValue::cast<_mls_Tuple3>(_mls_x1747)->_mls_field1;
  auto _mls_x1749 = _mlsValue::cast<_mls_Tuple3>(_mls_x1747)->_mls_field2;
  _mls_x1733 = _mls_x1750;
  _mls_x1734 = _mls_x1746;
  _mls_x1735 = _mls_x1748;
  _mls_x1736 = _mls_x1749;
  goto _mls_vecscale_case0_sr_post;
  return _mls_retval;
  _mls_vecscale_case0_sr_post:
  {
    auto _mls_x1742 = (_mls_x1733 * _mls_x1734);
    auto _mls_x1743 = (_mls_x1733 * _mls_x1735);
    auto _mls_x1744 = (_mls_x1733 * _mls_x1736);
    auto _mls_x1745 = _mlsValue::create<_mls_Tuple3>(_mls_x1742, _mls_x1743, _mls_x1744);
    _mls_retval = _mls_x1745;
    return _mls_retval;
  }
}
_mlsValue _mls_vecscale_case0_sr_post(_mlsValue _mls_x1733, _mlsValue _mls_x1734, _mlsValue _mls_x1735, _mlsValue _mls_x1736) {
  _mlsValue _mls_retval;
  auto _mls_x1742 = (_mls_x1733 * _mls_x1734);
  auto _mls_x1743 = (_mls_x1733 * _mls_x1735);
  auto _mls_x1744 = (_mls_x1733 * _mls_x1736);
  auto _mls_x1745 = _mlsValue::create<_mls_Tuple3>(_mls_x1742, _mls_x1743, _mls_x1744);
  _mls_retval = _mls_x1745;
  return _mls_retval;
}
_mlsValue _mls_vecsub(_mlsValue _mls_x1763, _mlsValue _mls_x1764) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1751, _mls_x1752;
  _mlsValue _mls_x1753, _mls_x1754, _mls_x1755, _mls_x1756;
  _mlsValue _mls_x1757, _mls_x1758, _mls_x1759, _mls_x1760, _mls_x1761, _mls_x1762;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1763)) {
    _mls_x1751 = _mls_x1763;
    _mls_x1752 = _mls_x1764;
    goto _mls_vecsub_case0_sr_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_vecsub_case0_sr_post:
  {
    auto [_mls_x1765, _mls_x1766, _mls_x1767, _mls_x1768] = _mls_vecsub_case0_pre(_mls_x1751, _mls_x1752);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1765)) {
      _mls_x1753 = _mls_x1765;
      _mls_x1754 = _mls_x1767;
      _mls_x1755 = _mls_x1766;
      _mls_x1756 = _mls_x1768;
      goto _mls_vecsub_case0_sr_post_case0;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_vecsub_case0_sr_post_case0:
  {
    auto _mls_x1769 = _mlsValue::cast<_mls_Tuple3>(_mls_x1753)->_mls_field0;
    auto _mls_x1770 = _mlsValue::cast<_mls_Tuple3>(_mls_x1753)->_mls_field1;
    auto _mls_x1771 = _mlsValue::cast<_mls_Tuple3>(_mls_x1753)->_mls_field2;
    _mls_x1757 = _mls_x1754;
    _mls_x1758 = _mls_x1769;
    _mls_x1759 = _mls_x1771;
    _mls_x1760 = _mls_x1770;
    _mls_x1761 = _mls_x1755;
    _mls_x1762 = _mls_x1756;
    goto _mls_vecsub_case0_case0_sr_post;
    return _mls_retval;
  }
  _mls_vecsub_case0_case0_sr_post:
  {
    auto _mls_x1772 = (_mls_x1761 - _mls_x1758);
    auto _mls_x1773 = (_mls_x1757 - _mls_x1760);
    auto _mls_x1774 = (_mls_x1762 - _mls_x1759);
    auto _mls_x1775 = _mlsValue::create<_mls_Tuple3>(_mls_x1772, _mls_x1773, _mls_x1774);
    _mls_retval = _mls_x1775;
    return _mls_retval;
  }
}
_mlsValue _mls_vecsub_case0_case0(_mlsValue _mls_x1777, _mlsValue _mls_x1781, _mlsValue _mls_x1780, _mlsValue _mls_x1782) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1757, _mls_x1758, _mls_x1759, _mls_x1760, _mls_x1761, _mls_x1762;
  auto _mls_x1776 = _mlsValue::cast<_mls_Tuple3>(_mls_x1777)->_mls_field0;
  auto _mls_x1778 = _mlsValue::cast<_mls_Tuple3>(_mls_x1777)->_mls_field1;
  auto _mls_x1779 = _mlsValue::cast<_mls_Tuple3>(_mls_x1777)->_mls_field2;
  _mls_x1757 = _mls_x1780;
  _mls_x1758 = _mls_x1776;
  _mls_x1759 = _mls_x1779;
  _mls_x1760 = _mls_x1778;
  _mls_x1761 = _mls_x1781;
  _mls_x1762 = _mls_x1782;
  goto _mls_vecsub_case0_case0_sr_post;
  return _mls_retval;
  _mls_vecsub_case0_case0_sr_post:
  {
    auto _mls_x1772 = (_mls_x1761 - _mls_x1758);
    auto _mls_x1773 = (_mls_x1757 - _mls_x1760);
    auto _mls_x1774 = (_mls_x1762 - _mls_x1759);
    auto _mls_x1775 = _mlsValue::create<_mls_Tuple3>(_mls_x1772, _mls_x1773, _mls_x1774);
    _mls_retval = _mls_x1775;
    return _mls_retval;
  }
}
_mlsValue _mls_vecsub_case0_case0_sr_post(_mlsValue _mls_x1757, _mlsValue _mls_x1758, _mlsValue _mls_x1759, _mlsValue _mls_x1760, _mlsValue _mls_x1761, _mlsValue _mls_x1762) {
  _mlsValue _mls_retval;
  auto _mls_x1772 = (_mls_x1761 - _mls_x1758);
  auto _mls_x1773 = (_mls_x1757 - _mls_x1760);
  auto _mls_x1774 = (_mls_x1762 - _mls_x1759);
  auto _mls_x1775 = _mlsValue::create<_mls_Tuple3>(_mls_x1772, _mls_x1773, _mls_x1774);
  _mls_retval = _mls_x1775;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_vecsub_case0_pre(_mlsValue _mls_x1784, _mlsValue _mls_x1787) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x1783 = _mlsValue::cast<_mls_Tuple3>(_mls_x1784)->_mls_field0;
  auto _mls_x1785 = _mlsValue::cast<_mls_Tuple3>(_mls_x1784)->_mls_field1;
  auto _mls_x1786 = _mlsValue::cast<_mls_Tuple3>(_mls_x1784)->_mls_field2;
  _mls_retval = std::make_tuple(_mls_x1787, _mls_x1783, _mls_x1785, _mls_x1786);
  return _mls_retval;
}
_mlsValue _mls_vecsub_case0_sr_post(_mlsValue _mls_x1751, _mlsValue _mls_x1752) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1753, _mls_x1754, _mls_x1755, _mls_x1756;
  _mlsValue _mls_x1757, _mls_x1758, _mls_x1759, _mls_x1760, _mls_x1761, _mls_x1762;
  auto [_mls_x1765, _mls_x1766, _mls_x1767, _mls_x1768] = _mls_vecsub_case0_pre(_mls_x1751, _mls_x1752);
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1765)) {
    _mls_x1753 = _mls_x1765;
    _mls_x1754 = _mls_x1767;
    _mls_x1755 = _mls_x1766;
    _mls_x1756 = _mls_x1768;
    goto _mls_vecsub_case0_sr_post_case0;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_vecsub_case0_sr_post_case0:
  {
    auto _mls_x1769 = _mlsValue::cast<_mls_Tuple3>(_mls_x1753)->_mls_field0;
    auto _mls_x1770 = _mlsValue::cast<_mls_Tuple3>(_mls_x1753)->_mls_field1;
    auto _mls_x1771 = _mlsValue::cast<_mls_Tuple3>(_mls_x1753)->_mls_field2;
    _mls_x1757 = _mls_x1754;
    _mls_x1758 = _mls_x1769;
    _mls_x1759 = _mls_x1771;
    _mls_x1760 = _mls_x1770;
    _mls_x1761 = _mls_x1755;
    _mls_x1762 = _mls_x1756;
    goto _mls_vecsub_case0_case0_sr_post;
    return _mls_retval;
  }
  _mls_vecsub_case0_case0_sr_post:
  {
    auto _mls_x1772 = (_mls_x1761 - _mls_x1758);
    auto _mls_x1773 = (_mls_x1757 - _mls_x1760);
    auto _mls_x1774 = (_mls_x1762 - _mls_x1759);
    auto _mls_x1775 = _mlsValue::create<_mls_Tuple3>(_mls_x1772, _mls_x1773, _mls_x1774);
    _mls_retval = _mls_x1775;
    return _mls_retval;
  }
}
_mlsValue _mls_vecsub_case0_sr_post_case0(_mlsValue _mls_x1753, _mlsValue _mls_x1754, _mlsValue _mls_x1755, _mlsValue _mls_x1756) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x1757, _mls_x1758, _mls_x1759, _mls_x1760, _mls_x1761, _mls_x1762;
  auto _mls_x1769 = _mlsValue::cast<_mls_Tuple3>(_mls_x1753)->_mls_field0;
  auto _mls_x1770 = _mlsValue::cast<_mls_Tuple3>(_mls_x1753)->_mls_field1;
  auto _mls_x1771 = _mlsValue::cast<_mls_Tuple3>(_mls_x1753)->_mls_field2;
  _mls_x1757 = _mls_x1754;
  _mls_x1758 = _mls_x1769;
  _mls_x1759 = _mls_x1771;
  _mls_x1760 = _mls_x1770;
  _mls_x1761 = _mls_x1755;
  _mls_x1762 = _mls_x1756;
  goto _mls_vecsub_case0_case0_sr_post;
  return _mls_retval;
  _mls_vecsub_case0_case0_sr_post:
  {
    auto _mls_x1772 = (_mls_x1761 - _mls_x1758);
    auto _mls_x1773 = (_mls_x1757 - _mls_x1760);
    auto _mls_x1774 = (_mls_x1762 - _mls_x1759);
    auto _mls_x1775 = _mlsValue::create<_mls_Tuple3>(_mls_x1772, _mls_x1773, _mls_x1774);
    _mls_retval = _mls_x1775;
    return _mls_retval;
  }
}
_mlsValue _mls_vecsum(_mlsValue _mls_param) {
  _mlsValue _mls_retval;
  auto _mls_x579 = _mlsValue::create<_mls_Lambda_vecadd>();
  auto _mls_x580 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
  auto _mls_x581 = _mls_foldr(_mls_x579, _mls_x580, _mls_param);
  _mls_retval = _mls_x581;
  return _mls_retval;
}
_mlsValue _mls_Lambda_f::_mls_apply2(_mlsValue _mls_i, _mlsValue _mls_j) {
  _mlsValue _mls_retval;
  auto _mls_x = _mls_testspheres();
  auto _mls_x1 = _mls_tracepixel(_mls_x, _mls_lam_arg2, _mls_i, _mls_j, _mls_lam_arg0, _mls_lam_arg1, _mls_lam_arg3);
  _mls_retval = _mls_x1;
  return _mls_retval;
}
_mlsValue _mls_Lambda_f1::_mls_apply2(_mlsValue _mls_d1s1, _mlsValue _mls_d2s2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_d1s1)) {
    auto _mls_x2 = _mlsValue::cast<_mls_Tuple2>(_mls_d1s1)->_mls_field0;
    auto _mls_x3 = _mlsValue::cast<_mls_Tuple2>(_mls_d1s1)->_mls_field1;
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_d2s2)) {
      auto _mls_x4 = _mlsValue::cast<_mls_Tuple2>(_mls_d2s2)->_mls_field0;
      auto _mls_x5 = _mlsValue::cast<_mls_Tuple2>(_mls_d2s2)->_mls_field1;
      auto _mls_x6 = (_mls_x2 < _mls_x4);
      if (_mlsValue::isIntLit(_mls_x6, 1)) {
        auto _mls_x8 = _mlsValue::create<_mls_Tuple2>(_mls_x2, _mls_x3);
        _mls_retval = _mls_x8;
      } else {
        auto _mls_x7 = _mlsValue::create<_mls_Tuple2>(_mls_x4, _mls_x5);
        _mls_retval = _mls_x7;
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda::_mls_apply1(_mlsValue _mls_l) {
  _mlsValue _mls_retval;
  auto _mls_x9 = _mls_lightray(_mls_l, _mls_lam_arg1, _mls_lam_arg3, _mls_lam_arg0, _mls_lam_arg2);
  _mls_retval = _mls_x9;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lscomp::_mls_apply1(_mlsValue _mls_ls) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls)) {
    auto _mls_x16 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x16;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls)) {
    auto _mls_x10 = _mlsValue::cast<_mls_Cons>(_mls_ls)->_mls_head;
    auto _mls_x11 = _mlsValue::cast<_mls_Cons>(_mls_ls)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Transmit>(_mls_x10)) {
      auto _mls_x13 = _mlsValue::cast<_mls_Transmit>(_mls_x10)->_mls_v;
      auto _mls_x14 = this->_mls_apply1(_mls_x11);
      auto _mls_x15 = _mlsValue::create<_mls_Cons>(_mls_x13, _mls_x14);
      _mls_retval = _mls_x15;
    } else {
      auto _mls_x12 = this->_mls_apply1(_mls_x11);
      _mls_retval = _mls_x12;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lscomp1::_mls_apply1(_mlsValue _mls_ls1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls1)) {
    auto _mls_x23 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x23;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls1)) {
    auto _mls_x17 = _mlsValue::cast<_mls_Cons>(_mls_ls1)->_mls_head;
    auto _mls_x18 = _mlsValue::cast<_mls_Cons>(_mls_ls1)->_mls_tail;
    auto _mls_x19 = _mlsValue::create<_mls_Lambda_lscomp21>(_mls_x18, _mlsValue(this, _mlsValue::inc_ref_tag{}), _mls_x17, _mls_lam_arg0);
    auto _mls_x20 = (_mls_lam_arg1 - _mlsValue::create<_mls_Float>(1.0));
    auto _mls_x21 = _mls_enumFromTo(_mlsValue::create<_mls_Float>(0.0), _mls_x20);
    auto _mls_x22 = _mlsMethodCall<_mls_Callable>(_mls_x19)->_mls_apply1(_mls_x21);
    _mls_retval = _mls_x22;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lscomp2::_mls_apply1(_mlsValue _mls_ls2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls2)) {
    auto _mls_x30 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x30;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls2)) {
    auto _mls_x24 = _mlsValue::cast<_mls_Cons>(_mls_ls2)->_mls_head;
    auto _mls_x25 = _mlsValue::cast<_mls_Cons>(_mls_ls2)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Body>(_mls_x24)) {
      auto _mls_x27 = _mlsValue::cast<_mls_Body>(_mls_x24)->_mls_v;
      auto _mls_x28 = this->_mls_apply1(_mls_x25);
      auto _mls_x29 = _mlsValue::create<_mls_Cons>(_mls_x27, _mls_x28);
      _mls_retval = _mls_x29;
    } else {
      auto _mls_x26 = this->_mls_apply1(_mls_x25);
      _mls_retval = _mls_x26;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lscomp21::_mls_apply1(_mlsValue _mls_ls21) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls21)) {
    auto _mls_x38 = _mlsMethodCall<_mls_Callable>(_mls_lam_arg1)->_mls_apply1(_mls_lam_arg0);
    _mls_retval = _mls_x38;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls21)) {
    auto _mls_x31 = _mlsValue::cast<_mls_Cons>(_mls_ls21)->_mls_head;
    auto _mls_x32 = _mlsValue::cast<_mls_Cons>(_mls_ls21)->_mls_tail;
    auto _mls_x33 = _mlsMethodCall<_mls_Callable>(_mls_lam_arg3)->_mls_apply2(_mls_lam_arg2, _mls_x31);
    auto _mls_x34 = this->_mls_apply1(_mls_x32);
    auto _mls_x35 = _mlsValue::create<_mls_Tuple2>(_mls_lam_arg2, _mls_x31);
    auto _mls_x36 = _mlsValue::create<_mls_Tuple2>(_mls_x35, _mls_x33);
    auto _mls_x37 = _mlsValue::create<_mls_Cons>(_mls_x36, _mls_x34);
    _mls_retval = _mls_x37;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lscomp3::_mls_apply1(_mlsValue _mls_ls3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls3)) {
    auto _mls_x45 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x45;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls3)) {
    auto _mls_x39 = _mlsValue::cast<_mls_Cons>(_mls_ls3)->_mls_head;
    auto _mls_x40 = _mlsValue::cast<_mls_Cons>(_mls_ls3)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Diffuse>(_mls_x39)) {
      auto _mls_x42 = _mlsValue::cast<_mls_Diffuse>(_mls_x39)->_mls_v;
      auto _mls_x43 = this->_mls_apply1(_mls_x40);
      auto _mls_x44 = _mlsValue::create<_mls_Cons>(_mls_x42, _mls_x43);
      _mls_retval = _mls_x44;
    } else {
      auto _mls_x41 = this->_mls_apply1(_mls_x40);
      _mls_retval = _mls_x41;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lscomp4::_mls_apply1(_mlsValue _mls_ls4) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls4)) {
    auto _mls_x52 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x52;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls4)) {
    auto _mls_x46 = _mlsValue::cast<_mls_Cons>(_mls_ls4)->_mls_head;
    auto _mls_x47 = _mlsValue::cast<_mls_Cons>(_mls_ls4)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Ambient>(_mls_x46)) {
      auto _mls_x49 = _mlsValue::cast<_mls_Ambient>(_mls_x46)->_mls_v;
      auto _mls_x50 = this->_mls_apply1(_mls_x47);
      auto _mls_x51 = _mlsValue::create<_mls_Cons>(_mls_x49, _mls_x50);
      _mls_retval = _mls_x51;
    } else {
      auto _mls_x48 = this->_mls_apply1(_mls_x47);
      _mls_retval = _mls_x48;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lscomp5::_mls_apply1(_mlsValue _mls_ls5) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls5)) {
    auto _mls_x59 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x59;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls5)) {
    auto _mls_x53 = _mlsValue::cast<_mls_Cons>(_mls_ls5)->_mls_head;
    auto _mls_x54 = _mlsValue::cast<_mls_Cons>(_mls_ls5)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Reflect>(_mls_x53)) {
      auto _mls_x56 = _mlsValue::cast<_mls_Reflect>(_mls_x53)->_mls_v;
      auto _mls_x57 = this->_mls_apply1(_mls_x54);
      auto _mls_x58 = _mlsValue::create<_mls_Cons>(_mls_x56, _mls_x57);
      _mls_retval = _mls_x58;
    } else {
      auto _mls_x55 = this->_mls_apply1(_mls_x54);
      _mls_retval = _mls_x55;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lscomp6::_mls_apply1(_mlsValue _mls_ls6) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls6)) {
    auto _mls_x66 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x66;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls6)) {
    auto _mls_x60 = _mlsValue::cast<_mls_Cons>(_mls_ls6)->_mls_head;
    auto _mls_x61 = _mlsValue::cast<_mls_Cons>(_mls_ls6)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Specpow>(_mls_x60)) {
      auto _mls_x63 = _mlsValue::cast<_mls_Specpow>(_mls_x60)->_mls_v;
      auto _mls_x64 = this->_mls_apply1(_mls_x61);
      auto _mls_x65 = _mlsValue::create<_mls_Cons>(_mls_x63, _mls_x64);
      _mls_retval = _mls_x65;
    } else {
      auto _mls_x62 = this->_mls_apply1(_mls_x61);
      _mls_retval = _mls_x62;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lscomp7::_mls_apply1(_mlsValue _mls_ls7) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls7)) {
    auto _mls_x73 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x73;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls7)) {
    auto _mls_x67 = _mlsValue::cast<_mls_Cons>(_mls_ls7)->_mls_head;
    auto _mls_x68 = _mlsValue::cast<_mls_Cons>(_mls_ls7)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Refract>(_mls_x67)) {
      auto _mls_x70 = _mlsValue::cast<_mls_Refract>(_mls_x67)->_mls_v;
      auto _mls_x71 = this->_mls_apply1(_mls_x68);
      auto _mls_x72 = _mlsValue::create<_mls_Cons>(_mls_x70, _mls_x71);
      _mls_retval = _mls_x72;
    } else {
      auto _mls_x69 = this->_mls_apply1(_mls_x68);
      _mls_retval = _mls_x69;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lscomp8::_mls_apply1(_mlsValue _mls_ls8) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls8)) {
    auto _mls_x80 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x80;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls8)) {
    auto _mls_x74 = _mlsValue::cast<_mls_Cons>(_mls_ls8)->_mls_head;
    auto _mls_x75 = _mlsValue::cast<_mls_Cons>(_mls_ls8)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Specular>(_mls_x74)) {
      auto _mls_x77 = _mlsValue::cast<_mls_Specular>(_mls_x74)->_mls_v;
      auto _mls_x78 = this->_mls_apply1(_mls_x75);
      auto _mls_x79 = _mlsValue::create<_mls_Cons>(_mls_x77, _mls_x78);
      _mls_retval = _mls_x79;
    } else {
      auto _mls_x76 = this->_mls_apply1(_mls_x75);
      _mls_retval = _mls_x76;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_snd::_mls_apply1(_mlsValue _mls_arg) {
  _mlsValue _mls_retval;
  auto _mls_x81 = _mls_snd(_mls_arg);
  _mls_retval = _mls_x81;
  return _mls_retval;
}
_mlsValue _mls_Lambda_sphmap::_mls_apply1(_mlsValue _mls_xss) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xss)) {
    auto _mls_x91 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x91;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xss)) {
    auto _mls_x82 = _mlsValue::cast<_mls_Cons>(_mls_xss)->_mls_head;
    auto _mls_x83 = _mlsValue::cast<_mls_Cons>(_mls_xss)->_mls_tail;
    auto _mls_x84 = _mls_sphereintersect(_mls_lam_arg1, _mls_lam_arg0, _mls_x82);
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x84)) {
      auto _mls_x85 = _mlsValue::cast<_mls_Tuple2>(_mls_x84)->_mls_field0;
      auto _mls_x86 = _mlsValue::cast<_mls_Tuple2>(_mls_x84)->_mls_field1;
      if (_mlsValue::isIntLit(_mls_x85, 1)) {
        auto _mls_x88 = this->_mls_apply1(_mls_x83);
        auto _mls_x89 = _mlsValue::create<_mls_Tuple2>(_mls_x86, _mls_x82);
        auto _mls_x90 = _mlsValue::create<_mls_Cons>(_mls_x89, _mls_x88);
        _mls_retval = _mls_x90;
      } else {
        auto _mls_x87 = this->_mls_apply1(_mls_x83);
        _mls_retval = _mls_x87;
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_vecadd::_mls_apply2(_mlsValue _mls_arg1, _mlsValue _mls_arg2) {
  _mlsValue _mls_retval;
  auto _mls_x92 = _mls_vecadd(_mls_arg1, _mls_arg2);
  _mls_retval = _mls_x92;
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
