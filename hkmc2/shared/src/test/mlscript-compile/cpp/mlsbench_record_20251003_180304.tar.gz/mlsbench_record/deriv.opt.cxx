#include "mlsprelude.h"
struct _mls_Expr;
struct _mls_Add;
struct _mls_LamDeriv;
struct _mls_Ln;
struct _mls_Mul;
struct _mls_Pow;
struct _mls_Val;
struct _mls_Var;
_mlsValue _mls_add(_mlsValue, _mlsValue);
_mlsValue _mls_add_case01(_mlsValue, _mlsValue);
_mlsValue _mls_add_case0(_mlsValue, _mlsValue);
_mlsValue _mls_add_default(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_case0_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_case0_sr_post1(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_case0_sr_post_default(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_case1_case01(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_add_default_case1_case0(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_add_default_case1_case02(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_add_default_case1_case0_sr_post1(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_add_default_case1_case0_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_add_default_case1_default1(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_case1_default(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_case1_default_case0(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_case1_default_default(_mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_add_default_case1_pre1(_mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_add_default_case1_pre(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_default_case02(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_default_case0(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_default_case01(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_default_case0_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_add_default_default_default(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_default_default1(_mlsValue, _mlsValue);
_mlsValue _mls_count(_mlsValue);
_mlsValue _mls_d_case0();
_mlsValue _mls_d_case1(_mlsValue, _mlsValue);
_mlsValue _mls_d_case11(_mlsValue, _mlsValue);
_mlsValue _mls_d_case12(_mlsValue, _mlsValue);
_mlsValue _mls_d_case1_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_d_case2(_mlsValue, _mlsValue);
_mlsValue _mls_d_case21(_mlsValue, _mlsValue);
_mlsValue _mls_d_case22(_mlsValue, _mlsValue);
_mlsValue _mls_d_case2_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case2_sr_post_caller_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case2_sr_post_caller_post_case0(_mlsValue);
_mlsValue _mls_d_case2_sr_post_caller_post_case1(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case2_sr_post_caller_post_case2(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case2_sr_post_caller_post_case3(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case2_sr_post_caller_post_case4(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case2_sr_post_caller_post_case5(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case2_sr_post_case0(_mlsValue, _mlsValue);
_mlsValue _mls_d_case2_sr_post_case1(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case2_sr_post_case2(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case2_sr_post_case3(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case2_sr_post_case4(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case2_sr_post_case5(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case31(_mlsValue, _mlsValue);
_mlsValue _mls_d_case3(_mlsValue, _mlsValue);
_mlsValue _mls_d_case32(_mlsValue, _mlsValue);
_mlsValue _mls_d_case3_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case3_sr_post_caller_post_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case3_sr_post_caller_post_post_caller_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case3_sr_post_case0(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case3_sr_post_case1(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case3_sr_post_case2(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case3_sr_post_case3(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case3_sr_post_case4(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case3_sr_post_case5(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case42(_mlsValue, _mlsValue);
_mlsValue _mls_d_case41(_mlsValue, _mlsValue);
_mlsValue _mls_d_case4(_mlsValue, _mlsValue);
_mlsValue _mls_d_case4_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case4_caller_post_caller_post_caller_post1(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case4_caller_post_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case4_caller_post_caller_post_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case4_caller_post_caller_post_caller_post_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case4_caller_post_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case4_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case4_sr_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case4_sr_post_case0(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case4_sr_post_default(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case51(_mlsValue, _mlsValue);
_mlsValue _mls_d_case5(_mlsValue, _mlsValue);
_mlsValue _mls_d_case52(_mlsValue, _mlsValue);
_mlsValue _mls_d_case5_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_d_case5_sr_post_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_d_case5_sr_post_caller_post_case0(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case5_sr_post_caller_post_default(_mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_d_case5_sr_post_caller_post_pre(_mlsValue, _mlsValue);
_mlsValue _mls_d_case5_sr_post_case0(_mlsValue);
_mlsValue _mls_d_case5_sr_post_case1(_mlsValue, _mlsValue);
_mlsValue _mls_d_case5_sr_post_case2(_mlsValue, _mlsValue);
_mlsValue _mls_d_case5_sr_post_case3(_mlsValue, _mlsValue);
_mlsValue _mls_d_case5_sr_post_case4(_mlsValue, _mlsValue);
_mlsValue _mls_d_case5_sr_post_case5(_mlsValue, _mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_j(_mlsValue, _mlsValue);
_mlsValue _mls_ln_case0(_mlsValue);
_mlsValue _mls_ln_default(_mlsValue);
_mlsValue _mls_main(_mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_main_caller_post_pre(_mlsValue, _mlsValue);
_mlsValue _mls_mul(_mlsValue, _mlsValue);
_mlsValue _mls_mul_case0(_mlsValue, _mlsValue);
_mlsValue _mls_mul_case01(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_case0(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_case0_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_case0_sr_post1(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_case0_sr_post_case0();
_mlsValue _mls_mul_default_case0_sr_post_default(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_case1(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_case1_case0(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_mul_default_case1_case01(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_mul_default_case1_case02(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_mul_default_case1_case0_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_mul_default_case1_case0_sr_post1(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_mul_default_case1_default1(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_case1_default(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_case1_default_case0(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_case1_default_default(_mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_mul_default_case1_pre1(_mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_mul_default_case1_pre(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_default(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_default_case0(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_default_case01(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_default_case0_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_mul_default_default_default(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_default_default1(_mlsValue, _mlsValue);
_mlsValue _mls_nestAux(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_nestAux_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_nestAux_caller_post_pre(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_nestAux_default(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_nestAux_default_case0(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_pow_case0(_mlsValue, _mlsValue);
_mlsValue _mls_pow_default(_mlsValue, _mlsValue);
_mlsValue _mls_pow_default_case0(_mlsValue, _mlsValue);
_mlsValue _mls_pow_default_default(_mlsValue, _mlsValue);
_mlsValue _mls_pown(_mlsValue, _mlsValue);
struct _mls_Expr: public _mlsObject {
  
  constexpr static inline const char *typeName = "Expr";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Expr; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Add: public _mls_Expr {
  _mlsValue _mls_e1;
  _mlsValue _mls_e2;
  constexpr static inline const char *typeName = "Add";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e1.print(); std::printf(", "); this->_mls_e2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e1); _mlsValue::destroy(this->_mls_e2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e1.asObject()->operator==(*other.cast<_mls_Add>()->_mls_e1.asObject()) && this->_mls_e2.asObject()->operator==(*other.cast<_mls_Add>()->_mls_e2.asObject()); }
  static _mlsValue create(_mlsValue _mls_e1, _mlsValue _mls_e2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Add; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e1 = _mls_e1; _mlsVal->_mls_e2 = _mls_e2;  return _mlsValue(_mlsVal); }
  
};
struct _mls_LamDeriv: public _mlsObject {
  
  constexpr static inline const char *typeName = "LamDeriv";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_LamDeriv; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Ln: public _mls_Expr {
  _mlsValue _mls_e;
  constexpr static inline const char *typeName = "Ln";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e.asObject()->operator==(*other.cast<_mls_Ln>()->_mls_e.asObject()); }
  static _mlsValue create(_mlsValue _mls_e) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Ln; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e = _mls_e;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Mul: public _mls_Expr {
  _mlsValue _mls_e1;
  _mlsValue _mls_e2;
  constexpr static inline const char *typeName = "Mul";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e1.print(); std::printf(", "); this->_mls_e2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e1); _mlsValue::destroy(this->_mls_e2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e1.asObject()->operator==(*other.cast<_mls_Mul>()->_mls_e1.asObject()) && this->_mls_e2.asObject()->operator==(*other.cast<_mls_Mul>()->_mls_e2.asObject()); }
  static _mlsValue create(_mlsValue _mls_e1, _mlsValue _mls_e2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Mul; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e1 = _mls_e1; _mlsVal->_mls_e2 = _mls_e2;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Pow: public _mls_Expr {
  _mlsValue _mls_e1;
  _mlsValue _mls_e2;
  constexpr static inline const char *typeName = "Pow";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e1.print(); std::printf(", "); this->_mls_e2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e1); _mlsValue::destroy(this->_mls_e2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e1.asObject()->operator==(*other.cast<_mls_Pow>()->_mls_e1.asObject()) && this->_mls_e2.asObject()->operator==(*other.cast<_mls_Pow>()->_mls_e2.asObject()); }
  static _mlsValue create(_mlsValue _mls_e1, _mlsValue _mls_e2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Pow; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e1 = _mls_e1; _mlsVal->_mls_e2 = _mls_e2;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Val: public _mls_Expr {
  _mlsValue _mls_n;
  constexpr static inline const char *typeName = "Val";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_n.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_n);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_n.asObject()->operator==(*other.cast<_mls_Val>()->_mls_n.asObject()); }
  static _mlsValue create(_mlsValue _mls_n) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Val; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_n = _mls_n;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Var: public _mls_Expr {
  _mlsValue _mls_x;
  constexpr static inline const char *typeName = "Var";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_x.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_x);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_x.asObject()->operator==(*other.cast<_mls_Var>()->_mls_x.asObject()); }
  static _mlsValue create(_mlsValue _mls_x) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Var; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_x = _mls_x;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_add(_mlsValue _mls_x, _mlsValue _mls_x153) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x)) {
    _mls_retval = _mls_add_case0(_mls_x, _mls_x153);
  } else {
    _mls_retval = _mls_add_default(_mls_x153, _mls_x);
  }
  return _mls_retval;
}
_mlsValue _mls_add_case01(_mlsValue _mls_x155, _mlsValue _mls_x156) {
  _mlsValue _mls_retval;
  auto _mls_x154 = _mlsValue::cast<_mls_Val>(_mls_x155)->_mls_n;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x156)) {
    auto _mls_x165 = _mlsValue::cast<_mls_Val>(_mls_x156)->_mls_n;
    auto _mls_x166 = (_mls_x154 + _mls_x165);
    auto _mls_x167 = _mlsValue::create<_mls_Val>(_mls_x166);
    _mls_retval = _mls_x167;
  } else {
    if (_mlsValue::isIntLit(_mls_x154, 0)) {
      _mls_retval = _mls_x156;
    } else {
      if (_mlsValue::isValueOf<_mls_Add>(_mls_x156)) {
        auto _mls_x158 = _mlsValue::cast<_mls_Add>(_mls_x156)->_mls_e1;
        auto _mls_x159 = _mlsValue::cast<_mls_Add>(_mls_x156)->_mls_e2;
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x158)) {
          auto _mls_x161 = _mlsValue::cast<_mls_Val>(_mls_x158)->_mls_n;
          auto _mls_x162 = (_mls_x154 + _mls_x161);
          auto _mls_x163 = _mlsValue::create<_mls_Val>(_mls_x162);
          auto _mls_x164 = _mls_add_case0(_mls_x163, _mls_x159);
          _mls_retval = _mls_x164;
        } else {
          auto _mls_x160 = _mlsValue::create<_mls_Add>(_mls_x155, _mls_x156);
          _mls_retval = _mls_x160;
        }
      } else {
        auto _mls_x157 = _mlsValue::create<_mls_Add>(_mls_x155, _mls_x156);
        _mls_retval = _mls_x157;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_add_case0(_mlsValue _mls_x169, _mlsValue _mls_x170) {
  _mlsValue _mls_retval;
  auto _mls_x168 = _mlsValue::cast<_mls_Val>(_mls_x169)->_mls_n;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x170)) {
    auto _mls_x179 = _mlsValue::cast<_mls_Val>(_mls_x170)->_mls_n;
    auto _mls_x180 = (_mls_x168 + _mls_x179);
    auto _mls_x181 = _mlsValue::create<_mls_Val>(_mls_x180);
    _mls_retval = _mls_x181;
  } else {
    if (_mlsValue::isIntLit(_mls_x168, 0)) {
      _mls_retval = _mls_x170;
    } else {
      if (_mlsValue::isValueOf<_mls_Add>(_mls_x170)) {
        auto _mls_x172 = _mlsValue::cast<_mls_Add>(_mls_x170)->_mls_e1;
        auto _mls_x173 = _mlsValue::cast<_mls_Add>(_mls_x170)->_mls_e2;
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x172)) {
          auto _mls_x175 = _mlsValue::cast<_mls_Val>(_mls_x172)->_mls_n;
          auto _mls_x176 = (_mls_x168 + _mls_x175);
          auto _mls_x177 = _mlsValue::create<_mls_Val>(_mls_x176);
          auto _mls_x178 = _mls_add_case01(_mls_x177, _mls_x173);
          _mls_retval = _mls_x178;
        } else {
          auto _mls_x174 = _mlsValue::create<_mls_Add>(_mls_x169, _mls_x170);
          _mls_retval = _mls_x174;
        }
      } else {
        auto _mls_x171 = _mlsValue::create<_mls_Add>(_mls_x169, _mls_x170);
        _mls_retval = _mls_x171;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_add_default(_mlsValue _mls_x182, _mlsValue _mls_x183) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x182)) {
    auto _mls_x190 = _mlsValue::cast<_mls_Val>(_mls_x182)->_mls_n;
    if (_mlsValue::isIntLit(_mls_x190, 0)) {
      _mls_retval = _mls_x183;
    } else {
      _mls_retval = _mls_add_default_case0_sr_post_default(_mls_x190, _mls_x183);
    }
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x182)) {
    auto [_mls_x186, _mls_x187, _mls_x188, _mls_x189] = _mls_add_default_case1_pre(_mls_x182, _mls_x183);
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x186)) {
      _mls_retval = _mls_add_default_case1_case0(_mls_x186, _mls_x187, _mls_x188);
    } else {
      _mls_retval = _mls_add_default_case1_default(_mls_x187, _mls_x189);
    }
  } else {
    if (_mlsValue::isValueOf<_mls_Add>(_mls_x183)) {
      auto _mls_x184 = _mlsValue::cast<_mls_Add>(_mls_x183)->_mls_e1;
      auto _mls_x185 = _mlsValue::cast<_mls_Add>(_mls_x183)->_mls_e2;
      _mls_retval = _mls_add_default_default_case0_sr_post(_mls_x185, _mls_x182, _mls_x184);
    } else {
      _mls_retval = _mls_add_default_default_default(_mls_x183, _mls_x182);
    }
  }
  return _mls_retval;
}
_mlsValue _mls_add_default_case0_sr_post(_mlsValue _mls_x191, _mlsValue _mls_x192) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_x191, 0)) {
    _mls_retval = _mls_x192;
  } else {
    _mls_retval = _mls_add_default_case0_sr_post_default(_mls_x191, _mls_x192);
  }
  return _mls_retval;
}
_mlsValue _mls_add_default_case0_sr_post1(_mlsValue _mls_x193, _mlsValue _mls_x195) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_x193, 0)) {
    _mls_retval = _mls_x195;
  } else {
    auto _mls_x194 = _mlsValue::create<_mls_Val>(_mls_x193);
    auto _mls_x196 = _mls_add_case0(_mls_x194, _mls_x195);
    _mls_retval = _mls_x196;
  }
  return _mls_retval;
}
_mlsValue _mls_add_default_case0_sr_post_default(_mlsValue _mls_x198, _mlsValue _mls_x199) {
  _mlsValue _mls_retval;
  auto _mls_x197 = _mlsValue::create<_mls_Val>(_mls_x198);
  auto _mls_x200 = _mls_add_case01(_mls_x197, _mls_x199);
  _mls_retval = _mls_x200;
  return _mls_retval;
}
_mlsValue _mls_add_default_case1_case01(_mlsValue _mls_x202, _mlsValue _mls_x203, _mlsValue _mls_x204) {
  _mlsValue _mls_retval;
  auto _mls_x201 = _mlsValue::cast<_mls_Val>(_mls_x202)->_mls_n;
  _mls_retval = _mls_add_default_case1_case0_sr_post(_mls_x201, _mls_x203, _mls_x204);
  return _mls_retval;
}
_mlsValue _mls_add_default_case1_case0(_mlsValue _mls_x206, _mlsValue _mls_x207, _mlsValue _mls_x208) {
  _mlsValue _mls_retval;
  auto _mls_x205 = _mlsValue::cast<_mls_Val>(_mls_x206)->_mls_n;
  _mls_retval = _mls_add_default_case1_case0_sr_post1(_mls_x205, _mls_x207, _mls_x208);
  return _mls_retval;
}
_mlsValue _mls_add_default_case1_case02(_mlsValue _mls_x210, _mlsValue _mls_x211, _mlsValue _mls_x212) {
  _mlsValue _mls_retval;
  auto _mls_x209 = _mlsValue::cast<_mls_Val>(_mls_x210)->_mls_n;
  _mls_retval = _mls_add_default_case1_case0_sr_post1(_mls_x209, _mls_x211, _mls_x212);
  return _mls_retval;
}
_mlsValue _mls_add_default_case1_case0_sr_post1(_mlsValue _mls_x214, _mlsValue _mls_x215, _mlsValue _mls_x216) {
  _mlsValue _mls_retval;
  auto _mls_x213 = _mlsValue::create<_mls_Val>(_mls_x214);
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x215)) {
    auto _mls_x232 = _mls_add_case01(_mls_x215, _mls_x216);
    auto _mls_x233 = _mls_add(_mls_x213, _mls_x232);
    _mls_retval = _mls_x233;
  } else {
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x216)) {
      auto _mls_x229 = _mlsValue::cast<_mls_Val>(_mls_x216)->_mls_n;
      auto _mls_x230 = _mls_add_default_case0_sr_post1(_mls_x229, _mls_x215);
      auto _mls_x231 = _mls_add(_mls_x213, _mls_x230);
      _mls_retval = _mls_x231;
    } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x216)) {
      auto [_mls_x221, _mls_x222, _mls_x223, _mls_x224] = _mls_add_default_case1_pre1(_mls_x216, _mls_x215);
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x221)) {
        auto _mls_x227 = _mls_add_default_case1_case01(_mls_x221, _mls_x222, _mls_x223);
        auto _mls_x228 = _mls_add(_mls_x213, _mls_x227);
        _mls_retval = _mls_x228;
      } else {
        auto _mls_x225 = _mls_add_default_case1_default1(_mls_x222, _mls_x224);
        auto _mls_x226 = _mls_add(_mls_x213, _mls_x225);
        _mls_retval = _mls_x226;
      }
    } else {
      if (_mlsValue::isValueOf<_mls_Add>(_mls_x215)) {
        auto _mls_x219 = _mls_add_default_default_case0(_mls_x215, _mls_x216);
        auto _mls_x220 = _mls_add(_mls_x213, _mls_x219);
        _mls_retval = _mls_x220;
      } else {
        auto _mls_x217 = _mls_add_default_default_default1(_mls_x215, _mls_x216);
        auto _mls_x218 = _mls_add(_mls_x213, _mls_x217);
        _mls_retval = _mls_x218;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_add_default_case1_case0_sr_post(_mlsValue _mls_x235, _mlsValue _mls_x236, _mlsValue _mls_x237) {
  _mlsValue _mls_retval;
  auto _mls_x234 = _mlsValue::create<_mls_Val>(_mls_x235);
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x236)) {
    auto _mls_x256 = _mls_add_case0(_mls_x236, _mls_x237);
    auto _mls_x257 = _mls_add(_mls_x234, _mls_x256);
    _mls_retval = _mls_x257;
  } else {
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x237)) {
      auto _mls_x252 = _mlsValue::cast<_mls_Val>(_mls_x237)->_mls_n;
      if (_mlsValue::isIntLit(_mls_x252, 0)) {
        auto _mls_x255 = _mls_add(_mls_x234, _mls_x236);
        _mls_retval = _mls_x255;
      } else {
        auto _mls_x253 = _mls_add_default_case0_sr_post_default(_mls_x252, _mls_x236);
        auto _mls_x254 = _mls_add(_mls_x234, _mls_x253);
        _mls_retval = _mls_x254;
      }
    } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x237)) {
      auto [_mls_x244, _mls_x245, _mls_x246, _mls_x247] = _mls_add_default_case1_pre(_mls_x237, _mls_x236);
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x244)) {
        auto _mls_x250 = _mls_add_default_case1_case0(_mls_x244, _mls_x245, _mls_x246);
        auto _mls_x251 = _mls_add(_mls_x234, _mls_x250);
        _mls_retval = _mls_x251;
      } else {
        auto _mls_x248 = _mls_add_default_case1_default(_mls_x245, _mls_x247);
        auto _mls_x249 = _mls_add(_mls_x234, _mls_x248);
        _mls_retval = _mls_x249;
      }
    } else {
      if (_mlsValue::isValueOf<_mls_Add>(_mls_x236)) {
        auto _mls_x240 = _mlsValue::cast<_mls_Add>(_mls_x236)->_mls_e1;
        auto _mls_x241 = _mlsValue::cast<_mls_Add>(_mls_x236)->_mls_e2;
        auto _mls_x242 = _mls_add_default_default_case0_sr_post(_mls_x241, _mls_x237, _mls_x240);
        auto _mls_x243 = _mls_add(_mls_x234, _mls_x242);
        _mls_retval = _mls_x243;
      } else {
        auto _mls_x238 = _mls_add_default_default_default(_mls_x236, _mls_x237);
        auto _mls_x239 = _mls_add_case0(_mls_x234, _mls_x238);
        _mls_retval = _mls_x239;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_add_default_case1_default1(_mlsValue _mls_x258, _mlsValue _mls_x259) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_x258)) {
    _mls_retval = _mls_add_default_case1_default_case0(_mls_x258, _mls_x259);
  } else {
    _mls_retval = _mls_add_default_case1_default_default(_mls_x258, _mls_x259);
  }
  return _mls_retval;
}
_mlsValue _mls_add_default_case1_default(_mlsValue _mls_x260, _mlsValue _mls_x262) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_x260)) {
    auto _mls_x263 = _mlsValue::cast<_mls_Add>(_mls_x260)->_mls_e1;
    auto _mls_x264 = _mlsValue::cast<_mls_Add>(_mls_x260)->_mls_e2;
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x264)) {
      auto _mls_x276 = _mls_add_case01(_mls_x264, _mls_x262);
      auto _mls_x277 = _mls_add(_mls_x263, _mls_x276);
      _mls_retval = _mls_x277;
    } else {
      auto [_mls_x265, _mls_x266, _mls_x267, _mls_x268] = _mls_add_default_case1_pre1(_mls_x262, _mls_x264);
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x265)) {
        auto _mls_x273 = _mlsValue::cast<_mls_Val>(_mls_x265)->_mls_n;
        auto _mls_x274 = _mls_add_default_case1_case0_sr_post(_mls_x273, _mls_x266, _mls_x267);
        auto _mls_x275 = _mls_add(_mls_x263, _mls_x274);
        _mls_retval = _mls_x275;
      } else {
        if (_mlsValue::isValueOf<_mls_Add>(_mls_x266)) {
          auto _mls_x271 = _mls_add_default_case1_default_case0(_mls_x266, _mls_x268);
          auto _mls_x272 = _mls_add(_mls_x263, _mls_x271);
          _mls_retval = _mls_x272;
        } else {
          auto _mls_x269 = _mls_add_default_case1_default_default(_mls_x266, _mls_x268);
          auto _mls_x270 = _mls_add(_mls_x263, _mls_x269);
          _mls_retval = _mls_x270;
        }
      }
    }
  } else {
    auto _mls_x261 = _mlsValue::create<_mls_Add>(_mls_x260, _mls_x262);
    _mls_retval = _mls_x261;
  }
  return _mls_retval;
}
_mlsValue _mls_add_default_case1_default_case0(_mlsValue _mls_x279, _mlsValue _mls_x281) {
  _mlsValue _mls_retval;
  auto _mls_x278 = _mlsValue::cast<_mls_Add>(_mls_x279)->_mls_e1;
  auto _mls_x280 = _mlsValue::cast<_mls_Add>(_mls_x279)->_mls_e2;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x280)) {
    auto _mls_x297 = _mls_add_case0(_mls_x280, _mls_x281);
    auto _mls_x298 = _mls_add(_mls_x278, _mls_x297);
    _mls_retval = _mls_x298;
  } else {
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x281)) {
      auto _mls_x294 = _mlsValue::cast<_mls_Val>(_mls_x281)->_mls_n;
      auto _mls_x295 = _mls_add_default_case0_sr_post(_mls_x294, _mls_x280);
      auto _mls_x296 = _mls_add(_mls_x278, _mls_x295);
      _mls_retval = _mls_x296;
    } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x281)) {
      auto [_mls_x286, _mls_x287, _mls_x288, _mls_x289] = _mls_add_default_case1_pre(_mls_x281, _mls_x280);
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x286)) {
        auto _mls_x292 = _mls_add_default_case1_case0(_mls_x286, _mls_x287, _mls_x288);
        auto _mls_x293 = _mls_add(_mls_x278, _mls_x292);
        _mls_retval = _mls_x293;
      } else {
        auto _mls_x290 = _mls_add_default_case1_default(_mls_x287, _mls_x289);
        auto _mls_x291 = _mls_add(_mls_x278, _mls_x290);
        _mls_retval = _mls_x291;
      }
    } else {
      if (_mlsValue::isValueOf<_mls_Add>(_mls_x280)) {
        auto _mls_x284 = _mls_add_default_default_case01(_mls_x280, _mls_x281);
        auto _mls_x285 = _mls_add(_mls_x278, _mls_x284);
        _mls_retval = _mls_x285;
      } else {
        auto _mls_x282 = _mls_add_default_default_default(_mls_x280, _mls_x281);
        auto _mls_x283 = _mls_add(_mls_x278, _mls_x282);
        _mls_retval = _mls_x283;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_add_default_case1_default_default(_mlsValue _mls_x300, _mlsValue _mls_x301) {
  _mlsValue _mls_retval;
  auto _mls_x299 = _mlsValue::create<_mls_Add>(_mls_x300, _mls_x301);
  _mls_retval = _mls_x299;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_add_default_case1_pre1(_mlsValue _mls_x303, _mlsValue _mls_x305) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x302 = _mlsValue::cast<_mls_Add>(_mls_x303)->_mls_e1;
  auto _mls_x304 = _mlsValue::cast<_mls_Add>(_mls_x303)->_mls_e2;
  _mls_retval = std::make_tuple(_mls_x302, _mls_x305, _mls_x304, _mls_x303);
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_add_default_case1_pre(_mlsValue _mls_x307, _mlsValue _mls_x309) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x306 = _mlsValue::cast<_mls_Add>(_mls_x307)->_mls_e1;
  auto _mls_x308 = _mlsValue::cast<_mls_Add>(_mls_x307)->_mls_e2;
  _mls_retval = std::make_tuple(_mls_x306, _mls_x309, _mls_x308, _mls_x307);
  return _mls_retval;
}
_mlsValue _mls_add_default_default_case02(_mlsValue _mls_x311, _mlsValue _mls_x313) {
  _mlsValue _mls_retval;
  auto _mls_x310 = _mlsValue::cast<_mls_Add>(_mls_x311)->_mls_e1;
  auto _mls_x312 = _mlsValue::cast<_mls_Add>(_mls_x311)->_mls_e2;
  _mls_retval = _mls_add_default_default_case0_sr_post(_mls_x312, _mls_x313, _mls_x310);
  return _mls_retval;
}
_mlsValue _mls_add_default_default_case0(_mlsValue _mls_x315, _mlsValue _mls_x317) {
  _mlsValue _mls_retval;
  auto _mls_x314 = _mlsValue::cast<_mls_Add>(_mls_x315)->_mls_e1;
  auto _mls_x316 = _mlsValue::cast<_mls_Add>(_mls_x315)->_mls_e2;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x316)) {
    auto _mls_x333 = _mls_add_case0(_mls_x316, _mls_x317);
    auto _mls_x334 = _mls_add(_mls_x314, _mls_x333);
    _mls_retval = _mls_x334;
  } else {
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x317)) {
      auto _mls_x330 = _mlsValue::cast<_mls_Val>(_mls_x317)->_mls_n;
      auto _mls_x331 = _mls_add_default_case0_sr_post(_mls_x330, _mls_x316);
      auto _mls_x332 = _mls_add(_mls_x314, _mls_x331);
      _mls_retval = _mls_x332;
    } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x317)) {
      auto [_mls_x322, _mls_x323, _mls_x324, _mls_x325] = _mls_add_default_case1_pre(_mls_x317, _mls_x316);
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x322)) {
        auto _mls_x328 = _mls_add_default_case1_case02(_mls_x322, _mls_x323, _mls_x324);
        auto _mls_x329 = _mls_add(_mls_x314, _mls_x328);
        _mls_retval = _mls_x329;
      } else {
        auto _mls_x326 = _mls_add_default_case1_default(_mls_x323, _mls_x325);
        auto _mls_x327 = _mls_add(_mls_x314, _mls_x326);
        _mls_retval = _mls_x327;
      }
    } else {
      if (_mlsValue::isValueOf<_mls_Add>(_mls_x316)) {
        auto _mls_x320 = _mls_add_default_default_case02(_mls_x316, _mls_x317);
        auto _mls_x321 = _mls_add(_mls_x314, _mls_x320);
        _mls_retval = _mls_x321;
      } else {
        auto _mls_x318 = _mls_add_default_default_default(_mls_x316, _mls_x317);
        auto _mls_x319 = _mls_add(_mls_x314, _mls_x318);
        _mls_retval = _mls_x319;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_add_default_default_case01(_mlsValue _mls_x336, _mlsValue _mls_x338) {
  _mlsValue _mls_retval;
  auto _mls_x335 = _mlsValue::cast<_mls_Add>(_mls_x336)->_mls_e1;
  auto _mls_x337 = _mlsValue::cast<_mls_Add>(_mls_x336)->_mls_e2;
  _mls_retval = _mls_add_default_default_case0_sr_post(_mls_x337, _mls_x338, _mls_x335);
  return _mls_retval;
}
_mlsValue _mls_add_default_default_case0_sr_post(_mlsValue _mls_x339, _mlsValue _mls_x340, _mlsValue _mls_x342) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x339)) {
    auto _mls_x357 = _mls_add_case01(_mls_x339, _mls_x340);
    auto _mls_x358 = _mls_add(_mls_x342, _mls_x357);
    _mls_retval = _mls_x358;
  } else {
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x340)) {
      auto _mls_x354 = _mlsValue::cast<_mls_Val>(_mls_x340)->_mls_n;
      auto _mls_x355 = _mls_add_default_case0_sr_post1(_mls_x354, _mls_x339);
      auto _mls_x356 = _mls_add(_mls_x342, _mls_x355);
      _mls_retval = _mls_x356;
    } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x340)) {
      auto [_mls_x346, _mls_x347, _mls_x348, _mls_x349] = _mls_add_default_case1_pre1(_mls_x340, _mls_x339);
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x346)) {
        auto _mls_x352 = _mls_add_default_case1_case01(_mls_x346, _mls_x347, _mls_x348);
        auto _mls_x353 = _mls_add(_mls_x342, _mls_x352);
        _mls_retval = _mls_x353;
      } else {
        auto _mls_x350 = _mls_add_default_case1_default1(_mls_x347, _mls_x349);
        auto _mls_x351 = _mls_add(_mls_x342, _mls_x350);
        _mls_retval = _mls_x351;
      }
    } else {
      if (_mlsValue::isValueOf<_mls_Add>(_mls_x339)) {
        auto _mls_x344 = _mls_add_default_default_case0(_mls_x339, _mls_x340);
        auto _mls_x345 = _mls_add(_mls_x342, _mls_x344);
        _mls_retval = _mls_x345;
      } else {
        auto _mls_x341 = _mls_add_default_default_default1(_mls_x339, _mls_x340);
        auto _mls_x343 = _mls_add(_mls_x342, _mls_x341);
        _mls_retval = _mls_x343;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_add_default_default_default(_mlsValue _mls_x360, _mlsValue _mls_x361) {
  _mlsValue _mls_retval;
  auto _mls_x359 = _mlsValue::create<_mls_Add>(_mls_x360, _mls_x361);
  _mls_retval = _mls_x359;
  return _mls_retval;
}
_mlsValue _mls_add_default_default_default1(_mlsValue _mls_x363, _mlsValue _mls_x364) {
  _mlsValue _mls_retval;
  auto _mls_x362 = _mlsValue::create<_mls_Add>(_mls_x363, _mls_x364);
  _mls_retval = _mls_x362;
  return _mls_retval;
}
_mlsValue _mls_count(_mlsValue _mls_e3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_e3)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else if (_mlsValue::isValueOf<_mls_Var>(_mls_e3)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_e3)) {
    auto _mls_x45 = _mlsValue::cast<_mls_Add>(_mls_e3)->_mls_e1;
    auto _mls_x46 = _mlsValue::cast<_mls_Add>(_mls_e3)->_mls_e2;
    auto _mls_x47 = _mls_count(_mls_x45);
    auto _mls_x48 = _mls_count(_mls_x46);
    auto _mls_x49 = (_mls_x47 + _mls_x48);
    _mls_retval = _mls_x49;
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_e3)) {
    auto _mls_x40 = _mlsValue::cast<_mls_Mul>(_mls_e3)->_mls_e1;
    auto _mls_x41 = _mlsValue::cast<_mls_Mul>(_mls_e3)->_mls_e2;
    auto _mls_x42 = _mls_count(_mls_x40);
    auto _mls_x43 = _mls_count(_mls_x41);
    auto _mls_x44 = (_mls_x42 + _mls_x43);
    _mls_retval = _mls_x44;
  } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_e3)) {
    auto _mls_x35 = _mlsValue::cast<_mls_Pow>(_mls_e3)->_mls_e1;
    auto _mls_x36 = _mlsValue::cast<_mls_Pow>(_mls_e3)->_mls_e2;
    auto _mls_x37 = _mls_count(_mls_x35);
    auto _mls_x38 = _mls_count(_mls_x36);
    auto _mls_x39 = (_mls_x37 + _mls_x38);
    _mls_retval = _mls_x39;
  } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_e3)) {
    auto _mls_x33 = _mlsValue::cast<_mls_Ln>(_mls_e3)->_mls_e;
    auto _mls_x34 = _mls_count(_mls_x33);
    _mls_retval = _mls_x34;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_d_case0() {
  _mlsValue _mls_retval;
  auto _mls_x365 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
  _mls_retval = _mls_x365;
  return _mls_retval;
}
_mlsValue _mls_d_case1(_mlsValue _mls_x367, _mlsValue _mls_x368) {
  _mlsValue _mls_retval;
  auto _mls_x366 = _mlsValue::cast<_mls_Var>(_mls_x367)->_mls_x;
  _mls_retval = _mls_d_case1_sr_post(_mls_x368, _mls_x366);
  return _mls_retval;
}
_mlsValue _mls_d_case11(_mlsValue _mls_x370, _mlsValue _mls_x371) {
  _mlsValue _mls_retval;
  auto _mls_x369 = _mlsValue::cast<_mls_Var>(_mls_x370)->_mls_x;
  _mls_retval = _mls_d_case1_sr_post(_mls_x371, _mls_x369);
  return _mls_retval;
}
_mlsValue _mls_d_case12(_mlsValue _mls_x373, _mlsValue _mls_x374) {
  _mlsValue _mls_retval;
  auto _mls_x372 = _mlsValue::cast<_mls_Var>(_mls_x373)->_mls_x;
  _mls_retval = _mls_d_case1_sr_post(_mls_x374, _mls_x372);
  return _mls_retval;
}
_mlsValue _mls_d_case1_sr_post(_mlsValue _mls_x376, _mlsValue _mls_x377) {
  _mlsValue _mls_retval;
  auto _mls_x375 = (_mls_x376 == _mls_x377);
  if (_mlsValue::isIntLit(_mls_x375, 1)) {
    auto _mls_x379 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(1));
    _mls_retval = _mls_x379;
  } else {
    auto _mls_x378 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
    _mls_retval = _mls_x378;
  }
  return _mls_retval;
}
_mlsValue _mls_d_case2(_mlsValue _mls_x381, _mlsValue _mls_x383) {
  _mlsValue _mls_retval;
  auto _mls_x380 = _mlsValue::cast<_mls_Add>(_mls_x381)->_mls_e1;
  auto _mls_x382 = _mlsValue::cast<_mls_Add>(_mls_x381)->_mls_e2;
  _mls_retval = _mls_d_case2_sr_post(_mls_x383, _mls_x380, _mls_x382);
  return _mls_retval;
}
_mlsValue _mls_d_case21(_mlsValue _mls_x385, _mlsValue _mls_x387) {
  _mlsValue _mls_retval;
  auto _mls_x384 = _mlsValue::cast<_mls_Add>(_mls_x385)->_mls_e1;
  auto _mls_x386 = _mlsValue::cast<_mls_Add>(_mls_x385)->_mls_e2;
  _mls_retval = _mls_d_case2_sr_post(_mls_x387, _mls_x384, _mls_x386);
  return _mls_retval;
}
_mlsValue _mls_d_case22(_mlsValue _mls_x389, _mlsValue _mls_x391) {
  _mlsValue _mls_retval;
  auto _mls_x388 = _mlsValue::cast<_mls_Add>(_mls_x389)->_mls_e1;
  auto _mls_x390 = _mlsValue::cast<_mls_Add>(_mls_x389)->_mls_e2;
  _mls_retval = _mls_d_case2_sr_post(_mls_x391, _mls_x388, _mls_x390);
  return _mls_retval;
}
_mlsValue _mls_d_case2_sr_post(_mlsValue _mls_x393, _mlsValue _mls_x392, _mlsValue _mls_x394) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x392)) {
    _mls_retval = _mls_d_case2_sr_post_case0(_mls_x394, _mls_x393);
  } else if (_mlsValue::isValueOf<_mls_Var>(_mls_x392)) {
    _mls_retval = _mls_d_case2_sr_post_case1(_mls_x392, _mls_x393, _mls_x394);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x392)) {
    _mls_retval = _mls_d_case2_sr_post_case2(_mls_x392, _mls_x393, _mls_x394);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x392)) {
    _mls_retval = _mls_d_case2_sr_post_case3(_mls_x392, _mls_x393, _mls_x394);
  } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_x392)) {
    _mls_retval = _mls_d_case2_sr_post_case4(_mls_x392, _mls_x393, _mls_x394);
  } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_x392)) {
    _mls_retval = _mls_d_case2_sr_post_case5(_mls_x392, _mls_x393, _mls_x394);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_d_case2_sr_post_caller_post(_mlsValue _mls_x395, _mlsValue _mls_x397, _mlsValue _mls_x396) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x395)) {
    _mls_retval = _mls_d_case2_sr_post_caller_post_case0(_mls_x397);
  } else if (_mlsValue::isValueOf<_mls_Var>(_mls_x395)) {
    _mls_retval = _mls_d_case2_sr_post_caller_post_case1(_mls_x395, _mls_x396, _mls_x397);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x395)) {
    _mls_retval = _mls_d_case2_sr_post_caller_post_case2(_mls_x395, _mls_x396, _mls_x397);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x395)) {
    _mls_retval = _mls_d_case2_sr_post_caller_post_case3(_mls_x395, _mls_x396, _mls_x397);
  } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_x395)) {
    _mls_retval = _mls_d_case2_sr_post_caller_post_case4(_mls_x395, _mls_x396, _mls_x397);
  } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_x395)) {
    _mls_retval = _mls_d_case2_sr_post_caller_post_case5(_mls_x395, _mls_x396, _mls_x397);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_d_case2_sr_post_caller_post_case0(_mlsValue _mls_x399) {
  _mlsValue _mls_retval;
  auto _mls_x398 = _mls_d_case0();
  auto _mls_x400 = _mls_add(_mls_x399, _mls_x398);
  _mls_retval = _mls_x400;
  return _mls_retval;
}
_mlsValue _mls_d_case2_sr_post_caller_post_case1(_mlsValue _mls_x401, _mlsValue _mls_x402, _mlsValue _mls_x404) {
  _mlsValue _mls_retval;
  auto _mls_x403 = _mls_d_case11(_mls_x401, _mls_x402);
  auto _mls_x405 = _mls_add(_mls_x404, _mls_x403);
  _mls_retval = _mls_x405;
  return _mls_retval;
}
_mlsValue _mls_d_case2_sr_post_caller_post_case2(_mlsValue _mls_x406, _mlsValue _mls_x407, _mlsValue _mls_x409) {
  _mlsValue _mls_retval;
  auto _mls_x408 = _mls_d_case22(_mls_x406, _mls_x407);
  auto _mls_x410 = _mls_add(_mls_x409, _mls_x408);
  _mls_retval = _mls_x410;
  return _mls_retval;
}
_mlsValue _mls_d_case2_sr_post_caller_post_case3(_mlsValue _mls_x411, _mlsValue _mls_x412, _mlsValue _mls_x414) {
  _mlsValue _mls_retval;
  auto _mls_x413 = _mls_d_case3(_mls_x411, _mls_x412);
  auto _mls_x415 = _mls_add(_mls_x414, _mls_x413);
  _mls_retval = _mls_x415;
  return _mls_retval;
}
_mlsValue _mls_d_case2_sr_post_caller_post_case4(_mlsValue _mls_x416, _mlsValue _mls_x417, _mlsValue _mls_x419) {
  _mlsValue _mls_retval;
  auto _mls_x418 = _mls_d_case4(_mls_x416, _mls_x417);
  auto _mls_x420 = _mls_add(_mls_x419, _mls_x418);
  _mls_retval = _mls_x420;
  return _mls_retval;
}
_mlsValue _mls_d_case2_sr_post_caller_post_case5(_mlsValue _mls_x421, _mlsValue _mls_x422, _mlsValue _mls_x424) {
  _mlsValue _mls_retval;
  auto _mls_x423 = _mls_d_case5(_mls_x421, _mls_x422);
  auto _mls_x425 = _mls_add(_mls_x424, _mls_x423);
  _mls_retval = _mls_x425;
  return _mls_retval;
}
_mlsValue _mls_d_case2_sr_post_case0(_mlsValue _mls_x427, _mlsValue _mls_x428) {
  _mlsValue _mls_retval;
  auto _mls_x426 = _mls_d_case0();
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x427)) {
    _mls_retval = _mls_d_case2_sr_post_caller_post_case0(_mls_x426);
  } else if (_mlsValue::isValueOf<_mls_Var>(_mls_x427)) {
    _mls_retval = _mls_d_case2_sr_post_caller_post_case1(_mls_x427, _mls_x428, _mls_x426);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x427)) {
    _mls_retval = _mls_d_case2_sr_post_caller_post_case2(_mls_x427, _mls_x428, _mls_x426);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x427)) {
    _mls_retval = _mls_d_case2_sr_post_caller_post_case3(_mls_x427, _mls_x428, _mls_x426);
  } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_x427)) {
    _mls_retval = _mls_d_case2_sr_post_caller_post_case4(_mls_x427, _mls_x428, _mls_x426);
  } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_x427)) {
    _mls_retval = _mls_d_case2_sr_post_caller_post_case5(_mls_x427, _mls_x428, _mls_x426);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_d_case2_sr_post_case1(_mlsValue _mls_x430, _mlsValue _mls_x431, _mlsValue _mls_x433) {
  _mlsValue _mls_retval;
  auto _mls_x429 = _mlsValue::cast<_mls_Var>(_mls_x430)->_mls_x;
  auto _mls_x432 = _mls_d_case1_sr_post(_mls_x431, _mls_x429);
  _mls_retval = _mls_d_case2_sr_post_caller_post(_mls_x433, _mls_x432, _mls_x431);
  return _mls_retval;
}
_mlsValue _mls_d_case2_sr_post_case2(_mlsValue _mls_x435, _mlsValue _mls_x437, _mlsValue _mls_x439) {
  _mlsValue _mls_retval;
  auto _mls_x434 = _mlsValue::cast<_mls_Add>(_mls_x435)->_mls_e1;
  auto _mls_x436 = _mlsValue::cast<_mls_Add>(_mls_x435)->_mls_e2;
  auto _mls_x438 = _mls_d_case2_sr_post(_mls_x437, _mls_x434, _mls_x436);
  _mls_retval = _mls_d_case2_sr_post_caller_post(_mls_x439, _mls_x438, _mls_x437);
  return _mls_retval;
}
_mlsValue _mls_d_case2_sr_post_case3(_mlsValue _mls_x441, _mlsValue _mls_x443, _mlsValue _mls_x445) {
  _mlsValue _mls_retval;
  auto _mls_x440 = _mlsValue::cast<_mls_Mul>(_mls_x441)->_mls_e1;
  auto _mls_x442 = _mlsValue::cast<_mls_Mul>(_mls_x441)->_mls_e2;
  auto _mls_x444 = _mls_d_case3_sr_post(_mls_x443, _mls_x442, _mls_x440);
  _mls_retval = _mls_d_case2_sr_post_caller_post(_mls_x445, _mls_x444, _mls_x443);
  return _mls_retval;
}
_mlsValue _mls_d_case2_sr_post_case4(_mlsValue _mls_x447, _mlsValue _mls_x449, _mlsValue _mls_x451) {
  _mlsValue _mls_retval;
  auto _mls_x446 = _mlsValue::cast<_mls_Pow>(_mls_x447)->_mls_e1;
  auto _mls_x448 = _mlsValue::cast<_mls_Pow>(_mls_x447)->_mls_e2;
  auto _mls_x450 = _mls_d_case4_sr_post(_mls_x446, _mls_x448, _mls_x449);
  _mls_retval = _mls_d_case2_sr_post_caller_post(_mls_x451, _mls_x450, _mls_x449);
  return _mls_retval;
}
_mlsValue _mls_d_case2_sr_post_case5(_mlsValue _mls_x453, _mlsValue _mls_x454, _mlsValue _mls_x456) {
  _mlsValue _mls_retval;
  auto _mls_x452 = _mlsValue::cast<_mls_Ln>(_mls_x453)->_mls_e;
  auto _mls_x455 = _mls_d_case5_sr_post(_mls_x454, _mls_x452);
  _mls_retval = _mls_d_case2_sr_post_caller_post(_mls_x456, _mls_x455, _mls_x454);
  return _mls_retval;
}
_mlsValue _mls_d_case31(_mlsValue _mls_x458, _mlsValue _mls_x460) {
  _mlsValue _mls_retval;
  auto _mls_x457 = _mlsValue::cast<_mls_Mul>(_mls_x458)->_mls_e1;
  auto _mls_x459 = _mlsValue::cast<_mls_Mul>(_mls_x458)->_mls_e2;
  _mls_retval = _mls_d_case3_sr_post(_mls_x460, _mls_x459, _mls_x457);
  return _mls_retval;
}
_mlsValue _mls_d_case3(_mlsValue _mls_x462, _mlsValue _mls_x464) {
  _mlsValue _mls_retval;
  auto _mls_x461 = _mlsValue::cast<_mls_Mul>(_mls_x462)->_mls_e1;
  auto _mls_x463 = _mlsValue::cast<_mls_Mul>(_mls_x462)->_mls_e2;
  _mls_retval = _mls_d_case3_sr_post(_mls_x464, _mls_x463, _mls_x461);
  return _mls_retval;
}
_mlsValue _mls_d_case32(_mlsValue _mls_x466, _mlsValue _mls_x468) {
  _mlsValue _mls_retval;
  auto _mls_x465 = _mlsValue::cast<_mls_Mul>(_mls_x466)->_mls_e1;
  auto _mls_x467 = _mlsValue::cast<_mls_Mul>(_mls_x466)->_mls_e2;
  _mls_retval = _mls_d_case3_sr_post(_mls_x468, _mls_x467, _mls_x465);
  return _mls_retval;
}
_mlsValue _mls_d_case3_sr_post(_mlsValue _mls_x470, _mlsValue _mls_x469, _mlsValue _mls_x471) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x469)) {
    _mls_retval = _mls_d_case3_sr_post_case0(_mls_x471, _mls_x470, _mls_x469);
  } else if (_mlsValue::isValueOf<_mls_Var>(_mls_x469)) {
    _mls_retval = _mls_d_case3_sr_post_case1(_mls_x469, _mls_x470, _mls_x471);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x469)) {
    _mls_retval = _mls_d_case3_sr_post_case2(_mls_x469, _mls_x470, _mls_x471);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x469)) {
    _mls_retval = _mls_d_case3_sr_post_case3(_mls_x469, _mls_x470, _mls_x471);
  } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_x469)) {
    _mls_retval = _mls_d_case3_sr_post_case4(_mls_x469, _mls_x470, _mls_x471);
  } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_x469)) {
    _mls_retval = _mls_d_case3_sr_post_case5(_mls_x469, _mls_x470, _mls_x471);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_d_case3_sr_post_caller_post_post(_mlsValue _mls_x473, _mlsValue _mls_x472, _mlsValue _mls_x475, _mlsValue _mls_x476) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x472)) {
    auto _mls_x481 = _mls_d_case0();
    _mls_retval = _mls_d_case3_sr_post_caller_post_post_caller_post(_mls_x475, _mls_x481, _mls_x476);
  } else if (_mlsValue::isValueOf<_mls_Var>(_mls_x472)) {
    auto _mls_x480 = _mls_d_case1(_mls_x472, _mls_x473);
    _mls_retval = _mls_d_case3_sr_post_caller_post_post_caller_post(_mls_x475, _mls_x480, _mls_x476);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x472)) {
    auto _mls_x479 = _mls_d_case21(_mls_x472, _mls_x473);
    _mls_retval = _mls_d_case3_sr_post_caller_post_post_caller_post(_mls_x475, _mls_x479, _mls_x476);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x472)) {
    auto _mls_x478 = _mls_d_case31(_mls_x472, _mls_x473);
    _mls_retval = _mls_d_case3_sr_post_caller_post_post_caller_post(_mls_x475, _mls_x478, _mls_x476);
  } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_x472)) {
    auto _mls_x477 = _mls_d_case41(_mls_x472, _mls_x473);
    _mls_retval = _mls_d_case3_sr_post_caller_post_post_caller_post(_mls_x475, _mls_x477, _mls_x476);
  } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_x472)) {
    auto _mls_x474 = _mls_d_case51(_mls_x472, _mls_x473);
    _mls_retval = _mls_d_case3_sr_post_caller_post_post_caller_post(_mls_x475, _mls_x474, _mls_x476);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_d_case3_sr_post_caller_post_post_caller_post(_mlsValue _mls_x482, _mlsValue _mls_x483, _mlsValue _mls_x485) {
  _mlsValue _mls_retval;
  auto _mls_x484 = _mls_mul(_mls_x482, _mls_x483);
  auto _mls_x486 = _mls_add(_mls_x485, _mls_x484);
  _mls_retval = _mls_x486;
  return _mls_retval;
}
_mlsValue _mls_d_case3_sr_post_case0(_mlsValue _mls_x488, _mlsValue _mls_x490, _mlsValue _mls_x491) {
  _mlsValue _mls_retval;
  auto _mls_x487 = _mls_d_case0();
  auto _mls_x489 = _mls_mul(_mls_x488, _mls_x487);
  _mls_retval = _mls_d_case3_sr_post_caller_post_post(_mls_x490, _mls_x488, _mls_x491, _mls_x489);
  return _mls_retval;
}
_mlsValue _mls_d_case3_sr_post_case1(_mlsValue _mls_x493, _mlsValue _mls_x494, _mlsValue _mls_x496) {
  _mlsValue _mls_retval;
  auto _mls_x492 = _mlsValue::cast<_mls_Var>(_mls_x493)->_mls_x;
  auto _mls_x495 = _mls_d_case1_sr_post(_mls_x494, _mls_x492);
  auto _mls_x497 = _mls_mul(_mls_x496, _mls_x495);
  _mls_retval = _mls_d_case3_sr_post_caller_post_post(_mls_x494, _mls_x496, _mls_x493, _mls_x497);
  return _mls_retval;
}
_mlsValue _mls_d_case3_sr_post_case2(_mlsValue _mls_x499, _mlsValue _mls_x501, _mlsValue _mls_x503) {
  _mlsValue _mls_retval;
  auto _mls_x498 = _mlsValue::cast<_mls_Add>(_mls_x499)->_mls_e1;
  auto _mls_x500 = _mlsValue::cast<_mls_Add>(_mls_x499)->_mls_e2;
  auto _mls_x502 = _mls_d_case2_sr_post(_mls_x501, _mls_x498, _mls_x500);
  auto _mls_x504 = _mls_mul(_mls_x503, _mls_x502);
  _mls_retval = _mls_d_case3_sr_post_caller_post_post(_mls_x501, _mls_x503, _mls_x499, _mls_x504);
  return _mls_retval;
}
_mlsValue _mls_d_case3_sr_post_case3(_mlsValue _mls_x506, _mlsValue _mls_x508, _mlsValue _mls_x510) {
  _mlsValue _mls_retval;
  auto _mls_x505 = _mlsValue::cast<_mls_Mul>(_mls_x506)->_mls_e1;
  auto _mls_x507 = _mlsValue::cast<_mls_Mul>(_mls_x506)->_mls_e2;
  auto _mls_x509 = _mls_d_case3_sr_post(_mls_x508, _mls_x507, _mls_x505);
  auto _mls_x511 = _mls_mul(_mls_x510, _mls_x509);
  _mls_retval = _mls_d_case3_sr_post_caller_post_post(_mls_x508, _mls_x510, _mls_x506, _mls_x511);
  return _mls_retval;
}
_mlsValue _mls_d_case3_sr_post_case4(_mlsValue _mls_x513, _mlsValue _mls_x515, _mlsValue _mls_x517) {
  _mlsValue _mls_retval;
  auto _mls_x512 = _mlsValue::cast<_mls_Pow>(_mls_x513)->_mls_e1;
  auto _mls_x514 = _mlsValue::cast<_mls_Pow>(_mls_x513)->_mls_e2;
  auto _mls_x516 = _mls_d_case4_sr_post(_mls_x512, _mls_x514, _mls_x515);
  auto _mls_x518 = _mls_mul(_mls_x517, _mls_x516);
  _mls_retval = _mls_d_case3_sr_post_caller_post_post(_mls_x515, _mls_x517, _mls_x513, _mls_x518);
  return _mls_retval;
}
_mlsValue _mls_d_case3_sr_post_case5(_mlsValue _mls_x520, _mlsValue _mls_x521, _mlsValue _mls_x523) {
  _mlsValue _mls_retval;
  auto _mls_x519 = _mlsValue::cast<_mls_Ln>(_mls_x520)->_mls_e;
  auto _mls_x522 = _mls_d_case5_sr_post(_mls_x521, _mls_x519);
  auto _mls_x524 = _mls_mul(_mls_x523, _mls_x522);
  _mls_retval = _mls_d_case3_sr_post_caller_post_post(_mls_x521, _mls_x523, _mls_x520, _mls_x524);
  return _mls_retval;
}
_mlsValue _mls_d_case42(_mlsValue _mls_x526, _mlsValue _mls_x528) {
  _mlsValue _mls_retval;
  auto _mls_x525 = _mlsValue::cast<_mls_Pow>(_mls_x526)->_mls_e1;
  auto _mls_x527 = _mlsValue::cast<_mls_Pow>(_mls_x526)->_mls_e2;
  _mls_retval = _mls_d_case4_sr_post(_mls_x525, _mls_x527, _mls_x528);
  return _mls_retval;
}
_mlsValue _mls_d_case41(_mlsValue _mls_x530, _mlsValue _mls_x532) {
  _mlsValue _mls_retval;
  auto _mls_x529 = _mlsValue::cast<_mls_Pow>(_mls_x530)->_mls_e1;
  auto _mls_x531 = _mlsValue::cast<_mls_Pow>(_mls_x530)->_mls_e2;
  _mls_retval = _mls_d_case4_sr_post(_mls_x529, _mls_x531, _mls_x532);
  return _mls_retval;
}
_mlsValue _mls_d_case4(_mlsValue _mls_x534, _mlsValue _mls_x536) {
  _mlsValue _mls_retval;
  auto _mls_x533 = _mlsValue::cast<_mls_Pow>(_mls_x534)->_mls_e1;
  auto _mls_x535 = _mlsValue::cast<_mls_Pow>(_mls_x534)->_mls_e2;
  _mls_retval = _mls_d_case4_sr_post(_mls_x533, _mls_x535, _mls_x536);
  return _mls_retval;
}
_mlsValue _mls_d_case4_caller_post_caller_post(_mlsValue _mls_x540, _mlsValue _mls_x543, _mlsValue _mls_x537, _mlsValue _mls_x542, _mlsValue _mls_x538, _mlsValue _mls_x541) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x537)) {
    auto _mls_x546 = _mls_mul_case0(_mls_x537, _mls_x538);
    _mls_retval = _mls_d_case4_caller_post_caller_post_caller_post(_mls_x546, _mls_x540, _mls_x541, _mls_x542, _mls_x543);
  } else {
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x538)) {
      auto _mls_x545 = _mls_mul_default_case0(_mls_x538, _mls_x537);
      _mls_retval = _mls_d_case4_caller_post_caller_post_caller_post(_mls_x545, _mls_x540, _mls_x541, _mls_x542, _mls_x543);
    } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x538)) {
      auto _mls_x544 = _mls_mul_default_case1(_mls_x538, _mls_x537);
      _mls_retval = _mls_d_case4_caller_post_caller_post_caller_post(_mls_x544, _mls_x540, _mls_x541, _mls_x542, _mls_x543);
    } else {
      auto _mls_x539 = _mls_mul_default_default(_mls_x537, _mls_x538);
      _mls_retval = _mls_d_case4_caller_post_caller_post_caller_post(_mls_x539, _mls_x540, _mls_x541, _mls_x542, _mls_x543);
    }
  }
  return _mls_retval;
}
_mlsValue _mls_d_case4_caller_post_caller_post_caller_post1(_mlsValue _mls_x551, _mlsValue _mls_x547, _mlsValue _mls_x550, _mlsValue _mls_x552, _mlsValue _mls_x548) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x547)) {
    auto _mls_x557 = _mls_d_case0();
    _mls_retval = _mls_d_case4_caller_post_caller_post_caller_post_caller_post(_mls_x550, _mls_x557, _mls_x551, _mls_x552);
  } else if (_mlsValue::isValueOf<_mls_Var>(_mls_x547)) {
    auto _mls_x556 = _mls_d_case12(_mls_x547, _mls_x548);
    _mls_retval = _mls_d_case4_caller_post_caller_post_caller_post_caller_post(_mls_x550, _mls_x556, _mls_x551, _mls_x552);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x547)) {
    auto _mls_x555 = _mls_d_case2(_mls_x547, _mls_x548);
    _mls_retval = _mls_d_case4_caller_post_caller_post_caller_post_caller_post(_mls_x550, _mls_x555, _mls_x551, _mls_x552);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x547)) {
    auto _mls_x554 = _mls_d_case32(_mls_x547, _mls_x548);
    _mls_retval = _mls_d_case4_caller_post_caller_post_caller_post_caller_post(_mls_x550, _mls_x554, _mls_x551, _mls_x552);
  } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_x547)) {
    auto _mls_x553 = _mls_d_case42(_mls_x547, _mls_x548);
    _mls_retval = _mls_d_case4_caller_post_caller_post_caller_post_caller_post(_mls_x550, _mls_x553, _mls_x551, _mls_x552);
  } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_x547)) {
    auto _mls_x549 = _mls_d_case52(_mls_x547, _mls_x548);
    _mls_retval = _mls_d_case4_caller_post_caller_post_caller_post_caller_post(_mls_x550, _mls_x549, _mls_x551, _mls_x552);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_d_case4_caller_post_caller_post_caller_post(_mlsValue _mls_x563, _mlsValue _mls_x558, _mlsValue _mls_x560, _mlsValue _mls_x564, _mlsValue _mls_x561) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x558)) {
    auto _mls_x570 = _mls_ln_case0(_mls_x558);
    _mls_retval = _mls_d_case4_caller_post_caller_post_caller_post1(_mls_x563, _mls_x560, _mls_x570, _mls_x564, _mls_x561);
  } else {
    auto _mls_x559 = _mls_ln_default(_mls_x558);
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x560)) {
      auto _mls_x569 = _mls_d_case0();
      _mls_retval = _mls_d_case4_caller_post_caller_post_caller_post_caller_post(_mls_x559, _mls_x569, _mls_x563, _mls_x564);
    } else if (_mlsValue::isValueOf<_mls_Var>(_mls_x560)) {
      auto _mls_x568 = _mls_d_case12(_mls_x560, _mls_x561);
      _mls_retval = _mls_d_case4_caller_post_caller_post_caller_post_caller_post(_mls_x559, _mls_x568, _mls_x563, _mls_x564);
    } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x560)) {
      auto _mls_x567 = _mls_d_case2(_mls_x560, _mls_x561);
      _mls_retval = _mls_d_case4_caller_post_caller_post_caller_post_caller_post(_mls_x559, _mls_x567, _mls_x563, _mls_x564);
    } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x560)) {
      auto _mls_x566 = _mls_d_case32(_mls_x560, _mls_x561);
      _mls_retval = _mls_d_case4_caller_post_caller_post_caller_post_caller_post(_mls_x559, _mls_x566, _mls_x563, _mls_x564);
    } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_x560)) {
      auto _mls_x565 = _mls_d_case42(_mls_x560, _mls_x561);
      _mls_retval = _mls_d_case4_caller_post_caller_post_caller_post_caller_post(_mls_x559, _mls_x565, _mls_x563, _mls_x564);
    } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_x560)) {
      auto _mls_x562 = _mls_d_case52(_mls_x560, _mls_x561);
      _mls_retval = _mls_d_case4_caller_post_caller_post_caller_post_caller_post(_mls_x559, _mls_x562, _mls_x563, _mls_x564);
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  }
  return _mls_retval;
}
_mlsValue _mls_d_case4_caller_post_caller_post_caller_post_caller_post(_mlsValue _mls_x571, _mlsValue _mls_x572, _mlsValue _mls_x574, _mlsValue _mls_x575) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x571)) {
    auto _mls_x576 = _mls_mul_case0(_mls_x571, _mls_x572);
    _mls_retval = _mls_d_case4_caller_post_caller_post_caller_post_caller_post_caller_post(_mls_x574, _mls_x576, _mls_x575);
  } else {
    auto _mls_x573 = _mls_mul_default(_mls_x572, _mls_x571);
    _mls_retval = _mls_d_case4_caller_post_caller_post_caller_post_caller_post_caller_post(_mls_x574, _mls_x573, _mls_x575);
  }
  return _mls_retval;
}
_mlsValue _mls_d_case4_caller_post_caller_post_caller_post_caller_post_caller_post(_mlsValue _mls_x577, _mlsValue _mls_x578, _mlsValue _mls_x580) {
  _mlsValue _mls_retval;
  auto _mls_x579 = _mls_add(_mls_x577, _mls_x578);
  auto _mls_x581 = _mls_mul(_mls_x580, _mls_x579);
  _mls_retval = _mls_x581;
  return _mls_retval;
}
_mlsValue _mls_d_case4_caller_post_post(_mlsValue _mls_x584, _mlsValue _mls_x586, _mlsValue _mls_x587, _mlsValue _mls_x588, _mlsValue _mls_x589) {
  _mlsValue _mls_retval;
  auto _mls_x582 = (-_mlsValue::fromIntLit(1));
  auto _mls_x583 = _mlsValue::create<_mls_Val>(_mls_x582);
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x584)) {
    auto _mls_x590 = _mls_pow_case0(_mls_x584, _mls_x583);
    _mls_retval = _mls_d_case4_caller_post_caller_post(_mls_x584, _mls_x586, _mls_x587, _mls_x588, _mls_x590, _mls_x589);
  } else {
    auto _mls_x585 = _mls_pow_default_case0(_mls_x583, _mls_x584);
    _mls_retval = _mls_d_case4_caller_post_caller_post(_mls_x584, _mls_x586, _mls_x587, _mls_x588, _mls_x585, _mls_x589);
  }
  return _mls_retval;
}
_mlsValue _mls_d_case4_sr_post(_mlsValue _mls_x591, _mlsValue _mls_x592, _mlsValue _mls_x593) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x591)) {
    auto _mls_x594 = _mls_pow_case0(_mls_x591, _mls_x592);
    _mls_retval = _mls_d_case4_sr_post_caller_post(_mls_x591, _mls_x592, _mls_x593, _mls_x594);
  } else {
    _mls_retval = _mls_d_case4_sr_post_default(_mls_x592, _mls_x591, _mls_x593);
  }
  return _mls_retval;
}
_mlsValue _mls_d_case4_sr_post_caller_post(_mlsValue _mls_x595, _mlsValue _mls_x599, _mlsValue _mls_x597, _mlsValue _mls_x601) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x595)) {
    auto _mls_x650 = _mls_d_case0();
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x599)) {
      auto _mls_x652 = _mls_mul_case0(_mls_x599, _mls_x650);
      _mls_retval = _mls_d_case4_caller_post_post(_mls_x595, _mls_x597, _mls_x652, _mls_x601, _mls_x599);
    } else {
      auto _mls_x651 = _mls_mul_default(_mls_x650, _mls_x599);
      _mls_retval = _mls_d_case4_caller_post_post(_mls_x595, _mls_x597, _mls_x651, _mls_x601, _mls_x599);
    }
  } else if (_mlsValue::isValueOf<_mls_Var>(_mls_x595)) {
    auto _mls_x646 = _mlsValue::cast<_mls_Var>(_mls_x595)->_mls_x;
    auto _mls_x647 = _mls_d_case1_sr_post(_mls_x597, _mls_x646);
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x599)) {
      auto _mls_x649 = _mls_mul_case0(_mls_x599, _mls_x647);
      _mls_retval = _mls_d_case4_caller_post_post(_mls_x595, _mls_x597, _mls_x649, _mls_x601, _mls_x599);
    } else {
      auto _mls_x648 = _mls_mul_default(_mls_x647, _mls_x599);
      _mls_retval = _mls_d_case4_caller_post_post(_mls_x595, _mls_x597, _mls_x648, _mls_x601, _mls_x599);
    }
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x595)) {
    auto _mls_x632 = _mlsValue::cast<_mls_Add>(_mls_x595)->_mls_e1;
    auto _mls_x633 = _mlsValue::cast<_mls_Add>(_mls_x595)->_mls_e2;
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x632)) {
      auto _mls_x644 = _mls_d_case2_sr_post_case0(_mls_x633, _mls_x597);
      auto _mls_x645 = _mls_mul(_mls_x599, _mls_x644);
      _mls_retval = _mls_d_case4_caller_post_post(_mls_x595, _mls_x597, _mls_x645, _mls_x601, _mls_x599);
    } else if (_mlsValue::isValueOf<_mls_Var>(_mls_x632)) {
      auto _mls_x642 = _mls_d_case2_sr_post_case1(_mls_x632, _mls_x597, _mls_x633);
      auto _mls_x643 = _mls_mul(_mls_x599, _mls_x642);
      _mls_retval = _mls_d_case4_caller_post_post(_mls_x595, _mls_x597, _mls_x643, _mls_x601, _mls_x599);
    } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x632)) {
      auto _mls_x640 = _mls_d_case2_sr_post_case2(_mls_x632, _mls_x597, _mls_x633);
      auto _mls_x641 = _mls_mul(_mls_x599, _mls_x640);
      _mls_retval = _mls_d_case4_caller_post_post(_mls_x595, _mls_x597, _mls_x641, _mls_x601, _mls_x599);
    } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x632)) {
      auto _mls_x638 = _mls_d_case2_sr_post_case3(_mls_x632, _mls_x597, _mls_x633);
      auto _mls_x639 = _mls_mul(_mls_x599, _mls_x638);
      _mls_retval = _mls_d_case4_caller_post_post(_mls_x595, _mls_x597, _mls_x639, _mls_x601, _mls_x599);
    } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_x632)) {
      auto _mls_x636 = _mls_d_case2_sr_post_case4(_mls_x632, _mls_x597, _mls_x633);
      auto _mls_x637 = _mls_mul(_mls_x599, _mls_x636);
      _mls_retval = _mls_d_case4_caller_post_post(_mls_x595, _mls_x597, _mls_x637, _mls_x601, _mls_x599);
    } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_x632)) {
      auto _mls_x634 = _mls_d_case2_sr_post_case5(_mls_x632, _mls_x597, _mls_x633);
      auto _mls_x635 = _mls_mul(_mls_x599, _mls_x634);
      _mls_retval = _mls_d_case4_caller_post_post(_mls_x595, _mls_x597, _mls_x635, _mls_x601, _mls_x599);
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x595)) {
    auto _mls_x618 = _mlsValue::cast<_mls_Mul>(_mls_x595)->_mls_e1;
    auto _mls_x619 = _mlsValue::cast<_mls_Mul>(_mls_x595)->_mls_e2;
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x619)) {
      auto _mls_x630 = _mls_d_case3_sr_post_case0(_mls_x618, _mls_x597, _mls_x619);
      auto _mls_x631 = _mls_mul(_mls_x599, _mls_x630);
      _mls_retval = _mls_d_case4_caller_post_post(_mls_x595, _mls_x597, _mls_x631, _mls_x601, _mls_x599);
    } else if (_mlsValue::isValueOf<_mls_Var>(_mls_x619)) {
      auto _mls_x628 = _mls_d_case3_sr_post_case1(_mls_x619, _mls_x597, _mls_x618);
      auto _mls_x629 = _mls_mul(_mls_x599, _mls_x628);
      _mls_retval = _mls_d_case4_caller_post_post(_mls_x595, _mls_x597, _mls_x629, _mls_x601, _mls_x599);
    } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x619)) {
      auto _mls_x626 = _mls_d_case3_sr_post_case2(_mls_x619, _mls_x597, _mls_x618);
      auto _mls_x627 = _mls_mul(_mls_x599, _mls_x626);
      _mls_retval = _mls_d_case4_caller_post_post(_mls_x595, _mls_x597, _mls_x627, _mls_x601, _mls_x599);
    } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x619)) {
      auto _mls_x624 = _mls_d_case3_sr_post_case3(_mls_x619, _mls_x597, _mls_x618);
      auto _mls_x625 = _mls_mul(_mls_x599, _mls_x624);
      _mls_retval = _mls_d_case4_caller_post_post(_mls_x595, _mls_x597, _mls_x625, _mls_x601, _mls_x599);
    } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_x619)) {
      auto _mls_x622 = _mls_d_case3_sr_post_case4(_mls_x619, _mls_x597, _mls_x618);
      auto _mls_x623 = _mls_mul(_mls_x599, _mls_x622);
      _mls_retval = _mls_d_case4_caller_post_post(_mls_x595, _mls_x597, _mls_x623, _mls_x601, _mls_x599);
    } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_x619)) {
      auto _mls_x620 = _mls_d_case3_sr_post_case5(_mls_x619, _mls_x597, _mls_x618);
      auto _mls_x621 = _mls_mul(_mls_x599, _mls_x620);
      _mls_retval = _mls_d_case4_caller_post_post(_mls_x595, _mls_x597, _mls_x621, _mls_x601, _mls_x599);
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_x595)) {
    auto _mls_x612 = _mlsValue::cast<_mls_Pow>(_mls_x595)->_mls_e1;
    auto _mls_x613 = _mlsValue::cast<_mls_Pow>(_mls_x595)->_mls_e2;
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x612)) {
      auto _mls_x616 = _mls_d_case4_sr_post_case0(_mls_x612, _mls_x613, _mls_x597);
      auto _mls_x617 = _mls_mul(_mls_x599, _mls_x616);
      _mls_retval = _mls_d_case4_caller_post_post(_mls_x595, _mls_x597, _mls_x617, _mls_x601, _mls_x599);
    } else {
      auto _mls_x614 = _mls_d_case4_sr_post_default(_mls_x613, _mls_x612, _mls_x597);
      auto _mls_x615 = _mls_mul(_mls_x599, _mls_x614);
      _mls_retval = _mls_d_case4_caller_post_post(_mls_x595, _mls_x597, _mls_x615, _mls_x601, _mls_x599);
    }
  } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_x595)) {
    auto _mls_x596 = _mlsValue::cast<_mls_Ln>(_mls_x595)->_mls_e;
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x596)) {
      auto _mls_x610 = _mls_d_case5_sr_post_case0(_mls_x596);
      auto _mls_x611 = _mls_mul(_mls_x599, _mls_x610);
      _mls_retval = _mls_d_case4_caller_post_post(_mls_x595, _mls_x597, _mls_x611, _mls_x601, _mls_x599);
    } else if (_mlsValue::isValueOf<_mls_Var>(_mls_x596)) {
      auto _mls_x608 = _mls_d_case5_sr_post_case1(_mls_x596, _mls_x597);
      auto _mls_x609 = _mls_mul(_mls_x599, _mls_x608);
      _mls_retval = _mls_d_case4_caller_post_post(_mls_x595, _mls_x597, _mls_x609, _mls_x601, _mls_x599);
    } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x596)) {
      auto _mls_x606 = _mls_d_case5_sr_post_case2(_mls_x596, _mls_x597);
      auto _mls_x607 = _mls_mul(_mls_x599, _mls_x606);
      _mls_retval = _mls_d_case4_caller_post_post(_mls_x595, _mls_x597, _mls_x607, _mls_x601, _mls_x599);
    } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x596)) {
      auto _mls_x604 = _mls_d_case5_sr_post_case3(_mls_x596, _mls_x597);
      auto _mls_x605 = _mls_mul(_mls_x599, _mls_x604);
      _mls_retval = _mls_d_case4_caller_post_post(_mls_x595, _mls_x597, _mls_x605, _mls_x601, _mls_x599);
    } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_x596)) {
      auto _mls_x602 = _mls_d_case5_sr_post_case4(_mls_x596, _mls_x597);
      auto _mls_x603 = _mls_mul(_mls_x599, _mls_x602);
      _mls_retval = _mls_d_case4_caller_post_post(_mls_x595, _mls_x597, _mls_x603, _mls_x601, _mls_x599);
    } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_x596)) {
      auto _mls_x598 = _mls_d_case5_sr_post_case5(_mls_x596, _mls_x597);
      auto _mls_x600 = _mls_mul(_mls_x599, _mls_x598);
      _mls_retval = _mls_d_case4_caller_post_post(_mls_x595, _mls_x597, _mls_x600, _mls_x601, _mls_x599);
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_d_case4_sr_post_case0(_mlsValue _mls_x653, _mlsValue _mls_x654, _mlsValue _mls_x656) {
  _mlsValue _mls_retval;
  auto _mls_x655 = _mls_pow_case0(_mls_x653, _mls_x654);
  _mls_retval = _mls_d_case4_sr_post_caller_post(_mls_x653, _mls_x654, _mls_x656, _mls_x655);
  return _mls_retval;
}
_mlsValue _mls_d_case4_sr_post_default(_mlsValue _mls_x657, _mlsValue _mls_x658, _mlsValue _mls_x660) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x657)) {
    auto _mls_x661 = _mls_pow_default_case0(_mls_x657, _mls_x658);
    _mls_retval = _mls_d_case4_sr_post_caller_post(_mls_x658, _mls_x657, _mls_x660, _mls_x661);
  } else {
    auto _mls_x659 = _mls_pow_default_default(_mls_x658, _mls_x657);
    _mls_retval = _mls_d_case4_sr_post_caller_post(_mls_x658, _mls_x657, _mls_x660, _mls_x659);
  }
  return _mls_retval;
}
_mlsValue _mls_d_case51(_mlsValue _mls_x663, _mlsValue _mls_x664) {
  _mlsValue _mls_retval;
  auto _mls_x662 = _mlsValue::cast<_mls_Ln>(_mls_x663)->_mls_e;
  _mls_retval = _mls_d_case5_sr_post(_mls_x664, _mls_x662);
  return _mls_retval;
}
_mlsValue _mls_d_case5(_mlsValue _mls_x666, _mlsValue _mls_x667) {
  _mlsValue _mls_retval;
  auto _mls_x665 = _mlsValue::cast<_mls_Ln>(_mls_x666)->_mls_e;
  _mls_retval = _mls_d_case5_sr_post(_mls_x667, _mls_x665);
  return _mls_retval;
}
_mlsValue _mls_d_case52(_mlsValue _mls_x669, _mlsValue _mls_x670) {
  _mlsValue _mls_retval;
  auto _mls_x668 = _mlsValue::cast<_mls_Ln>(_mls_x669)->_mls_e;
  _mls_retval = _mls_d_case5_sr_post(_mls_x670, _mls_x668);
  return _mls_retval;
}
_mlsValue _mls_d_case5_sr_post(_mlsValue _mls_x672, _mlsValue _mls_x671) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x671)) {
    _mls_retval = _mls_d_case5_sr_post_case0(_mls_x671);
  } else if (_mlsValue::isValueOf<_mls_Var>(_mls_x671)) {
    _mls_retval = _mls_d_case5_sr_post_case1(_mls_x671, _mls_x672);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x671)) {
    _mls_retval = _mls_d_case5_sr_post_case2(_mls_x671, _mls_x672);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x671)) {
    _mls_retval = _mls_d_case5_sr_post_case3(_mls_x671, _mls_x672);
  } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_x671)) {
    _mls_retval = _mls_d_case5_sr_post_case4(_mls_x671, _mls_x672);
  } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_x671)) {
    _mls_retval = _mls_d_case5_sr_post_case5(_mls_x671, _mls_x672);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_d_case5_sr_post_caller_post(_mlsValue _mls_x673, _mlsValue _mls_x674) {
  _mlsValue _mls_retval;
  auto [_mls_x675, _mls_x676, _mls_x677] = _mls_d_case5_sr_post_caller_post_pre(_mls_x673, _mls_x674);
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x675)) {
    auto _mls_x680 = _mls_pow_case0(_mls_x675, _mls_x676);
    auto _mls_x681 = _mls_mul(_mls_x677, _mls_x680);
    _mls_retval = _mls_x681;
  } else {
    auto _mls_x678 = _mls_pow_default(_mls_x676, _mls_x675);
    auto _mls_x679 = _mls_mul(_mls_x677, _mls_x678);
    _mls_retval = _mls_x679;
  }
  return _mls_retval;
}
_mlsValue _mls_d_case5_sr_post_caller_post_case0(_mlsValue _mls_x682, _mlsValue _mls_x683, _mlsValue _mls_x685) {
  _mlsValue _mls_retval;
  auto _mls_x684 = _mls_pow_case0(_mls_x682, _mls_x683);
  auto _mls_x686 = _mls_mul(_mls_x685, _mls_x684);
  _mls_retval = _mls_x686;
  return _mls_retval;
}
_mlsValue _mls_d_case5_sr_post_caller_post_default(_mlsValue _mls_x687, _mlsValue _mls_x688, _mlsValue _mls_x690) {
  _mlsValue _mls_retval;
  auto _mls_x689 = _mls_pow_default(_mls_x687, _mls_x688);
  auto _mls_x691 = _mls_mul(_mls_x690, _mls_x689);
  _mls_retval = _mls_x691;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_d_case5_sr_post_caller_post_pre(_mlsValue _mls_x694, _mlsValue _mls_x695) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x692 = (-_mlsValue::fromIntLit(1));
  auto _mls_x693 = _mlsValue::create<_mls_Val>(_mls_x692);
  _mls_retval = std::make_tuple(_mls_x694, _mls_x693, _mls_x695);
  return _mls_retval;
}
_mlsValue _mls_d_case5_sr_post_case0(_mlsValue _mls_x697) {
  _mlsValue _mls_retval;
  auto _mls_x696 = _mls_d_case0();
  auto [_mls_x698, _mls_x699, _mls_x700] = _mls_d_case5_sr_post_caller_post_pre(_mls_x697, _mls_x696);
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x698)) {
    _mls_retval = _mls_d_case5_sr_post_caller_post_case0(_mls_x698, _mls_x699, _mls_x700);
  } else {
    _mls_retval = _mls_d_case5_sr_post_caller_post_default(_mls_x699, _mls_x698, _mls_x700);
  }
  return _mls_retval;
}
_mlsValue _mls_d_case5_sr_post_case1(_mlsValue _mls_x702, _mlsValue _mls_x703) {
  _mlsValue _mls_retval;
  auto _mls_x701 = _mlsValue::cast<_mls_Var>(_mls_x702)->_mls_x;
  auto _mls_x704 = _mls_d_case1_sr_post(_mls_x703, _mls_x701);
  _mls_retval = _mls_d_case5_sr_post_caller_post(_mls_x702, _mls_x704);
  return _mls_retval;
}
_mlsValue _mls_d_case5_sr_post_case2(_mlsValue _mls_x706, _mlsValue _mls_x708) {
  _mlsValue _mls_retval;
  auto _mls_x705 = _mlsValue::cast<_mls_Add>(_mls_x706)->_mls_e1;
  auto _mls_x707 = _mlsValue::cast<_mls_Add>(_mls_x706)->_mls_e2;
  auto _mls_x709 = _mls_d_case2_sr_post(_mls_x708, _mls_x705, _mls_x707);
  _mls_retval = _mls_d_case5_sr_post_caller_post(_mls_x706, _mls_x709);
  return _mls_retval;
}
_mlsValue _mls_d_case5_sr_post_case3(_mlsValue _mls_x711, _mlsValue _mls_x713) {
  _mlsValue _mls_retval;
  auto _mls_x710 = _mlsValue::cast<_mls_Mul>(_mls_x711)->_mls_e1;
  auto _mls_x712 = _mlsValue::cast<_mls_Mul>(_mls_x711)->_mls_e2;
  auto _mls_x714 = _mls_d_case3_sr_post(_mls_x713, _mls_x712, _mls_x710);
  _mls_retval = _mls_d_case5_sr_post_caller_post(_mls_x711, _mls_x714);
  return _mls_retval;
}
_mlsValue _mls_d_case5_sr_post_case4(_mlsValue _mls_x716, _mlsValue _mls_x718) {
  _mlsValue _mls_retval;
  auto _mls_x715 = _mlsValue::cast<_mls_Pow>(_mls_x716)->_mls_e1;
  auto _mls_x717 = _mlsValue::cast<_mls_Pow>(_mls_x716)->_mls_e2;
  auto _mls_x719 = _mls_d_case4_sr_post(_mls_x715, _mls_x717, _mls_x718);
  _mls_retval = _mls_d_case5_sr_post_caller_post(_mls_x716, _mls_x719);
  return _mls_retval;
}
_mlsValue _mls_d_case5_sr_post_case5(_mlsValue _mls_x721, _mlsValue _mls_x722) {
  _mlsValue _mls_retval;
  auto _mls_x720 = _mlsValue::cast<_mls_Ln>(_mls_x721)->_mls_e;
  auto _mls_x723 = _mls_d_case5_sr_post(_mls_x722, _mls_x720);
  _mls_retval = _mls_d_case5_sr_post_caller_post(_mls_x721, _mls_x723);
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x88 = _mls_main(_mlsValue::fromIntLit(10));
  _mls_retval = _mls_x88;
  return _mls_retval;
}
_mlsValue _mls_j(_mlsValue _mls_tmp, _mlsValue _mls_tmp1) {
  _mlsValue _mls_retval;
  auto _mls_x89 = (_mls_tmp * _mls_tmp1);
  _mls_retval = _mls_x89;
  return _mls_retval;
}
_mlsValue _mls_ln_case0(_mlsValue _mls_x725) {
  _mlsValue _mls_retval;
  auto _mls_x724 = _mlsValue::cast<_mls_Val>(_mls_x725)->_mls_n;
  if (_mlsValue::isIntLit(_mls_x724, 1)) {
    auto _mls_x727 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
    _mls_retval = _mls_x727;
  } else {
    auto _mls_x726 = _mlsValue::create<_mls_Ln>(_mls_x725);
    _mls_retval = _mls_x726;
  }
  return _mls_retval;
}
_mlsValue _mls_ln_default(_mlsValue _mls_x729) {
  _mlsValue _mls_retval;
  auto _mls_x728 = _mlsValue::create<_mls_Ln>(_mls_x729);
  _mls_retval = _mls_x728;
  return _mls_retval;
}
_mlsValue _mls_main(_mlsValue _mls_n1) {
  _mlsValue _mls_retval;
  auto _mls_x94 = _mlsValue::create<_mls_Var>(_mlsValue::create<_mls_Str>("x"));
  auto _mls_x730 = _mls_pow_default_default(_mls_x94, _mls_x94);
  auto [_mls_x731, _mls_x732, _mls_x733] = _mls_main_caller_post_pre(_mls_n1, _mls_x730);
  if (_mlsValue::isIntLit(_mls_x731, 0)) {
    auto _mls_x736 = _mls_count(_mls_x732);
    _mls_retval = _mls_x736;
  } else {
    auto _mls_x734 = _mls_nestAux_default_case0(_mls_x732, _mls_x731, _mls_x731, _mls_x733);
    auto _mls_x735 = _mls_count(_mls_x734);
    _mls_retval = _mls_x735;
  }
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_main_caller_post_pre(_mlsValue _mls_x738, _mlsValue _mls_x739) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x737 = _mlsValue::create<_mls_LamDeriv>();
  _mls_retval = std::make_tuple(_mls_x738, _mls_x739, _mls_x737);
  return _mls_retval;
}
_mlsValue _mls_mul(_mlsValue _mls_x740, _mlsValue _mls_x741) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x740)) {
    _mls_retval = _mls_mul_case0(_mls_x740, _mls_x741);
  } else {
    _mls_retval = _mls_mul_default(_mls_x741, _mls_x740);
  }
  return _mls_retval;
}
_mlsValue _mls_mul_case0(_mlsValue _mls_x743, _mlsValue _mls_x744) {
  _mlsValue _mls_retval;
  auto _mls_x742 = _mlsValue::cast<_mls_Val>(_mls_x743)->_mls_n;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x744)) {
    auto _mls_x754 = _mlsValue::cast<_mls_Val>(_mls_x744)->_mls_n;
    auto _mls_x755 = (_mls_x742 * _mls_x754);
    auto _mls_x756 = _mlsValue::create<_mls_Val>(_mls_x755);
    _mls_retval = _mls_x756;
  } else {
    if (_mlsValue::isIntLit(_mls_x742, 0)) {
      auto _mls_x753 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
      _mls_retval = _mls_x753;
    } else if (_mlsValue::isIntLit(_mls_x742, 1)) {
      _mls_retval = _mls_x744;
    } else {
      if (_mlsValue::isValueOf<_mls_Mul>(_mls_x744)) {
        auto _mls_x746 = _mlsValue::cast<_mls_Mul>(_mls_x744)->_mls_e1;
        auto _mls_x747 = _mlsValue::cast<_mls_Mul>(_mls_x744)->_mls_e2;
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x746)) {
          auto _mls_x749 = _mlsValue::cast<_mls_Val>(_mls_x746)->_mls_n;
          auto _mls_x750 = (_mls_x742 * _mls_x749);
          auto _mls_x751 = _mlsValue::create<_mls_Val>(_mls_x750);
          auto _mls_x752 = _mls_mul_case01(_mls_x751, _mls_x747);
          _mls_retval = _mls_x752;
        } else {
          auto _mls_x748 = _mlsValue::create<_mls_Mul>(_mls_x743, _mls_x744);
          _mls_retval = _mls_x748;
        }
      } else {
        auto _mls_x745 = _mlsValue::create<_mls_Mul>(_mls_x743, _mls_x744);
        _mls_retval = _mls_x745;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_mul_case01(_mlsValue _mls_x758, _mlsValue _mls_x759) {
  _mlsValue _mls_retval;
  auto _mls_x757 = _mlsValue::cast<_mls_Val>(_mls_x758)->_mls_n;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x759)) {
    auto _mls_x769 = _mlsValue::cast<_mls_Val>(_mls_x759)->_mls_n;
    auto _mls_x770 = (_mls_x757 * _mls_x769);
    auto _mls_x771 = _mlsValue::create<_mls_Val>(_mls_x770);
    _mls_retval = _mls_x771;
  } else {
    if (_mlsValue::isIntLit(_mls_x757, 0)) {
      auto _mls_x768 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
      _mls_retval = _mls_x768;
    } else if (_mlsValue::isIntLit(_mls_x757, 1)) {
      _mls_retval = _mls_x759;
    } else {
      if (_mlsValue::isValueOf<_mls_Mul>(_mls_x759)) {
        auto _mls_x761 = _mlsValue::cast<_mls_Mul>(_mls_x759)->_mls_e1;
        auto _mls_x762 = _mlsValue::cast<_mls_Mul>(_mls_x759)->_mls_e2;
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x761)) {
          auto _mls_x764 = _mlsValue::cast<_mls_Val>(_mls_x761)->_mls_n;
          auto _mls_x765 = (_mls_x757 * _mls_x764);
          auto _mls_x766 = _mlsValue::create<_mls_Val>(_mls_x765);
          auto _mls_x767 = _mls_mul_case0(_mls_x766, _mls_x762);
          _mls_retval = _mls_x767;
        } else {
          auto _mls_x763 = _mlsValue::create<_mls_Mul>(_mls_x758, _mls_x759);
          _mls_retval = _mls_x763;
        }
      } else {
        auto _mls_x760 = _mlsValue::create<_mls_Mul>(_mls_x758, _mls_x759);
        _mls_retval = _mls_x760;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default(_mlsValue _mls_x772, _mlsValue _mls_x773) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x772)) {
    _mls_retval = _mls_mul_default_case0(_mls_x772, _mls_x773);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x772)) {
    _mls_retval = _mls_mul_default_case1(_mls_x772, _mls_x773);
  } else {
    _mls_retval = _mls_mul_default_default(_mls_x773, _mls_x772);
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default_case0(_mlsValue _mls_x775, _mlsValue _mls_x776) {
  _mlsValue _mls_retval;
  auto _mls_x774 = _mlsValue::cast<_mls_Val>(_mls_x775)->_mls_n;
  _mls_retval = _mls_mul_default_case0_sr_post(_mls_x774, _mls_x776);
  return _mls_retval;
}
_mlsValue _mls_mul_default_case0_sr_post(_mlsValue _mls_x777, _mlsValue _mls_x778) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_x777, 0)) {
    _mls_retval = _mls_mul_default_case0_sr_post_case0();
  } else if (_mlsValue::isIntLit(_mls_x777, 1)) {
    _mls_retval = _mls_x778;
  } else {
    _mls_retval = _mls_mul_default_case0_sr_post_default(_mls_x777, _mls_x778);
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default_case0_sr_post1(_mlsValue _mls_x779, _mlsValue _mls_x781) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_x779, 0)) {
    auto _mls_x783 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
    _mls_retval = _mls_x783;
  } else if (_mlsValue::isIntLit(_mls_x779, 1)) {
    _mls_retval = _mls_x781;
  } else {
    auto _mls_x780 = _mlsValue::create<_mls_Val>(_mls_x779);
    auto _mls_x782 = _mls_mul_case0(_mls_x780, _mls_x781);
    _mls_retval = _mls_x782;
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default_case0_sr_post_case0() {
  _mlsValue _mls_retval;
  auto _mls_x784 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
  _mls_retval = _mls_x784;
  return _mls_retval;
}
_mlsValue _mls_mul_default_case0_sr_post_default(_mlsValue _mls_x786, _mlsValue _mls_x787) {
  _mlsValue _mls_retval;
  auto _mls_x785 = _mlsValue::create<_mls_Val>(_mls_x786);
  auto _mls_x788 = _mls_mul_case01(_mls_x785, _mls_x787);
  _mls_retval = _mls_x788;
  return _mls_retval;
}
_mlsValue _mls_mul_default_case1(_mlsValue _mls_x789, _mlsValue _mls_x790) {
  _mlsValue _mls_retval;
  auto [_mls_x791, _mls_x792, _mls_x793, _mls_x794] = _mls_mul_default_case1_pre(_mls_x789, _mls_x790);
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x791)) {
    auto _mls_x795 = _mlsValue::cast<_mls_Val>(_mls_x791)->_mls_n;
    _mls_retval = _mls_mul_default_case1_case0_sr_post(_mls_x795, _mls_x792, _mls_x793);
  } else {
    _mls_retval = _mls_mul_default_case1_default(_mls_x792, _mls_x794);
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default_case1_case0(_mlsValue _mls_x797, _mlsValue _mls_x798, _mlsValue _mls_x799) {
  _mlsValue _mls_retval;
  auto _mls_x796 = _mlsValue::cast<_mls_Val>(_mls_x797)->_mls_n;
  _mls_retval = _mls_mul_default_case1_case0_sr_post1(_mls_x796, _mls_x798, _mls_x799);
  return _mls_retval;
}
_mlsValue _mls_mul_default_case1_case01(_mlsValue _mls_x801, _mlsValue _mls_x802, _mlsValue _mls_x803) {
  _mlsValue _mls_retval;
  auto _mls_x800 = _mlsValue::cast<_mls_Val>(_mls_x801)->_mls_n;
  _mls_retval = _mls_mul_default_case1_case0_sr_post(_mls_x800, _mls_x802, _mls_x803);
  return _mls_retval;
}
_mlsValue _mls_mul_default_case1_case02(_mlsValue _mls_x805, _mlsValue _mls_x806, _mlsValue _mls_x807) {
  _mlsValue _mls_retval;
  auto _mls_x804 = _mlsValue::cast<_mls_Val>(_mls_x805)->_mls_n;
  _mls_retval = _mls_mul_default_case1_case0_sr_post(_mls_x804, _mls_x806, _mls_x807);
  return _mls_retval;
}
_mlsValue _mls_mul_default_case1_case0_sr_post(_mlsValue _mls_x809, _mlsValue _mls_x810, _mlsValue _mls_x811) {
  _mlsValue _mls_retval;
  auto _mls_x808 = _mlsValue::create<_mls_Val>(_mls_x809);
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x810)) {
    auto _mls_x827 = _mls_mul_case01(_mls_x810, _mls_x811);
    auto _mls_x828 = _mls_mul(_mls_x808, _mls_x827);
    _mls_retval = _mls_x828;
  } else {
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x811)) {
      auto _mls_x824 = _mlsValue::cast<_mls_Val>(_mls_x811)->_mls_n;
      auto _mls_x825 = _mls_mul_default_case0_sr_post1(_mls_x824, _mls_x810);
      auto _mls_x826 = _mls_mul(_mls_x808, _mls_x825);
      _mls_retval = _mls_x826;
    } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x811)) {
      auto [_mls_x816, _mls_x817, _mls_x818, _mls_x819] = _mls_mul_default_case1_pre1(_mls_x811, _mls_x810);
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x816)) {
        auto _mls_x822 = _mls_mul_default_case1_case0(_mls_x816, _mls_x817, _mls_x818);
        auto _mls_x823 = _mls_mul(_mls_x808, _mls_x822);
        _mls_retval = _mls_x823;
      } else {
        auto _mls_x820 = _mls_mul_default_case1_default1(_mls_x817, _mls_x819);
        auto _mls_x821 = _mls_mul(_mls_x808, _mls_x820);
        _mls_retval = _mls_x821;
      }
    } else {
      if (_mlsValue::isValueOf<_mls_Mul>(_mls_x810)) {
        auto _mls_x814 = _mls_mul_default_default_case0(_mls_x810, _mls_x811);
        auto _mls_x815 = _mls_mul(_mls_x808, _mls_x814);
        _mls_retval = _mls_x815;
      } else {
        auto _mls_x812 = _mls_mul_default_default_default(_mls_x810, _mls_x811);
        auto _mls_x813 = _mls_mul(_mls_x808, _mls_x812);
        _mls_retval = _mls_x813;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default_case1_case0_sr_post1(_mlsValue _mls_x830, _mlsValue _mls_x831, _mlsValue _mls_x832) {
  _mlsValue _mls_retval;
  auto _mls_x829 = _mlsValue::create<_mls_Val>(_mls_x830);
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x831)) {
    auto _mls_x853 = _mls_mul_case0(_mls_x831, _mls_x832);
    auto _mls_x854 = _mls_mul(_mls_x829, _mls_x853);
    _mls_retval = _mls_x854;
  } else {
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x832)) {
      auto _mls_x847 = _mlsValue::cast<_mls_Val>(_mls_x832)->_mls_n;
      if (_mlsValue::isIntLit(_mls_x847, 0)) {
        auto _mls_x851 = _mls_mul_default_case0_sr_post_case0();
        auto _mls_x852 = _mls_mul(_mls_x829, _mls_x851);
        _mls_retval = _mls_x852;
      } else if (_mlsValue::isIntLit(_mls_x847, 1)) {
        auto _mls_x850 = _mls_mul(_mls_x829, _mls_x831);
        _mls_retval = _mls_x850;
      } else {
        auto _mls_x848 = _mls_mul_default_case0_sr_post_default(_mls_x847, _mls_x831);
        auto _mls_x849 = _mls_mul(_mls_x829, _mls_x848);
        _mls_retval = _mls_x849;
      }
    } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x832)) {
      auto [_mls_x839, _mls_x840, _mls_x841, _mls_x842] = _mls_mul_default_case1_pre(_mls_x832, _mls_x831);
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x839)) {
        auto _mls_x845 = _mls_mul_default_case1_case02(_mls_x839, _mls_x840, _mls_x841);
        auto _mls_x846 = _mls_mul(_mls_x829, _mls_x845);
        _mls_retval = _mls_x846;
      } else {
        auto _mls_x843 = _mls_mul_default_case1_default(_mls_x840, _mls_x842);
        auto _mls_x844 = _mls_mul(_mls_x829, _mls_x843);
        _mls_retval = _mls_x844;
      }
    } else {
      if (_mlsValue::isValueOf<_mls_Mul>(_mls_x831)) {
        auto _mls_x835 = _mlsValue::cast<_mls_Mul>(_mls_x831)->_mls_e1;
        auto _mls_x836 = _mlsValue::cast<_mls_Mul>(_mls_x831)->_mls_e2;
        auto _mls_x837 = _mls_mul_default_default_case0_sr_post(_mls_x836, _mls_x832, _mls_x835);
        auto _mls_x838 = _mls_mul(_mls_x829, _mls_x837);
        _mls_retval = _mls_x838;
      } else {
        auto _mls_x833 = _mls_mul_default_default_default1(_mls_x831, _mls_x832);
        auto _mls_x834 = _mls_mul_case0(_mls_x829, _mls_x833);
        _mls_retval = _mls_x834;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default_case1_default1(_mlsValue _mls_x855, _mlsValue _mls_x856) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Mul>(_mls_x855)) {
    _mls_retval = _mls_mul_default_case1_default_case0(_mls_x855, _mls_x856);
  } else {
    _mls_retval = _mls_mul_default_case1_default_default(_mls_x855, _mls_x856);
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default_case1_default(_mlsValue _mls_x857, _mlsValue _mls_x859) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Mul>(_mls_x857)) {
    auto _mls_x860 = _mlsValue::cast<_mls_Mul>(_mls_x857)->_mls_e1;
    auto _mls_x861 = _mlsValue::cast<_mls_Mul>(_mls_x857)->_mls_e2;
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x861)) {
      auto _mls_x873 = _mls_mul_case01(_mls_x861, _mls_x859);
      auto _mls_x874 = _mls_mul(_mls_x860, _mls_x873);
      _mls_retval = _mls_x874;
    } else {
      auto [_mls_x862, _mls_x863, _mls_x864, _mls_x865] = _mls_mul_default_case1_pre1(_mls_x859, _mls_x861);
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x862)) {
        auto _mls_x870 = _mlsValue::cast<_mls_Val>(_mls_x862)->_mls_n;
        auto _mls_x871 = _mls_mul_default_case1_case0_sr_post1(_mls_x870, _mls_x863, _mls_x864);
        auto _mls_x872 = _mls_mul(_mls_x860, _mls_x871);
        _mls_retval = _mls_x872;
      } else {
        if (_mlsValue::isValueOf<_mls_Mul>(_mls_x863)) {
          auto _mls_x868 = _mls_mul_default_case1_default_case0(_mls_x863, _mls_x865);
          auto _mls_x869 = _mls_mul(_mls_x860, _mls_x868);
          _mls_retval = _mls_x869;
        } else {
          auto _mls_x866 = _mls_mul_default_case1_default_default(_mls_x863, _mls_x865);
          auto _mls_x867 = _mls_mul(_mls_x860, _mls_x866);
          _mls_retval = _mls_x867;
        }
      }
    }
  } else {
    auto _mls_x858 = _mlsValue::create<_mls_Mul>(_mls_x857, _mls_x859);
    _mls_retval = _mls_x858;
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default_case1_default_case0(_mlsValue _mls_x876, _mlsValue _mls_x878) {
  _mlsValue _mls_retval;
  auto _mls_x875 = _mlsValue::cast<_mls_Mul>(_mls_x876)->_mls_e1;
  auto _mls_x877 = _mlsValue::cast<_mls_Mul>(_mls_x876)->_mls_e2;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x877)) {
    auto _mls_x900 = _mls_mul_case0(_mls_x877, _mls_x878);
    auto _mls_x901 = _mls_mul(_mls_x875, _mls_x900);
    _mls_retval = _mls_x901;
  } else {
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x878)) {
      auto _mls_x894 = _mlsValue::cast<_mls_Val>(_mls_x878)->_mls_n;
      if (_mlsValue::isIntLit(_mls_x894, 0)) {
        auto _mls_x898 = _mls_mul_default_case0_sr_post_case0();
        auto _mls_x899 = _mls_mul(_mls_x875, _mls_x898);
        _mls_retval = _mls_x899;
      } else if (_mlsValue::isIntLit(_mls_x894, 1)) {
        auto _mls_x897 = _mls_mul(_mls_x875, _mls_x877);
        _mls_retval = _mls_x897;
      } else {
        auto _mls_x895 = _mls_mul_default_case0_sr_post_default(_mls_x894, _mls_x877);
        auto _mls_x896 = _mls_mul(_mls_x875, _mls_x895);
        _mls_retval = _mls_x896;
      }
    } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x878)) {
      auto [_mls_x886, _mls_x887, _mls_x888, _mls_x889] = _mls_mul_default_case1_pre(_mls_x878, _mls_x877);
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x886)) {
        auto _mls_x892 = _mls_mul_default_case1_case02(_mls_x886, _mls_x887, _mls_x888);
        auto _mls_x893 = _mls_mul(_mls_x875, _mls_x892);
        _mls_retval = _mls_x893;
      } else {
        auto _mls_x890 = _mls_mul_default_case1_default(_mls_x887, _mls_x889);
        auto _mls_x891 = _mls_mul(_mls_x875, _mls_x890);
        _mls_retval = _mls_x891;
      }
    } else {
      if (_mlsValue::isValueOf<_mls_Mul>(_mls_x877)) {
        auto _mls_x882 = _mlsValue::cast<_mls_Mul>(_mls_x877)->_mls_e1;
        auto _mls_x883 = _mlsValue::cast<_mls_Mul>(_mls_x877)->_mls_e2;
        auto _mls_x884 = _mls_mul_default_default_case0_sr_post(_mls_x883, _mls_x878, _mls_x882);
        auto _mls_x885 = _mls_mul(_mls_x875, _mls_x884);
        _mls_retval = _mls_x885;
      } else {
        auto _mls_x879 = _mls_mul_default_default_default1(_mls_x877, _mls_x878);
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x875)) {
          auto _mls_x881 = _mls_mul_case0(_mls_x875, _mls_x879);
          _mls_retval = _mls_x881;
        } else {
          auto _mls_x880 = _mls_mul_default(_mls_x879, _mls_x875);
          _mls_retval = _mls_x880;
        }
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default_case1_default_default(_mlsValue _mls_x903, _mlsValue _mls_x904) {
  _mlsValue _mls_retval;
  auto _mls_x902 = _mlsValue::create<_mls_Mul>(_mls_x903, _mls_x904);
  _mls_retval = _mls_x902;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_mul_default_case1_pre1(_mlsValue _mls_x906, _mlsValue _mls_x908) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x905 = _mlsValue::cast<_mls_Mul>(_mls_x906)->_mls_e1;
  auto _mls_x907 = _mlsValue::cast<_mls_Mul>(_mls_x906)->_mls_e2;
  _mls_retval = std::make_tuple(_mls_x905, _mls_x908, _mls_x907, _mls_x906);
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_mul_default_case1_pre(_mlsValue _mls_x910, _mlsValue _mls_x912) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x909 = _mlsValue::cast<_mls_Mul>(_mls_x910)->_mls_e1;
  auto _mls_x911 = _mlsValue::cast<_mls_Mul>(_mls_x910)->_mls_e2;
  _mls_retval = std::make_tuple(_mls_x909, _mls_x912, _mls_x911, _mls_x910);
  return _mls_retval;
}
_mlsValue _mls_mul_default_default(_mlsValue _mls_x913, _mlsValue _mls_x914) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Mul>(_mls_x913)) {
    auto _mls_x915 = _mlsValue::cast<_mls_Mul>(_mls_x913)->_mls_e1;
    auto _mls_x916 = _mlsValue::cast<_mls_Mul>(_mls_x913)->_mls_e2;
    _mls_retval = _mls_mul_default_default_case0_sr_post(_mls_x916, _mls_x914, _mls_x915);
  } else {
    _mls_retval = _mls_mul_default_default_default1(_mls_x913, _mls_x914);
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default_default_case0(_mlsValue _mls_x918, _mlsValue _mls_x920) {
  _mlsValue _mls_retval;
  auto _mls_x917 = _mlsValue::cast<_mls_Mul>(_mls_x918)->_mls_e1;
  auto _mls_x919 = _mlsValue::cast<_mls_Mul>(_mls_x918)->_mls_e2;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x919)) {
    auto _mls_x936 = _mls_mul_case0(_mls_x919, _mls_x920);
    auto _mls_x937 = _mls_mul(_mls_x917, _mls_x936);
    _mls_retval = _mls_x937;
  } else {
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x920)) {
      auto _mls_x933 = _mlsValue::cast<_mls_Val>(_mls_x920)->_mls_n;
      auto _mls_x934 = _mls_mul_default_case0_sr_post(_mls_x933, _mls_x919);
      auto _mls_x935 = _mls_mul(_mls_x917, _mls_x934);
      _mls_retval = _mls_x935;
    } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x920)) {
      auto [_mls_x925, _mls_x926, _mls_x927, _mls_x928] = _mls_mul_default_case1_pre(_mls_x920, _mls_x919);
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x925)) {
        auto _mls_x931 = _mls_mul_default_case1_case01(_mls_x925, _mls_x926, _mls_x927);
        auto _mls_x932 = _mls_mul(_mls_x917, _mls_x931);
        _mls_retval = _mls_x932;
      } else {
        auto _mls_x929 = _mls_mul_default_case1_default(_mls_x926, _mls_x928);
        auto _mls_x930 = _mls_mul(_mls_x917, _mls_x929);
        _mls_retval = _mls_x930;
      }
    } else {
      if (_mlsValue::isValueOf<_mls_Mul>(_mls_x919)) {
        auto _mls_x923 = _mls_mul_default_default_case01(_mls_x919, _mls_x920);
        auto _mls_x924 = _mls_mul(_mls_x917, _mls_x923);
        _mls_retval = _mls_x924;
      } else {
        auto _mls_x921 = _mls_mul_default_default_default1(_mls_x919, _mls_x920);
        auto _mls_x922 = _mls_mul(_mls_x917, _mls_x921);
        _mls_retval = _mls_x922;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default_default_case01(_mlsValue _mls_x939, _mlsValue _mls_x941) {
  _mlsValue _mls_retval;
  auto _mls_x938 = _mlsValue::cast<_mls_Mul>(_mls_x939)->_mls_e1;
  auto _mls_x940 = _mlsValue::cast<_mls_Mul>(_mls_x939)->_mls_e2;
  _mls_retval = _mls_mul_default_default_case0_sr_post(_mls_x940, _mls_x941, _mls_x938);
  return _mls_retval;
}
_mlsValue _mls_mul_default_default_case0_sr_post(_mlsValue _mls_x942, _mlsValue _mls_x943, _mlsValue _mls_x945) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x942)) {
    auto _mls_x960 = _mls_mul_case01(_mls_x942, _mls_x943);
    auto _mls_x961 = _mls_mul(_mls_x945, _mls_x960);
    _mls_retval = _mls_x961;
  } else {
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x943)) {
      auto _mls_x957 = _mlsValue::cast<_mls_Val>(_mls_x943)->_mls_n;
      auto _mls_x958 = _mls_mul_default_case0_sr_post1(_mls_x957, _mls_x942);
      auto _mls_x959 = _mls_mul(_mls_x945, _mls_x958);
      _mls_retval = _mls_x959;
    } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x943)) {
      auto [_mls_x949, _mls_x950, _mls_x951, _mls_x952] = _mls_mul_default_case1_pre1(_mls_x943, _mls_x942);
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x949)) {
        auto _mls_x955 = _mls_mul_default_case1_case0(_mls_x949, _mls_x950, _mls_x951);
        auto _mls_x956 = _mls_mul(_mls_x945, _mls_x955);
        _mls_retval = _mls_x956;
      } else {
        auto _mls_x953 = _mls_mul_default_case1_default1(_mls_x950, _mls_x952);
        auto _mls_x954 = _mls_mul(_mls_x945, _mls_x953);
        _mls_retval = _mls_x954;
      }
    } else {
      if (_mlsValue::isValueOf<_mls_Mul>(_mls_x942)) {
        auto _mls_x947 = _mls_mul_default_default_case0(_mls_x942, _mls_x943);
        auto _mls_x948 = _mls_mul(_mls_x945, _mls_x947);
        _mls_retval = _mls_x948;
      } else {
        auto _mls_x944 = _mls_mul_default_default_default(_mls_x942, _mls_x943);
        auto _mls_x946 = _mls_mul(_mls_x945, _mls_x944);
        _mls_retval = _mls_x946;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default_default_default(_mlsValue _mls_x963, _mlsValue _mls_x964) {
  _mlsValue _mls_retval;
  auto _mls_x962 = _mlsValue::create<_mls_Mul>(_mls_x963, _mls_x964);
  _mls_retval = _mls_x962;
  return _mls_retval;
}
_mlsValue _mls_mul_default_default_default1(_mlsValue _mls_x966, _mlsValue _mls_x967) {
  _mlsValue _mls_retval;
  auto _mls_x965 = _mlsValue::create<_mls_Mul>(_mls_x966, _mls_x967);
  _mls_retval = _mls_x965;
  return _mls_retval;
}
_mlsValue _mls_nestAux(_mlsValue _mls_x971, _mlsValue _mls_x969, _mlsValue _mls_x968, _mlsValue _mls_x970) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_x968, 0)) {
    _mls_retval = _mls_x970;
  } else {
    _mls_retval = _mls_nestAux_default(_mls_x969, _mls_x970, _mls_x968, _mls_x971);
  }
  return _mls_retval;
}
_mlsValue _mls_nestAux_caller_post(_mlsValue _mls_x972, _mlsValue _mls_x973, _mlsValue _mls_x974, _mlsValue _mls_x975) {
  _mlsValue _mls_retval;
  auto [_mls_x976, _mls_x977, _mls_x978, _mls_x979] = _mls_nestAux_caller_post_pre(_mls_x972, _mls_x973, _mls_x974, _mls_x975);
  auto _mls_x980 = _mls_nestAux(_mls_x976, _mls_x977, _mls_x978, _mls_x979);
  _mls_retval = _mls_x980;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_nestAux_caller_post_pre(_mlsValue _mls_x982, _mlsValue _mls_x983, _mlsValue _mls_x984, _mlsValue _mls_x985) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x981 = (_mls_x982 - _mlsValue::fromIntLit(1));
  _mls_retval = std::make_tuple(_mls_x983, _mls_x984, _mls_x981, _mls_x985);
  return _mls_retval;
}
_mlsValue _mls_nestAux_default(_mlsValue _mls_x986, _mlsValue _mls_x987, _mlsValue _mls_x988, _mlsValue _mls_x989) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_LamDeriv>(_mls_x986)) {
    _mls_retval = _mls_nestAux_default_case0(_mls_x987, _mls_x988, _mls_x989, _mls_x986);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_nestAux_default_case0(_mlsValue _mls_x990, _mlsValue _mls_x993, _mlsValue _mls_x994, _mlsValue _mls_x995) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x990)) {
    auto _mls_x1007 = _mls_d_case0();
    auto [_mls_x1008, _mls_x1009, _mls_x1010, _mls_x1011] = _mls_nestAux_caller_post_pre(_mls_x993, _mls_x994, _mls_x995, _mls_x1007);
    auto _mls_x1012 = _mls_nestAux(_mls_x1008, _mls_x1009, _mls_x1010, _mls_x1011);
    _mls_retval = _mls_x1012;
  } else if (_mlsValue::isValueOf<_mls_Var>(_mls_x990)) {
    auto _mls_x1005 = _mlsValue::cast<_mls_Var>(_mls_x990)->_mls_x;
    auto _mls_x1006 = _mls_d_case1_sr_post(_mlsValue::create<_mls_Str>("x"), _mls_x1005);
    _mls_retval = _mls_nestAux_caller_post(_mls_x993, _mls_x994, _mls_x995, _mls_x1006);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x990)) {
    auto _mls_x1002 = _mlsValue::cast<_mls_Add>(_mls_x990)->_mls_e1;
    auto _mls_x1003 = _mlsValue::cast<_mls_Add>(_mls_x990)->_mls_e2;
    auto _mls_x1004 = _mls_d_case2_sr_post(_mlsValue::create<_mls_Str>("x"), _mls_x1002, _mls_x1003);
    _mls_retval = _mls_nestAux_caller_post(_mls_x993, _mls_x994, _mls_x995, _mls_x1004);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x990)) {
    auto _mls_x999 = _mlsValue::cast<_mls_Mul>(_mls_x990)->_mls_e1;
    auto _mls_x1000 = _mlsValue::cast<_mls_Mul>(_mls_x990)->_mls_e2;
    auto _mls_x1001 = _mls_d_case3_sr_post(_mlsValue::create<_mls_Str>("x"), _mls_x1000, _mls_x999);
    _mls_retval = _mls_nestAux_caller_post(_mls_x993, _mls_x994, _mls_x995, _mls_x1001);
  } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_x990)) {
    auto _mls_x996 = _mlsValue::cast<_mls_Pow>(_mls_x990)->_mls_e1;
    auto _mls_x997 = _mlsValue::cast<_mls_Pow>(_mls_x990)->_mls_e2;
    auto _mls_x998 = _mls_d_case4_sr_post(_mls_x996, _mls_x997, _mlsValue::create<_mls_Str>("x"));
    _mls_retval = _mls_nestAux_caller_post(_mls_x993, _mls_x994, _mls_x995, _mls_x998);
  } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_x990)) {
    auto _mls_x991 = _mlsValue::cast<_mls_Ln>(_mls_x990)->_mls_e;
    auto _mls_x992 = _mls_d_case5_sr_post(_mlsValue::create<_mls_Str>("x"), _mls_x991);
    _mls_retval = _mls_nestAux_caller_post(_mls_x993, _mls_x994, _mls_x995, _mls_x992);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_pow_case0(_mlsValue _mls_x1014, _mlsValue _mls_x1015) {
  _mlsValue _mls_retval;
  auto _mls_x1013 = _mlsValue::cast<_mls_Val>(_mls_x1014)->_mls_n;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x1015)) {
    auto _mls_x1018 = _mlsValue::cast<_mls_Val>(_mls_x1015)->_mls_n;
    auto _mls_x1019 = _mls_pown(_mls_x1013, _mls_x1018);
    auto _mls_x1020 = _mlsValue::create<_mls_Val>(_mls_x1019);
    _mls_retval = _mls_x1020;
  } else {
    if (_mlsValue::isIntLit(_mls_x1013, 0)) {
      auto _mls_x1017 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
      _mls_retval = _mls_x1017;
    } else {
      auto _mls_x1016 = _mlsValue::create<_mls_Pow>(_mls_x1014, _mls_x1015);
      _mls_retval = _mls_x1016;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_pow_default(_mlsValue _mls_x1021, _mlsValue _mls_x1022) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x1021)) {
    _mls_retval = _mls_pow_default_case0(_mls_x1021, _mls_x1022);
  } else {
    _mls_retval = _mls_pow_default_default(_mls_x1022, _mls_x1021);
  }
  return _mls_retval;
}
_mlsValue _mls_pow_default_case0(_mlsValue _mls_x1024, _mlsValue _mls_x1026) {
  _mlsValue _mls_retval;
  auto _mls_x1023 = _mlsValue::cast<_mls_Val>(_mls_x1024)->_mls_n;
  if (_mlsValue::isIntLit(_mls_x1023, 0)) {
    auto _mls_x1027 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(1));
    _mls_retval = _mls_x1027;
  } else if (_mlsValue::isIntLit(_mls_x1023, 1)) {
    _mls_retval = _mls_x1026;
  } else {
    auto _mls_x1025 = _mlsValue::create<_mls_Pow>(_mls_x1026, _mls_x1024);
    _mls_retval = _mls_x1025;
  }
  return _mls_retval;
}
_mlsValue _mls_pow_default_default(_mlsValue _mls_x1029, _mlsValue _mls_x1030) {
  _mlsValue _mls_retval;
  auto _mls_x1028 = _mlsValue::create<_mls_Pow>(_mls_x1029, _mls_x1030);
  _mls_retval = _mls_x1028;
  return _mls_retval;
}
_mlsValue _mls_pown(_mlsValue _mls_x147, _mlsValue _mls_n3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_n3, 0)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else if (_mlsValue::isIntLit(_mls_n3, 1)) {
    _mls_retval = _mls_x147;
  } else {
    auto _mls_x146 = (_mls_n3 / _mlsValue::fromIntLit(2));
    auto _mls_x148 = _mls_pown(_mls_x147, _mls_x146);
    auto _mls_x149 = (_mls_x148 * _mls_x148);
    auto _mls_x150 = (_mls_n3 % _mlsValue::fromIntLit(2));
    auto _mls_x151 = (_mls_x150 == _mlsValue::fromIntLit(0));
    if (_mlsValue::isIntLit(_mls_x151, 1)) {
      _mls_retval = _mls_j(_mls_x149, _mlsValue::fromIntLit(1));
    } else {
      _mls_retval = _mls_j(_mls_x149, _mls_x147);
    }
  }
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
