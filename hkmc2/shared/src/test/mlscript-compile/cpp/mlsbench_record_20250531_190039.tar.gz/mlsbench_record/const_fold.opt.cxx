#include "mlsprelude.h"
struct _mls_Expr;
struct _mls_Var;
struct _mls_Val;
struct _mls_Add;
struct _mls_Mul;
_mlsValue _mls_appendAdd(_mlsValue, _mlsValue);
_mlsValue _mls_appendMul(_mlsValue, _mlsValue);
_mlsValue _mls_constFolding(_mlsValue);
_mlsValue _mls_constFolding_case0(_mlsValue);
_mlsValue _mls_constFolding_case0_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_constFolding_case1(_mlsValue);
_mlsValue _mls_constFolding_case1_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_eval1(_mlsValue);
_mlsValue _mls_eval_case1(_mlsValue);
_mlsValue _mls_eval_case2(_mlsValue);
_mlsValue _mls_eval_case3(_mlsValue);
_mlsValue _mls_main();
_mlsValue _mls_main_caller_post_post(_mlsValue, _mlsValue);
_mlsValue _mls_main_caller_post_post_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_mkExpr(_mlsValue, _mlsValue);
_mlsValue _mls_mkExpr_case0(_mlsValue);
_mlsValue _mls_mkExpr_case0_case0();
_mlsValue _mls_mkExpr_case0_default(_mlsValue);
std::tuple<_mlsValue, _mlsValue> _mls_mkExpr_case0_pre(_mlsValue);
_mlsValue _mls_mkExpr_default(_mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_mkExpr_pre(_mlsValue, _mlsValue);
_mlsValue _mls_reassoc(_mlsValue);
_mlsValue _mls_reassoc_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_reassoc_caller_post1(_mlsValue, _mlsValue);
_mlsValue _mls_reassoc_case0(_mlsValue);
_mlsValue _mls_reassoc_case0_sr_post1(_mlsValue, _mlsValue);
_mlsValue _mls_reassoc_case0_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_reassoc_case0_sr_post_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_reassoc_case1(_mlsValue);
_mlsValue _mls_reassoc_case1_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_reassoc_case1_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_reassoc_case1_sr_post1(_mlsValue, _mlsValue);
struct _mls_Expr: public _mlsObject {
  
  constexpr static inline const char *typeName = "Expr";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Expr; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Var: public _mls_Expr {
  _mlsValue _mls_x;
  constexpr static inline const char *typeName = "Var";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_x.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_x);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_x.asObject()->operator==(*other.cast<_mls_Var>()->_mls_x.asObject()); }
  static _mlsValue create(_mlsValue _mls_x) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Var; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_x = _mls_x;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Val: public _mls_Expr {
  _mlsValue _mls_n;
  constexpr static inline const char *typeName = "Val";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_n.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_n);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_n.asObject()->operator==(*other.cast<_mls_Val>()->_mls_n.asObject()); }
  static _mlsValue create(_mlsValue _mls_n) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Val; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_n = _mls_n;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Add: public _mls_Expr {
  _mlsValue _mls_e1;
  _mlsValue _mls_e2;
  constexpr static inline const char *typeName = "Add";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e1.print(); std::printf(", "); this->_mls_e2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e1); _mlsValue::destroy(this->_mls_e2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e1.asObject()->operator==(*other.cast<_mls_Add>()->_mls_e1.asObject()) && this->_mls_e2.asObject()->operator==(*other.cast<_mls_Add>()->_mls_e2.asObject()); }
  static _mlsValue create(_mlsValue _mls_e1, _mlsValue _mls_e2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Add; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e1 = _mls_e1; _mlsVal->_mls_e2 = _mls_e2;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Mul: public _mls_Expr {
  _mlsValue _mls_e1;
  _mlsValue _mls_e2;
  constexpr static inline const char *typeName = "Mul";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e1.print(); std::printf(", "); this->_mls_e2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e1); _mlsValue::destroy(this->_mls_e2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e1.asObject()->operator==(*other.cast<_mls_Mul>()->_mls_e1.asObject()) && this->_mls_e2.asObject()->operator==(*other.cast<_mls_Mul>()->_mls_e2.asObject()); }
  static _mlsValue create(_mlsValue _mls_e1, _mlsValue _mls_e2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Mul; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e1 = _mls_e1; _mlsVal->_mls_e2 = _mls_e2;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_appendAdd(_mlsValue _mls_e12, _mlsValue _mls_e22) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_e12)) {
    auto _mls_x2 = _mlsValue::cast<_mls_Add>(_mls_e12)->_mls_e1;
    auto _mls_x3 = _mlsValue::cast<_mls_Add>(_mls_e12)->_mls_e2;
    auto _mls_x4 = _mls_appendAdd(_mls_x3, _mls_e22);
    auto _mls_x5 = _mlsValue::create<_mls_Add>(_mls_x2, _mls_x4);
    _mls_retval = _mls_x5;
  } else {
    auto _mls_x1 = _mlsValue::create<_mls_Add>(_mls_e12, _mls_e22);
    _mls_retval = _mls_x1;
  }
  return _mls_retval;
}
_mlsValue _mls_appendMul(_mlsValue _mls_e13, _mlsValue _mls_e23) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Mul>(_mls_e13)) {
    auto _mls_x7 = _mlsValue::cast<_mls_Mul>(_mls_e13)->_mls_e1;
    auto _mls_x8 = _mlsValue::cast<_mls_Mul>(_mls_e13)->_mls_e2;
    auto _mls_x9 = _mls_appendMul(_mls_x8, _mls_e23);
    auto _mls_x10 = _mlsValue::create<_mls_Mul>(_mls_x7, _mls_x9);
    _mls_retval = _mls_x10;
  } else {
    auto _mls_x6 = _mlsValue::create<_mls_Mul>(_mls_e13, _mls_e23);
    _mls_retval = _mls_x6;
  }
  return _mls_retval;
}
_mlsValue _mls_constFolding(_mlsValue _mls_x) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_x)) {
    _mls_retval = _mls_constFolding_case0(_mls_x);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x)) {
    _mls_retval = _mls_constFolding_case1(_mls_x);
  } else {
    _mls_retval = _mls_x;
  }
  return _mls_retval;
}
_mlsValue _mls_constFolding_case0(_mlsValue _mls_x94) {
  _mlsValue _mls_retval;
  auto _mls_x93 = _mlsValue::cast<_mls_Add>(_mls_x94)->_mls_e1;
  auto _mls_x95 = _mlsValue::cast<_mls_Add>(_mls_x94)->_mls_e2;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_x93)) {
    auto _mls_x97 = _mls_constFolding_case0(_mls_x93);
    _mls_retval = _mls_constFolding_case0_caller_post(_mls_x95, _mls_x97);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x93)) {
    auto _mls_x96 = _mls_constFolding_case1(_mls_x93);
    _mls_retval = _mls_constFolding_case0_caller_post(_mls_x95, _mls_x96);
  } else {
    _mls_retval = _mls_constFolding_case0_caller_post(_mls_x95, _mls_x93);
  }
  return _mls_retval;
}
_mlsValue _mls_constFolding_case0_caller_post(_mlsValue _mls_x98, _mlsValue _mls_x100) {
  _mlsValue _mls_retval;
  auto _mls_x99 = _mls_constFolding(_mls_x98);
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x100)) {
    auto _mls_x102 = _mlsValue::cast<_mls_Val>(_mls_x100)->_mls_n;
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x99)) {
      auto _mls_x115 = _mlsValue::cast<_mls_Val>(_mls_x99)->_mls_n;
      auto _mls_x116 = (_mls_x102 + _mls_x115);
      auto _mls_x117 = _mlsValue::create<_mls_Val>(_mls_x116);
      _mls_retval = _mls_x117;
    } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x99)) {
      auto _mls_x104 = _mlsValue::cast<_mls_Add>(_mls_x99)->_mls_e1;
      auto _mls_x105 = _mlsValue::cast<_mls_Add>(_mls_x99)->_mls_e2;
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x105)) {
        auto _mls_x111 = _mlsValue::cast<_mls_Val>(_mls_x105)->_mls_n;
        auto _mls_x112 = (_mls_x102 + _mls_x111);
        auto _mls_x113 = _mlsValue::create<_mls_Val>(_mls_x112);
        auto _mls_x114 = _mlsValue::create<_mls_Add>(_mls_x113, _mls_x104);
        _mls_retval = _mls_x114;
      } else {
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x104)) {
          auto _mls_x107 = _mlsValue::cast<_mls_Val>(_mls_x104)->_mls_n;
          auto _mls_x108 = (_mls_x102 + _mls_x107);
          auto _mls_x109 = _mlsValue::create<_mls_Val>(_mls_x108);
          auto _mls_x110 = _mlsValue::create<_mls_Add>(_mls_x109, _mls_x105);
          _mls_retval = _mls_x110;
        } else {
          auto _mls_x106 = _mlsValue::create<_mls_Add>(_mls_x100, _mls_x99);
          _mls_retval = _mls_x106;
        }
      }
    } else {
      auto _mls_x103 = _mlsValue::create<_mls_Add>(_mls_x100, _mls_x99);
      _mls_retval = _mls_x103;
    }
  } else {
    auto _mls_x101 = _mlsValue::create<_mls_Add>(_mls_x100, _mls_x99);
    _mls_retval = _mls_x101;
  }
  return _mls_retval;
}
_mlsValue _mls_constFolding_case1(_mlsValue _mls_x119) {
  _mlsValue _mls_retval;
  auto _mls_x118 = _mlsValue::cast<_mls_Mul>(_mls_x119)->_mls_e1;
  auto _mls_x120 = _mlsValue::cast<_mls_Mul>(_mls_x119)->_mls_e2;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_x118)) {
    auto _mls_x122 = _mls_constFolding_case0(_mls_x118);
    _mls_retval = _mls_constFolding_case1_caller_post(_mls_x120, _mls_x122);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x118)) {
    auto _mls_x121 = _mls_constFolding_case1(_mls_x118);
    _mls_retval = _mls_constFolding_case1_caller_post(_mls_x120, _mls_x121);
  } else {
    _mls_retval = _mls_constFolding_case1_caller_post(_mls_x120, _mls_x118);
  }
  return _mls_retval;
}
_mlsValue _mls_constFolding_case1_caller_post(_mlsValue _mls_x123, _mlsValue _mls_x125) {
  _mlsValue _mls_retval;
  auto _mls_x124 = _mls_constFolding(_mls_x123);
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x125)) {
    auto _mls_x127 = _mlsValue::cast<_mls_Val>(_mls_x125)->_mls_n;
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x124)) {
      auto _mls_x140 = _mlsValue::cast<_mls_Val>(_mls_x124)->_mls_n;
      auto _mls_x141 = (_mls_x127 * _mls_x140);
      auto _mls_x142 = _mlsValue::create<_mls_Val>(_mls_x141);
      _mls_retval = _mls_x142;
    } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x124)) {
      auto _mls_x129 = _mlsValue::cast<_mls_Mul>(_mls_x124)->_mls_e1;
      auto _mls_x130 = _mlsValue::cast<_mls_Mul>(_mls_x124)->_mls_e2;
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x130)) {
        auto _mls_x136 = _mlsValue::cast<_mls_Val>(_mls_x130)->_mls_n;
        auto _mls_x137 = (_mls_x127 * _mls_x136);
        auto _mls_x138 = _mlsValue::create<_mls_Val>(_mls_x137);
        auto _mls_x139 = _mlsValue::create<_mls_Mul>(_mls_x138, _mls_x129);
        _mls_retval = _mls_x139;
      } else {
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x129)) {
          auto _mls_x132 = _mlsValue::cast<_mls_Val>(_mls_x129)->_mls_n;
          auto _mls_x133 = (_mls_x127 * _mls_x132);
          auto _mls_x134 = _mlsValue::create<_mls_Val>(_mls_x133);
          auto _mls_x135 = _mlsValue::create<_mls_Mul>(_mls_x134, _mls_x130);
          _mls_retval = _mls_x135;
        } else {
          auto _mls_x131 = _mlsValue::create<_mls_Mul>(_mls_x125, _mls_x124);
          _mls_retval = _mls_x131;
        }
      }
    } else {
      auto _mls_x128 = _mlsValue::create<_mls_Mul>(_mls_x125, _mls_x124);
      _mls_retval = _mls_x128;
    }
  } else {
    auto _mls_x126 = _mlsValue::create<_mls_Mul>(_mls_x125, _mls_x124);
    _mls_retval = _mls_x126;
  }
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x53 = _mls_main();
  _mls_retval = _mls_x53;
  return _mls_retval;
}
_mlsValue _mls_eval1(_mlsValue _mls_x143) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Var>(_mls_x143)) {
    _mls_retval = _mlsValue::fromIntLit(0);
  } else if (_mlsValue::isValueOf<_mls_Val>(_mls_x143)) {
    _mls_retval = _mls_eval_case1(_mls_x143);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x143)) {
    _mls_retval = _mls_eval_case2(_mls_x143);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x143)) {
    _mls_retval = _mls_eval_case3(_mls_x143);
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_eval_case1(_mlsValue _mls_x145) {
  _mlsValue _mls_retval;
  auto _mls_x144 = _mlsValue::cast<_mls_Val>(_mls_x145)->_mls_n;
  _mls_retval = _mls_x144;
  return _mls_retval;
}
_mlsValue _mls_eval_case2(_mlsValue _mls_x147) {
  _mlsValue _mls_retval;
  auto _mls_x146 = _mlsValue::cast<_mls_Add>(_mls_x147)->_mls_e1;
  auto _mls_x148 = _mlsValue::cast<_mls_Add>(_mls_x147)->_mls_e2;
  auto _mls_x149 = _mls_eval1(_mls_x146);
  auto _mls_x150 = _mls_eval1(_mls_x148);
  auto _mls_x151 = (_mls_x149 + _mls_x150);
  _mls_retval = _mls_x151;
  return _mls_retval;
}
_mlsValue _mls_eval_case3(_mlsValue _mls_x153) {
  _mlsValue _mls_retval;
  auto _mls_x152 = _mlsValue::cast<_mls_Mul>(_mls_x153)->_mls_e1;
  auto _mls_x154 = _mlsValue::cast<_mls_Mul>(_mls_x153)->_mls_e2;
  auto _mls_x155 = _mls_eval1(_mls_x152);
  auto _mls_x156 = _mls_eval1(_mls_x154);
  auto _mls_x157 = (_mls_x155 * _mls_x156);
  _mls_retval = _mls_x157;
  return _mls_retval;
}
_mlsValue _mls_main() {
  _mlsValue _mls_retval;
  auto [_mls_x158, _mls_x159, _mls_x160] = _mls_mkExpr_pre(_mlsValue::fromIntLit(21), _mlsValue::fromIntLit(1));
  if (_mlsValue::isIntLit(_mls_x158, 1)) {
    auto [_mls_x163, _mls_x164] = _mls_mkExpr_case0_pre(_mls_x159);
    if (_mlsValue::isIntLit(_mls_x163, 1)) {
      auto _mls_x167 = _mls_mkExpr_case0_case0();
      _mls_retval = _mls_main_caller_post_post(_mls_x167, _mlsValue::fromIntLit(0));
    } else {
      auto _mls_x165 = _mls_mkExpr_case0_default(_mls_x164);
      auto _mls_x166 = _mls_eval_case1(_mls_x165);
      _mls_retval = _mls_main_caller_post_post(_mls_x165, _mls_x166);
    }
  } else {
    auto _mls_x161 = _mls_mkExpr_default(_mls_x160, _mls_x159);
    auto _mls_x162 = _mls_eval_case2(_mls_x161);
    _mls_retval = _mls_main_caller_post_post(_mls_x161, _mls_x162);
  }
  return _mls_retval;
}
_mlsValue _mls_main_caller_post_post(_mlsValue _mls_x168, _mlsValue _mls_x169) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_x168)) {
    auto _mls_x171 = _mls_reassoc_case0(_mls_x168);
    _mls_retval = _mls_main_caller_post_post_caller_post(_mls_x171, _mls_x169);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x168)) {
    auto _mls_x170 = _mls_reassoc_case1(_mls_x168);
    _mls_retval = _mls_main_caller_post_post_caller_post(_mls_x170, _mls_x169);
  } else {
    _mls_retval = _mls_main_caller_post_post_caller_post(_mls_x168, _mls_x169);
  }
  return _mls_retval;
}
_mlsValue _mls_main_caller_post_post_caller_post(_mlsValue _mls_x172, _mlsValue _mls_x176) {
  _mlsValue _mls_retval;
  auto _mls_x173 = _mls_constFolding(_mls_x172);
  auto _mls_x174 = _mls_eval1(_mls_x173);
  auto _mls_x175 = (_mls_x176 == _mls_x174);
  _mls_retval = _mls_x175;
  return _mls_retval;
}
_mlsValue _mls_mkExpr(_mlsValue _mls_x177, _mlsValue _mls_x178) {
  _mlsValue _mls_retval;
  auto [_mls_x179, _mls_x180, _mls_x181] = _mls_mkExpr_pre(_mls_x177, _mls_x178);
  if (_mlsValue::isIntLit(_mls_x179, 1)) {
    _mls_retval = _mls_mkExpr_case0(_mls_x180);
  } else {
    _mls_retval = _mls_mkExpr_default(_mls_x181, _mls_x180);
  }
  return _mls_retval;
}
_mlsValue _mls_mkExpr_case0(_mlsValue _mls_x182) {
  _mlsValue _mls_retval;
  auto [_mls_x183, _mls_x184] = _mls_mkExpr_case0_pre(_mls_x182);
  if (_mlsValue::isIntLit(_mls_x183, 1)) {
    _mls_retval = _mls_mkExpr_case0_case0();
  } else {
    _mls_retval = _mls_mkExpr_case0_default(_mls_x184);
  }
  return _mls_retval;
}
_mlsValue _mls_mkExpr_case0_case0() {
  _mlsValue _mls_retval;
  auto _mls_x185 = _mlsValue::create<_mls_Var>(_mlsValue::fromIntLit(1));
  _mls_retval = _mls_x185;
  return _mls_retval;
}
_mlsValue _mls_mkExpr_case0_default(_mlsValue _mls_x187) {
  _mlsValue _mls_retval;
  auto _mls_x186 = _mlsValue::create<_mls_Val>(_mls_x187);
  _mls_retval = _mls_x186;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue> _mls_mkExpr_case0_pre(_mlsValue _mls_x189) {
  std::tuple<_mlsValue, _mlsValue> _mls_retval;
  auto _mls_x188 = (_mls_x189 == _mlsValue::fromIntLit(0));
  _mls_retval = std::make_tuple(_mls_x188, _mls_x189);
  return _mls_retval;
}
_mlsValue _mls_mkExpr_default(_mlsValue _mls_x191, _mlsValue _mls_x193) {
  _mlsValue _mls_retval;
  auto _mls_x190 = (_mls_x191 - _mlsValue::fromIntLit(1));
  auto _mls_x192 = (_mls_x193 + _mlsValue::fromIntLit(1));
  auto _mls_x194 = _mls_mkExpr(_mls_x190, _mls_x192);
  auto _mls_x195 = (_mls_x191 - _mlsValue::fromIntLit(1));
  auto _mls_x196 = (_mls_x193 - _mlsValue::fromIntLit(1));
  auto _mls_x197 = _mls_mkExpr(_mls_x195, _mls_x196);
  auto _mls_x198 = _mlsValue::create<_mls_Add>(_mls_x194, _mls_x197);
  _mls_retval = _mls_x198;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_mkExpr_pre(_mlsValue _mls_x200, _mlsValue _mls_x201) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x199 = (_mls_x200 == _mlsValue::fromIntLit(0));
  _mls_retval = std::make_tuple(_mls_x199, _mls_x201, _mls_x200);
  return _mls_retval;
}
_mlsValue _mls_reassoc(_mlsValue _mls_e4) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_e4)) {
    auto _mls_x87 = _mlsValue::cast<_mls_Add>(_mls_e4)->_mls_e1;
    auto _mls_x88 = _mlsValue::cast<_mls_Add>(_mls_e4)->_mls_e2;
    if (_mlsValue::isValueOf<_mls_Add>(_mls_x87)) {
      auto _mls_x217 = _mlsValue::cast<_mls_Add>(_mls_x87)->_mls_e1;
      auto _mls_x218 = _mlsValue::cast<_mls_Add>(_mls_x87)->_mls_e2;
      auto _mls_x219 = _mls_reassoc_case0_sr_post(_mls_x217, _mls_x218);
      auto _mls_x220 = _mls_reassoc(_mls_x88);
      auto _mls_x221 = _mls_appendAdd(_mls_x219, _mls_x220);
      _mls_retval = _mls_x221;
    } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x87)) {
      auto _mls_x212 = _mlsValue::cast<_mls_Mul>(_mls_x87)->_mls_e1;
      auto _mls_x213 = _mlsValue::cast<_mls_Mul>(_mls_x87)->_mls_e2;
      auto _mls_x214 = _mls_reassoc_case1_sr_post(_mls_x212, _mls_x213);
      auto _mls_x215 = _mls_reassoc(_mls_x88);
      auto _mls_x216 = _mls_appendAdd(_mls_x214, _mls_x215);
      _mls_retval = _mls_x216;
    } else {
      _mls_retval = _mls_reassoc_caller_post1(_mls_x88, _mls_x87);
    }
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_e4)) {
    auto _mls_x82 = _mlsValue::cast<_mls_Mul>(_mls_e4)->_mls_e1;
    auto _mls_x83 = _mlsValue::cast<_mls_Mul>(_mls_e4)->_mls_e2;
    if (_mlsValue::isValueOf<_mls_Add>(_mls_x82)) {
      auto _mls_x207 = _mlsValue::cast<_mls_Add>(_mls_x82)->_mls_e1;
      auto _mls_x208 = _mlsValue::cast<_mls_Add>(_mls_x82)->_mls_e2;
      auto _mls_x209 = _mls_reassoc_case0_sr_post(_mls_x207, _mls_x208);
      auto _mls_x210 = _mls_reassoc(_mls_x83);
      auto _mls_x211 = _mls_appendMul(_mls_x209, _mls_x210);
      _mls_retval = _mls_x211;
    } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x82)) {
      auto _mls_x202 = _mlsValue::cast<_mls_Mul>(_mls_x82)->_mls_e1;
      auto _mls_x203 = _mlsValue::cast<_mls_Mul>(_mls_x82)->_mls_e2;
      auto _mls_x204 = _mls_reassoc_case1_sr_post(_mls_x202, _mls_x203);
      auto _mls_x205 = _mls_reassoc(_mls_x83);
      auto _mls_x206 = _mls_appendMul(_mls_x204, _mls_x205);
      _mls_retval = _mls_x206;
    } else {
      _mls_retval = _mls_reassoc_caller_post(_mls_x83, _mls_x82);
    }
  } else {
    _mls_retval = _mls_e4;
  }
  return _mls_retval;
}
_mlsValue _mls_reassoc_caller_post(_mlsValue _mls_x222, _mlsValue _mls_x224) {
  _mlsValue _mls_retval;
  auto _mls_x223 = _mls_reassoc(_mls_x222);
  auto _mls_x225 = _mls_appendMul(_mls_x224, _mls_x223);
  _mls_retval = _mls_x225;
  return _mls_retval;
}
_mlsValue _mls_reassoc_caller_post1(_mlsValue _mls_x226, _mlsValue _mls_x228) {
  _mlsValue _mls_retval;
  auto _mls_x227 = _mls_reassoc(_mls_x226);
  auto _mls_x229 = _mls_appendAdd(_mls_x228, _mls_x227);
  _mls_retval = _mls_x229;
  return _mls_retval;
}
_mlsValue _mls_reassoc_case0(_mlsValue _mls_x231) {
  _mlsValue _mls_retval;
  auto _mls_x230 = _mlsValue::cast<_mls_Add>(_mls_x231)->_mls_e1;
  auto _mls_x232 = _mlsValue::cast<_mls_Add>(_mls_x231)->_mls_e2;
  _mls_retval = _mls_reassoc_case0_sr_post(_mls_x230, _mls_x232);
  return _mls_retval;
}
_mlsValue _mls_reassoc_case0_sr_post1(_mlsValue _mls_x233, _mlsValue _mls_x235) {
  _mlsValue _mls_retval;
  auto _mls_x234 = _mls_reassoc(_mls_x233);
  auto _mls_x236 = _mls_reassoc(_mls_x235);
  auto _mls_x237 = _mls_appendAdd(_mls_x234, _mls_x236);
  _mls_retval = _mls_x237;
  return _mls_retval;
}
_mlsValue _mls_reassoc_case0_sr_post(_mlsValue _mls_x238, _mlsValue _mls_x239) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_x238)) {
    auto _mls_x241 = _mls_reassoc_case0(_mls_x238);
    _mls_retval = _mls_reassoc_case0_sr_post_caller_post(_mls_x239, _mls_x241);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x238)) {
    auto _mls_x240 = _mls_reassoc_case1(_mls_x238);
    _mls_retval = _mls_reassoc_case0_sr_post_caller_post(_mls_x239, _mls_x240);
  } else {
    _mls_retval = _mls_reassoc_case0_sr_post_caller_post(_mls_x239, _mls_x238);
  }
  return _mls_retval;
}
_mlsValue _mls_reassoc_case0_sr_post_caller_post(_mlsValue _mls_x242, _mlsValue _mls_x244) {
  _mlsValue _mls_retval;
  auto _mls_x243 = _mls_reassoc(_mls_x242);
  auto _mls_x245 = _mls_appendAdd(_mls_x244, _mls_x243);
  _mls_retval = _mls_x245;
  return _mls_retval;
}
_mlsValue _mls_reassoc_case1(_mlsValue _mls_x247) {
  _mlsValue _mls_retval;
  auto _mls_x246 = _mlsValue::cast<_mls_Mul>(_mls_x247)->_mls_e1;
  auto _mls_x248 = _mlsValue::cast<_mls_Mul>(_mls_x247)->_mls_e2;
  _mls_retval = _mls_reassoc_case1_sr_post(_mls_x246, _mls_x248);
  return _mls_retval;
}
_mlsValue _mls_reassoc_case1_caller_post(_mlsValue _mls_x249, _mlsValue _mls_x251) {
  _mlsValue _mls_retval;
  auto _mls_x250 = _mls_reassoc(_mls_x249);
  auto _mls_x252 = _mls_appendMul(_mls_x251, _mls_x250);
  _mls_retval = _mls_x252;
  return _mls_retval;
}
_mlsValue _mls_reassoc_case1_sr_post(_mlsValue _mls_x253, _mlsValue _mls_x254) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_x253)) {
    auto _mls_x260 = _mlsValue::cast<_mls_Add>(_mls_x253)->_mls_e1;
    auto _mls_x261 = _mlsValue::cast<_mls_Add>(_mls_x253)->_mls_e2;
    auto _mls_x262 = _mls_reassoc_case0_sr_post1(_mls_x260, _mls_x261);
    _mls_retval = _mls_reassoc_case1_caller_post(_mls_x254, _mls_x262);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x253)) {
    auto _mls_x257 = _mlsValue::cast<_mls_Mul>(_mls_x253)->_mls_e1;
    auto _mls_x258 = _mlsValue::cast<_mls_Mul>(_mls_x253)->_mls_e2;
    auto _mls_x259 = _mls_reassoc_case1_sr_post1(_mls_x257, _mls_x258);
    _mls_retval = _mls_reassoc_case1_caller_post(_mls_x254, _mls_x259);
  } else {
    auto _mls_x255 = _mls_reassoc(_mls_x254);
    auto _mls_x256 = _mls_appendMul(_mls_x253, _mls_x255);
    _mls_retval = _mls_x256;
  }
  return _mls_retval;
}
_mlsValue _mls_reassoc_case1_sr_post1(_mlsValue _mls_x263, _mlsValue _mls_x265) {
  _mlsValue _mls_retval;
  auto _mls_x264 = _mls_reassoc(_mls_x263);
  auto _mls_x266 = _mls_reassoc(_mls_x265);
  auto _mls_x267 = _mls_appendMul(_mls_x264, _mls_x266);
  _mls_retval = _mls_x267;
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
