#include "mlsprelude.h"
struct _mls_Branch;
struct _mls_Evaluation;
struct _mls_Lambda_best_;
struct _mls_Lambda_board;
struct _mls_Lambda_cropTree;
struct _mls_Lambda_lambda;
struct _mls_Lambda_lambda1;
struct _mls_Lambda_lambda10;
struct _mls_Lambda_lambda2;
struct _mls_Lambda_lambda3;
struct _mls_Lambda_lambda4;
struct _mls_Lambda_lambda5;
struct _mls_Lambda_lambda6;
struct _mls_Lambda_lambda7;
struct _mls_Lambda_lambda8;
struct _mls_Lambda_lambda9;
struct _mls_Lambda_lscomp1;
struct _mls_Lambda_lscomp2;
struct _mls_Lambda_max_;
struct _mls_Lambda_min_;
struct _mls_Lambda_scorePiece;
struct _mls_Lambda_showMove;
struct _mls_Lambda_static;
struct _mls_Lambda_sum;
struct _mls_List;
struct _mls_Cons;
struct _mls_Nil;
struct _mls_OWin;
struct _mls_Piece;
struct _mls_Empty;
struct _mls_O;
struct _mls_Score;
struct _mls_Tuple2;
struct _mls_X;
struct _mls_XWin;
_mlsValue _mls_alternate(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_andd(_mlsValue);
_mlsValue _mls_append(_mlsValue, _mlsValue);
_mlsValue _mls_best(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_bestMove(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_concat(_mlsValue);
_mlsValue _mls_cropTree(_mlsValue);
_mlsValue _mls_empty(_mlsValue, _mlsValue);
_mlsValue _mls_empty_(_mlsValue, _mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_eqPiece(_mlsValue, _mlsValue);
_mlsValue _mls_eval1(_mlsValue);
_mlsValue _mls_evaluationEq(_mlsValue, _mlsValue);
_mlsValue _mls_foldr(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_fullBoard(_mlsValue);
_mlsValue _mls_go(_mlsValue, _mlsValue);
_mlsValue _mls_insert(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_interpret(_mlsValue, _mlsValue);
_mlsValue _mls_map(_mlsValue, _mlsValue);
_mlsValue _mls_map2(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_mapTree(_mlsValue, _mlsValue);
_mlsValue _mls_max_(_mlsValue, _mlsValue);
_mlsValue _mls_min_(_mlsValue, _mlsValue);
_mlsValue _mls_mise(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_newPositions(_mlsValue, _mlsValue);
_mlsValue _mls_not(_mlsValue);
_mlsValue _mls_opposite(_mlsValue);
_mlsValue _mls_placePiece(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_prog(_mlsValue);
_mlsValue _mls_prune(_mlsValue, _mlsValue);
_mlsValue _mls_repTree(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_run(_mlsValue);
_mlsValue _mls_score(_mlsValue, _mlsValue);
_mlsValue _mls_scorePiece(_mlsValue, _mlsValue);
_mlsValue _mls_searchTree(_mlsValue, _mlsValue);
_mlsValue _mls_showBoard(_mlsValue);
_mlsValue _mls_showEvaluation(_mlsValue);
_mlsValue _mls_showMove(_mlsValue);
_mlsValue _mls_showPiece(_mlsValue);
_mlsValue _mls_showRow(_mlsValue);
_mlsValue _mls_static1(_mlsValue);
_mlsValue _mls_str_to_list(_mlsValue);
_mlsValue _mls_sum(_mlsValue);
_mlsValue _mls_win1();
_mlsValue _mls_win2();
_mlsValue _mls_win3();
_mlsValue _mls_win4();
_mlsValue _mls_win5();
_mlsValue _mls_win6();
_mlsValue _mls_win7();
_mlsValue _mls_win8();
_mlsValue _mls_wins();
struct _mls_Branch: public _mlsObject {
  _mlsValue _mls_a;
  _mlsValue _mls_cs;
  constexpr static inline const char *typeName = "Branch";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_a.print(); std::printf(", "); this->_mls_cs.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_a); _mlsValue::destroy(this->_mls_cs);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_a.asObject()->operator==(*other.cast<_mls_Branch>()->_mls_a.asObject()) && this->_mls_cs.asObject()->operator==(*other.cast<_mls_Branch>()->_mls_cs.asObject()); }
  static _mlsValue create(_mlsValue _mls_a, _mlsValue _mls_cs) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Branch; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_a = _mls_a; _mlsVal->_mls_cs = _mls_cs;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Evaluation: public _mlsObject {
  
  constexpr static inline const char *typeName = "Evaluation";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Evaluation; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Lambda_best_: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_best_";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_best_>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_best_; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply4(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
};
struct _mls_Lambda_board: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_board";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_board; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_cropTree: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_cropTree";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_cropTree; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  _mlsValue _mls_lam_arg1;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print(); std::printf(", "); this->_mls_lam_arg1.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0); _mlsValue::destroy(this->_mls_lam_arg1);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda>()->_mls_lam_arg0.asObject()) && this->_mls_lam_arg1.asObject()->operator==(*other.cast<_mls_Lambda_lambda>()->_mls_lam_arg1.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0, _mlsValue _mls_lam_arg1) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0; _mlsVal->_mls_lam_arg1 = _mls_lam_arg1;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda1: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda1; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda10: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda10; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_lambda2: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda2>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda3: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  _mlsValue _mls_lam_arg1;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print(); std::printf(", "); this->_mls_lam_arg1.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0); _mlsValue::destroy(this->_mls_lam_arg1);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda3>()->_mls_lam_arg0.asObject()) && this->_mls_lam_arg1.asObject()->operator==(*other.cast<_mls_Lambda_lambda3>()->_mls_lam_arg1.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0, _mlsValue _mls_lam_arg1) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda3; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0; _mlsVal->_mls_lam_arg1 = _mls_lam_arg1;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda4: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda4>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda4; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda5: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda5>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda5; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda6: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda6>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda6; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda7: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  _mlsValue _mls_lam_arg1;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print(); std::printf(", "); this->_mls_lam_arg1.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0); _mlsValue::destroy(this->_mls_lam_arg1);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda7>()->_mls_lam_arg0.asObject()) && this->_mls_lam_arg1.asObject()->operator==(*other.cast<_mls_Lambda_lambda7>()->_mls_lam_arg1.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0, _mlsValue _mls_lam_arg1) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda7; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0; _mlsVal->_mls_lam_arg1 = _mls_lam_arg1;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda8: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda8>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda8; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda9: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  _mlsValue _mls_lam_arg1;
  _mlsValue _mls_lam_arg2;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print(); std::printf(", "); this->_mls_lam_arg1.print(); std::printf(", "); this->_mls_lam_arg2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0); _mlsValue::destroy(this->_mls_lam_arg1); _mlsValue::destroy(this->_mls_lam_arg2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda9>()->_mls_lam_arg0.asObject()) && this->_mls_lam_arg1.asObject()->operator==(*other.cast<_mls_Lambda_lambda9>()->_mls_lam_arg1.asObject()) && this->_mls_lam_arg2.asObject()->operator==(*other.cast<_mls_Lambda_lambda9>()->_mls_lam_arg2.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0, _mlsValue _mls_lam_arg1, _mlsValue _mls_lam_arg2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda9; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0; _mlsVal->_mls_lam_arg1 = _mls_lam_arg1; _mlsVal->_mls_lam_arg2 = _mls_lam_arg2;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lscomp1: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lscomp1";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lscomp1; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lscomp2: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  _mlsValue _mls_lam_arg1;
  _mlsValue _mls_lam_arg2;
  constexpr static inline const char *typeName = "Lambda_lscomp2";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print(); std::printf(", "); this->_mls_lam_arg1.print(); std::printf(", "); this->_mls_lam_arg2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0); _mlsValue::destroy(this->_mls_lam_arg1); _mlsValue::destroy(this->_mls_lam_arg2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lscomp2>()->_mls_lam_arg0.asObject()) && this->_mls_lam_arg1.asObject()->operator==(*other.cast<_mls_Lambda_lscomp2>()->_mls_lam_arg1.asObject()) && this->_mls_lam_arg2.asObject()->operator==(*other.cast<_mls_Lambda_lscomp2>()->_mls_lam_arg2.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0, _mlsValue _mls_lam_arg1, _mlsValue _mls_lam_arg2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lscomp2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0; _mlsVal->_mls_lam_arg1 = _mls_lam_arg1; _mlsVal->_mls_lam_arg2 = _mls_lam_arg2;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_max_: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_max_";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_max_; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_min_: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_min_";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_min_; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_scorePiece: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_scorePiece";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_scorePiece; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_showMove: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_showMove";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_showMove; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_static: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_static";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_static; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_sum: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_sum";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_sum; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_List: public _mlsObject {
  
  constexpr static inline const char *typeName = "List";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_List; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Cons: public _mls_List {
  _mlsValue _mls_head;
  _mlsValue _mls_tail;
  constexpr static inline const char *typeName = "Cons";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_head.print(); std::printf(", "); this->_mls_tail.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_head); _mlsValue::destroy(this->_mls_tail);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_head.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_head.asObject()) && this->_mls_tail.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_tail.asObject()); }
  static _mlsValue create(_mlsValue _mls_head, _mlsValue _mls_tail) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Cons; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_head = _mls_head; _mlsVal->_mls_tail = _mls_tail;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Nil: public _mls_List {
  
  constexpr static inline const char *typeName = "Nil";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Nil; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_OWin: public _mls_Evaluation {
  
  constexpr static inline const char *typeName = "OWin";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_OWin; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Piece: public _mlsObject {
  
  constexpr static inline const char *typeName = "Piece";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Piece; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Empty: public _mls_Piece {
  
  constexpr static inline const char *typeName = "Empty";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Empty; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_O: public _mls_Piece {
  
  constexpr static inline const char *typeName = "O";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_O; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Score: public _mls_Evaluation {
  _mlsValue _mls_i;
  constexpr static inline const char *typeName = "Score";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_i.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_i);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_i.asObject()->operator==(*other.cast<_mls_Score>()->_mls_i.asObject()); }
  static _mlsValue create(_mlsValue _mls_i) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Score; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_i = _mls_i;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Tuple2: public _mlsObject {
  _mlsValue _mls_field0;
  _mlsValue _mls_field1;
  constexpr static inline const char *typeName = "Tuple2";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_field0.print(); std::printf(", "); this->_mls_field1.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_field0); _mlsValue::destroy(this->_mls_field1);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_field0.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field0.asObject()) && this->_mls_field1.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field1.asObject()); }
  static _mlsValue create(_mlsValue _mls_field0, _mlsValue _mls_field1) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Tuple2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_field0 = _mls_field0; _mlsVal->_mls_field1 = _mls_field1;  return _mlsValue(_mlsVal); }
  
};
struct _mls_X: public _mls_Piece {
  
  constexpr static inline const char *typeName = "X";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_X; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_XWin: public _mls_Evaluation {
  
  constexpr static inline const char *typeName = "XWin";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_XWin; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_alternate(_mlsValue _mls_player, _mlsValue _mls_f, _mlsValue _mls_g, _mlsValue _mls_board) {
  _mlsValue _mls_retval;
  auto _mls_x85 = _mls_fullBoard(_mls_board);
  if (_mlsValue::isIntLit(_mls_x85, 1)) {
    auto _mls_x104 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x104;
  } else {
    auto _mls_x86 = _mls_static1(_mls_board);
    auto _mls_x87 = _mlsValue::create<_mls_XWin>();
    auto _mls_x88 = _mls_evaluationEq(_mls_x86, _mls_x87);
    if (_mlsValue::isIntLit(_mls_x88, 1)) {
      auto _mls_x103 = _mlsValue::create<_mls_Nil>();
      _mls_retval = _mls_x103;
    } else {
      auto _mls_x89 = _mls_static1(_mls_board);
      auto _mls_x90 = _mlsValue::create<_mls_OWin>();
      auto _mls_x91 = _mls_evaluationEq(_mls_x89, _mls_x90);
      if (_mlsValue::isIntLit(_mls_x91, 1)) {
        auto _mls_x102 = _mlsValue::create<_mls_Nil>();
        _mls_retval = _mls_x102;
      } else {
        auto _mls_x92 = _mls_opposite(_mls_player);
        auto _mls_x93 = _mls_newPositions(_mls_player, _mls_board);
        auto _mls_x94 = _mlsValue::create<_mls_Lambda_lambda9>(_mls_f, _mls_x92, _mls_g);
        auto _mls_x95 = _mls_map(_mls_x94, _mls_x93);
        auto _mls_x96 = _mls_best(_mls_f, _mls_x93, _mls_x95);
        if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x96)) {
          auto _mls_x97 = _mlsValue::cast<_mls_Tuple2>(_mls_x96)->_mls_field0;
          auto _mls_x98 = _mlsValue::cast<_mls_Tuple2>(_mls_x96)->_mls_field1;
          auto _mls_x99 = _mls_alternate(_mls_x92, _mls_g, _mls_f, _mls_x97);
          auto _mls_x100 = _mlsValue::create<_mls_Tuple2>(_mls_x97, _mls_x98);
          auto _mls_x101 = _mlsValue::create<_mls_Cons>(_mls_x100, _mls_x99);
          _mls_retval = _mls_x101;
        } else {
          _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
        }
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_andd(_mlsValue _mls_ls4) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls4)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls4)) {
    auto _mls_x105 = _mlsValue::cast<_mls_Cons>(_mls_ls4)->_mls_head;
    auto _mls_x106 = _mlsValue::cast<_mls_Cons>(_mls_ls4)->_mls_tail;
    auto _mls_x107 = _mls_andd(_mls_x106);
    auto _mls_x108 = (_mls_x105 && _mls_x107);
    _mls_retval = _mls_x108;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_append(_mlsValue _mls_xs, _mlsValue _mls_ys) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs)) {
    _mls_retval = _mls_ys;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs)) {
    auto _mls_x109 = _mlsValue::cast<_mls_Cons>(_mls_xs)->_mls_head;
    auto _mls_x110 = _mlsValue::cast<_mls_Cons>(_mls_xs)->_mls_tail;
    auto _mls_x111 = _mls_append(_mls_x110, _mls_ys);
    auto _mls_x112 = _mlsValue::create<_mls_Cons>(_mls_x109, _mls_x111);
    _mls_retval = _mls_x112;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_best(_mlsValue _mls_f1, _mlsValue _mls_bs, _mlsValue _mls_ss) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_bs)) {
    auto _mls_x113 = _mlsValue::cast<_mls_Cons>(_mls_bs)->_mls_head;
    auto _mls_x114 = _mlsValue::cast<_mls_Cons>(_mls_bs)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_ss)) {
      auto _mls_x115 = _mlsValue::cast<_mls_Cons>(_mls_ss)->_mls_head;
      auto _mls_x116 = _mlsValue::cast<_mls_Cons>(_mls_ss)->_mls_tail;
      auto _mls_x117 = _mlsValue::create<_mls_Lambda_best_>(_mls_f1);
      auto _mls_x118 = _mlsMethodCall<_mls_Callable>(_mls_x117)->_mls_apply4(_mls_x113, _mls_x115, _mls_x114, _mls_x116);
      _mls_retval = _mls_x118;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_bestMove(_mlsValue _mls_p, _mlsValue _mls_f2, _mlsValue _mls_g1, _mlsValue _mls_b1) {
  _mlsValue _mls_retval;
  auto _mls_x119 = _mls_searchTree(_mls_p, _mls_b1);
  auto _mls_x120 = _mlsValue::create<_mls_Lambda_static>();
  auto _mls_x121 = _mls_mapTree(_mls_x120, _mls_x119);
  auto _mls_x122 = _mls_cropTree(_mls_x121);
  auto _mls_x123 = _mls_mise(_mls_f2, _mls_g1, _mls_x122);
  _mls_retval = _mls_x123;
  return _mls_retval;
}
_mlsValue _mls_concat(_mlsValue _mls_ls5) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls5)) {
    auto _mls_x128 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x128;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls5)) {
    auto _mls_x124 = _mlsValue::cast<_mls_Cons>(_mls_ls5)->_mls_head;
    auto _mls_x125 = _mlsValue::cast<_mls_Cons>(_mls_ls5)->_mls_tail;
    auto _mls_x126 = _mls_concat(_mls_x125);
    auto _mls_x127 = _mls_append(_mls_x124, _mls_x126);
    _mls_retval = _mls_x127;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_cropTree(_mlsValue _mls_t) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Branch>(_mls_t)) {
    auto _mls_x129 = _mlsValue::cast<_mls_Branch>(_mls_t)->_mls_a;
    auto _mls_x130 = _mlsValue::cast<_mls_Branch>(_mls_t)->_mls_cs;
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x130)) {
      auto _mls_x138 = _mlsValue::create<_mls_Nil>();
      auto _mls_x139 = _mlsValue::create<_mls_Branch>(_mls_x129, _mls_x138);
      _mls_retval = _mls_x139;
    } else {
      if (_mlsValue::isValueOf<_mls_Score>(_mls_x129)) {
        auto _mls_x133 = _mlsValue::cast<_mls_Score>(_mls_x129)->_mls_i;
        auto _mls_x134 = _mlsValue::create<_mls_Score>(_mls_x133);
        auto _mls_x135 = _mlsValue::create<_mls_Lambda_cropTree>();
        auto _mls_x136 = _mls_map(_mls_x135, _mls_x130);
        auto _mls_x137 = _mlsValue::create<_mls_Branch>(_mls_x134, _mls_x136);
        _mls_retval = _mls_x137;
      } else {
        auto _mls_x131 = _mlsValue::create<_mls_Nil>();
        auto _mls_x132 = _mlsValue::create<_mls_Branch>(_mls_x129, _mls_x131);
        _mls_retval = _mls_x132;
      }
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_empty(_mlsValue _mls_pos1, _mlsValue _mls_board1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_board1)) {
    auto _mls_x140 = _mlsValue::cast<_mls_Cons>(_mls_board1)->_mls_head;
    auto _mls_x141 = _mlsValue::cast<_mls_Cons>(_mls_board1)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x141)) {
      auto _mls_x142 = _mlsValue::cast<_mls_Cons>(_mls_x141)->_mls_head;
      auto _mls_x143 = _mlsValue::cast<_mls_Cons>(_mls_x141)->_mls_tail;
      if (_mlsValue::isValueOf<_mls_Cons>(_mls_x143)) {
        auto _mls_x144 = _mlsValue::cast<_mls_Cons>(_mls_x143)->_mls_head;
        auto _mls_x145 = _mlsValue::cast<_mls_Cons>(_mls_x143)->_mls_tail;
        if (_mlsValue::isValueOf<_mls_Nil>(_mls_x145)) {
          if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_pos1)) {
            auto _mls_x146 = _mlsValue::cast<_mls_Tuple2>(_mls_pos1)->_mls_field0;
            auto _mls_x147 = _mlsValue::cast<_mls_Tuple2>(_mls_pos1)->_mls_field1;
            if (_mlsValue::isIntLit(_mls_x146, 1)) {
              auto _mls_x150 = _mls_empty_(_mls_x147, _mls_x140);
              _mls_retval = _mls_x150;
            } else if (_mlsValue::isIntLit(_mls_x146, 2)) {
              auto _mls_x149 = _mls_empty_(_mls_x147, _mls_x142);
              _mls_retval = _mls_x149;
            } else if (_mlsValue::isIntLit(_mls_x146, 3)) {
              auto _mls_x148 = _mls_empty_(_mls_x147, _mls_x144);
              _mls_retval = _mls_x148;
            } else {
              _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
            }
          } else {
            _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
          }
        } else {
          _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_empty_(_mlsValue _mls_x152, _mlsValue _mls_r) {
  _mlsValue _mls_retval;
  auto _mls_x151 = (_mls_x152 == _mlsValue::fromIntLit(1));
  if (_mlsValue::isIntLit(_mls_x151, 1)) {
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_r)) {
      auto _mls_x174 = _mlsValue::cast<_mls_Cons>(_mls_r)->_mls_head;
      auto _mls_x175 = _mlsValue::cast<_mls_Cons>(_mls_r)->_mls_tail;
      if (_mlsValue::isValueOf<_mls_Empty>(_mls_x174)) {
        if (_mlsValue::isValueOf<_mls_Cons>(_mls_x175)) {
          auto _mls_x194 = _mlsValue::cast<_mls_Cons>(_mls_x175)->_mls_head;
          auto _mls_x195 = _mlsValue::cast<_mls_Cons>(_mls_x175)->_mls_tail;
          if (_mlsValue::isValueOf<_mls_Cons>(_mls_x195)) {
            auto _mls_x200 = _mlsValue::cast<_mls_Cons>(_mls_x195)->_mls_head;
            auto _mls_x201 = _mlsValue::cast<_mls_Cons>(_mls_x195)->_mls_tail;
            if (_mlsValue::isValueOf<_mls_Nil>(_mls_x201)) {
              _mls_retval = _mlsValue::fromIntLit(1);
            } else {
              auto _mls_x202 = (_mls_x152 == _mlsValue::fromIntLit(2));
              if (_mlsValue::isIntLit(_mls_x202, 1)) {
                if (_mlsValue::isValueOf<_mls_Empty>(_mls_x194)) {
                  auto _mls_x205 = (_mls_x152 == _mlsValue::fromIntLit(3));
                  if (_mlsValue::isIntLit(_mls_x205, 1)) {
                    if (_mlsValue::isValueOf<_mls_Empty>(_mls_x200)) {
                      _mls_retval = _mlsValue::fromIntLit(0);
                    } else {
                      _mls_retval = _mlsValue::fromIntLit(0);
                    }
                  } else {
                    _mls_retval = _mlsValue::fromIntLit(0);
                  }
                } else {
                  auto _mls_x204 = (_mls_x152 == _mlsValue::fromIntLit(3));
                  if (_mlsValue::isIntLit(_mls_x204, 1)) {
                    if (_mlsValue::isValueOf<_mls_Empty>(_mls_x200)) {
                      _mls_retval = _mlsValue::fromIntLit(0);
                    } else {
                      _mls_retval = _mlsValue::fromIntLit(0);
                    }
                  } else {
                    _mls_retval = _mlsValue::fromIntLit(0);
                  }
                }
              } else {
                auto _mls_x203 = (_mls_x152 == _mlsValue::fromIntLit(3));
                if (_mlsValue::isIntLit(_mls_x203, 1)) {
                  if (_mlsValue::isValueOf<_mls_Empty>(_mls_x200)) {
                    _mls_retval = _mlsValue::fromIntLit(0);
                  } else {
                    _mls_retval = _mlsValue::fromIntLit(0);
                  }
                } else {
                  _mls_retval = _mlsValue::fromIntLit(0);
                }
              }
            }
          } else {
            auto _mls_x196 = (_mls_x152 == _mlsValue::fromIntLit(2));
            if (_mlsValue::isIntLit(_mls_x196, 1)) {
              if (_mlsValue::isValueOf<_mls_Empty>(_mls_x194)) {
                auto _mls_x199 = (_mls_x152 == _mlsValue::fromIntLit(3));
                if (_mlsValue::isIntLit(_mls_x199, 1)) {
                  _mls_retval = _mlsValue::fromIntLit(0);
                } else {
                  _mls_retval = _mlsValue::fromIntLit(0);
                }
              } else {
                auto _mls_x198 = (_mls_x152 == _mlsValue::fromIntLit(3));
                if (_mlsValue::isIntLit(_mls_x198, 1)) {
                  _mls_retval = _mlsValue::fromIntLit(0);
                } else {
                  _mls_retval = _mlsValue::fromIntLit(0);
                }
              }
            } else {
              auto _mls_x197 = (_mls_x152 == _mlsValue::fromIntLit(3));
              if (_mlsValue::isIntLit(_mls_x197, 1)) {
                _mls_retval = _mlsValue::fromIntLit(0);
              } else {
                _mls_retval = _mlsValue::fromIntLit(0);
              }
            }
          }
        } else {
          auto _mls_x191 = (_mls_x152 == _mlsValue::fromIntLit(2));
          if (_mlsValue::isIntLit(_mls_x191, 1)) {
            auto _mls_x193 = (_mls_x152 == _mlsValue::fromIntLit(3));
            if (_mlsValue::isIntLit(_mls_x193, 1)) {
              _mls_retval = _mlsValue::fromIntLit(0);
            } else {
              _mls_retval = _mlsValue::fromIntLit(0);
            }
          } else {
            auto _mls_x192 = (_mls_x152 == _mlsValue::fromIntLit(3));
            if (_mlsValue::isIntLit(_mls_x192, 1)) {
              _mls_retval = _mlsValue::fromIntLit(0);
            } else {
              _mls_retval = _mlsValue::fromIntLit(0);
            }
          }
        }
      } else {
        auto _mls_x176 = (_mls_x152 == _mlsValue::fromIntLit(2));
        if (_mlsValue::isIntLit(_mls_x176, 1)) {
          if (_mlsValue::isValueOf<_mls_Cons>(_mls_x175)) {
            auto _mls_x182 = _mlsValue::cast<_mls_Cons>(_mls_x175)->_mls_head;
            auto _mls_x183 = _mlsValue::cast<_mls_Cons>(_mls_x175)->_mls_tail;
            if (_mlsValue::isValueOf<_mls_Empty>(_mls_x182)) {
              if (_mlsValue::isValueOf<_mls_Cons>(_mls_x183)) {
                auto _mls_x188 = _mlsValue::cast<_mls_Cons>(_mls_x183)->_mls_head;
                auto _mls_x189 = _mlsValue::cast<_mls_Cons>(_mls_x183)->_mls_tail;
                if (_mlsValue::isValueOf<_mls_Nil>(_mls_x189)) {
                  _mls_retval = _mlsValue::fromIntLit(1);
                } else {
                  auto _mls_x190 = (_mls_x152 == _mlsValue::fromIntLit(3));
                  if (_mlsValue::isIntLit(_mls_x190, 1)) {
                    if (_mlsValue::isValueOf<_mls_Empty>(_mls_x188)) {
                      _mls_retval = _mlsValue::fromIntLit(0);
                    } else {
                      _mls_retval = _mlsValue::fromIntLit(0);
                    }
                  } else {
                    _mls_retval = _mlsValue::fromIntLit(0);
                  }
                }
              } else {
                auto _mls_x187 = (_mls_x152 == _mlsValue::fromIntLit(3));
                if (_mlsValue::isIntLit(_mls_x187, 1)) {
                  _mls_retval = _mlsValue::fromIntLit(0);
                } else {
                  _mls_retval = _mlsValue::fromIntLit(0);
                }
              }
            } else {
              auto _mls_x184 = (_mls_x152 == _mlsValue::fromIntLit(3));
              if (_mlsValue::isIntLit(_mls_x184, 1)) {
                if (_mlsValue::isValueOf<_mls_Cons>(_mls_x183)) {
                  auto _mls_x185 = _mlsValue::cast<_mls_Cons>(_mls_x183)->_mls_head;
                  auto _mls_x186 = _mlsValue::cast<_mls_Cons>(_mls_x183)->_mls_tail;
                  if (_mlsValue::isValueOf<_mls_Empty>(_mls_x185)) {
                    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x186)) {
                      _mls_retval = _mlsValue::fromIntLit(1);
                    } else {
                      _mls_retval = _mlsValue::fromIntLit(0);
                    }
                  } else {
                    _mls_retval = _mlsValue::fromIntLit(0);
                  }
                } else {
                  _mls_retval = _mlsValue::fromIntLit(0);
                }
              } else {
                _mls_retval = _mlsValue::fromIntLit(0);
              }
            }
          } else {
            auto _mls_x181 = (_mls_x152 == _mlsValue::fromIntLit(3));
            if (_mlsValue::isIntLit(_mls_x181, 1)) {
              _mls_retval = _mlsValue::fromIntLit(0);
            } else {
              _mls_retval = _mlsValue::fromIntLit(0);
            }
          }
        } else {
          auto _mls_x177 = (_mls_x152 == _mlsValue::fromIntLit(3));
          if (_mlsValue::isIntLit(_mls_x177, 1)) {
            if (_mlsValue::isValueOf<_mls_Cons>(_mls_x175)) {
              auto _mls_x178 = _mlsValue::cast<_mls_Cons>(_mls_x175)->_mls_tail;
              if (_mlsValue::isValueOf<_mls_Cons>(_mls_x178)) {
                auto _mls_x179 = _mlsValue::cast<_mls_Cons>(_mls_x178)->_mls_head;
                auto _mls_x180 = _mlsValue::cast<_mls_Cons>(_mls_x178)->_mls_tail;
                if (_mlsValue::isValueOf<_mls_Empty>(_mls_x179)) {
                  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x180)) {
                    _mls_retval = _mlsValue::fromIntLit(1);
                  } else {
                    _mls_retval = _mlsValue::fromIntLit(0);
                  }
                } else {
                  _mls_retval = _mlsValue::fromIntLit(0);
                }
              } else {
                _mls_retval = _mlsValue::fromIntLit(0);
              }
            } else {
              _mls_retval = _mlsValue::fromIntLit(0);
            }
          } else {
            _mls_retval = _mlsValue::fromIntLit(0);
          }
        }
      }
    } else {
      auto _mls_x171 = (_mls_x152 == _mlsValue::fromIntLit(2));
      if (_mlsValue::isIntLit(_mls_x171, 1)) {
        auto _mls_x173 = (_mls_x152 == _mlsValue::fromIntLit(3));
        if (_mlsValue::isIntLit(_mls_x173, 1)) {
          _mls_retval = _mlsValue::fromIntLit(0);
        } else {
          _mls_retval = _mlsValue::fromIntLit(0);
        }
      } else {
        auto _mls_x172 = (_mls_x152 == _mlsValue::fromIntLit(3));
        if (_mlsValue::isIntLit(_mls_x172, 1)) {
          _mls_retval = _mlsValue::fromIntLit(0);
        } else {
          _mls_retval = _mlsValue::fromIntLit(0);
        }
      }
    }
  } else {
    auto _mls_x153 = (_mls_x152 == _mlsValue::fromIntLit(2));
    if (_mlsValue::isIntLit(_mls_x153, 1)) {
      if (_mlsValue::isValueOf<_mls_Cons>(_mls_r)) {
        auto _mls_x160 = _mlsValue::cast<_mls_Cons>(_mls_r)->_mls_tail;
        if (_mlsValue::isValueOf<_mls_Cons>(_mls_x160)) {
          auto _mls_x162 = _mlsValue::cast<_mls_Cons>(_mls_x160)->_mls_head;
          auto _mls_x163 = _mlsValue::cast<_mls_Cons>(_mls_x160)->_mls_tail;
          if (_mlsValue::isValueOf<_mls_Empty>(_mls_x162)) {
            if (_mlsValue::isValueOf<_mls_Cons>(_mls_x163)) {
              auto _mls_x168 = _mlsValue::cast<_mls_Cons>(_mls_x163)->_mls_head;
              auto _mls_x169 = _mlsValue::cast<_mls_Cons>(_mls_x163)->_mls_tail;
              if (_mlsValue::isValueOf<_mls_Nil>(_mls_x169)) {
                _mls_retval = _mlsValue::fromIntLit(1);
              } else {
                auto _mls_x170 = (_mls_x152 == _mlsValue::fromIntLit(3));
                if (_mlsValue::isIntLit(_mls_x170, 1)) {
                  if (_mlsValue::isValueOf<_mls_Empty>(_mls_x168)) {
                    _mls_retval = _mlsValue::fromIntLit(0);
                  } else {
                    _mls_retval = _mlsValue::fromIntLit(0);
                  }
                } else {
                  _mls_retval = _mlsValue::fromIntLit(0);
                }
              }
            } else {
              auto _mls_x167 = (_mls_x152 == _mlsValue::fromIntLit(3));
              if (_mlsValue::isIntLit(_mls_x167, 1)) {
                _mls_retval = _mlsValue::fromIntLit(0);
              } else {
                _mls_retval = _mlsValue::fromIntLit(0);
              }
            }
          } else {
            auto _mls_x164 = (_mls_x152 == _mlsValue::fromIntLit(3));
            if (_mlsValue::isIntLit(_mls_x164, 1)) {
              if (_mlsValue::isValueOf<_mls_Cons>(_mls_x163)) {
                auto _mls_x165 = _mlsValue::cast<_mls_Cons>(_mls_x163)->_mls_head;
                auto _mls_x166 = _mlsValue::cast<_mls_Cons>(_mls_x163)->_mls_tail;
                if (_mlsValue::isValueOf<_mls_Empty>(_mls_x165)) {
                  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x166)) {
                    _mls_retval = _mlsValue::fromIntLit(1);
                  } else {
                    _mls_retval = _mlsValue::fromIntLit(0);
                  }
                } else {
                  _mls_retval = _mlsValue::fromIntLit(0);
                }
              } else {
                _mls_retval = _mlsValue::fromIntLit(0);
              }
            } else {
              _mls_retval = _mlsValue::fromIntLit(0);
            }
          }
        } else {
          auto _mls_x161 = (_mls_x152 == _mlsValue::fromIntLit(3));
          if (_mlsValue::isIntLit(_mls_x161, 1)) {
            _mls_retval = _mlsValue::fromIntLit(0);
          } else {
            _mls_retval = _mlsValue::fromIntLit(0);
          }
        }
      } else {
        auto _mls_x159 = (_mls_x152 == _mlsValue::fromIntLit(3));
        if (_mlsValue::isIntLit(_mls_x159, 1)) {
          _mls_retval = _mlsValue::fromIntLit(0);
        } else {
          _mls_retval = _mlsValue::fromIntLit(0);
        }
      }
    } else {
      auto _mls_x154 = (_mls_x152 == _mlsValue::fromIntLit(3));
      if (_mlsValue::isIntLit(_mls_x154, 1)) {
        if (_mlsValue::isValueOf<_mls_Cons>(_mls_r)) {
          auto _mls_x155 = _mlsValue::cast<_mls_Cons>(_mls_r)->_mls_tail;
          if (_mlsValue::isValueOf<_mls_Cons>(_mls_x155)) {
            auto _mls_x156 = _mlsValue::cast<_mls_Cons>(_mls_x155)->_mls_tail;
            if (_mlsValue::isValueOf<_mls_Cons>(_mls_x156)) {
              auto _mls_x157 = _mlsValue::cast<_mls_Cons>(_mls_x156)->_mls_head;
              auto _mls_x158 = _mlsValue::cast<_mls_Cons>(_mls_x156)->_mls_tail;
              if (_mlsValue::isValueOf<_mls_Empty>(_mls_x157)) {
                if (_mlsValue::isValueOf<_mls_Nil>(_mls_x158)) {
                  _mls_retval = _mlsValue::fromIntLit(1);
                } else {
                  _mls_retval = _mlsValue::fromIntLit(0);
                }
              } else {
                _mls_retval = _mlsValue::fromIntLit(0);
              }
            } else {
              _mls_retval = _mlsValue::fromIntLit(0);
            }
          } else {
            _mls_retval = _mlsValue::fromIntLit(0);
          }
        } else {
          _mls_retval = _mlsValue::fromIntLit(0);
        }
      } else {
        _mls_retval = _mlsValue::fromIntLit(0);
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x206 = _mls_run(_mlsValue::fromIntLit(10));
  _mls_retval = _mls_x206;
  return _mls_retval;
}
_mlsValue _mls_eqPiece(_mlsValue _mls_p1, _mlsValue _mls_p2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_X>(_mls_p1)) {
    if (_mlsValue::isValueOf<_mls_X>(_mls_p2)) {
      _mls_retval = _mlsValue::fromIntLit(1);
    } else {
      _mls_retval = _mlsValue::fromIntLit(0);
    }
  } else if (_mlsValue::isValueOf<_mls_O>(_mls_p1)) {
    if (_mlsValue::isValueOf<_mls_O>(_mls_p2)) {
      _mls_retval = _mlsValue::fromIntLit(1);
    } else {
      _mls_retval = _mlsValue::fromIntLit(0);
    }
  } else if (_mlsValue::isValueOf<_mls_Empty>(_mls_p1)) {
    if (_mlsValue::isValueOf<_mls_Empty>(_mls_p2)) {
      _mls_retval = _mlsValue::fromIntLit(1);
    } else {
      _mls_retval = _mlsValue::fromIntLit(0);
    }
  } else {
    _mls_retval = _mlsValue::fromIntLit(0);
  }
  return _mls_retval;
}
_mlsValue _mls_eval1(_mlsValue _mls_x208) {
  _mlsValue _mls_retval;
  auto _mls_x207 = (_mls_x208 == _mlsValue::fromIntLit(3));
  if (_mlsValue::isIntLit(_mls_x207, 1)) {
    auto _mls_x213 = _mlsValue::create<_mls_XWin>();
    _mls_retval = _mls_x213;
  } else {
    auto _mls_x209 = (-_mlsValue::fromIntLit(3));
    auto _mls_x210 = (_mls_x208 == _mls_x209);
    if (_mlsValue::isIntLit(_mls_x210, 1)) {
      auto _mls_x212 = _mlsValue::create<_mls_OWin>();
      _mls_retval = _mls_x212;
    } else {
      auto _mls_x211 = _mlsValue::create<_mls_Score>(_mls_x208);
      _mls_retval = _mls_x211;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_evaluationEq(_mlsValue _mls_x214, _mlsValue _mls_y1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_XWin>(_mls_x214)) {
    if (_mlsValue::isValueOf<_mls_XWin>(_mls_y1)) {
      _mls_retval = _mlsValue::fromIntLit(1);
    } else {
      _mls_retval = _mlsValue::fromIntLit(0);
    }
  } else if (_mlsValue::isValueOf<_mls_OWin>(_mls_x214)) {
    if (_mlsValue::isValueOf<_mls_OWin>(_mls_y1)) {
      _mls_retval = _mlsValue::fromIntLit(1);
    } else {
      _mls_retval = _mlsValue::fromIntLit(0);
    }
  } else if (_mlsValue::isValueOf<_mls_Score>(_mls_x214)) {
    auto _mls_x215 = _mlsValue::cast<_mls_Score>(_mls_x214)->_mls_i;
    if (_mlsValue::isValueOf<_mls_Score>(_mls_y1)) {
      auto _mls_x216 = _mlsValue::cast<_mls_Score>(_mls_y1)->_mls_i;
      auto _mls_x217 = (_mls_x215 == _mls_x216);
      if (_mlsValue::isIntLit(_mls_x217, 1)) {
        _mls_retval = _mlsValue::fromIntLit(1);
      } else {
        _mls_retval = _mlsValue::fromIntLit(0);
      }
    } else {
      _mls_retval = _mlsValue::fromIntLit(0);
    }
  } else {
    _mls_retval = _mlsValue::fromIntLit(0);
  }
  return _mls_retval;
}
_mlsValue _mls_foldr(_mlsValue _mls_f3, _mlsValue _mls_z, _mlsValue _mls_xs1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs1)) {
    _mls_retval = _mls_z;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs1)) {
    auto _mls_x218 = _mlsValue::cast<_mls_Cons>(_mls_xs1)->_mls_head;
    auto _mls_x219 = _mlsValue::cast<_mls_Cons>(_mls_xs1)->_mls_tail;
    auto _mls_x220 = _mls_foldr(_mls_f3, _mls_z, _mls_x219);
    auto _mls_x221 = _mlsMethodCall<_mls_Callable>(_mls_f3)->_mls_apply2(_mls_x218, _mls_x220);
    _mls_retval = _mls_x221;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_fullBoard(_mlsValue _mls_b2) {
  _mlsValue _mls_retval;
  auto _mls_x222 = _mls_concat(_mls_b2);
  auto _mls_x223 = _mlsValue::create<_mls_Lambda_lambda1>();
  auto _mls_x224 = _mls_map(_mls_x223, _mls_x222);
  auto _mls_x225 = _mls_andd(_mls_x224);
  _mls_retval = _mls_x225;
  return _mls_retval;
}
_mlsValue _mls_go(_mlsValue _mls_xs2, _mlsValue _mls_a1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs2)) {
    _mls_retval = _mls_a1;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs2)) {
    auto _mls_x226 = _mlsValue::cast<_mls_Cons>(_mls_xs2)->_mls_head;
    auto _mls_x227 = _mlsValue::cast<_mls_Cons>(_mls_xs2)->_mls_tail;
    auto _mls_x228 = (_mls_a1 + _mls_x226);
    auto _mls_x229 = _mls_go(_mls_x227, _mls_x228);
    _mls_retval = _mls_x229;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_insert(_mlsValue _mls_p3, _mlsValue _mls_ps, _mlsValue _mls_i1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_ps)) {
    auto _mls_x230 = _mlsValue::cast<_mls_Cons>(_mls_ps)->_mls_head;
    auto _mls_x231 = _mlsValue::cast<_mls_Cons>(_mls_ps)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x231)) {
      auto _mls_x232 = _mlsValue::cast<_mls_Cons>(_mls_x231)->_mls_head;
      auto _mls_x233 = _mlsValue::cast<_mls_Cons>(_mls_x231)->_mls_tail;
      if (_mlsValue::isValueOf<_mls_Cons>(_mls_x233)) {
        auto _mls_x234 = _mlsValue::cast<_mls_Cons>(_mls_x233)->_mls_head;
        auto _mls_x235 = _mlsValue::cast<_mls_Cons>(_mls_x233)->_mls_tail;
        if (_mlsValue::isValueOf<_mls_Nil>(_mls_x235)) {
          auto _mls_x236 = (_mls_i1 == _mlsValue::fromIntLit(1));
          if (_mlsValue::isIntLit(_mls_x236, 1)) {
            auto _mls_x247 = _mlsValue::create<_mls_Nil>();
            auto _mls_x248 = _mlsValue::create<_mls_Cons>(_mls_x234, _mls_x247);
            auto _mls_x249 = _mlsValue::create<_mls_Cons>(_mls_x232, _mls_x248);
            auto _mls_x250 = _mlsValue::create<_mls_Cons>(_mls_p3, _mls_x249);
            _mls_retval = _mls_x250;
          } else {
            auto _mls_x237 = (_mls_i1 == _mlsValue::fromIntLit(2));
            if (_mlsValue::isIntLit(_mls_x237, 1)) {
              auto _mls_x243 = _mlsValue::create<_mls_Nil>();
              auto _mls_x244 = _mlsValue::create<_mls_Cons>(_mls_x234, _mls_x243);
              auto _mls_x245 = _mlsValue::create<_mls_Cons>(_mls_p3, _mls_x244);
              auto _mls_x246 = _mlsValue::create<_mls_Cons>(_mls_x230, _mls_x245);
              _mls_retval = _mls_x246;
            } else {
              auto _mls_x238 = (_mls_i1 == _mlsValue::fromIntLit(3));
              if (_mlsValue::isIntLit(_mls_x238, 1)) {
                auto _mls_x239 = _mlsValue::create<_mls_Nil>();
                auto _mls_x240 = _mlsValue::create<_mls_Cons>(_mls_p3, _mls_x239);
                auto _mls_x241 = _mlsValue::create<_mls_Cons>(_mls_x232, _mls_x240);
                auto _mls_x242 = _mlsValue::create<_mls_Cons>(_mls_x230, _mls_x241);
                _mls_retval = _mls_x242;
              } else {
                _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
              }
            }
          }
        } else {
          _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_interpret(_mlsValue _mls_x257, _mlsValue _mls_l) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_l)) {
    auto _mls_x259 = _mlsValue::create<_mls_Score>(_mls_x257);
    _mls_retval = _mls_x259;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_l)) {
    auto _mls_x251 = _mlsValue::cast<_mls_Cons>(_mls_l)->_mls_head;
    auto _mls_x252 = _mlsValue::cast<_mls_Cons>(_mls_l)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Score>(_mls_x251)) {
      auto _mls_x255 = _mlsValue::cast<_mls_Score>(_mls_x251)->_mls_i;
      auto _mls_x256 = (_mls_x257 + _mls_x255);
      auto _mls_x258 = _mls_interpret(_mls_x256, _mls_x252);
      _mls_retval = _mls_x258;
    } else if (_mlsValue::isValueOf<_mls_XWin>(_mls_x251)) {
      auto _mls_x254 = _mlsValue::create<_mls_XWin>();
      _mls_retval = _mls_x254;
    } else if (_mlsValue::isValueOf<_mls_OWin>(_mls_x251)) {
      auto _mls_x253 = _mlsValue::create<_mls_OWin>();
      _mls_retval = _mls_x253;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_map(_mlsValue _mls_f4, _mlsValue _mls_xs3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs3)) {
    auto _mls_x261 = _mlsValue::cast<_mls_Cons>(_mls_xs3)->_mls_head;
    auto _mls_x262 = _mlsValue::cast<_mls_Cons>(_mls_xs3)->_mls_tail;
    auto _mls_x263 = _mlsMethodCall<_mls_Callable>(_mls_f4)->_mls_apply1(_mls_x261);
    auto _mls_x264 = _mls_map(_mls_f4, _mls_x262);
    auto _mls_x265 = _mlsValue::create<_mls_Cons>(_mls_x263, _mls_x264);
    _mls_retval = _mls_x265;
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs3)) {
    auto _mls_x260 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x260;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_map2(_mlsValue _mls_f5, _mlsValue _mls_xs4, _mlsValue _mls_ys1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs4)) {
    auto _mls_x273 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x273;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs4)) {
    auto _mls_x266 = _mlsValue::cast<_mls_Cons>(_mls_xs4)->_mls_head;
    auto _mls_x267 = _mlsValue::cast<_mls_Cons>(_mls_xs4)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_ys1)) {
      auto _mls_x268 = _mlsValue::cast<_mls_Cons>(_mls_ys1)->_mls_head;
      auto _mls_x269 = _mlsValue::cast<_mls_Cons>(_mls_ys1)->_mls_tail;
      auto _mls_x270 = _mlsMethodCall<_mls_Callable>(_mls_f5)->_mls_apply2(_mls_x266, _mls_x268);
      auto _mls_x271 = _mls_map2(_mls_f5, _mls_x267, _mls_x269);
      auto _mls_x272 = _mlsValue::create<_mls_Cons>(_mls_x270, _mls_x271);
      _mls_retval = _mls_x272;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_mapTree(_mlsValue _mls_f6, _mlsValue _mls_t1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Branch>(_mls_t1)) {
    auto _mls_x274 = _mlsValue::cast<_mls_Branch>(_mls_t1)->_mls_a;
    auto _mls_x275 = _mlsValue::cast<_mls_Branch>(_mls_t1)->_mls_cs;
    auto _mls_x276 = _mlsMethodCall<_mls_Callable>(_mls_f6)->_mls_apply1(_mls_x274);
    auto _mls_x277 = _mlsValue::create<_mls_Lambda_lambda6>(_mls_f6);
    auto _mls_x278 = _mls_map(_mls_x277, _mls_x275);
    auto _mls_x279 = _mlsValue::create<_mls_Branch>(_mls_x276, _mls_x278);
    _mls_retval = _mls_x279;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_max_(_mlsValue _mls_e1, _mlsValue _mls_e2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_XWin>(_mls_e1)) {
    auto _mls_x286 = _mlsValue::create<_mls_XWin>();
    _mls_retval = _mls_x286;
  } else {
    if (_mlsValue::isValueOf<_mls_XWin>(_mls_e2)) {
      auto _mls_x285 = _mlsValue::create<_mls_XWin>();
      _mls_retval = _mls_x285;
    } else if (_mlsValue::isValueOf<_mls_OWin>(_mls_e2)) {
      _mls_retval = _mls_e1;
    } else {
      if (_mlsValue::isValueOf<_mls_OWin>(_mls_e1)) {
        _mls_retval = _mls_e2;
      } else if (_mlsValue::isValueOf<_mls_Score>(_mls_e1)) {
        auto _mls_x280 = _mlsValue::cast<_mls_Score>(_mls_e1)->_mls_i;
        if (_mlsValue::isValueOf<_mls_Score>(_mls_e2)) {
          auto _mls_x281 = _mlsValue::cast<_mls_Score>(_mls_e2)->_mls_i;
          auto _mls_x282 = (_mls_x280 > _mls_x281);
          if (_mlsValue::isIntLit(_mls_x282, 1)) {
            auto _mls_x284 = _mlsValue::create<_mls_Score>(_mls_x280);
            _mls_retval = _mls_x284;
          } else {
            auto _mls_x283 = _mlsValue::create<_mls_Score>(_mls_x281);
            _mls_retval = _mls_x283;
          }
        } else {
          _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_min_(_mlsValue _mls_e11, _mlsValue _mls_e21) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_OWin>(_mls_e11)) {
    auto _mls_x293 = _mlsValue::create<_mls_OWin>();
    _mls_retval = _mls_x293;
  } else {
    if (_mlsValue::isValueOf<_mls_OWin>(_mls_e21)) {
      auto _mls_x292 = _mlsValue::create<_mls_OWin>();
      _mls_retval = _mls_x292;
    } else if (_mlsValue::isValueOf<_mls_XWin>(_mls_e21)) {
      _mls_retval = _mls_e11;
    } else {
      if (_mlsValue::isValueOf<_mls_XWin>(_mls_e11)) {
        _mls_retval = _mls_e21;
      } else if (_mlsValue::isValueOf<_mls_Score>(_mls_e11)) {
        auto _mls_x287 = _mlsValue::cast<_mls_Score>(_mls_e11)->_mls_i;
        if (_mlsValue::isValueOf<_mls_Score>(_mls_e21)) {
          auto _mls_x288 = _mlsValue::cast<_mls_Score>(_mls_e21)->_mls_i;
          auto _mls_x289 = (_mls_x287 < _mls_x288);
          if (_mlsValue::isIntLit(_mls_x289, 1)) {
            auto _mls_x291 = _mlsValue::create<_mls_Score>(_mls_x287);
            _mls_retval = _mls_x291;
          } else {
            auto _mls_x290 = _mlsValue::create<_mls_Score>(_mls_x288);
            _mls_retval = _mls_x290;
          }
        } else {
          _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_mise(_mlsValue _mls_f7, _mlsValue _mls_g2, _mlsValue _mls_t2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Branch>(_mls_t2)) {
    auto _mls_x294 = _mlsValue::cast<_mls_Branch>(_mls_t2)->_mls_a;
    auto _mls_x295 = _mlsValue::cast<_mls_Branch>(_mls_t2)->_mls_cs;
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x295)) {
      _mls_retval = _mls_x294;
    } else {
      auto _mls_x296 = _mlsValue::create<_mls_OWin>();
      auto _mls_x297 = _mlsValue::create<_mls_XWin>();
      auto _mls_x298 = _mlsMethodCall<_mls_Callable>(_mls_g2)->_mls_apply2(_mls_x296, _mls_x297);
      auto _mls_x299 = _mlsValue::create<_mls_Lambda_lambda>(_mls_g2, _mls_f7);
      auto _mls_x300 = _mls_map(_mls_x299, _mls_x295);
      auto _mls_x301 = _mls_foldr(_mls_f7, _mls_x298, _mls_x300);
      _mls_retval = _mls_x301;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_newPositions(_mlsValue _mls_piece, _mlsValue _mls_board2) {
  _mlsValue _mls_retval;
  auto _mls_x302 = _mlsValue::create<_mls_Lambda_lscomp1>();
  auto _mls_x303 = _mlsValue::create<_mls_Nil>();
  auto _mls_x304 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(3), _mls_x303);
  auto _mls_x305 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(2), _mls_x304);
  auto _mls_x306 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x305);
  auto _mls_x307 = _mlsMethodCall<_mls_Callable>(_mls_x302)->_mls_apply1(_mls_x306);
  auto _mls_x308 = _mlsValue::create<_mls_Lambda_lambda3>(_mls_piece, _mls_board2);
  auto _mls_x309 = _mls_map(_mls_x308, _mls_x307);
  auto _mls_x310 = _mls_concat(_mls_x309);
  _mls_retval = _mls_x310;
  return _mls_retval;
}
_mlsValue _mls_not(_mlsValue _mls_c) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_c, 1)) {
    _mls_retval = _mlsValue::fromIntLit(0);
  } else {
    _mls_retval = _mlsValue::fromIntLit(1);
  }
  return _mls_retval;
}
_mlsValue _mls_opposite(_mlsValue _mls_p4) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_X>(_mls_p4)) {
    auto _mls_x312 = _mlsValue::create<_mls_O>();
    _mls_retval = _mls_x312;
  } else if (_mlsValue::isValueOf<_mls_O>(_mls_p4)) {
    auto _mls_x311 = _mlsValue::create<_mls_X>();
    _mls_retval = _mls_x311;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_placePiece(_mlsValue _mls_p5, _mlsValue _mls_board3, _mlsValue _mls_pos2) {
  _mlsValue _mls_retval;
  auto _mls_x313 = _mls_empty(_mls_pos2, _mls_board3);
  auto _mls_x314 = _mls_not(_mls_x313);
  if (_mlsValue::isIntLit(_mls_x314, 1)) {
    auto _mls_x344 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x344;
  } else {
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_board3)) {
      auto _mls_x315 = _mlsValue::cast<_mls_Cons>(_mls_board3)->_mls_head;
      auto _mls_x316 = _mlsValue::cast<_mls_Cons>(_mls_board3)->_mls_tail;
      if (_mlsValue::isValueOf<_mls_Cons>(_mls_x316)) {
        auto _mls_x317 = _mlsValue::cast<_mls_Cons>(_mls_x316)->_mls_head;
        auto _mls_x318 = _mlsValue::cast<_mls_Cons>(_mls_x316)->_mls_tail;
        if (_mlsValue::isValueOf<_mls_Cons>(_mls_x318)) {
          auto _mls_x319 = _mlsValue::cast<_mls_Cons>(_mls_x318)->_mls_head;
          auto _mls_x320 = _mlsValue::cast<_mls_Cons>(_mls_x318)->_mls_tail;
          if (_mlsValue::isValueOf<_mls_Nil>(_mls_x320)) {
            if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_pos2)) {
              auto _mls_x321 = _mlsValue::cast<_mls_Tuple2>(_mls_pos2)->_mls_field0;
              auto _mls_x322 = _mlsValue::cast<_mls_Tuple2>(_mls_pos2)->_mls_field1;
              if (_mlsValue::isIntLit(_mls_x321, 1)) {
                auto _mls_x337 = _mls_insert(_mls_p5, _mls_x315, _mls_x322);
                auto _mls_x338 = _mlsValue::create<_mls_Nil>();
                auto _mls_x339 = _mlsValue::create<_mls_Cons>(_mls_x319, _mls_x338);
                auto _mls_x340 = _mlsValue::create<_mls_Cons>(_mls_x317, _mls_x339);
                auto _mls_x341 = _mlsValue::create<_mls_Cons>(_mls_x337, _mls_x340);
                auto _mls_x342 = _mlsValue::create<_mls_Nil>();
                auto _mls_x343 = _mlsValue::create<_mls_Cons>(_mls_x341, _mls_x342);
                _mls_retval = _mls_x343;
              } else if (_mlsValue::isIntLit(_mls_x321, 2)) {
                auto _mls_x330 = _mls_insert(_mls_p5, _mls_x317, _mls_x322);
                auto _mls_x331 = _mlsValue::create<_mls_Nil>();
                auto _mls_x332 = _mlsValue::create<_mls_Cons>(_mls_x319, _mls_x331);
                auto _mls_x333 = _mlsValue::create<_mls_Cons>(_mls_x330, _mls_x332);
                auto _mls_x334 = _mlsValue::create<_mls_Cons>(_mls_x315, _mls_x333);
                auto _mls_x335 = _mlsValue::create<_mls_Nil>();
                auto _mls_x336 = _mlsValue::create<_mls_Cons>(_mls_x334, _mls_x335);
                _mls_retval = _mls_x336;
              } else if (_mlsValue::isIntLit(_mls_x321, 3)) {
                auto _mls_x323 = _mls_insert(_mls_p5, _mls_x319, _mls_x322);
                auto _mls_x324 = _mlsValue::create<_mls_Nil>();
                auto _mls_x325 = _mlsValue::create<_mls_Cons>(_mls_x323, _mls_x324);
                auto _mls_x326 = _mlsValue::create<_mls_Cons>(_mls_x317, _mls_x325);
                auto _mls_x327 = _mlsValue::create<_mls_Cons>(_mls_x315, _mls_x326);
                auto _mls_x328 = _mlsValue::create<_mls_Nil>();
                auto _mls_x329 = _mlsValue::create<_mls_Cons>(_mls_x327, _mls_x328);
                _mls_retval = _mls_x329;
              } else {
                _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
              }
            } else {
              _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
            }
          } else {
            _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
          }
        } else {
          _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  }
  return _mls_retval;
}
_mlsValue _mls_prog(_mlsValue _mls_input) {
  _mlsValue _mls_retval;
  auto _mls_x345 = _mlsValue::create<_mls_Lambda_board>();
  auto _mls_x346 = _mlsMethodCall<_mls_Callable>(_mls_x345)->_mls_apply1(_mls_input);
  auto _mls_x347 = _mlsValue::create<_mls_X>();
  auto _mls_x348 = _mlsValue::create<_mls_Lambda_max_>();
  auto _mls_x349 = _mlsValue::create<_mls_Lambda_min_>();
  auto _mls_x350 = _mls_alternate(_mls_x347, _mls_x348, _mls_x349, _mls_x346);
  auto _mls_x351 = _mls_str_to_list(_mlsValue::create<_mls_Str>("OXO\n"));
  auto _mls_x352 = _mlsValue::create<_mls_Lambda_showMove>();
  auto _mls_x353 = _mls_map(_mls_x352, _mls_x350);
  auto _mls_x354 = _mls_concat(_mls_x353);
  auto _mls_x355 = _mls_append(_mls_x351, _mls_x354);
  _mls_retval = _mls_x355;
  return _mls_retval;
}
_mlsValue _mls_prune(_mlsValue _mls_n, _mlsValue _mls_t3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Branch>(_mls_t3)) {
    auto _mls_x356 = _mlsValue::cast<_mls_Branch>(_mls_t3)->_mls_a;
    auto _mls_x357 = _mlsValue::cast<_mls_Branch>(_mls_t3)->_mls_cs;
    auto _mls_x358 = (_mls_n == _mlsValue::fromIntLit(0));
    if (_mlsValue::isIntLit(_mls_x358, 1)) {
      auto _mls_x363 = _mlsValue::create<_mls_Nil>();
      auto _mls_x364 = _mlsValue::create<_mls_Branch>(_mls_x356, _mls_x363);
      _mls_retval = _mls_x364;
    } else {
      auto _mls_x359 = (_mls_n > _mlsValue::fromIntLit(0));
      if (_mlsValue::isIntLit(_mls_x359, 1)) {
        auto _mls_x360 = _mlsValue::create<_mls_Lambda_lambda2>(_mls_n);
        auto _mls_x361 = _mls_map(_mls_x360, _mls_x357);
        auto _mls_x362 = _mlsValue::create<_mls_Branch>(_mls_x356, _mls_x361);
        _mls_retval = _mls_x362;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_repTree(_mlsValue _mls_f8, _mlsValue _mls_g3, _mlsValue _mls_a2) {
  _mlsValue _mls_retval;
  auto _mls_x365 = _mlsMethodCall<_mls_Callable>(_mls_f8)->_mls_apply1(_mls_a2);
  auto _mls_x366 = _mlsValue::create<_mls_Lambda_lambda7>(_mls_g3, _mls_f8);
  auto _mls_x367 = _mls_map(_mls_x366, _mls_x365);
  auto _mls_x368 = _mlsValue::create<_mls_Branch>(_mls_a2, _mls_x367);
  _mls_retval = _mls_x368;
  return _mls_retval;
}
_mlsValue _mls_run(_mlsValue _mls_n1) {
  _mlsValue _mls_retval;
  auto _mls_x369 = (_mls_n1 == _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x369, 1)) {
    auto _mls_x373 = _mls_prog(_mlsValue::create<_mls_Str>("180000"));
    _mls_retval = _mls_x373;
  } else {
    auto _mls_x370 = _mls_prog(_mlsValue::create<_mls_Str>("180000"));
    auto _mls_x371 = (_mls_n1 - _mlsValue::fromIntLit(1));
    auto _mls_x372 = _mls_run(_mls_x371);
    _mls_retval = _mls_x372;
  }
  return _mls_retval;
}
_mlsValue _mls_score(_mlsValue _mls_board4, _mlsValue _mls_win) {
  _mlsValue _mls_retval;
  auto _mls_x374 = _mlsValue::create<_mls_Lambda_lambda10>();
  auto _mls_x375 = _mls_map2(_mls_x374, _mls_board4, _mls_win);
  auto _mls_x376 = _mlsValue::create<_mls_Lambda_sum>();
  auto _mls_x377 = _mls_map(_mls_x376, _mls_x375);
  auto _mls_x378 = _mls_go(_mls_x377, _mlsValue::fromIntLit(0));
  auto _mls_x379 = _mls_eval1(_mls_x378);
  _mls_retval = _mls_x379;
  return _mls_retval;
}
_mlsValue _mls_scorePiece(_mlsValue _mls_p6, _mlsValue _mls_score1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_X>(_mls_p6)) {
    _mls_retval = _mls_score1;
  } else if (_mlsValue::isValueOf<_mls_Empty>(_mls_p6)) {
    _mls_retval = _mlsValue::fromIntLit(0);
  } else if (_mlsValue::isValueOf<_mls_O>(_mls_p6)) {
    auto _mls_x380 = (-_mls_score1);
    _mls_retval = _mls_x380;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_searchTree(_mlsValue _mls_p7, _mlsValue _mls_board5) {
  _mlsValue _mls_retval;
  auto _mls_x381 = _mlsValue::create<_mls_Lambda_lambda5>(_mls_p7);
  auto _mls_x382 = _mlsValue::create<_mls_Lambda_lambda4>(_mls_p7);
  auto _mls_x383 = _mls_repTree(_mls_x381, _mls_x382, _mls_board5);
  auto _mls_x384 = _mls_prune(_mlsValue::fromIntLit(5), _mls_x383);
  _mls_retval = _mls_x384;
  return _mls_retval;
}
_mlsValue _mls_showBoard(_mlsValue _mls_rs) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_rs)) {
    auto _mls_x385 = _mlsValue::cast<_mls_Cons>(_mls_rs)->_mls_head;
    auto _mls_x386 = _mlsValue::cast<_mls_Cons>(_mls_rs)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x386)) {
      auto _mls_x387 = _mlsValue::cast<_mls_Cons>(_mls_x386)->_mls_head;
      auto _mls_x388 = _mlsValue::cast<_mls_Cons>(_mls_x386)->_mls_tail;
      if (_mlsValue::isValueOf<_mls_Cons>(_mls_x388)) {
        auto _mls_x389 = _mlsValue::cast<_mls_Cons>(_mls_x388)->_mls_head;
        auto _mls_x390 = _mlsValue::cast<_mls_Cons>(_mls_x388)->_mls_tail;
        if (_mlsValue::isValueOf<_mls_Nil>(_mls_x390)) {
          auto _mls_x391 = _mls_showRow(_mls_x385);
          auto _mls_x392 = _mls_str_to_list(_mlsValue::create<_mls_Str>("\n-------\n"));
          auto _mls_x393 = _mls_showRow(_mls_x387);
          auto _mls_x394 = _mls_str_to_list(_mlsValue::create<_mls_Str>("\n------\n"));
          auto _mls_x395 = _mls_showRow(_mls_x389);
          auto _mls_x396 = _mls_str_to_list(_mlsValue::create<_mls_Str>("\n\n"));
          auto _mls_x397 = _mls_append(_mls_x395, _mls_x396);
          auto _mls_x398 = _mls_append(_mls_x394, _mls_x397);
          auto _mls_x399 = _mls_append(_mls_x393, _mls_x398);
          auto _mls_x400 = _mls_append(_mls_x392, _mls_x399);
          auto _mls_x401 = _mls_append(_mls_x391, _mls_x400);
          _mls_retval = _mls_x401;
        } else {
          _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_showEvaluation(_mlsValue _mls_e) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_XWin>(_mls_e)) {
    auto _mls_x408 = _mls_str_to_list(_mlsValue::create<_mls_Str>("XWin"));
    _mls_retval = _mls_x408;
  } else if (_mlsValue::isValueOf<_mls_OWin>(_mls_e)) {
    auto _mls_x407 = _mls_str_to_list(_mlsValue::create<_mls_Str>("OWin"));
    _mls_retval = _mls_x407;
  } else if (_mlsValue::isValueOf<_mls_Score>(_mls_e)) {
    auto _mls_x402 = _mlsValue::cast<_mls_Score>(_mls_e)->_mls_i;
    auto _mls_x403 = _mls_str_to_list(_mlsValue::create<_mls_Str>("Score "));
    auto _mls_x404 = _mls_builtin_int2str(_mls_x402);
    auto _mls_x405 = _mls_str_to_list(_mls_x404);
    auto _mls_x406 = _mls_append(_mls_x403, _mls_x405);
    _mls_retval = _mls_x406;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_showMove(_mlsValue _mls_m) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_m)) {
    auto _mls_x409 = _mlsValue::cast<_mls_Tuple2>(_mls_m)->_mls_field0;
    auto _mls_x410 = _mlsValue::cast<_mls_Tuple2>(_mls_m)->_mls_field1;
    auto _mls_x411 = _mls_showEvaluation(_mls_x410);
    auto _mls_x412 = _mls_str_to_list(_mlsValue::create<_mls_Str>("\n"));
    auto _mls_x413 = _mls_showBoard(_mls_x409);
    auto _mls_x414 = _mls_append(_mls_x412, _mls_x413);
    auto _mls_x415 = _mls_append(_mls_x411, _mls_x414);
    _mls_retval = _mls_x415;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_showPiece(_mlsValue _mls_p8) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_X>(_mls_p8)) {
    auto _mls_x418 = _mls_str_to_list(_mlsValue::create<_mls_Str>("X"));
    _mls_retval = _mls_x418;
  } else if (_mlsValue::isValueOf<_mls_O>(_mls_p8)) {
    auto _mls_x417 = _mls_str_to_list(_mlsValue::create<_mls_Str>("O"));
    _mls_retval = _mls_x417;
  } else if (_mlsValue::isValueOf<_mls_Empty>(_mls_p8)) {
    auto _mls_x416 = _mls_str_to_list(_mlsValue::create<_mls_Str>(" "));
    _mls_retval = _mls_x416;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_showRow(_mlsValue _mls_ps1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_ps1)) {
    auto _mls_x419 = _mlsValue::cast<_mls_Cons>(_mls_ps1)->_mls_head;
    auto _mls_x420 = _mlsValue::cast<_mls_Cons>(_mls_ps1)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x420)) {
      auto _mls_x421 = _mlsValue::cast<_mls_Cons>(_mls_x420)->_mls_head;
      auto _mls_x422 = _mlsValue::cast<_mls_Cons>(_mls_x420)->_mls_tail;
      if (_mlsValue::isValueOf<_mls_Cons>(_mls_x422)) {
        auto _mls_x423 = _mlsValue::cast<_mls_Cons>(_mls_x422)->_mls_head;
        auto _mls_x424 = _mlsValue::cast<_mls_Cons>(_mls_x422)->_mls_tail;
        if (_mlsValue::isValueOf<_mls_Nil>(_mls_x424)) {
          auto _mls_x425 = _mls_showPiece(_mls_x419);
          auto _mls_x426 = _mls_str_to_list(_mlsValue::create<_mls_Str>("|"));
          auto _mls_x427 = _mls_showPiece(_mls_x421);
          auto _mls_x428 = _mls_str_to_list(_mlsValue::create<_mls_Str>("|"));
          auto _mls_x429 = _mls_showPiece(_mls_x423);
          auto _mls_x430 = _mls_append(_mls_x428, _mls_x429);
          auto _mls_x431 = _mls_append(_mls_x427, _mls_x430);
          auto _mls_x432 = _mls_append(_mls_x426, _mls_x431);
          auto _mls_x433 = _mls_append(_mls_x425, _mls_x432);
          _mls_retval = _mls_x433;
        } else {
          _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_static1(_mlsValue _mls_board6) {
  _mlsValue _mls_retval;
  auto _mls_x434 = _mls_wins();
  auto _mls_x435 = _mlsValue::create<_mls_Lambda_lambda8>(_mls_board6);
  auto _mls_x436 = _mls_map(_mls_x435, _mls_x434);
  auto _mls_x437 = _mls_interpret(_mlsValue::fromIntLit(0), _mls_x436);
  _mls_retval = _mls_x437;
  return _mls_retval;
}
_mlsValue _mls_str_to_list(_mlsValue _mls_x439) {
  _mlsValue _mls_retval;
  auto _mls_x438 = _mls_builtin_str_head(_mls_x439);
  if (_mlsValue::isValueOf<_mls_Unit>(_mls_x438)) {
    auto _mls_x444 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x444;
  } else {
    auto _mls_x440 = _mls_builtin_str_head(_mls_x439);
    auto _mls_x441 = _mls_builtin_str_tail(_mls_x439);
    auto _mls_x442 = _mls_str_to_list(_mls_x441);
    auto _mls_x443 = _mlsValue::create<_mls_Cons>(_mls_x440, _mls_x442);
    _mls_retval = _mls_x443;
  }
  return _mls_retval;
}
_mlsValue _mls_sum(_mlsValue _mls_xs5) {
  _mlsValue _mls_retval;
  auto _mls_x445 = _mls_go(_mls_xs5, _mlsValue::fromIntLit(0));
  _mls_retval = _mls_x445;
  return _mls_retval;
}
_mlsValue _mls_win1() {
  _mlsValue _mls_retval;
  auto _mls_x446 = _mlsValue::create<_mls_Nil>();
  auto _mls_x447 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x446);
  auto _mls_x448 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x447);
  auto _mls_x449 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x448);
  auto _mls_x450 = _mlsValue::create<_mls_Nil>();
  auto _mls_x451 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x450);
  auto _mls_x452 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x451);
  auto _mls_x453 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x452);
  auto _mls_x454 = _mlsValue::create<_mls_Nil>();
  auto _mls_x455 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x454);
  auto _mls_x456 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x455);
  auto _mls_x457 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x456);
  auto _mls_x458 = _mlsValue::create<_mls_Nil>();
  auto _mls_x459 = _mlsValue::create<_mls_Cons>(_mls_x457, _mls_x458);
  auto _mls_x460 = _mlsValue::create<_mls_Cons>(_mls_x453, _mls_x459);
  auto _mls_x461 = _mlsValue::create<_mls_Cons>(_mls_x449, _mls_x460);
  _mls_retval = _mls_x461;
  return _mls_retval;
}
_mlsValue _mls_win2() {
  _mlsValue _mls_retval;
  auto _mls_x462 = _mlsValue::create<_mls_Nil>();
  auto _mls_x463 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x462);
  auto _mls_x464 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x463);
  auto _mls_x465 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x464);
  auto _mls_x466 = _mlsValue::create<_mls_Nil>();
  auto _mls_x467 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x466);
  auto _mls_x468 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x467);
  auto _mls_x469 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x468);
  auto _mls_x470 = _mlsValue::create<_mls_Nil>();
  auto _mls_x471 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x470);
  auto _mls_x472 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x471);
  auto _mls_x473 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x472);
  auto _mls_x474 = _mlsValue::create<_mls_Nil>();
  auto _mls_x475 = _mlsValue::create<_mls_Cons>(_mls_x473, _mls_x474);
  auto _mls_x476 = _mlsValue::create<_mls_Cons>(_mls_x469, _mls_x475);
  auto _mls_x477 = _mlsValue::create<_mls_Cons>(_mls_x465, _mls_x476);
  _mls_retval = _mls_x477;
  return _mls_retval;
}
_mlsValue _mls_win3() {
  _mlsValue _mls_retval;
  auto _mls_x478 = _mlsValue::create<_mls_Nil>();
  auto _mls_x479 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x478);
  auto _mls_x480 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x479);
  auto _mls_x481 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x480);
  auto _mls_x482 = _mlsValue::create<_mls_Nil>();
  auto _mls_x483 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x482);
  auto _mls_x484 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x483);
  auto _mls_x485 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x484);
  auto _mls_x486 = _mlsValue::create<_mls_Nil>();
  auto _mls_x487 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x486);
  auto _mls_x488 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x487);
  auto _mls_x489 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x488);
  auto _mls_x490 = _mlsValue::create<_mls_Nil>();
  auto _mls_x491 = _mlsValue::create<_mls_Cons>(_mls_x489, _mls_x490);
  auto _mls_x492 = _mlsValue::create<_mls_Cons>(_mls_x485, _mls_x491);
  auto _mls_x493 = _mlsValue::create<_mls_Cons>(_mls_x481, _mls_x492);
  _mls_retval = _mls_x493;
  return _mls_retval;
}
_mlsValue _mls_win4() {
  _mlsValue _mls_retval;
  auto _mls_x494 = _mlsValue::create<_mls_Nil>();
  auto _mls_x495 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x494);
  auto _mls_x496 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x495);
  auto _mls_x497 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x496);
  auto _mls_x498 = _mlsValue::create<_mls_Nil>();
  auto _mls_x499 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x498);
  auto _mls_x500 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x499);
  auto _mls_x501 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x500);
  auto _mls_x502 = _mlsValue::create<_mls_Nil>();
  auto _mls_x503 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x502);
  auto _mls_x504 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x503);
  auto _mls_x505 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x504);
  auto _mls_x506 = _mlsValue::create<_mls_Nil>();
  auto _mls_x507 = _mlsValue::create<_mls_Cons>(_mls_x505, _mls_x506);
  auto _mls_x508 = _mlsValue::create<_mls_Cons>(_mls_x501, _mls_x507);
  auto _mls_x509 = _mlsValue::create<_mls_Cons>(_mls_x497, _mls_x508);
  _mls_retval = _mls_x509;
  return _mls_retval;
}
_mlsValue _mls_win5() {
  _mlsValue _mls_retval;
  auto _mls_x510 = _mlsValue::create<_mls_Nil>();
  auto _mls_x511 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x510);
  auto _mls_x512 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x511);
  auto _mls_x513 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x512);
  auto _mls_x514 = _mlsValue::create<_mls_Nil>();
  auto _mls_x515 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x514);
  auto _mls_x516 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x515);
  auto _mls_x517 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x516);
  auto _mls_x518 = _mlsValue::create<_mls_Nil>();
  auto _mls_x519 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x518);
  auto _mls_x520 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x519);
  auto _mls_x521 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x520);
  auto _mls_x522 = _mlsValue::create<_mls_Nil>();
  auto _mls_x523 = _mlsValue::create<_mls_Cons>(_mls_x521, _mls_x522);
  auto _mls_x524 = _mlsValue::create<_mls_Cons>(_mls_x517, _mls_x523);
  auto _mls_x525 = _mlsValue::create<_mls_Cons>(_mls_x513, _mls_x524);
  _mls_retval = _mls_x525;
  return _mls_retval;
}
_mlsValue _mls_win6() {
  _mlsValue _mls_retval;
  auto _mls_x526 = _mlsValue::create<_mls_Nil>();
  auto _mls_x527 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x526);
  auto _mls_x528 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x527);
  auto _mls_x529 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x528);
  auto _mls_x530 = _mlsValue::create<_mls_Nil>();
  auto _mls_x531 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x530);
  auto _mls_x532 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x531);
  auto _mls_x533 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x532);
  auto _mls_x534 = _mlsValue::create<_mls_Nil>();
  auto _mls_x535 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x534);
  auto _mls_x536 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x535);
  auto _mls_x537 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x536);
  auto _mls_x538 = _mlsValue::create<_mls_Nil>();
  auto _mls_x539 = _mlsValue::create<_mls_Cons>(_mls_x537, _mls_x538);
  auto _mls_x540 = _mlsValue::create<_mls_Cons>(_mls_x533, _mls_x539);
  auto _mls_x541 = _mlsValue::create<_mls_Cons>(_mls_x529, _mls_x540);
  _mls_retval = _mls_x541;
  return _mls_retval;
}
_mlsValue _mls_win7() {
  _mlsValue _mls_retval;
  auto _mls_x542 = _mlsValue::create<_mls_Nil>();
  auto _mls_x543 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x542);
  auto _mls_x544 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x543);
  auto _mls_x545 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x544);
  auto _mls_x546 = _mlsValue::create<_mls_Nil>();
  auto _mls_x547 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x546);
  auto _mls_x548 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x547);
  auto _mls_x549 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x548);
  auto _mls_x550 = _mlsValue::create<_mls_Nil>();
  auto _mls_x551 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x550);
  auto _mls_x552 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x551);
  auto _mls_x553 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x552);
  auto _mls_x554 = _mlsValue::create<_mls_Nil>();
  auto _mls_x555 = _mlsValue::create<_mls_Cons>(_mls_x553, _mls_x554);
  auto _mls_x556 = _mlsValue::create<_mls_Cons>(_mls_x549, _mls_x555);
  auto _mls_x557 = _mlsValue::create<_mls_Cons>(_mls_x545, _mls_x556);
  _mls_retval = _mls_x557;
  return _mls_retval;
}
_mlsValue _mls_win8() {
  _mlsValue _mls_retval;
  auto _mls_x558 = _mlsValue::create<_mls_Nil>();
  auto _mls_x559 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x558);
  auto _mls_x560 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x559);
  auto _mls_x561 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x560);
  auto _mls_x562 = _mlsValue::create<_mls_Nil>();
  auto _mls_x563 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x562);
  auto _mls_x564 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x563);
  auto _mls_x565 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x564);
  auto _mls_x566 = _mlsValue::create<_mls_Nil>();
  auto _mls_x567 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x566);
  auto _mls_x568 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x567);
  auto _mls_x569 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x568);
  auto _mls_x570 = _mlsValue::create<_mls_Nil>();
  auto _mls_x571 = _mlsValue::create<_mls_Cons>(_mls_x569, _mls_x570);
  auto _mls_x572 = _mlsValue::create<_mls_Cons>(_mls_x565, _mls_x571);
  auto _mls_x573 = _mlsValue::create<_mls_Cons>(_mls_x561, _mls_x572);
  _mls_retval = _mls_x573;
  return _mls_retval;
}
_mlsValue _mls_wins() {
  _mlsValue _mls_retval;
  auto _mls_x574 = _mls_win1();
  auto _mls_x575 = _mls_win2();
  auto _mls_x576 = _mls_win3();
  auto _mls_x577 = _mls_win4();
  auto _mls_x578 = _mls_win5();
  auto _mls_x579 = _mls_win6();
  auto _mls_x580 = _mls_win7();
  auto _mls_x581 = _mls_win8();
  auto _mls_x582 = _mlsValue::create<_mls_Nil>();
  auto _mls_x583 = _mlsValue::create<_mls_Cons>(_mls_x581, _mls_x582);
  auto _mls_x584 = _mlsValue::create<_mls_Cons>(_mls_x580, _mls_x583);
  auto _mls_x585 = _mlsValue::create<_mls_Cons>(_mls_x579, _mls_x584);
  auto _mls_x586 = _mlsValue::create<_mls_Cons>(_mls_x578, _mls_x585);
  auto _mls_x587 = _mlsValue::create<_mls_Cons>(_mls_x577, _mls_x586);
  auto _mls_x588 = _mlsValue::create<_mls_Cons>(_mls_x576, _mls_x587);
  auto _mls_x589 = _mlsValue::create<_mls_Cons>(_mls_x575, _mls_x588);
  auto _mls_x590 = _mlsValue::create<_mls_Cons>(_mls_x574, _mls_x589);
  _mls_retval = _mls_x590;
  return _mls_retval;
}
_mlsValue _mls_Lambda_best_::_mls_apply4(_mlsValue _mls_b, _mlsValue _mls_s, _mlsValue _mls_ls1, _mlsValue _mls_ls2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls1)) {
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls2)) {
      auto _mls_x8 = _mlsValue::create<_mls_Tuple2>(_mls_b, _mls_s);
      _mls_retval = _mls_x8;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls1)) {
    auto _mls_x = _mlsValue::cast<_mls_Cons>(_mls_ls1)->_mls_head;
    auto _mls_x1 = _mlsValue::cast<_mls_Cons>(_mls_ls1)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls2)) {
      auto _mls_x2 = _mlsValue::cast<_mls_Cons>(_mls_ls2)->_mls_head;
      auto _mls_x3 = _mlsValue::cast<_mls_Cons>(_mls_ls2)->_mls_tail;
      auto _mls_x4 = _mlsMethodCall<_mls_Callable>(_mls_lam_arg0)->_mls_apply2(_mls_s, _mls_x2);
      auto _mls_x5 = _mls_evaluationEq(_mls_s, _mls_x4);
      if (_mlsValue::isIntLit(_mls_x5, 1)) {
        auto _mls_x7 = this->_mls_apply4(_mls_b, _mls_s, _mls_x1, _mls_x3);
        _mls_retval = _mls_x7;
      } else {
        auto _mls_x6 = this->_mls_apply4(_mls_x, _mls_x2, _mls_x1, _mls_x3);
        _mls_retval = _mls_x6;
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_board::_mls_apply1(_mlsValue _mls_x35) {
  _mlsValue _mls_retval;
  auto _mls_x9 = _mlsValue::create<_mls_Empty>();
  auto _mls_x10 = _mlsValue::create<_mls_Nil>();
  auto _mls_x11 = _mlsValue::create<_mls_Cons>(_mls_x9, _mls_x10);
  auto _mls_x12 = _mlsValue::create<_mls_O>();
  auto _mls_x13 = _mlsValue::create<_mls_Cons>(_mls_x12, _mls_x11);
  auto _mls_x14 = _mlsValue::create<_mls_Empty>();
  auto _mls_x15 = _mlsValue::create<_mls_Cons>(_mls_x14, _mls_x13);
  auto _mls_x16 = _mlsValue::create<_mls_Empty>();
  auto _mls_x17 = _mlsValue::create<_mls_Nil>();
  auto _mls_x18 = _mlsValue::create<_mls_Cons>(_mls_x16, _mls_x17);
  auto _mls_x19 = _mlsValue::create<_mls_X>();
  auto _mls_x20 = _mlsValue::create<_mls_Cons>(_mls_x19, _mls_x18);
  auto _mls_x21 = _mlsValue::create<_mls_Empty>();
  auto _mls_x22 = _mlsValue::create<_mls_Cons>(_mls_x21, _mls_x20);
  auto _mls_x23 = _mlsValue::create<_mls_Empty>();
  auto _mls_x24 = _mlsValue::create<_mls_Nil>();
  auto _mls_x25 = _mlsValue::create<_mls_Cons>(_mls_x23, _mls_x24);
  auto _mls_x26 = _mlsValue::create<_mls_Empty>();
  auto _mls_x27 = _mlsValue::create<_mls_Cons>(_mls_x26, _mls_x25);
  auto _mls_x28 = _mlsValue::create<_mls_Empty>();
  auto _mls_x29 = _mlsValue::create<_mls_Cons>(_mls_x28, _mls_x27);
  auto _mls_x30 = _mlsValue::create<_mls_Nil>();
  auto _mls_x31 = _mlsValue::create<_mls_Cons>(_mls_x29, _mls_x30);
  auto _mls_x32 = _mlsValue::create<_mls_Cons>(_mls_x22, _mls_x31);
  auto _mls_x33 = _mlsValue::create<_mls_Cons>(_mls_x15, _mls_x32);
  auto _mls_x34 = (_mls_x35 == _mlsValue::create<_mls_Str>("doesn't happen"));
  if (_mlsValue::isIntLit(_mls_x34, 1)) {
    auto _mls_x36 = _mls_append(_mls_x33, _mls_x33);
    _mls_retval = _mls_x36;
  } else {
    _mls_retval = _mls_x33;
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_cropTree::_mls_apply1(_mlsValue _mls_arg) {
  _mlsValue _mls_retval;
  auto _mls_x37 = _mls_cropTree(_mls_arg);
  _mls_retval = _mls_x37;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda::_mls_apply1(_mlsValue _mls_x38) {
  _mlsValue _mls_retval;
  auto _mls_x39 = _mls_mise(_mls_lam_arg0, _mls_lam_arg1, _mls_x38);
  _mls_retval = _mls_x39;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda1::_mls_apply1(_mlsValue _mls_x41) {
  _mlsValue _mls_retval;
  auto _mls_x40 = _mlsValue::create<_mls_Empty>();
  auto _mls_x42 = _mls_eqPiece(_mls_x41, _mls_x40);
  auto _mls_x43 = _mls_not(_mls_x42);
  _mls_retval = _mls_x43;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda10::_mls_apply2(_mlsValue _mls_x45, _mlsValue _mls_y) {
  _mlsValue _mls_retval;
  auto _mls_x44 = _mlsValue::create<_mls_Lambda_scorePiece>();
  auto _mls_x46 = _mls_map2(_mls_x44, _mls_x45, _mls_y);
  _mls_retval = _mls_x46;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda2::_mls_apply1(_mlsValue _mls_x48) {
  _mlsValue _mls_retval;
  auto _mls_x47 = (_mls_lam_arg0 - _mlsValue::fromIntLit(1));
  auto _mls_x49 = _mls_prune(_mls_x47, _mls_x48);
  _mls_retval = _mls_x49;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda3::_mls_apply1(_mlsValue _mls_pos) {
  _mlsValue _mls_retval;
  auto _mls_x50 = _mls_placePiece(_mls_lam_arg0, _mls_lam_arg1, _mls_pos);
  _mls_retval = _mls_x50;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda4::_mls_apply1(_mlsValue _mls_x52) {
  _mlsValue _mls_retval;
  auto _mls_x51 = _mls_opposite(_mls_lam_arg0);
  auto _mls_x53 = _mls_newPositions(_mls_x51, _mls_x52);
  _mls_retval = _mls_x53;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda5::_mls_apply1(_mlsValue _mls_x54) {
  _mlsValue _mls_retval;
  auto _mls_x55 = _mls_newPositions(_mls_lam_arg0, _mls_x54);
  _mls_retval = _mls_x55;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda6::_mls_apply1(_mlsValue _mls_x56) {
  _mlsValue _mls_retval;
  auto _mls_x57 = _mls_mapTree(_mls_lam_arg0, _mls_x56);
  _mls_retval = _mls_x57;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda7::_mls_apply1(_mlsValue _mls_x58) {
  _mlsValue _mls_retval;
  auto _mls_x59 = _mls_repTree(_mls_lam_arg0, _mls_lam_arg1, _mls_x58);
  _mls_retval = _mls_x59;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda8::_mls_apply1(_mlsValue _mls_x60) {
  _mlsValue _mls_retval;
  auto _mls_x61 = _mls_score(_mls_lam_arg0, _mls_x60);
  _mls_retval = _mls_x61;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda9::_mls_apply1(_mlsValue _mls_x62) {
  _mlsValue _mls_retval;
  auto _mls_x63 = _mls_bestMove(_mls_lam_arg1, _mls_lam_arg2, _mls_lam_arg0, _mls_x62);
  _mls_retval = _mls_x63;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lscomp1::_mls_apply1(_mlsValue _mls_ls) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls)) {
    auto _mls_x72 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x72;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls)) {
    auto _mls_x64 = _mlsValue::cast<_mls_Cons>(_mls_ls)->_mls_head;
    auto _mls_x65 = _mlsValue::cast<_mls_Cons>(_mls_ls)->_mls_tail;
    auto _mls_x66 = _mlsValue::create<_mls_Lambda_lscomp2>(_mls_x65, _mls_x64, _mlsValue(this, _mlsValue::inc_ref_tag{}));
    auto _mls_x67 = _mlsValue::create<_mls_Nil>();
    auto _mls_x68 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(3), _mls_x67);
    auto _mls_x69 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(2), _mls_x68);
    auto _mls_x70 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x69);
    auto _mls_x71 = _mlsMethodCall<_mls_Callable>(_mls_x66)->_mls_apply1(_mls_x70);
    _mls_retval = _mls_x71;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lscomp2::_mls_apply1(_mlsValue _mls_ls3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls3)) {
    auto _mls_x78 = _mlsMethodCall<_mls_Callable>(_mls_lam_arg2)->_mls_apply1(_mls_lam_arg0);
    _mls_retval = _mls_x78;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls3)) {
    auto _mls_x73 = _mlsValue::cast<_mls_Cons>(_mls_ls3)->_mls_head;
    auto _mls_x74 = _mlsValue::cast<_mls_Cons>(_mls_ls3)->_mls_tail;
    auto _mls_x75 = this->_mls_apply1(_mls_x74);
    auto _mls_x76 = _mlsValue::create<_mls_Tuple2>(_mls_lam_arg1, _mls_x73);
    auto _mls_x77 = _mlsValue::create<_mls_Cons>(_mls_x76, _mls_x75);
    _mls_retval = _mls_x77;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_max_::_mls_apply2(_mlsValue _mls_arg1, _mlsValue _mls_arg2) {
  _mlsValue _mls_retval;
  auto _mls_x79 = _mls_max_(_mls_arg1, _mls_arg2);
  _mls_retval = _mls_x79;
  return _mls_retval;
}
_mlsValue _mls_Lambda_min_::_mls_apply2(_mlsValue _mls_arg3, _mlsValue _mls_arg4) {
  _mlsValue _mls_retval;
  auto _mls_x80 = _mls_min_(_mls_arg3, _mls_arg4);
  _mls_retval = _mls_x80;
  return _mls_retval;
}
_mlsValue _mls_Lambda_scorePiece::_mls_apply2(_mlsValue _mls_arg5, _mlsValue _mls_arg6) {
  _mlsValue _mls_retval;
  auto _mls_x81 = _mls_scorePiece(_mls_arg5, _mls_arg6);
  _mls_retval = _mls_x81;
  return _mls_retval;
}
_mlsValue _mls_Lambda_showMove::_mls_apply1(_mlsValue _mls_arg7) {
  _mlsValue _mls_retval;
  auto _mls_x82 = _mls_showMove(_mls_arg7);
  _mls_retval = _mls_x82;
  return _mls_retval;
}
_mlsValue _mls_Lambda_static::_mls_apply1(_mlsValue _mls_arg8) {
  _mlsValue _mls_retval;
  auto _mls_x83 = _mls_static1(_mls_arg8);
  _mls_retval = _mls_x83;
  return _mls_retval;
}
_mlsValue _mls_Lambda_sum::_mls_apply1(_mlsValue _mls_arg9) {
  _mlsValue _mls_retval;
  auto _mls_x84 = _mls_sum(_mls_arg9);
  _mls_retval = _mls_x84;
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
