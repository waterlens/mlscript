#include "mlsprelude.h"
struct _mls_List;
struct _mls_Cons;
struct _mls_Nil;
_mlsValue _mls_append_safe(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_append_safe_caller_post_case0(_mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue>
    _mls_append_safe_caller_post_case0_pre(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_append_safe_default(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_append_safe_default1(_mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue>
    _mls_append_safe_pre(_mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue>
    _mls_append_safe_pre1(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_extend(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_find_solution_case0();
_mlsValue _mls_find_solution_default(_mlsValue, _mlsValue);
_mlsValue _mls_find_solution_default_caller_post(_mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue>
    _mls_find_solution_default_caller_post_pre(_mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_find_solution_pre(_mlsValue,
                                                                   _mlsValue);
_mlsValue _mls_length(_mlsValue);
_mlsValue _mls_length_case0_sr_post(_mlsValue);
_mlsValue _mls_queens(_mlsValue);
_mlsValue _mls_safe(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_safe_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_safe_case0_sr_post_default(_mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue>
    _mls_safe_case0_sr_post_pre(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
struct _mls_List : public _mlsObject {

  constexpr static inline const char *typeName = "List";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {
    operator delete(this, std::align_val_t(_mlsAlignment));
  }
  virtual bool operator==(const _mlsObject &other) const override {
    return typeTag == other.tag;
  }
  static _mlsValue create() {
    auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_List;
    _mlsVal->refCount = 1;
    _mlsVal->tag = typeTag;
    return _mlsValue(_mlsVal);
  }
};
struct _mls_Cons : public _mls_List {
  _mlsValue _mls_head;
  _mlsValue _mls_tail;
  constexpr static inline const char *typeName = "Cons";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override {
    std::printf("%s", typeName);
    std::printf("(");
    this->_mls_head.print();
    std::printf(", ");
    this->_mls_tail.print();
    std::printf(")");
  }
  virtual void destroy() override {
    _mlsValue::destroy(this->_mls_head);
    _mlsValue::destroy(this->_mls_tail);
    operator delete(this, std::align_val_t(_mlsAlignment));
  }
  virtual bool operator==(const _mlsObject &other) const override {
    return typeTag == other.tag &&
           this->_mls_head.asObject()->operator==(
               *other.cast<_mls_Cons>()->_mls_head.asObject()) &&
           this->_mls_tail.asObject()->operator==(
               *other.cast<_mls_Cons>()->_mls_tail.asObject());
  }
  static _mlsValue create(_mlsValue _mls_head, _mlsValue _mls_tail) {
    auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Cons;
    _mlsVal->refCount = 1;
    _mlsVal->tag = typeTag;
    _mlsVal->_mls_head = _mls_head;
    _mlsVal->_mls_tail = _mls_tail;
    return _mlsValue(_mlsVal);
  }
};
struct _mls_Nil : public _mls_List {

  constexpr static inline const char *typeName = "Nil";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {
    operator delete(this, std::align_val_t(_mlsAlignment));
  }
  virtual bool operator==(const _mlsObject &other) const override {
    return typeTag == other.tag;
  }
  static _mlsValue create() {
    auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Nil;
    _mlsVal->refCount = 1;
    _mlsVal->tag = typeTag;
    return _mlsValue(_mlsVal);
  }
};
_mlsValue _mls_append_safe(_mlsValue _mls_x36, _mlsValue _mls_x37,
                           _mlsValue _mls_x38) {
  _mlsValue _mls_retval;
  auto [_mls_x39, _mls_x40, _mls_x41, _mls_x42] =
      _mls_append_safe_pre(_mls_x36, _mls_x37, _mls_x38);
  if (_mlsValue::isIntLit(_mls_x39, 1)) {
    _mls_retval = _mls_x40;
  } else {
    _mls_retval = _mls_append_safe_default(_mls_x41, _mls_x42, _mls_x40);
  }
  return _mls_retval;
}
_mlsValue _mls_append_safe_caller_post_case0(_mlsValue _mls_x43,
                                             _mlsValue _mls_x44,
                                             _mlsValue _mls_x45) {
  _mlsValue _mls_retval;
  auto [_mls_x46, _mls_x47, _mls_x48] =
      _mls_append_safe_caller_post_case0_pre(_mls_x43, _mls_x44, _mls_x45);
  auto _mls_x49 = _mls_append_safe(_mls_x46, _mls_x47, _mls_x48);
  _mls_retval = _mls_x49;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue>
_mls_append_safe_caller_post_case0_pre(_mlsValue _mls_x51, _mlsValue _mls_x53,
                                       _mlsValue _mls_x55) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x50 = (_mls_x51 - _mlsValue::fromIntLit(1));
  auto _mls_x52 = _mlsValue::create<_mls_Cons>(_mls_x51, _mls_x53);
  auto _mls_x54 = _mlsValue::create<_mls_Cons>(_mls_x52, _mls_x55);
  _mls_retval = std::make_tuple(_mls_x50, _mls_x53, _mls_x54);
  return _mls_retval;
}
_mlsValue _mls_append_safe_default(_mlsValue _mls_x56, _mlsValue _mls_x57,
                                   _mlsValue _mls_x58) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x56)) {
    auto _mls_x63 = _mlsValue::cast<_mls_Cons>(_mls_x56)->_mls_head;
    auto _mls_x64 = _mlsValue::cast<_mls_Cons>(_mls_x56)->_mls_tail;
    auto [_mls_x65, _mls_x66, _mls_x67, _mls_x68] = _mls_safe_case0_sr_post_pre(
        _mls_x57, _mls_x63, _mlsValue::fromIntLit(1), _mls_x64);
    if (_mlsValue::isIntLit(_mls_x65, 1)) {
      _mls_retval =
          _mls_append_safe_caller_post_case0(_mls_x57, _mls_x56, _mls_x58);
    } else {
      auto _mls_x69 =
          _mls_safe_case0_sr_post_default(_mls_x66, _mls_x67, _mls_x68);
      if (_mlsValue::isIntLit(_mls_x69, 1)) {
        _mls_retval =
            _mls_append_safe_caller_post_case0(_mls_x57, _mls_x56, _mls_x58);
      } else {
        auto [_mls_x70, _mls_x71, _mls_x72, _mls_x73] =
            _mls_append_safe_pre1(_mls_x57, _mls_x56, _mls_x58);
        if (_mlsValue::isIntLit(_mls_x70, 1)) {
          _mls_retval = _mls_x71;
        } else {
          auto _mls_x74 =
              _mls_append_safe_default1(_mls_x72, _mls_x73, _mls_x71);
          _mls_retval = _mls_x74;
        }
      }
    }
  } else {
    auto [_mls_x59, _mls_x60, _mls_x61] =
        _mls_append_safe_caller_post_case0_pre(_mls_x57, _mls_x56, _mls_x58);
    auto _mls_x62 = _mls_append_safe(_mls_x59, _mls_x60, _mls_x61);
    _mls_retval = _mls_x62;
  }
  return _mls_retval;
}
_mlsValue _mls_append_safe_default1(_mlsValue _mls_x75, _mlsValue _mls_x76,
                                    _mlsValue _mls_x77) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x75)) {
    auto _mls_x82 = _mlsValue::cast<_mls_Cons>(_mls_x75)->_mls_head;
    auto _mls_x83 = _mlsValue::cast<_mls_Cons>(_mls_x75)->_mls_tail;
    auto [_mls_x84, _mls_x85, _mls_x86, _mls_x87] = _mls_safe_case0_sr_post_pre(
        _mls_x76, _mls_x82, _mlsValue::fromIntLit(1), _mls_x83);
    if (_mlsValue::isIntLit(_mls_x84, 1)) {
      _mls_retval =
          _mls_append_safe_caller_post_case0(_mls_x76, _mls_x75, _mls_x77);
    } else {
      auto _mls_x88 =
          _mls_safe_case0_sr_post_default(_mls_x85, _mls_x86, _mls_x87);
      if (_mlsValue::isIntLit(_mls_x88, 1)) {
        _mls_retval =
            _mls_append_safe_caller_post_case0(_mls_x76, _mls_x75, _mls_x77);
      } else {
        auto [_mls_x89, _mls_x90, _mls_x91, _mls_x92] =
            _mls_append_safe_pre(_mls_x76, _mls_x75, _mls_x77);
        if (_mlsValue::isIntLit(_mls_x89, 1)) {
          _mls_retval = _mls_x90;
        } else {
          auto _mls_x93 =
              _mls_append_safe_default(_mls_x91, _mls_x92, _mls_x90);
          _mls_retval = _mls_x93;
        }
      }
    }
  } else {
    auto [_mls_x78, _mls_x79, _mls_x80] =
        _mls_append_safe_caller_post_case0_pre(_mls_x76, _mls_x75, _mls_x77);
    auto _mls_x81 = _mls_append_safe(_mls_x78, _mls_x79, _mls_x80);
    _mls_retval = _mls_x81;
  }
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue>
_mls_append_safe_pre(_mlsValue _mls_x95, _mlsValue _mls_x97,
                     _mlsValue _mls_x96) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x94 = (_mls_x95 <= _mlsValue::fromIntLit(0));
  _mls_retval = std::make_tuple(_mls_x94, _mls_x96, _mls_x97, _mls_x95);
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue>
_mls_append_safe_pre1(_mlsValue _mls_x99, _mlsValue _mls_x101,
                      _mlsValue _mls_x100) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x98 = (_mls_x99 <= _mlsValue::fromIntLit(0));
  _mls_retval = std::make_tuple(_mls_x98, _mls_x100, _mls_x101, _mls_x99);
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x7 = _mls_queens(_mlsValue::fromIntLit(8));
  _mls_retval = _mls_x7;
  return _mls_retval;
}
_mlsValue _mls_extend(_mlsValue _mls_queen1, _mlsValue _mls_acc,
                      _mlsValue _mls_xss1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_xss1)) {
    auto _mls_x8 = _mlsValue::cast<_mls_Cons>(_mls_xss1)->_mls_head;
    auto _mls_x9 = _mlsValue::cast<_mls_Cons>(_mls_xss1)->_mls_tail;
    auto _mls_x10 = _mls_append_safe(_mls_queen1, _mls_x8, _mls_acc);
    auto _mls_x11 = _mls_extend(_mls_queen1, _mls_x10, _mls_x9);
    _mls_retval = _mls_x11;
  } else {
    _mls_retval = _mls_acc;
  }
  return _mls_retval;
}
_mlsValue _mls_find_solution_case0() {
  _mlsValue _mls_retval;
  auto _mls_x102 = _mlsValue::create<_mls_Nil>();
  auto _mls_x103 = _mlsValue::create<_mls_Nil>();
  auto _mls_x104 = _mlsValue::create<_mls_Cons>(_mls_x102, _mls_x103);
  _mls_retval = _mls_x104;
  return _mls_retval;
}
_mlsValue _mls_find_solution_default(_mlsValue _mls_x106, _mlsValue _mls_x107) {
  _mlsValue _mls_retval;
  auto _mls_x105 = (_mls_x106 - _mlsValue::fromIntLit(1));
  auto [_mls_x108, _mls_x109, _mls_x110] =
      _mls_find_solution_pre(_mls_x107, _mls_x105);
  if (_mlsValue::isIntLit(_mls_x108, 1)) {
    auto _mls_x112 = _mls_find_solution_case0();
    auto [_mls_x113, _mls_x114, _mls_x115] =
        _mls_find_solution_default_caller_post_pre(_mls_x107, _mls_x112);
    auto _mls_x116 = _mls_extend(_mls_x113, _mls_x114, _mls_x115);
    _mls_retval = _mls_x116;
  } else {
    auto _mls_x111 = _mls_find_solution_default(_mls_x109, _mls_x110);
    _mls_retval = _mls_find_solution_default_caller_post(_mls_x107, _mls_x111);
  }
  return _mls_retval;
}
_mlsValue _mls_find_solution_default_caller_post(_mlsValue _mls_x117,
                                                 _mlsValue _mls_x118) {
  _mlsValue _mls_retval;
  auto [_mls_x119, _mls_x120, _mls_x121] =
      _mls_find_solution_default_caller_post_pre(_mls_x117, _mls_x118);
  auto _mls_x122 = _mls_extend(_mls_x119, _mls_x120, _mls_x121);
  _mls_retval = _mls_x122;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue>
_mls_find_solution_default_caller_post_pre(_mlsValue _mls_x124,
                                           _mlsValue _mls_x125) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x123 = _mlsValue::create<_mls_Nil>();
  _mls_retval = std::make_tuple(_mls_x124, _mls_x123, _mls_x125);
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue>
_mls_find_solution_pre(_mlsValue _mls_x128, _mlsValue _mls_x127) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x126 = (_mls_x127 == _mlsValue::fromIntLit(0));
  _mls_retval = std::make_tuple(_mls_x126, _mls_x127, _mls_x128);
  return _mls_retval;
}
_mlsValue _mls_length(_mlsValue _mls_x129) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x129)) {
    auto _mls_x130 = _mlsValue::cast<_mls_Cons>(_mls_x129)->_mls_tail;
    _mls_retval = _mls_length_case0_sr_post(_mls_x130);
  } else {
    _mls_retval = _mlsValue::fromIntLit(0);
  }
  return _mls_retval;
}
_mlsValue _mls_length_case0_sr_post(_mlsValue _mls_x131) {
  _mlsValue _mls_retval;
  auto _mls_x132 = _mls_length(_mls_x131);
  auto _mls_x133 = (_mlsValue::fromIntLit(1) + _mls_x132);
  _mls_retval = _mls_x133;
  return _mls_retval;
}
_mlsValue _mls_queens(_mlsValue _mls_n1) {
  _mlsValue _mls_retval;
  auto [_mls_x134, _mls_x135, _mls_x136] =
      _mls_find_solution_pre(_mls_n1, _mls_n1);
  if (_mlsValue::isIntLit(_mls_x134, 1)) {
    auto _mls_x139 = _mls_find_solution_case0();
    auto _mls_x140 = _mlsValue::cast<_mls_Cons>(_mls_x139)->_mls_tail;
    auto _mls_x141 = _mls_length_case0_sr_post(_mls_x140);
    _mls_retval = _mls_x141;
  } else {
    auto _mls_x137 = _mls_find_solution_default(_mls_x135, _mls_x136);
    auto _mls_x138 = _mls_length(_mls_x137);
    _mls_retval = _mls_x138;
  }
  return _mls_retval;
}
_mlsValue _mls_safe(_mlsValue _mls_x145, _mlsValue _mls_x146,
                    _mlsValue _mls_x142) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x142)) {
    auto _mls_x143 = _mlsValue::cast<_mls_Cons>(_mls_x142)->_mls_head;
    auto _mls_x144 = _mlsValue::cast<_mls_Cons>(_mls_x142)->_mls_tail;
    _mls_retval =
        _mls_safe_case0_sr_post(_mls_x145, _mls_x143, _mls_x146, _mls_x144);
  } else {
    _mls_retval = _mlsValue::fromIntLit(1);
  }
  return _mls_retval;
}
_mlsValue _mls_safe_case0_sr_post(_mlsValue _mls_x147, _mlsValue _mls_x148,
                                  _mlsValue _mls_x149, _mlsValue _mls_x150) {
  _mlsValue _mls_retval;
  auto [_mls_x151, _mls_x152, _mls_x153, _mls_x154] =
      _mls_safe_case0_sr_post_pre(_mls_x147, _mls_x148, _mls_x149, _mls_x150);
  if (_mlsValue::isIntLit(_mls_x151, 1)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else {
    _mls_retval =
        _mls_safe_case0_sr_post_default(_mls_x152, _mls_x153, _mls_x154);
  }
  return _mls_retval;
}
_mlsValue _mls_safe_case0_sr_post_default(_mlsValue _mls_x156,
                                          _mlsValue _mls_x157,
                                          _mlsValue _mls_x158) {
  _mlsValue _mls_retval;
  auto _mls_x155 = (_mls_x156 + _mlsValue::fromIntLit(1));
  auto _mls_x159 = _mls_safe(_mls_x157, _mls_x155, _mls_x158);
  _mls_retval = _mls_x159;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue>
_mls_safe_case0_sr_post_pre(_mlsValue _mls_x161, _mlsValue _mls_x162,
                            _mlsValue _mls_x164, _mlsValue _mls_x170) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x160 = (_mls_x161 != _mls_x162);
  auto _mls_x163 = (_mls_x162 + _mls_x164);
  auto _mls_x165 = (_mls_x161 != _mls_x163);
  auto _mls_x166 = (_mls_x160 && _mls_x165);
  auto _mls_x167 = (_mls_x162 - _mls_x164);
  auto _mls_x168 = (_mls_x161 != _mls_x167);
  auto _mls_x169 = (_mls_x166 && _mls_x168);
  _mls_retval = std::make_tuple(_mls_x169, _mls_x164, _mls_x161, _mls_x170);
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
