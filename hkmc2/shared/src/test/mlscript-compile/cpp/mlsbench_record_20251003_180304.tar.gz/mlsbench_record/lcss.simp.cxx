#include "mlsprelude.h"
struct _mls_Lambda_l;
struct _mls_Lambda_lambda;
struct _mls_Lambda_lambda1;
struct _mls_Lambda_lambda2;
struct _mls_Lambda_lambda3;
struct _mls_Lambda_r;
struct _mls_Lambda_snd;
struct _mls_List;
struct _mls_Cons;
struct _mls_Nil;
struct _mls_Tuple2;
_mlsValue _mls_algb(_mlsValue, _mlsValue);
_mlsValue _mls_algb1(_mlsValue, _mlsValue);
_mlsValue _mls_algb2(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_algc(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_compose(_mlsValue, _mlsValue);
_mlsValue _mls_drop(_mlsValue, _mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_enumFromThenTo(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_findk(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_inList(_mlsValue, _mlsValue);
_mlsValue _mls_j(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_lcss(_mlsValue, _mlsValue);
_mlsValue _mls_lcssMain(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_listLen(_mlsValue);
_mlsValue _mls_listcomp_fun(_mlsValue);
_mlsValue _mls_map(_mlsValue, _mlsValue);
_mlsValue _mls_max(_mlsValue, _mlsValue);
_mlsValue _mls_reverse(_mlsValue);
_mlsValue _mls_snd(_mlsValue);
_mlsValue _mls_take(_mlsValue, _mlsValue);
_mlsValue _mls_zip(_mlsValue, _mlsValue);
struct _mls_Lambda_l: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_l";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_l; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_lambda: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda1: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  _mlsValue _mls_lam_arg1;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print(); std::printf(", "); this->_mls_lam_arg1.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0); _mlsValue::destroy(this->_mls_lam_arg1);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda1>()->_mls_lam_arg0.asObject()) && this->_mls_lam_arg1.asObject()->operator==(*other.cast<_mls_Lambda_lambda1>()->_mls_lam_arg1.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0, _mlsValue _mls_lam_arg1) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda1; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0; _mlsVal->_mls_lam_arg1 = _mls_lam_arg1;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda2: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda2>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda3: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda3; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_r: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_r";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_r; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_snd: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_snd";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_snd; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_List: public _mlsObject {
  
  constexpr static inline const char *typeName = "List";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_List; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Cons: public _mls_List {
  _mlsValue _mls_head;
  _mlsValue _mls_tail;
  constexpr static inline const char *typeName = "Cons";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_head.print(); std::printf(", "); this->_mls_tail.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_head); _mlsValue::destroy(this->_mls_tail);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_head.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_head.asObject()) && this->_mls_tail.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_tail.asObject()); }
  static _mlsValue create(_mlsValue _mls_head, _mlsValue _mls_tail) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Cons; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_head = _mls_head; _mlsVal->_mls_tail = _mls_tail;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Nil: public _mls_List {
  
  constexpr static inline const char *typeName = "Nil";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Nil; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Tuple2: public _mlsObject {
  _mlsValue _mls_field0;
  _mlsValue _mls_field1;
  constexpr static inline const char *typeName = "Tuple2";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_field0.print(); std::printf(", "); this->_mls_field1.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_field0); _mlsValue::destroy(this->_mls_field1);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_field0.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field0.asObject()) && this->_mls_field1.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field1.asObject()); }
  static _mlsValue create(_mlsValue _mls_field0, _mlsValue _mls_field1) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Tuple2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_field0 = _mls_field0; _mlsVal->_mls_field1 = _mls_field1;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_algb(_mlsValue _mls_xs, _mlsValue _mls_ys) {
  _mlsValue _mls_retval;
  auto _mls_x15 = _mls_listcomp_fun(_mls_ys);
  auto _mls_x16 = _mls_algb1(_mls_xs, _mls_x15);
  auto _mls_x17 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x16);
  _mls_retval = _mls_x17;
  return _mls_retval;
}
_mlsValue _mls_algb1(_mlsValue _mls_xss, _mlsValue _mls_yss) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xss)) {
    auto _mls_x22 = _mlsValue::create<_mls_Lambda_snd>();
    auto _mls_x23 = _mls_map(_mls_x22, _mls_yss);
    _mls_retval = _mls_x23;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xss)) {
    auto _mls_x18 = _mlsValue::cast<_mls_Cons>(_mls_xss)->_mls_head;
    auto _mls_x19 = _mlsValue::cast<_mls_Cons>(_mls_xss)->_mls_tail;
    auto _mls_x20 = _mls_algb2(_mls_x18, _mlsValue::fromIntLit(0), _mlsValue::fromIntLit(0), _mls_yss);
    auto _mls_x21 = _mls_algb1(_mls_x19, _mls_x20);
    _mls_retval = _mls_x21;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_algb2(_mlsValue _mls_x29, _mlsValue _mls_k0j1, _mlsValue _mls_k1j1, _mlsValue _mls_yss1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_yss1)) {
    auto _mls_x32 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x32;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_yss1)) {
    auto _mls_x24 = _mlsValue::cast<_mls_Cons>(_mls_yss1)->_mls_head;
    auto _mls_x25 = _mlsValue::cast<_mls_Cons>(_mls_yss1)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x24)) {
      auto _mls_x26 = _mlsValue::cast<_mls_Tuple2>(_mls_x24)->_mls_field0;
      auto _mls_x27 = _mlsValue::cast<_mls_Tuple2>(_mls_x24)->_mls_field1;
      auto _mls_x28 = (_mls_x29 == _mls_x26);
      if (_mlsValue::isIntLit(_mls_x28, 1)) {
        auto _mls_x31 = (_mls_k0j1 + _mlsValue::fromIntLit(1));
        _mls_retval = _mls_j(_mls_x25, _mls_x26, _mls_x29, _mls_x27, _mls_x31);
      } else {
        auto _mls_x30 = _mls_max(_mls_k1j1, _mls_x27);
        _mls_retval = _mls_j(_mls_x25, _mls_x26, _mls_x29, _mls_x27, _mls_x30);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_algc(_mlsValue _mls_m, _mlsValue _mls_n, _mlsValue _mls_xs1, _mlsValue _mls_ys1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ys1)) {
    auto _mls_x74 = _mlsValue::create<_mls_Lambda_lambda>();
    _mls_retval = _mls_x74;
  } else {
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs1)) {
      auto _mls_x51 = _mlsValue::cast<_mls_Cons>(_mls_xs1)->_mls_head;
      auto _mls_x52 = _mlsValue::cast<_mls_Cons>(_mls_xs1)->_mls_tail;
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x52)) {
        auto _mls_x71 = _mls_inList(_mls_x51, _mls_ys1);
        if (_mlsValue::isIntLit(_mls_x71, 1)) {
          auto _mls_x73 = _mlsValue::create<_mls_Lambda_lambda2>(_mls_x51);
          _mls_retval = _mls_x73;
        } else {
          auto _mls_x72 = _mlsValue::create<_mls_Lambda_lambda3>();
          _mls_retval = _mls_x72;
        }
      } else {
        auto _mls_x53 = _mls_builtin_floor_div(_mls_m, _mlsValue::fromIntLit(2));
        auto _mls_x54 = _mls_take(_mls_x53, _mls_xs1);
        auto _mls_x55 = _mls_drop(_mls_x53, _mls_xs1);
        auto _mls_x56 = _mls_algb(_mls_x54, _mls_ys1);
        auto _mls_x57 = _mls_reverse(_mls_x55);
        auto _mls_x58 = _mls_reverse(_mls_ys1);
        auto _mls_x59 = _mls_algb(_mls_x57, _mls_x58);
        auto _mls_x60 = _mls_reverse(_mls_x59);
        auto _mls_x61 = (-_mlsValue::fromIntLit(1));
        auto _mls_x62 = _mls_zip(_mls_x56, _mls_x60);
        auto _mls_x63 = _mls_findk(_mlsValue::fromIntLit(0), _mlsValue::fromIntLit(0), _mls_x61, _mls_x62);
        auto _mls_x64 = _mls_take(_mls_x63, _mls_ys1);
        auto _mls_x65 = _mls_algc(_mls_x53, _mls_x63, _mls_x54, _mls_x64);
        auto _mls_x66 = (_mls_m - _mls_x53);
        auto _mls_x67 = (_mls_n - _mls_x63);
        auto _mls_x68 = _mls_drop(_mls_x63, _mls_ys1);
        auto _mls_x69 = _mls_algc(_mls_x66, _mls_x67, _mls_x55, _mls_x68);
        auto _mls_x70 = _mls_compose(_mls_x65, _mls_x69);
        _mls_retval = _mls_x70;
      }
    } else {
      auto _mls_x33 = _mls_builtin_floor_div(_mls_m, _mlsValue::fromIntLit(2));
      auto _mls_x34 = _mls_take(_mls_x33, _mls_xs1);
      auto _mls_x35 = _mls_drop(_mls_x33, _mls_xs1);
      auto _mls_x36 = _mls_algb(_mls_x34, _mls_ys1);
      auto _mls_x37 = _mls_reverse(_mls_x35);
      auto _mls_x38 = _mls_reverse(_mls_ys1);
      auto _mls_x39 = _mls_algb(_mls_x37, _mls_x38);
      auto _mls_x40 = _mls_reverse(_mls_x39);
      auto _mls_x41 = (-_mlsValue::fromIntLit(1));
      auto _mls_x42 = _mls_zip(_mls_x36, _mls_x40);
      auto _mls_x43 = _mls_findk(_mlsValue::fromIntLit(0), _mlsValue::fromIntLit(0), _mls_x41, _mls_x42);
      auto _mls_x44 = _mls_take(_mls_x43, _mls_ys1);
      auto _mls_x45 = _mls_algc(_mls_x33, _mls_x43, _mls_x34, _mls_x44);
      auto _mls_x46 = (_mls_m - _mls_x33);
      auto _mls_x47 = (_mls_n - _mls_x43);
      auto _mls_x48 = _mls_drop(_mls_x43, _mls_ys1);
      auto _mls_x49 = _mls_algc(_mls_x46, _mls_x47, _mls_x35, _mls_x48);
      auto _mls_x50 = _mls_compose(_mls_x45, _mls_x49);
      _mls_retval = _mls_x50;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_compose(_mlsValue _mls_f, _mlsValue _mls_g) {
  _mlsValue _mls_retval;
  auto _mls_x75 = _mlsValue::create<_mls_Lambda_lambda1>(_mls_g, _mls_f);
  _mls_retval = _mls_x75;
  return _mls_retval;
}
_mlsValue _mls_drop(_mlsValue _mls_n1, _mlsValue _mls_ls1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls1)) {
    auto _mls_x80 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x80;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls1)) {
    auto _mls_x76 = _mlsValue::cast<_mls_Cons>(_mls_ls1)->_mls_tail;
    auto _mls_x77 = (_mls_n1 <= _mlsValue::fromIntLit(0));
    if (_mlsValue::isIntLit(_mls_x77, 1)) {
      _mls_retval = _mls_ls1;
    } else {
      auto _mls_x78 = (_mls_n1 - _mlsValue::fromIntLit(1));
      auto _mls_x79 = _mls_drop(_mls_x78, _mls_x76);
      _mls_retval = _mls_x79;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x81 = _mls_lcssMain(_mlsValue::fromIntLit(1), _mlsValue::fromIntLit(2), _mlsValue::fromIntLit(4000), _mlsValue::fromIntLit(1000), _mlsValue::fromIntLit(1001), _mlsValue::fromIntLit(4000));
  _mls_retval = _mls_x81;
  return _mls_retval;
}
_mlsValue _mls_enumFromThenTo(_mlsValue _mls_a1, _mlsValue _mls_t1, _mlsValue _mls_b) {
  _mlsValue _mls_retval;
  auto _mls_x82 = (_mls_a1 <= _mls_b);
  if (_mlsValue::isIntLit(_mls_x82, 1)) {
    auto _mls_x84 = (_mlsValue::fromIntLit(2) * _mls_t1);
    auto _mls_x85 = (_mls_x84 - _mls_a1);
    auto _mls_x86 = _mls_enumFromThenTo(_mls_t1, _mls_x85, _mls_b);
    auto _mls_x87 = _mlsValue::create<_mls_Cons>(_mls_a1, _mls_x86);
    _mls_retval = _mls_x87;
  } else {
    auto _mls_x83 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x83;
  }
  return _mls_retval;
}
_mlsValue _mls_findk(_mlsValue _mls_k, _mlsValue _mls_km, _mlsValue _mls_m1, _mlsValue _mls_ls2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls2)) {
    _mls_retval = _mls_km;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls2)) {
    auto _mls_x88 = _mlsValue::cast<_mls_Cons>(_mls_ls2)->_mls_head;
    auto _mls_x89 = _mlsValue::cast<_mls_Cons>(_mls_ls2)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x88)) {
      auto _mls_x90 = _mlsValue::cast<_mls_Tuple2>(_mls_x88)->_mls_field0;
      auto _mls_x91 = _mlsValue::cast<_mls_Tuple2>(_mls_x88)->_mls_field1;
      auto _mls_x92 = (_mls_x90 + _mls_x91);
      auto _mls_x93 = (_mls_x92 >= _mls_m1);
      if (_mlsValue::isIntLit(_mls_x93, 1)) {
        auto _mls_x96 = (_mls_k + _mlsValue::fromIntLit(1));
        auto _mls_x97 = (_mls_x90 + _mls_x91);
        auto _mls_x98 = _mls_findk(_mls_x96, _mls_k, _mls_x97, _mls_x89);
        _mls_retval = _mls_x98;
      } else {
        auto _mls_x94 = (_mls_k + _mlsValue::fromIntLit(1));
        auto _mls_x95 = _mls_findk(_mls_x94, _mls_km, _mls_m1, _mls_x89);
        _mls_retval = _mls_x95;
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_inList(_mlsValue _mls_x102, _mlsValue _mls_ls3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls3)) {
    auto _mls_x99 = _mlsValue::cast<_mls_Cons>(_mls_ls3)->_mls_head;
    auto _mls_x100 = _mlsValue::cast<_mls_Cons>(_mls_ls3)->_mls_tail;
    auto _mls_x101 = (_mls_x102 == _mls_x99);
    if (_mlsValue::isIntLit(_mls_x101, 1)) {
      _mls_retval = _mlsValue::fromIntLit(1);
    } else {
      auto _mls_x103 = _mls_inList(_mls_x102, _mls_x100);
      _mls_retval = _mls_x103;
    }
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls3)) {
    _mls_retval = _mlsValue::fromIntLit(0);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_j(_mlsValue _mls_ys2, _mlsValue _mls_y, _mlsValue _mls_x29, _mlsValue _mls_k0j, _mlsValue _mls_tmp) {
  _mlsValue _mls_retval;
  auto _mls_x104 = _mls_algb2(_mls_x29, _mls_k0j, _mls_tmp, _mls_ys2);
  auto _mls_x105 = _mlsValue::create<_mls_Tuple2>(_mls_y, _mls_tmp);
  auto _mls_x106 = _mlsValue::create<_mls_Cons>(_mls_x105, _mls_x104);
  _mls_retval = _mls_x106;
  return _mls_retval;
}
_mlsValue _mls_lcss(_mlsValue _mls_xs2, _mlsValue _mls_ys3) {
  _mlsValue _mls_retval;
  auto _mls_x107 = _mls_listLen(_mls_xs2);
  auto _mls_x108 = _mls_listLen(_mls_ys3);
  auto _mls_x109 = _mls_algc(_mls_x107, _mls_x108, _mls_xs2, _mls_ys3);
  auto _mls_x110 = _mlsValue::create<_mls_Nil>();
  auto _mls_x111 = _mlsMethodCall<_mls_Callable>(_mls_x109)->_mls_apply1(_mls_x110);
  _mls_retval = _mls_x111;
  return _mls_retval;
}
_mlsValue _mls_lcssMain(_mlsValue _mls_a2, _mlsValue _mls_b1, _mlsValue _mls_c, _mlsValue _mls_d, _mlsValue _mls_e, _mlsValue _mls_f1) {
  _mlsValue _mls_retval;
  auto _mls_x112 = _mls_enumFromThenTo(_mls_a2, _mls_b1, _mls_c);
  auto _mls_x113 = _mls_enumFromThenTo(_mls_d, _mls_e, _mls_f1);
  auto _mls_x114 = _mls_lcss(_mls_x112, _mls_x113);
  _mls_retval = _mls_x114;
  return _mls_retval;
}
_mlsValue _mls_listLen(_mlsValue _mls_ls4) {
  _mlsValue _mls_retval;
  auto _mls_x115 = _mlsValue::create<_mls_Lambda_l>();
  auto _mls_x116 = _mlsMethodCall<_mls_Callable>(_mls_x115)->_mls_apply2(_mls_ls4, _mlsValue::fromIntLit(0));
  _mls_retval = _mls_x116;
  return _mls_retval;
}
_mlsValue _mls_listcomp_fun(_mlsValue _mls_listcomp_fun_para) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_listcomp_fun_para)) {
    auto _mls_x118 = _mlsValue::cast<_mls_Cons>(_mls_listcomp_fun_para)->_mls_head;
    auto _mls_x119 = _mlsValue::cast<_mls_Cons>(_mls_listcomp_fun_para)->_mls_tail;
    auto _mls_x120 = _mls_listcomp_fun(_mls_x119);
    auto _mls_x121 = _mlsValue::create<_mls_Tuple2>(_mls_x118, _mlsValue::fromIntLit(0));
    auto _mls_x122 = _mlsValue::create<_mls_Cons>(_mls_x121, _mls_x120);
    _mls_retval = _mls_x122;
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_listcomp_fun_para)) {
    auto _mls_x117 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x117;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_map(_mlsValue _mls_f2, _mlsValue _mls_xs3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs3)) {
    auto _mls_x124 = _mlsValue::cast<_mls_Cons>(_mls_xs3)->_mls_head;
    auto _mls_x125 = _mlsValue::cast<_mls_Cons>(_mls_xs3)->_mls_tail;
    auto _mls_x126 = _mlsMethodCall<_mls_Callable>(_mls_f2)->_mls_apply1(_mls_x124);
    auto _mls_x127 = _mls_map(_mls_f2, _mls_x125);
    auto _mls_x128 = _mlsValue::create<_mls_Cons>(_mls_x126, _mls_x127);
    _mls_retval = _mls_x128;
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs3)) {
    auto _mls_x123 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x123;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_max(_mlsValue _mls_a3, _mlsValue _mls_b2) {
  _mlsValue _mls_retval;
  auto _mls_x129 = (_mls_a3 > _mls_b2);
  if (_mlsValue::isIntLit(_mls_x129, 1)) {
    _mls_retval = _mls_a3;
  } else {
    _mls_retval = _mls_b2;
  }
  return _mls_retval;
}
_mlsValue _mls_reverse(_mlsValue _mls_l1) {
  _mlsValue _mls_retval;
  auto _mls_x130 = _mlsValue::create<_mls_Lambda_r>();
  auto _mls_x131 = _mlsValue::create<_mls_Nil>();
  auto _mls_x132 = _mlsMethodCall<_mls_Callable>(_mls_x130)->_mls_apply2(_mls_x131, _mls_l1);
  _mls_retval = _mls_x132;
  return _mls_retval;
}
_mlsValue _mls_snd(_mlsValue _mls_x133) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x133)) {
    auto _mls_x134 = _mlsValue::cast<_mls_Tuple2>(_mls_x133)->_mls_field1;
    _mls_retval = _mls_x134;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_take(_mlsValue _mls_n2, _mlsValue _mls_ls5) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls5)) {
    auto _mls_x142 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x142;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls5)) {
    auto _mls_x135 = _mlsValue::cast<_mls_Cons>(_mls_ls5)->_mls_head;
    auto _mls_x136 = _mlsValue::cast<_mls_Cons>(_mls_ls5)->_mls_tail;
    auto _mls_x137 = (_mls_n2 <= _mlsValue::fromIntLit(0));
    if (_mlsValue::isIntLit(_mls_x137, 1)) {
      auto _mls_x141 = _mlsValue::create<_mls_Nil>();
      _mls_retval = _mls_x141;
    } else {
      auto _mls_x138 = (_mls_n2 - _mlsValue::fromIntLit(1));
      auto _mls_x139 = _mls_take(_mls_x138, _mls_x136);
      auto _mls_x140 = _mlsValue::create<_mls_Cons>(_mls_x135, _mls_x139);
      _mls_retval = _mls_x140;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_zip(_mlsValue _mls_xs4, _mlsValue _mls_ys4) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs4)) {
    auto _mls_x144 = _mlsValue::cast<_mls_Cons>(_mls_xs4)->_mls_head;
    auto _mls_x145 = _mlsValue::cast<_mls_Cons>(_mls_xs4)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_ys4)) {
      auto _mls_x147 = _mlsValue::cast<_mls_Cons>(_mls_ys4)->_mls_head;
      auto _mls_x148 = _mlsValue::cast<_mls_Cons>(_mls_ys4)->_mls_tail;
      auto _mls_x149 = _mls_zip(_mls_x145, _mls_x148);
      auto _mls_x150 = _mlsValue::create<_mls_Tuple2>(_mls_x144, _mls_x147);
      auto _mls_x151 = _mlsValue::create<_mls_Cons>(_mls_x150, _mls_x149);
      _mls_retval = _mls_x151;
    } else {
      auto _mls_x146 = _mlsValue::create<_mls_Nil>();
      _mls_retval = _mls_x146;
    }
  } else {
    auto _mls_x143 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x143;
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_l::_mls_apply2(_mlsValue _mls_ls, _mlsValue _mls_a) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls)) {
    _mls_retval = _mls_a;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls)) {
    auto _mls_x = _mlsValue::cast<_mls_Cons>(_mls_ls)->_mls_head;
    auto _mls_x1 = _mlsValue::cast<_mls_Cons>(_mls_ls)->_mls_tail;
    auto _mls_x2 = (_mls_a + _mlsValue::fromIntLit(1));
    auto _mls_x3 = this->_mls_apply2(_mls_x1, _mls_x2);
    _mls_retval = _mls_x3;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda::_mls_apply1(_mlsValue _mls_x4) {
  _mlsValue _mls_retval;
  _mls_retval = _mls_x4;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda1::_mls_apply1(_mlsValue _mls_x5) {
  _mlsValue _mls_retval;
  auto _mls_x6 = _mlsMethodCall<_mls_Callable>(_mls_lam_arg0)->_mls_apply1(_mls_x5);
  auto _mls_x7 = _mlsMethodCall<_mls_Callable>(_mls_lam_arg1)->_mls_apply1(_mls_x6);
  _mls_retval = _mls_x7;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda2::_mls_apply1(_mlsValue _mls_t) {
  _mlsValue _mls_retval;
  auto _mls_x8 = _mlsValue::create<_mls_Cons>(_mls_lam_arg0, _mls_t);
  _mls_retval = _mls_x8;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda3::_mls_apply1(_mlsValue _mls_x9) {
  _mlsValue _mls_retval;
  _mls_retval = _mls_x9;
  return _mls_retval;
}
_mlsValue _mls_Lambda_r::_mls_apply2(_mlsValue _mls_l__, _mlsValue _mls_l) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_l)) {
    auto _mls_x10 = _mlsValue::cast<_mls_Cons>(_mls_l)->_mls_head;
    auto _mls_x11 = _mlsValue::cast<_mls_Cons>(_mls_l)->_mls_tail;
    auto _mls_x12 = _mlsValue::create<_mls_Cons>(_mls_x10, _mls_l__);
    auto _mls_x13 = this->_mls_apply2(_mls_x12, _mls_x11);
    _mls_retval = _mls_x13;
  } else {
    _mls_retval = _mls_l__;
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_snd::_mls_apply1(_mlsValue _mls_arg) {
  _mlsValue _mls_retval;
  auto _mls_x14 = _mls_snd(_mls_arg);
  _mls_retval = _mls_x14;
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
