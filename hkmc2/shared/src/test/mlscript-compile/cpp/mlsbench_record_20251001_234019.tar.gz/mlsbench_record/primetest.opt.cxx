#include "mlsprelude.h"
struct _mls_Lambda_f;
struct _mls_Lambda_g;
struct _mls_Lambda_lambda;
struct _mls_Lambda_lambda1;
struct _mls_Lambda_lambda2;
struct _mls_Lambda_lambda3;
struct _mls_Lambda_lambda4;
struct _mls_List;
struct _mls_Cons;
struct _mls_Nil;
struct _mls_Tuple2;
struct _mls_Tuple3;
_mlsValue _mls_break__case0();
_mlsValue _mls_break__case1_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_break__case1_sr_post_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_break__case1_sr_post_caller_post_case0(_mlsValue, _mlsValue);
_mlsValue _mls_break__case1_sr_post_case0(_mlsValue, _mlsValue);
_mlsValue _mls_break__case1_sr_post_default(_mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_break__case1_sr_post_pre(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_chop(_mlsValue, _mlsValue);
_mlsValue _mls_chop_(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_divMod(_mlsValue, _mlsValue);
_mlsValue _mls_doInput(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_doLine(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_doLine_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_doLine_caller_post_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_even(_mlsValue);
_mlsValue _mls_findKQ(_mlsValue);
_mlsValue _mls_findKQ_f(_mlsValue, _mlsValue);
_mlsValue _mls_foldl(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_generateRands(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_generateRands_case0(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_generateRands_default(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_generateRands_pre(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_intDiv(_mlsValue, _mlsValue);
_mlsValue _mls_intMod(_mlsValue, _mlsValue);
_mlsValue _mls_int_val_of_char(_mlsValue);
_mlsValue _mls_int_val_of_string_f(_mlsValue, _mlsValue);
_mlsValue _mls_is_iter(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_iterate_square(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_j1(_mlsValue, _mlsValue);
_mlsValue _mls_j(_mlsValue, _mlsValue);
_mlsValue _mls_j2(_mlsValue, _mlsValue);
_mlsValue _mls_l2(_mlsValue, _mlsValue);
_mlsValue _mls_lines(_mlsValue);
_mlsValue _mls_lines_caller_post(_mlsValue);
_mlsValue _mls_lines_caller_post_case0_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_lines_case0();
_mlsValue _mls_lines_case1_sr_post(_mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue> _mls_lines_pre(_mlsValue);
_mlsValue _mls_makeNumber(_mlsValue, _mlsValue);
_mlsValue _mls_map(_mlsValue, _mlsValue);
_mlsValue _mls_multiTest_case0(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_multiTest_mTest(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_multiTest_mTest_caller_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_multiTest_mTest_caller_post_case0(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_multiTest_mTest_case0(_mlsValue, _mlsValue);
_mlsValue _mls_multiTest_mTest_default(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_multiTest_mTest_default_case0(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_multiTest_mTest_default_pre(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_multiTest_mTest_pre(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_multiTest_pre(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_nextRand(_mlsValue, _mlsValue);
_mlsValue _mls_powerMod(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_random(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_random_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_random_caller_post_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_random_caller_post_case0_sr_post_caller_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_repeatProcess(_mlsValue, _mlsValue);
_mlsValue _mls_repeatProcess_caller_post_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_singleTestX(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_singleTestX_square(_mlsValue, _mlsValue);
_mlsValue _mls_singleTestX_witness(_mlsValue, _mlsValue);
_mlsValue _mls_singleTest_case0(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_singleTest_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_singleTest_pre(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_str_to_list(_mlsValue);
_mlsValue _mls_str_to_list_case0();
_mlsValue _mls_str_to_list_default(_mlsValue);
_mlsValue _mls_testPrimetest_nofib(_mlsValue);
_mlsValue _mls_uniform(_mlsValue, _mlsValue);
_mlsValue _mls_uniform_case0(_mlsValue, _mlsValue);
struct _mls_Lambda_f: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_f";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_f>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_f; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply3(_mlsValue, _mlsValue, _mlsValue);
};
struct _mls_Lambda_g: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  _mlsValue _mls_lam_arg1;
  _mlsValue _mls_lam_arg2;
  constexpr static inline const char *typeName = "Lambda_g";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print(); std::printf(", "); this->_mls_lam_arg1.print(); std::printf(", "); this->_mls_lam_arg2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0); _mlsValue::destroy(this->_mls_lam_arg1); _mlsValue::destroy(this->_mls_lam_arg2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_g>()->_mls_lam_arg0.asObject()) && this->_mls_lam_arg1.asObject()->operator==(*other.cast<_mls_Lambda_g>()->_mls_lam_arg1.asObject()) && this->_mls_lam_arg2.asObject()->operator==(*other.cast<_mls_Lambda_g>()->_mls_lam_arg2.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0, _mlsValue _mls_lam_arg1, _mlsValue _mls_lam_arg2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_g; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0; _mlsVal->_mls_lam_arg1 = _mls_lam_arg1; _mlsVal->_mls_lam_arg2 = _mls_lam_arg2;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_lambda: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda1: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda1>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda1; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_lambda2: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda2>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_lambda3: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda3; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda4: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda4>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda4; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_List: public _mlsObject {
  
  constexpr static inline const char *typeName = "List";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_List; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Cons: public _mls_List {
  _mlsValue _mls_head;
  _mlsValue _mls_tail;
  constexpr static inline const char *typeName = "Cons";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_head.print(); std::printf(", "); this->_mls_tail.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_head); _mlsValue::destroy(this->_mls_tail);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_head.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_head.asObject()) && this->_mls_tail.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_tail.asObject()); }
  static _mlsValue create(_mlsValue _mls_head, _mlsValue _mls_tail) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Cons; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_head = _mls_head; _mlsVal->_mls_tail = _mls_tail;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Nil: public _mls_List {
  
  constexpr static inline const char *typeName = "Nil";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Nil; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Tuple2: public _mlsObject {
  _mlsValue _mls_field0;
  _mlsValue _mls_field1;
  constexpr static inline const char *typeName = "Tuple2";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_field0.print(); std::printf(", "); this->_mls_field1.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_field0); _mlsValue::destroy(this->_mls_field1);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_field0.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field0.asObject()) && this->_mls_field1.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field1.asObject()); }
  static _mlsValue create(_mlsValue _mls_field0, _mlsValue _mls_field1) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Tuple2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_field0 = _mls_field0; _mlsVal->_mls_field1 = _mls_field1;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Tuple3: public _mlsObject {
  _mlsValue _mls_field0;
  _mlsValue _mls_field1;
  _mlsValue _mls_field2;
  constexpr static inline const char *typeName = "Tuple3";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_field0.print(); std::printf(", "); this->_mls_field1.print(); std::printf(", "); this->_mls_field2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_field0); _mlsValue::destroy(this->_mls_field1); _mlsValue::destroy(this->_mls_field2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_field0.asObject()->operator==(*other.cast<_mls_Tuple3>()->_mls_field0.asObject()) && this->_mls_field1.asObject()->operator==(*other.cast<_mls_Tuple3>()->_mls_field1.asObject()) && this->_mls_field2.asObject()->operator==(*other.cast<_mls_Tuple3>()->_mls_field2.asObject()); }
  static _mlsValue create(_mlsValue _mls_field0, _mlsValue _mls_field1, _mlsValue _mls_field2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Tuple3; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_field0 = _mls_field0; _mlsVal->_mls_field1 = _mls_field1; _mlsVal->_mls_field2 = _mls_field2;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_break__case0() {
  _mlsValue _mls_retval;
  auto _mls_x240 = _mlsValue::create<_mls_Nil>();
  auto _mls_x241 = _mlsValue::create<_mls_Nil>();
  auto _mls_x242 = _mlsValue::create<_mls_Tuple2>(_mls_x240, _mls_x241);
  _mls_retval = _mls_x242;
  return _mls_retval;
}
_mlsValue _mls_break__case1_sr_post(_mlsValue _mls_x243, _mlsValue _mls_x244, _mlsValue _mls_x245) {
  _mlsValue _mls_retval;
  auto [_mls_x246, _mls_x247, _mls_x248, _mls_x249] = _mls_break__case1_sr_post_pre(_mls_x243, _mls_x244, _mls_x245);
  if (_mlsValue::isIntLit(_mls_x246, 1)) {
    _mls_retval = _mls_break__case1_sr_post_case0(_mls_x247, _mls_x248);
  } else {
    _mls_retval = _mls_break__case1_sr_post_default(_mls_x249, _mls_x248, _mls_x247);
  }
  return _mls_retval;
}
_mlsValue _mls_break__case1_sr_post_caller_post(_mlsValue _mls_x250, _mlsValue _mls_x251) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x250)) {
    _mls_retval = _mls_break__case1_sr_post_caller_post_case0(_mls_x250, _mls_x251);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_break__case1_sr_post_caller_post_case0(_mlsValue _mls_x253, _mlsValue _mls_x256) {
  _mlsValue _mls_retval;
  auto _mls_x252 = _mlsValue::cast<_mls_Tuple2>(_mls_x253)->_mls_field0;
  auto _mls_x254 = _mlsValue::cast<_mls_Tuple2>(_mls_x253)->_mls_field1;
  auto _mls_x255 = _mlsValue::create<_mls_Cons>(_mls_x256, _mls_x252);
  auto _mls_x257 = _mlsValue::create<_mls_Tuple2>(_mls_x255, _mls_x254);
  _mls_retval = _mls_x257;
  return _mls_retval;
}
_mlsValue _mls_break__case1_sr_post_case0(_mlsValue _mls_x259, _mlsValue _mls_x260) {
  _mlsValue _mls_retval;
  auto _mls_x258 = _mlsValue::create<_mls_Cons>(_mls_x259, _mls_x260);
  auto _mls_x261 = _mlsValue::create<_mls_Nil>();
  auto _mls_x262 = _mlsValue::create<_mls_Tuple2>(_mls_x261, _mls_x258);
  _mls_retval = _mls_x262;
  return _mls_retval;
}
_mlsValue _mls_break__case1_sr_post_default(_mlsValue _mls_x266, _mlsValue _mls_x263, _mlsValue _mls_x268) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x263)) {
    auto _mls_x269 = _mls_break__case0();
    _mls_retval = _mls_break__case1_sr_post_caller_post_case0(_mls_x269, _mls_x268);
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x263)) {
    auto _mls_x264 = _mlsValue::cast<_mls_Cons>(_mls_x263)->_mls_head;
    auto _mls_x265 = _mlsValue::cast<_mls_Cons>(_mls_x263)->_mls_tail;
    auto _mls_x267 = _mls_break__case1_sr_post(_mls_x266, _mls_x264, _mls_x265);
    _mls_retval = _mls_break__case1_sr_post_caller_post(_mls_x267, _mls_x268);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_break__case1_sr_post_pre(_mlsValue _mls_x270, _mlsValue _mls_x271, _mlsValue _mls_x273) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x272 = _mlsMethodCall<_mls_Callable>(_mls_x270)->_mls_apply1(_mls_x271);
  _mls_retval = std::make_tuple(_mls_x272, _mls_x271, _mls_x273, _mls_x270);
  return _mls_retval;
}
_mlsValue _mls_chop(_mlsValue _mls_b2, _mlsValue _mls_n) {
  _mlsValue _mls_retval;
  auto _mls_x36 = _mlsValue::create<_mls_Nil>();
  auto _mls_x37 = _mls_chop_(_mls_x36, _mls_n, _mls_b2);
  _mls_retval = _mls_x37;
  return _mls_retval;
}
_mlsValue _mls_chop_(_mlsValue _mls_a3, _mlsValue _mls_n1, _mlsValue _mls_b3) {
  _mlsValue _mls_retval;
  auto _mls_x38 = _mls_divMod(_mls_n1, _mls_b3);
  auto _mls_x39 = _mlsValue::cast<_mls_Tuple2>(_mls_x38)->_mls_field0;
  auto _mls_x40 = _mlsValue::cast<_mls_Tuple2>(_mls_x38)->_mls_field1;
  auto _mls_x41 = (_mls_n1 == _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x41, 1)) {
    _mls_retval = _mls_a3;
  } else {
    auto _mls_x42 = _mlsValue::create<_mls_Cons>(_mls_x40, _mls_a3);
    auto _mls_x43 = _mls_chop_(_mls_x42, _mls_x39, _mls_b3);
    _mls_retval = _mls_x43;
  }
  return _mls_retval;
}
_mlsValue _mls_divMod(_mlsValue _mls_a4, _mlsValue _mls_b4) {
  _mlsValue _mls_retval;
  auto _mls_x274 = _mls_builtin_floor_div(_mls_a4, _mls_b4);
  auto _mls_x275 = _mls_builtin_floor_mod(_mls_a4, _mls_b4);
  auto _mls_x46 = _mlsValue::create<_mls_Tuple2>(_mls_x274, _mls_x275);
  _mls_retval = _mls_x46;
  return _mls_retval;
}
_mlsValue _mls_doInput(_mlsValue _mls_s1, _mlsValue _mls_s2, _mlsValue _mls_lls) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_lls)) {
    auto _mls_x51 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x51;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_lls)) {
    auto _mls_x47 = _mlsValue::cast<_mls_Cons>(_mls_lls)->_mls_head;
    auto _mls_x48 = _mlsValue::cast<_mls_Cons>(_mls_lls)->_mls_tail;
    auto _mls_x49 = _mlsValue::create<_mls_Lambda_lambda1>(_mls_x48);
    auto _mls_x50 = _mls_doLine(_mls_x47, _mls_x49, _mls_s1, _mls_s2);
    _mls_retval = _mls_x50;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_doLine(_mlsValue _mls_cs, _mlsValue _mls_cont, _mlsValue _mls_s11, _mlsValue _mls_s21) {
  _mlsValue _mls_retval;
  auto _mls_x276 = _mls_int_val_of_string_f(_mls_cs, _mlsValue::fromIntLit(0));
  auto [_mls_x277, _mls_x278, _mls_x279, _mls_x280, _mls_x281] = _mls_multiTest_pre(_mlsValue::fromIntLit(100), _mls_s11, _mls_s21, _mls_x276);
  if (_mlsValue::isIntLit(_mls_x279, 1)) {
    auto _mls_x297 = _mls_multiTest_case0(_mls_x281, _mls_x277, _mls_x278);
    auto _mls_x298 = _mlsValue::cast<_mls_Tuple3>(_mls_x297)->_mls_field0;
    auto _mls_x299 = _mlsValue::cast<_mls_Tuple3>(_mls_x297)->_mls_field1;
    auto _mls_x300 = _mlsValue::cast<_mls_Tuple3>(_mls_x297)->_mls_field2;
    _mls_retval = _mls_doLine_caller_post_case0_sr_post(_mls_x298, _mls_cont, _mls_x299, _mls_x300);
  } else {
    auto [_mls_x282, _mls_x283, _mls_x284, _mls_x285, _mls_x286] = _mls_multiTest_mTest_pre(_mls_x280, _mls_x277, _mls_x278, _mls_x281);
    if (_mlsValue::isIntLit(_mls_x286, 1)) {
      auto _mls_x293 = _mls_multiTest_mTest_case0(_mls_x284, _mls_x285);
      auto _mls_x294 = _mlsValue::cast<_mls_Tuple3>(_mls_x293)->_mls_field0;
      auto _mls_x295 = _mlsValue::cast<_mls_Tuple3>(_mls_x293)->_mls_field1;
      auto _mls_x296 = _mlsValue::cast<_mls_Tuple3>(_mls_x293)->_mls_field2;
      _mls_retval = _mls_doLine_caller_post_case0_sr_post(_mls_x294, _mls_cont, _mls_x295, _mls_x296);
    } else {
      auto [_mls_x287, _mls_x288, _mls_x289, _mls_x290, _mls_x291] = _mls_multiTest_mTest_default_pre(_mls_x283, _mls_x284, _mls_x285, _mls_x282);
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x291)) {
        auto _mls_x292 = _mls_multiTest_mTest_default_case0(_mls_x287, _mls_x288, _mls_x289, _mls_x290, _mls_x291);
        _mls_retval = _mls_doLine_caller_post(_mls_x292, _mls_cont);
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_doLine_caller_post(_mlsValue _mls_x301, _mlsValue _mls_x305) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x301)) {
    auto _mls_x302 = _mlsValue::cast<_mls_Tuple3>(_mls_x301)->_mls_field0;
    auto _mls_x303 = _mlsValue::cast<_mls_Tuple3>(_mls_x301)->_mls_field1;
    auto _mls_x304 = _mlsValue::cast<_mls_Tuple3>(_mls_x301)->_mls_field2;
    _mls_retval = _mls_doLine_caller_post_case0_sr_post(_mls_x302, _mls_x305, _mls_x303, _mls_x304);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_doLine_caller_post_case0_sr_post(_mlsValue _mls_x306, _mlsValue _mls_x307, _mlsValue _mls_x308, _mlsValue _mls_x309) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_x306, 1)) {
    auto _mls_x312 = _mlsMethodCall<_mls_Callable>(_mls_x307)->_mls_apply2(_mls_x308, _mls_x309);
    auto _mls_x313 = _mlsValue::create<_mls_Cons>(_mlsValue::create<_mls_Str>("Probably prime"), _mls_x312);
    _mls_retval = _mls_x313;
  } else {
    auto _mls_x310 = _mlsMethodCall<_mls_Callable>(_mls_x307)->_mls_apply2(_mls_x308, _mls_x309);
    auto _mls_x311 = _mlsValue::create<_mls_Cons>(_mlsValue::create<_mls_Str>("Composite"), _mls_x310);
    _mls_retval = _mls_x311;
  }
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x61 = _mls_testPrimetest_nofib(_mlsValue::fromIntLit(0));
  _mls_retval = _mls_x61;
  return _mls_retval;
}
_mlsValue _mls_even(_mlsValue _mls_x63) {
  _mlsValue _mls_retval;
  auto _mls_x314 = _mls_builtin_floor_mod(_mls_x63, _mlsValue::fromIntLit(2));
  auto _mls_x64 = (_mls_x314 == _mlsValue::fromIntLit(0));
  _mls_retval = _mls_x64;
  return _mls_retval;
}
_mlsValue _mls_findKQ(_mlsValue _mls_n2) {
  _mlsValue _mls_retval;
  auto _mls_x65 = (_mls_n2 - _mlsValue::fromIntLit(1));
  auto _mls_x66 = _mls_findKQ_f(_mlsValue::fromIntLit(0), _mls_x65);
  _mls_retval = _mls_x66;
  return _mls_retval;
}
_mlsValue _mls_findKQ_f(_mlsValue _mls_k, _mlsValue _mls_q) {
  _mlsValue _mls_retval;
  auto _mls_x67 = _mls_divMod(_mls_q, _mlsValue::fromIntLit(2));
  auto _mls_x68 = _mlsValue::cast<_mls_Tuple2>(_mls_x67)->_mls_field0;
  auto _mls_x69 = _mlsValue::cast<_mls_Tuple2>(_mls_x67)->_mls_field1;
  auto _mls_x70 = (_mls_x69 == _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x70, 1)) {
    auto _mls_x72 = (_mls_k + _mlsValue::fromIntLit(1));
    auto _mls_x73 = _mls_findKQ_f(_mls_x72, _mls_x68);
    _mls_retval = _mls_x73;
  } else {
    auto _mls_x71 = _mlsValue::create<_mls_Tuple2>(_mls_k, _mls_q);
    _mls_retval = _mls_x71;
  }
  return _mls_retval;
}
_mlsValue _mls_foldl(_mlsValue _mls_f, _mlsValue _mls_a5, _mlsValue _mls_xs) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs)) {
    _mls_retval = _mls_a5;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs)) {
    auto _mls_x74 = _mlsValue::cast<_mls_Cons>(_mls_xs)->_mls_head;
    auto _mls_x75 = _mlsValue::cast<_mls_Cons>(_mls_xs)->_mls_tail;
    auto _mls_x76 = _mlsMethodCall<_mls_Callable>(_mls_f)->_mls_apply2(_mls_a5, _mls_x74);
    auto _mls_x77 = _mls_foldl(_mls_f, _mls_x76, _mls_x75);
    _mls_retval = _mls_x77;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_generateRands(_mlsValue _mls_x315, _mlsValue _mls_x316, _mlsValue _mls_x317, _mlsValue _mls_x318) {
  _mlsValue _mls_retval;
  auto [_mls_x319, _mls_x320, _mls_x321, _mls_x322, _mls_x323] = _mls_generateRands_pre(_mls_x315, _mls_x316, _mls_x317, _mls_x318);
  if (_mlsValue::isIntLit(_mls_x320, 1)) {
    _mls_retval = _mls_generateRands_case0(_mls_x321, _mls_x323, _mls_x322);
  } else {
    _mls_retval = _mls_generateRands_default(_mls_x323, _mls_x322, _mls_x319, _mls_x321);
  }
  return _mls_retval;
}
_mlsValue _mls_generateRands_case0(_mlsValue _mls_x325, _mlsValue _mls_x326, _mlsValue _mls_x327) {
  _mlsValue _mls_retval;
  auto _mls_x324 = _mlsValue::create<_mls_Tuple3>(_mls_x325, _mls_x326, _mls_x327);
  _mls_retval = _mls_x324;
  return _mls_retval;
}
_mlsValue _mls_generateRands_default(_mlsValue _mls_x328, _mlsValue _mls_x329, _mlsValue _mls_x335, _mlsValue _mls_x337) {
  _mlsValue _mls_retval;
  auto _mls_x330 = _mls_nextRand(_mls_x328, _mls_x329);
  auto _mls_x331 = _mlsValue::cast<_mls_Tuple3>(_mls_x330)->_mls_field0;
  auto _mls_x332 = _mlsValue::cast<_mls_Tuple3>(_mls_x330)->_mls_field1;
  auto _mls_x333 = _mlsValue::cast<_mls_Tuple3>(_mls_x330)->_mls_field2;
  auto _mls_x334 = (_mls_x335 - _mlsValue::fromIntLit(1));
  auto _mls_x336 = _mlsValue::create<_mls_Cons>(_mls_x331, _mls_x337);
  auto _mls_x338 = _mls_generateRands(_mls_x334, _mls_x332, _mls_x333, _mls_x336);
  _mls_retval = _mls_x338;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_generateRands_pre(_mlsValue _mls_x340, _mlsValue _mls_x343, _mlsValue _mls_x342, _mlsValue _mls_x341) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x339 = (_mls_x340 == _mlsValue::fromIntLit(0));
  _mls_retval = std::make_tuple(_mls_x340, _mls_x339, _mls_x341, _mls_x342, _mls_x343);
  return _mls_retval;
}
_mlsValue _mls_intDiv(_mlsValue _mls_a6, _mlsValue _mls_b5) {
  _mlsValue _mls_retval;
  auto _mls_x87 = _mls_builtin_floor_div(_mls_a6, _mls_b5);
  _mls_retval = _mls_x87;
  return _mls_retval;
}
_mlsValue _mls_intMod(_mlsValue _mls_a7, _mlsValue _mls_b6) {
  _mlsValue _mls_retval;
  auto _mls_x88 = _mls_builtin_floor_mod(_mls_a7, _mls_b6);
  _mls_retval = _mls_x88;
  return _mls_retval;
}
_mlsValue _mls_int_val_of_char(_mlsValue _mls_x90) {
  _mlsValue _mls_retval;
  auto _mls_x344 = _mls_builtin_char2int(_mls_x90);
  auto _mls_x91 = (_mls_x344 - _mlsValue::fromIntLit(48));
  _mls_retval = _mls_x91;
  return _mls_retval;
}
_mlsValue _mls_int_val_of_string_f(_mlsValue _mls_l, _mlsValue _mls_a8) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_l)) {
    _mls_retval = _mls_a8;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_l)) {
    auto _mls_x92 = _mlsValue::cast<_mls_Cons>(_mls_l)->_mls_head;
    auto _mls_x93 = _mlsValue::cast<_mls_Cons>(_mls_l)->_mls_tail;
    auto _mls_x94 = (_mlsValue::fromIntLit(10) * _mls_a8);
    auto _mls_x95 = _mls_int_val_of_char(_mls_x92);
    auto _mls_x96 = (_mls_x94 + _mls_x95);
    auto _mls_x97 = _mls_int_val_of_string_f(_mls_x93, _mls_x96);
    _mls_retval = _mls_x97;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_is_iter(_mlsValue _mls_n3, _mlsValue _mls_acc1, _mlsValue _mls_v, _mlsValue _mls_f1) {
  _mlsValue _mls_retval;
  auto _mls_x98 = (_mls_n3 == _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x98, 1)) {
    _mls_retval = _mls_acc1;
  } else {
    auto _mls_x99 = (_mls_n3 - _mlsValue::fromIntLit(1));
    auto _mls_x100 = _mlsValue::create<_mls_Cons>(_mls_v, _mls_acc1);
    auto _mls_x101 = _mlsMethodCall<_mls_Callable>(_mls_f1)->_mls_apply1(_mls_v);
    auto _mls_x102 = _mls_is_iter(_mls_x99, _mls_x100, _mls_x101, _mls_f1);
    _mls_retval = _mls_x102;
  }
  return _mls_retval;
}
_mlsValue _mls_iterate_square(_mlsValue _mls_f2, _mlsValue _mls_x104, _mlsValue _mls_k1) {
  _mlsValue _mls_retval;
  auto _mls_x103 = _mlsValue::create<_mls_Nil>();
  auto _mls_x105 = _mls_is_iter(_mls_k1, _mls_x103, _mls_x104, _mls_f2);
  _mls_retval = _mls_x105;
  return _mls_retval;
}
_mlsValue _mls_j1(_mlsValue _mls_tmp, _mlsValue _mls_s23) {
  _mlsValue _mls_retval;
  auto _mls_x345 = _mls_builtin_floor_div(_mls_s23, _mlsValue::fromIntLit(52774));
  auto _mls_x107 = (_mls_x345 * _mlsValue::fromIntLit(52774));
  auto _mls_x108 = (_mls_s23 - _mls_x107);
  auto _mls_x109 = (_mlsValue::fromIntLit(40692) * _mls_x108);
  auto _mls_x110 = (_mls_x345 * _mlsValue::fromIntLit(3791));
  auto _mls_x111 = (_mls_x109 - _mls_x110);
  auto _mls_x112 = (_mls_x111 < _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x112, 1)) {
    auto _mls_x113 = (_mls_x111 + _mlsValue::fromIntLit(2147483399));
    _mls_retval = _mls_j(_mls_x113, _mls_tmp);
  } else {
    _mls_retval = _mls_j(_mls_x111, _mls_tmp);
  }
  return _mls_retval;
}
_mlsValue _mls_j(_mlsValue _mls_tmp1, _mlsValue _mls_s1__) {
  _mlsValue _mls_retval;
  auto _mls_x114 = (_mls_s1__ - _mls_tmp1);
  auto _mls_x115 = (_mls_x114 < _mlsValue::fromIntLit(1));
  if (_mlsValue::isIntLit(_mls_x115, 1)) {
    auto _mls_x117 = (_mls_x114 + _mlsValue::fromIntLit(2147483562));
    auto _mls_x118 = _mlsValue::create<_mls_Tuple3>(_mls_x117, _mls_s1__, _mls_tmp1);
    _mls_retval = _mls_x118;
  } else {
    auto _mls_x116 = _mlsValue::create<_mls_Tuple3>(_mls_x114, _mls_s1__, _mls_tmp1);
    _mls_retval = _mls_x116;
  }
  return _mls_retval;
}
_mlsValue _mls_j2(_mlsValue _mls_tmp2, _mlsValue _mls_l1) {
  _mlsValue _mls_retval;
  auto _mls_x119 = _mlsValue::create<_mls_Cons>(_mls_l1, _mls_tmp2);
  _mls_retval = _mls_x119;
  return _mls_retval;
}
_mlsValue _mls_l2(_mlsValue _mls_ls1, _mlsValue _mls_a9) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls1)) {
    _mls_retval = _mls_a9;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls1)) {
    auto _mls_x120 = _mlsValue::cast<_mls_Cons>(_mls_ls1)->_mls_tail;
    auto _mls_x121 = (_mls_a9 + _mlsValue::fromIntLit(1));
    auto _mls_x122 = _mls_l2(_mls_x120, _mls_x121);
    _mls_retval = _mls_x122;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_lines(_mlsValue _mls_x346) {
  _mlsValue _mls_retval;
  auto [_mls_x347, _mls_x348] = _mls_lines_pre(_mls_x346);
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x347)) {
    _mls_retval = _mls_lines_case0();
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x347)) {
    auto _mls_x349 = _mlsValue::cast<_mls_Cons>(_mls_x347)->_mls_head;
    auto _mls_x350 = _mlsValue::cast<_mls_Cons>(_mls_x347)->_mls_tail;
    _mls_retval = _mls_lines_case1_sr_post(_mls_x348, _mls_x349, _mls_x350);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_lines_caller_post(_mlsValue _mls_x351) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x351)) {
    auto _mls_x352 = _mlsValue::cast<_mls_Tuple2>(_mls_x351)->_mls_field0;
    auto _mls_x353 = _mlsValue::cast<_mls_Tuple2>(_mls_x351)->_mls_field1;
    _mls_retval = _mls_lines_caller_post_case0_sr_post(_mls_x353, _mls_x352);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_lines_caller_post_case0_sr_post(_mlsValue _mls_x354, _mlsValue _mls_x357) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x354)) {
    auto _mls_x358 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_j2(_mls_x358, _mls_x357);
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x354)) {
    auto _mls_x355 = _mlsValue::cast<_mls_Cons>(_mls_x354)->_mls_tail;
    auto _mls_x356 = _mls_lines(_mls_x355);
    _mls_retval = _mls_j2(_mls_x356, _mls_x357);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_lines_case0() {
  _mlsValue _mls_retval;
  auto _mls_x359 = _mls_break__case0();
  auto _mls_x360 = _mlsValue::cast<_mls_Tuple2>(_mls_x359)->_mls_field0;
  auto _mls_x361 = _mlsValue::cast<_mls_Tuple2>(_mls_x359)->_mls_field1;
  _mls_retval = _mls_lines_caller_post_case0_sr_post(_mls_x361, _mls_x360);
  return _mls_retval;
}
_mlsValue _mls_lines_case1_sr_post(_mlsValue _mls_x362, _mlsValue _mls_x363, _mlsValue _mls_x364) {
  _mlsValue _mls_retval;
  auto [_mls_x365, _mls_x366, _mls_x367, _mls_x368] = _mls_break__case1_sr_post_pre(_mls_x362, _mls_x363, _mls_x364);
  if (_mlsValue::isIntLit(_mls_x365, 1)) {
    auto _mls_x370 = _mls_break__case1_sr_post_case0(_mls_x366, _mls_x367);
    _mls_retval = _mls_lines_caller_post(_mls_x370);
  } else {
    auto _mls_x369 = _mls_break__case1_sr_post_default(_mls_x368, _mls_x367, _mls_x366);
    _mls_retval = _mls_lines_caller_post(_mls_x369);
  }
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue> _mls_lines_pre(_mlsValue _mls_x372) {
  std::tuple<_mlsValue, _mlsValue> _mls_retval;
  auto _mls_x371 = _mlsValue::create<_mls_Lambda_lambda3>();
  _mls_retval = std::make_tuple(_mls_x372, _mls_x371);
  return _mls_retval;
}
_mlsValue _mls_makeNumber(_mlsValue _mls_b7, _mlsValue _mls_ls2) {
  _mlsValue _mls_retval;
  auto _mls_x130 = _mlsValue::create<_mls_Lambda_lambda2>(_mls_b7);
  auto _mls_x131 = _mls_foldl(_mls_x130, _mlsValue::fromIntLit(0), _mls_ls2);
  _mls_retval = _mls_x131;
  return _mls_retval;
}
_mlsValue _mls_map(_mlsValue _mls_f3, _mlsValue _mls_xs1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs1)) {
    auto _mls_x133 = _mlsValue::cast<_mls_Cons>(_mls_xs1)->_mls_head;
    auto _mls_x134 = _mlsValue::cast<_mls_Cons>(_mls_xs1)->_mls_tail;
    auto _mls_x135 = _mlsMethodCall<_mls_Callable>(_mls_f3)->_mls_apply1(_mls_x133);
    auto _mls_x136 = _mls_map(_mls_f3, _mls_x134);
    auto _mls_x137 = _mlsValue::create<_mls_Cons>(_mls_x135, _mls_x136);
    _mls_retval = _mls_x137;
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs1)) {
    auto _mls_x132 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x132;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_multiTest_case0(_mlsValue _mls_x374, _mlsValue _mls_x376, _mlsValue _mls_x377) {
  _mlsValue _mls_retval;
  auto _mls_x373 = (_mls_x374 == _mlsValue::fromIntLit(2));
  auto _mls_x375 = _mlsValue::create<_mls_Tuple3>(_mls_x373, _mls_x376, _mls_x377);
  _mls_retval = _mls_x375;
  return _mls_retval;
}
_mlsValue _mls_multiTest_mTest(_mlsValue _mls_x378, _mlsValue _mls_x379, _mlsValue _mls_x380, _mlsValue _mls_x381) {
  _mlsValue _mls_retval;
  auto [_mls_x382, _mls_x383, _mls_x384, _mls_x385, _mls_x386] = _mls_multiTest_mTest_pre(_mls_x378, _mls_x379, _mls_x380, _mls_x381);
  if (_mlsValue::isIntLit(_mls_x386, 1)) {
    _mls_retval = _mls_multiTest_mTest_case0(_mls_x384, _mls_x385);
  } else {
    _mls_retval = _mls_multiTest_mTest_default(_mls_x383, _mls_x384, _mls_x385, _mls_x382);
  }
  return _mls_retval;
}
_mlsValue _mls_multiTest_mTest_caller_post(_mlsValue _mls_x387, _mlsValue _mls_x388, _mlsValue _mls_x389) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x387)) {
    _mls_retval = _mls_multiTest_mTest_caller_post_case0(_mls_x387, _mls_x388, _mls_x389);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_multiTest_mTest_caller_post_case0(_mlsValue _mls_x391, _mlsValue _mls_x396, _mlsValue _mls_x397) {
  _mlsValue _mls_retval;
  auto _mls_x390 = _mlsValue::cast<_mls_Tuple3>(_mls_x391)->_mls_field0;
  auto _mls_x392 = _mlsValue::cast<_mls_Tuple3>(_mls_x391)->_mls_field1;
  auto _mls_x393 = _mlsValue::cast<_mls_Tuple3>(_mls_x391)->_mls_field2;
  if (_mlsValue::isIntLit(_mls_x390, 1)) {
    auto _mls_x395 = (_mls_x396 - _mlsValue::fromIntLit(1));
    auto _mls_x398 = _mls_multiTest_mTest(_mls_x395, _mls_x392, _mls_x393, _mls_x397);
    _mls_retval = _mls_x398;
  } else {
    auto _mls_x394 = _mlsValue::create<_mls_Tuple3>(_mlsValue::fromIntLit(0), _mls_x392, _mls_x393);
    _mls_retval = _mls_x394;
  }
  return _mls_retval;
}
_mlsValue _mls_multiTest_mTest_case0(_mlsValue _mls_x400, _mlsValue _mls_x401) {
  _mlsValue _mls_retval;
  auto _mls_x399 = _mlsValue::create<_mls_Tuple3>(_mlsValue::fromIntLit(1), _mls_x400, _mls_x401);
  _mls_retval = _mls_x399;
  return _mls_retval;
}
_mlsValue _mls_multiTest_mTest_default(_mlsValue _mls_x402, _mlsValue _mls_x403, _mlsValue _mls_x404, _mlsValue _mls_x405) {
  _mlsValue _mls_retval;
  auto [_mls_x406, _mls_x407, _mls_x408, _mls_x409, _mls_x410] = _mls_multiTest_mTest_default_pre(_mls_x402, _mls_x403, _mls_x404, _mls_x405);
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x410)) {
    auto _mls_x411 = _mlsValue::cast<_mls_Tuple3>(_mls_x410)->_mls_field0;
    auto _mls_x412 = _mlsValue::cast<_mls_Tuple3>(_mls_x410)->_mls_field1;
    auto _mls_x413 = _mlsValue::cast<_mls_Tuple3>(_mls_x410)->_mls_field2;
    auto _mls_x414 = _mls_singleTest_case0_sr_post(_mls_x412, _mls_x406, _mls_x411, _mls_x409, _mls_x413);
    _mls_retval = _mls_multiTest_mTest_caller_post(_mls_x414, _mls_x407, _mls_x408);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_multiTest_mTest_default_case0(_mlsValue _mls_x417, _mlsValue _mls_x419, _mlsValue _mls_x420, _mlsValue _mls_x416, _mlsValue _mls_x415) {
  _mlsValue _mls_retval;
  auto _mls_x418 = _mls_singleTest_case0(_mls_x415, _mls_x416, _mls_x417);
  _mls_retval = _mls_multiTest_mTest_caller_post_case0(_mls_x418, _mls_x419, _mls_x420);
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_multiTest_mTest_default_pre(_mlsValue _mls_x421, _mlsValue _mls_x423, _mlsValue _mls_x424, _mlsValue _mls_x428) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x422 = _mls_findKQ(_mls_x421);
  auto [_mls_x425, _mls_x426, _mls_x427] = _mls_singleTest_pre(_mls_x421, _mls_x422, _mls_x423, _mls_x424);
  _mls_retval = std::make_tuple(_mls_x427, _mls_x428, _mls_x421, _mls_x426, _mls_x425);
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_multiTest_mTest_pre(_mlsValue _mls_x430, _mlsValue _mls_x432, _mlsValue _mls_x433, _mlsValue _mls_x431) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x429 = (_mls_x430 == _mlsValue::fromIntLit(0));
  _mls_retval = std::make_tuple(_mls_x430, _mls_x431, _mls_x432, _mls_x433, _mls_x429);
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_multiTest_pre(_mlsValue _mls_x440, _mlsValue _mls_x438, _mlsValue _mls_x439, _mlsValue _mls_x435) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x434 = (_mls_x435 <= _mlsValue::fromIntLit(1));
  auto _mls_x436 = _mls_even(_mls_x435);
  auto _mls_x437 = (_mls_x434 || _mls_x436);
  _mls_retval = std::make_tuple(_mls_x438, _mls_x439, _mls_x437, _mls_x440, _mls_x435);
  return _mls_retval;
}
_mlsValue _mls_nextRand(_mlsValue _mls_s15, _mlsValue _mls_s23) {
  _mlsValue _mls_retval;
  auto _mls_x441 = _mls_builtin_floor_div(_mls_s15, _mlsValue::fromIntLit(53668));
  auto _mls_x155 = (_mls_x441 * _mlsValue::fromIntLit(53668));
  auto _mls_x156 = (_mls_s15 - _mls_x155);
  auto _mls_x157 = (_mlsValue::fromIntLit(40014) * _mls_x156);
  auto _mls_x158 = (_mls_x441 * _mlsValue::fromIntLit(12211));
  auto _mls_x159 = (_mls_x157 - _mls_x158);
  auto _mls_x160 = (_mls_x159 < _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x160, 1)) {
    auto _mls_x161 = (_mls_x159 + _mlsValue::fromIntLit(2147483563));
    _mls_retval = _mls_j1(_mls_x161, _mls_s23);
  } else {
    _mls_retval = _mls_j1(_mls_x159, _mls_s23);
  }
  return _mls_retval;
}
_mlsValue _mls_powerMod(_mlsValue _mls_a10, _mlsValue _mls_b8, _mlsValue _mls_m) {
  _mlsValue _mls_retval;
  auto _mls_x162 = _mlsValue::create<_mls_Lambda_f>(_mls_m);
  auto _mls_x163 = (_mls_b8 == _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x163, 1)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else {
    auto _mls_x442 = _mls_builtin_floor_mod(_mls_a10, _mls_m);
    auto _mls_x165 = (_mls_b8 - _mlsValue::fromIntLit(1));
    auto _mls_x166 = _mlsMethodCall<_mls_Callable>(_mls_x162)->_mls_apply3(_mls_x442, _mls_x165, _mls_x442);
    _mls_retval = _mls_x166;
  }
  return _mls_retval;
}
_mlsValue _mls_random(_mlsValue _mls_n6, _mlsValue _mls_s16, _mlsValue _mls_s26) {
  _mlsValue _mls_retval;
  auto _mls_x167 = _mls_chop(_mlsValue::fromIntLit(65536), _mls_n6);
  auto _mls_x443 = _mls_l2(_mls_x167, _mlsValue::fromIntLit(0));
  auto _mls_x169 = _mlsValue::create<_mls_Nil>();
  auto [_mls_x444, _mls_x445, _mls_x446, _mls_x447, _mls_x448] = _mls_generateRands_pre(_mls_x443, _mls_s16, _mls_s26, _mls_x169);
  if (_mlsValue::isIntLit(_mls_x445, 1)) {
    auto _mls_x450 = _mls_generateRands_case0(_mls_x446, _mls_x448, _mls_x447);
    auto _mls_x451 = _mlsValue::cast<_mls_Tuple3>(_mls_x450)->_mls_field0;
    auto _mls_x452 = _mlsValue::cast<_mls_Tuple3>(_mls_x450)->_mls_field1;
    auto _mls_x453 = _mlsValue::cast<_mls_Tuple3>(_mls_x450)->_mls_field2;
    _mls_retval = _mls_random_caller_post_case0_sr_post(_mls_x167, _mls_x451, _mls_x452, _mls_x453);
  } else {
    auto _mls_x449 = _mls_generateRands_default(_mls_x448, _mls_x447, _mls_x444, _mls_x446);
    _mls_retval = _mls_random_caller_post(_mls_x449, _mls_x167);
  }
  return _mls_retval;
}
_mlsValue _mls_random_caller_post(_mlsValue _mls_x454, _mlsValue _mls_x458) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x454)) {
    auto _mls_x455 = _mlsValue::cast<_mls_Tuple3>(_mls_x454)->_mls_field0;
    auto _mls_x456 = _mlsValue::cast<_mls_Tuple3>(_mls_x454)->_mls_field1;
    auto _mls_x457 = _mlsValue::cast<_mls_Tuple3>(_mls_x454)->_mls_field2;
    _mls_retval = _mls_random_caller_post_case0_sr_post(_mls_x458, _mls_x455, _mls_x456, _mls_x457);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_random_caller_post_case0_sr_post(_mlsValue _mls_x459, _mlsValue _mls_x460, _mlsValue _mls_x462, _mlsValue _mls_x463) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x459)) {
    auto _mls_x461 = _mls_uniform_case0(_mls_x459, _mls_x460);
    _mls_retval = _mls_random_caller_post_case0_sr_post_caller_post(_mls_x461, _mls_x462, _mls_x463);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_random_caller_post_case0_sr_post_caller_post(_mlsValue _mls_x464, _mlsValue _mls_x467, _mlsValue _mls_x468) {
  _mlsValue _mls_retval;
  auto _mls_x465 = _mls_makeNumber(_mlsValue::fromIntLit(65536), _mls_x464);
  auto _mls_x466 = _mlsValue::create<_mls_Tuple3>(_mls_x465, _mls_x467, _mls_x468);
  _mls_retval = _mls_x466;
  return _mls_retval;
}
_mlsValue _mls_repeatProcess(_mlsValue _mls_n7, _mlsValue _mls_acc2) {
  _mlsValue _mls_retval;
  auto _mls_x177 = (_mls_n7 == _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x177, 1)) {
    _mls_retval = _mls_acc2;
  } else {
    auto _mls_x469 = _mls_builtin_str_head(_mlsValue::create<_mls_Str>("17|24|48|47|1317|8901|97|101|103|107|109|113|127|131|137|139|149|151|157|163|167|173|179|181|191|193|197|199|211|223|227|229|233|239|241|251|257|263|269|271|277|281|283|293|307|311|313|317|331|337|347|349|353|359|367|373|379|383|389|397|401|409|419|421|431|433|439|443|449|457|461|463|467|479|487|491|499|503|509|521|523|541|547|557|563|569|571|577|587|593|599|601|607|613|617|619|631|641|643|647|653|659|661|673|677|683|691|701|709|719|727|733|739|743|751|757|761|769|773|787|797|809|811|821|823|827|829|839|853|857|859|863|877|881|883|887|907|911|919|929|937|941|947|953|967|971|977|983|991|997"));
    if (_mlsValue::isValueOf<_mls_Unit>(_mls_x469)) {
      auto _mls_x477 = _mls_str_to_list_case0();
      auto [_mls_x478, _mls_x479] = _mls_lines_pre(_mls_x477);
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x478)) {
        auto _mls_x483 = _mls_lines_case0();
        _mls_retval = _mls_repeatProcess_caller_post_post(_mls_n7, _mls_x483, _mls_acc2);
      } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x478)) {
        auto _mls_x480 = _mlsValue::cast<_mls_Cons>(_mls_x478)->_mls_head;
        auto _mls_x481 = _mlsValue::cast<_mls_Cons>(_mls_x478)->_mls_tail;
        auto _mls_x482 = _mls_lines_case1_sr_post(_mls_x479, _mls_x480, _mls_x481);
        _mls_retval = _mls_repeatProcess_caller_post_post(_mls_n7, _mls_x482, _mls_acc2);
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      auto _mls_x470 = _mls_str_to_list_default(_mlsValue::create<_mls_Str>("17|24|48|47|1317|8901|97|101|103|107|109|113|127|131|137|139|149|151|157|163|167|173|179|181|191|193|197|199|211|223|227|229|233|239|241|251|257|263|269|271|277|281|283|293|307|311|313|317|331|337|347|349|353|359|367|373|379|383|389|397|401|409|419|421|431|433|439|443|449|457|461|463|467|479|487|491|499|503|509|521|523|541|547|557|563|569|571|577|587|593|599|601|607|613|617|619|631|641|643|647|653|659|661|673|677|683|691|701|709|719|727|733|739|743|751|757|761|769|773|787|797|809|811|821|823|827|829|839|853|857|859|863|877|881|883|887|907|911|919|929|937|941|947|953|967|971|977|983|991|997"));
      auto [_mls_x471, _mls_x472] = _mls_lines_pre(_mls_x470);
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x471)) {
        auto _mls_x476 = _mls_lines_case0();
        _mls_retval = _mls_repeatProcess_caller_post_post(_mls_n7, _mls_x476, _mls_acc2);
      } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x471)) {
        auto _mls_x473 = _mlsValue::cast<_mls_Cons>(_mls_x471)->_mls_head;
        auto _mls_x474 = _mlsValue::cast<_mls_Cons>(_mls_x471)->_mls_tail;
        auto _mls_x475 = _mls_lines_case1_sr_post(_mls_x472, _mls_x473, _mls_x474);
        _mls_retval = _mls_repeatProcess_caller_post_post(_mls_n7, _mls_x475, _mls_acc2);
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_repeatProcess_caller_post_post(_mlsValue _mls_x485, _mlsValue _mls_x486, _mlsValue _mls_x489) {
  _mlsValue _mls_retval;
  auto _mls_x484 = (_mls_x485 - _mlsValue::fromIntLit(1));
  auto _mls_x487 = _mls_doInput(_mlsValue::fromIntLit(111), _mlsValue::fromIntLit(47), _mls_x486);
  auto _mls_x488 = _mlsValue::create<_mls_Cons>(_mls_x487, _mls_x489);
  auto _mls_x490 = _mls_repeatProcess(_mls_x484, _mls_x488);
  _mls_retval = _mls_x490;
  return _mls_retval;
}
_mlsValue _mls_singleTestX(_mlsValue _mls_n9, _mlsValue _mls_kq1, _mlsValue _mls_x194) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_kq1)) {
    auto _mls_x192 = _mlsValue::cast<_mls_Tuple2>(_mls_kq1)->_mls_field0;
    auto _mls_x193 = _mlsValue::cast<_mls_Tuple2>(_mls_kq1)->_mls_field1;
    auto _mls_x195 = _mls_powerMod(_mls_x194, _mls_x193, _mls_n9);
    auto _mls_x196 = _mlsValue::create<_mls_Lambda_lambda4>(_mls_n9);
    auto _mls_x197 = _mls_iterate_square(_mls_x196, _mls_x195, _mls_x192);
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x197)) {
      auto _mls_x198 = _mlsValue::cast<_mls_Cons>(_mls_x197)->_mls_head;
      auto _mls_x199 = _mlsValue::cast<_mls_Cons>(_mls_x197)->_mls_tail;
      auto _mls_x200 = (_mls_x198 == _mlsValue::fromIntLit(1));
      auto _mls_x201 = (_mls_n9 - _mlsValue::fromIntLit(1));
      auto _mls_x202 = (_mls_x198 == _mls_x201);
      auto _mls_x203 = (_mls_x200 || _mls_x202);
      auto _mls_x204 = _mls_singleTestX_witness(_mls_x199, _mls_n9);
      auto _mls_x205 = (_mls_x203 || _mls_x204);
      _mls_retval = _mls_x205;
    } else {
      _mls_retval = _mlsValue::fromIntLit(0);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_singleTestX_square(_mlsValue _mls_x207, _mlsValue _mls_n10) {
  _mlsValue _mls_retval;
  auto _mls_x206 = (_mls_x207 * _mls_x207);
  auto _mls_x491 = _mls_builtin_floor_mod(_mls_x206, _mls_n10);
  _mls_retval = _mls_x491;
  return _mls_retval;
}
_mlsValue _mls_singleTestX_witness(_mlsValue _mls_ls3, _mlsValue _mls_n11) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls3)) {
    _mls_retval = _mlsValue::fromIntLit(0);
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls3)) {
    auto _mls_x209 = _mlsValue::cast<_mls_Cons>(_mls_ls3)->_mls_head;
    auto _mls_x210 = _mlsValue::cast<_mls_Cons>(_mls_ls3)->_mls_tail;
    auto _mls_x211 = (_mls_n11 - _mlsValue::fromIntLit(1));
    auto _mls_x212 = (_mls_x209 == _mls_x211);
    if (_mlsValue::isIntLit(_mls_x212, 1)) {
      _mls_retval = _mlsValue::fromIntLit(1);
    } else {
      auto _mls_x213 = (_mls_x209 == _mlsValue::fromIntLit(1));
      if (_mlsValue::isIntLit(_mls_x213, 1)) {
        _mls_retval = _mlsValue::fromIntLit(0);
      } else {
        auto _mls_x214 = _mls_singleTestX_witness(_mls_x210, _mls_n11);
        _mls_retval = _mls_x214;
      }
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_singleTest_case0(_mlsValue _mls_x493, _mlsValue _mls_x497, _mlsValue _mls_x496) {
  _mlsValue _mls_retval;
  auto _mls_x492 = _mlsValue::cast<_mls_Tuple3>(_mls_x493)->_mls_field0;
  auto _mls_x494 = _mlsValue::cast<_mls_Tuple3>(_mls_x493)->_mls_field1;
  auto _mls_x495 = _mlsValue::cast<_mls_Tuple3>(_mls_x493)->_mls_field2;
  _mls_retval = _mls_singleTest_case0_sr_post(_mls_x494, _mls_x496, _mls_x492, _mls_x497, _mls_x495);
  return _mls_retval;
}
_mlsValue _mls_singleTest_case0_sr_post(_mlsValue _mls_x504, _mlsValue _mls_x501, _mlsValue _mls_x499, _mlsValue _mls_x500, _mlsValue _mls_x505) {
  _mlsValue _mls_retval;
  auto _mls_x498 = (_mlsValue::fromIntLit(2) + _mls_x499);
  auto _mls_x502 = _mls_singleTestX(_mls_x500, _mls_x501, _mls_x498);
  auto _mls_x503 = _mlsValue::create<_mls_Tuple3>(_mls_x502, _mls_x504, _mls_x505);
  _mls_retval = _mls_x503;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_singleTest_pre(_mlsValue _mls_x507, _mlsValue _mls_x511, _mlsValue _mls_x508, _mlsValue _mls_x509) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x506 = (_mls_x507 - _mlsValue::fromIntLit(2));
  auto _mls_x510 = _mls_random(_mls_x506, _mls_x508, _mls_x509);
  _mls_retval = std::make_tuple(_mls_x510, _mls_x507, _mls_x511);
  return _mls_retval;
}
_mlsValue _mls_str_to_list(_mlsValue _mls_x513) {
  _mlsValue _mls_retval;
  auto _mls_x512 = _mls_builtin_str_head(_mls_x513);
  if (_mlsValue::isValueOf<_mls_Unit>(_mls_x512)) {
    _mls_retval = _mls_str_to_list_case0();
  } else {
    _mls_retval = _mls_str_to_list_default(_mls_x513);
  }
  return _mls_retval;
}
_mlsValue _mls_str_to_list_case0() {
  _mlsValue _mls_retval;
  auto _mls_x514 = _mlsValue::create<_mls_Nil>();
  _mls_retval = _mls_x514;
  return _mls_retval;
}
_mlsValue _mls_str_to_list_default(_mlsValue _mls_x516) {
  _mlsValue _mls_retval;
  auto _mls_x515 = _mls_builtin_str_head(_mls_x516);
  auto _mls_x517 = _mls_builtin_str_tail(_mls_x516);
  auto _mls_x518 = _mls_str_to_list(_mls_x517);
  auto _mls_x519 = _mlsValue::create<_mls_Cons>(_mls_x515, _mls_x518);
  _mls_retval = _mls_x519;
  return _mls_retval;
}
_mlsValue _mls_testPrimetest_nofib(_mlsValue _mls_d) {
  _mlsValue _mls_retval;
  auto _mls_x222 = _mlsValue::create<_mls_Nil>();
  auto _mls_x223 = _mls_repeatProcess(_mlsValue::fromIntLit(100), _mls_x222);
  _mls_retval = _mls_x223;
  return _mls_retval;
}
_mlsValue _mls_uniform(_mlsValue _mls_x520, _mlsValue _mls_x521) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x520)) {
    _mls_retval = _mls_uniform_case0(_mls_x520, _mls_x521);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_uniform_case0(_mlsValue _mls_x523, _mlsValue _mls_x525) {
  _mlsValue _mls_retval;
  auto _mls_x522 = _mlsValue::cast<_mls_Cons>(_mls_x523)->_mls_head;
  auto _mls_x524 = _mlsValue::cast<_mls_Cons>(_mls_x523)->_mls_tail;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x524)) {
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x525)) {
      auto _mls_x536 = _mlsValue::cast<_mls_Cons>(_mls_x525)->_mls_head;
      auto _mls_x537 = _mls_builtin_floor_mod(_mls_x536, _mls_x522);
      auto _mls_x538 = _mlsValue::create<_mls_Nil>();
      auto _mls_x539 = _mlsValue::create<_mls_Cons>(_mls_x537, _mls_x538);
      _mls_retval = _mls_x539;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x525)) {
      auto _mls_x526 = _mlsValue::cast<_mls_Cons>(_mls_x525)->_mls_head;
      auto _mls_x527 = _mlsValue::cast<_mls_Cons>(_mls_x525)->_mls_tail;
      auto _mls_x528 = (_mls_x522 + _mlsValue::fromIntLit(1));
      auto _mls_x529 = _mls_builtin_floor_mod(_mls_x526, _mls_x528);
      auto _mls_x530 = (_mls_x529 == _mls_x522);
      if (_mlsValue::isIntLit(_mls_x530, 1)) {
        auto _mls_x534 = _mls_uniform(_mls_x524, _mls_x527);
        auto _mls_x535 = _mlsValue::create<_mls_Cons>(_mls_x529, _mls_x534);
        _mls_retval = _mls_x535;
      } else {
        auto _mls_x531 = _mlsValue::create<_mls_Lambda_lambda>();
        auto _mls_x532 = _mls_map(_mls_x531, _mls_x527);
        auto _mls_x533 = _mlsValue::create<_mls_Cons>(_mls_x529, _mls_x532);
        _mls_retval = _mls_x533;
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_f::_mls_apply3(_mlsValue _mls_a, _mlsValue _mls_b, _mlsValue _mls_c) {
  _mlsValue _mls_retval;
  auto _mls_x = _mlsValue::create<_mls_Lambda_g>(_mlsValue(this, _mlsValue::inc_ref_tag{}), _mls_c, _mls_lam_arg0);
  auto _mls_x1 = (_mls_b == _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x1, 1)) {
    _mls_retval = _mls_c;
  } else {
    auto _mls_x2 = _mlsMethodCall<_mls_Callable>(_mls_x)->_mls_apply2(_mls_a, _mls_b);
    _mls_retval = _mls_x2;
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_g::_mls_apply2(_mlsValue _mls_a1, _mlsValue _mls_b1) {
  _mlsValue _mls_retval;
  auto _mls_x3 = _mls_even(_mls_b1);
  if (_mlsValue::isIntLit(_mls_x3, 1)) {
    auto _mls_x8 = (_mls_a1 * _mls_a1);
    auto _mls_x9 = _mls_intMod(_mls_x8, _mls_lam_arg2);
    auto _mls_x10 = _mls_intDiv(_mls_b1, _mlsValue::fromIntLit(2));
    auto _mls_x11 = this->_mls_apply2(_mls_x9, _mls_x10);
    _mls_retval = _mls_x11;
  } else {
    auto _mls_x4 = (_mls_b1 - _mlsValue::fromIntLit(1));
    auto _mls_x5 = (_mls_a1 * _mls_lam_arg1);
    auto _mls_x6 = _mls_intMod(_mls_x5, _mls_lam_arg2);
    auto _mls_x7 = _mlsMethodCall<_mls_Callable>(_mls_lam_arg0)->_mls_apply3(_mls_a1, _mls_x4, _mls_x6);
    _mls_retval = _mls_x7;
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda::_mls_apply1(_mlsValue _mls_x12) {
  _mlsValue _mls_retval;
  auto _mls_x13 = _mls_intMod(_mls_x12, _mlsValue::fromIntLit(65536));
  _mls_retval = _mls_x13;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda1::_mls_apply2(_mlsValue _mls_s1_, _mlsValue _mls_s2_) {
  _mlsValue _mls_retval;
  auto _mls_x14 = _mls_doInput(_mls_s1_, _mls_s2_, _mls_lam_arg0);
  _mls_retval = _mls_x14;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda2::_mls_apply2(_mlsValue _mls_a2, _mlsValue _mls_x17) {
  _mlsValue _mls_retval;
  auto _mls_x15 = (_mls_a2 * _mls_lam_arg0);
  auto _mls_x16 = (_mls_x15 + _mls_x17);
  _mls_retval = _mls_x16;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda3::_mls_apply1(_mlsValue _mls_x19) {
  _mlsValue _mls_retval;
  auto _mls_x18 = (_mls_x19 == _mlsValue::create<_mls_Str>("|"));
  _mls_retval = _mls_x18;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda4::_mls_apply1(_mlsValue _mls_x20) {
  _mlsValue _mls_retval;
  auto _mls_x21 = _mls_singleTestX_square(_mls_x20, _mls_lam_arg0);
  _mls_retval = _mls_x21;
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
