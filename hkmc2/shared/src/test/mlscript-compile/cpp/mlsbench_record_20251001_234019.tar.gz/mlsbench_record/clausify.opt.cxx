#include "mlsprelude.h"
struct _mls_Formula;
struct _mls_Con;
struct _mls_Dis;
struct _mls_Eqv;
struct _mls_Imp;
struct _mls_Lambda_clauses;
struct _mls_Lambda_disp;
struct _mls_Lambda_l;
struct _mls_Lambda_lambda;
struct _mls_Lambda_lscomp;
struct _mls_Lambda_red;
struct _mls_Lambda_uniclHelper;
struct _mls_List;
struct _mls_Cons;
struct _mls_Nil;
struct _mls_Not;
struct _mls_StackFrame;
struct _mls_Ast;
struct _mls_Lex;
struct _mls_Sym;
struct _mls_Tuple2;
_mlsValue _mls_append(_mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper(_mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper_case0_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper_case0_sr_post_case0(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper_case0_sr_post_case1(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper_case0_sr_post_case2(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper_case1_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper_case1_sr_post_case0(_mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper_case2_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper_case2_sr_post_case0(_mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue> _mls_clause_pre(_mlsValue);
_mlsValue _mls_clauses(_mlsValue);
_mlsValue _mls_clauses_caller_post_caller_post(_mlsValue);
_mlsValue _mls_clauses_caller_post_caller_post_caller_post(_mlsValue);
_mlsValue _mls_concat(_mlsValue);
_mlsValue _mls_concat_case0();
_mlsValue _mls_concat_case1(_mlsValue);
_mlsValue _mls_concat_case1_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_conjunct(_mlsValue);
_mlsValue _mls_disin(_mlsValue);
_mlsValue _mls_disin_case0(_mlsValue);
_mlsValue _mls_disin_case01(_mlsValue);
_mlsValue _mls_disin_case0_caller_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_disin_case0_caller_post1(_mlsValue, _mlsValue);
_mlsValue _mls_disin_case0_caller_post2(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_disin_case0_caller_post_caller_post1(_mlsValue, _mlsValue);
_mlsValue _mls_disin_case0_caller_post_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_disin_case0_caller_post_caller_post2(_mlsValue, _mlsValue);
_mlsValue _mls_disin_case0_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_disin_case11(_mlsValue);
_mlsValue _mls_disin_case1(_mlsValue);
_mlsValue _mls_disin_case1_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_disp(_mlsValue);
_mlsValue _mls_disp_caller_post_post(_mlsValue, _mlsValue);
_mlsValue _mls_disp_caller_post_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_disp_caller_post_post_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_disp_caller_post_post_pre(_mlsValue, _mlsValue);
_mlsValue _mls_elim(_mlsValue);
_mlsValue _mls_elim_case0(_mlsValue);
_mlsValue _mls_elim_case0_sr_post(_mlsValue);
_mlsValue _mls_elim_case1(_mlsValue);
_mlsValue _mls_elim_case1_sr_post(_mlsValue);
_mlsValue _mls_elim_case2(_mlsValue);
_mlsValue _mls_elim_case2_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_elim_case3(_mlsValue);
_mlsValue _mls_elim_case3_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_elim_case4(_mlsValue);
_mlsValue _mls_elim_case4_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_elim_case5(_mlsValue);
_mlsValue _mls_elim_case5_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_elim_case5_sr_post_caller_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_elim_case5_sr_post_caller_post_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_foldr(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_inList(_mlsValue, _mlsValue);
_mlsValue _mls_insert(_mlsValue, _mlsValue);
_mlsValue _mls_interleave(_mlsValue, _mlsValue);
_mlsValue _mls_interleave_case0(_mlsValue, _mlsValue);
_mlsValue _mls_interleave_case0_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_interleave_case1();
_mlsValue _mls_listLen(_mlsValue);
_mlsValue _mls_list_to_str(_mlsValue);
_mlsValue _mls_map(_mlsValue, _mlsValue);
_mlsValue _mls_map_case0(_mlsValue, _mlsValue);
_mlsValue _mls_map_case0_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_map_case1();
_mlsValue _mls_negin(_mlsValue);
_mlsValue _mls_negin_case0(_mlsValue);
_mlsValue _mls_negin_case0_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_negin_case0_caller_post1(_mlsValue, _mlsValue);
_mlsValue _mls_negin_case0_caller_post_caller_post1(_mlsValue, _mlsValue);
_mlsValue _mls_negin_case0_caller_post_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_negin_case1_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_negin_case2_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_opri(_mlsValue);
_mlsValue _mls_parse(_mlsValue);
_mlsValue _mls_parseHelper(_mlsValue, _mlsValue);
_mlsValue _mls_parseHelper_case1(_mlsValue, _mlsValue);
_mlsValue _mls_parseHelper_case1_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_parseHelper_case1_sr_post_case1(_mlsValue, _mlsValue);
_mlsValue _mls_parseHelper_case1_sr_post_case2(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_parseHelper_case1_sr_post_case2_case0(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_parseHelper_case1_sr_post_case2_default(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_parseHelper_case1_sr_post_default(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_parseHelper_case1_sr_post_default_case0(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_parseHelper_case1_sr_post_default_default(_mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_parseHelper_case1_sr_post_default_pre(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_parse_caller_post(_mlsValue);
_mlsValue _mls_red(_mlsValue);
_mlsValue _mls_redstar(_mlsValue);
_mlsValue _mls_replicate(_mlsValue, _mlsValue);
_mlsValue _mls_replicate_case0();
_mlsValue _mls_replicate_default(_mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_replicate_pre(_mlsValue, _mlsValue);
_mlsValue _mls_split(_mlsValue);
_mlsValue _mls_splitHelper(_mlsValue, _mlsValue);
_mlsValue _mls_spri(_mlsValue);
_mlsValue _mls_str_to_list(_mlsValue);
_mlsValue _mls_tautclause_case0_sr_post_pre(_mlsValue, _mlsValue);
_mlsValue _mls_testClausify_nofib(_mlsValue);
_mlsValue _mls_testClausify_nofib_caller_post_post(_mlsValue);
_mlsValue _mls_testClausify_nofib_caller_post_post_case0();
_mlsValue _mls_testClausify_nofib_caller_post_post_case1(_mlsValue);
std::tuple<_mlsValue, _mlsValue> _mls_testClausify_nofib_caller_post_pre(_mlsValue);
_mlsValue _mls_unicl(_mlsValue);
_mlsValue _mls_uniclHelper(_mlsValue, _mlsValue);
_mlsValue _mls_uniclHelper_caller_post1(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_uniclHelper_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_while_(_mlsValue, _mlsValue, _mlsValue);
struct _mls_Formula: public _mlsObject {
  
  constexpr static inline const char *typeName = "Formula";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Formula; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Con: public _mls_Formula {
  _mlsValue _mls_a;
  _mlsValue _mls_b;
  constexpr static inline const char *typeName = "Con";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_a.print(); std::printf(", "); this->_mls_b.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_a); _mlsValue::destroy(this->_mls_b);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_a.asObject()->operator==(*other.cast<_mls_Con>()->_mls_a.asObject()) && this->_mls_b.asObject()->operator==(*other.cast<_mls_Con>()->_mls_b.asObject()); }
  static _mlsValue create(_mlsValue _mls_a, _mlsValue _mls_b) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Con; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_a = _mls_a; _mlsVal->_mls_b = _mls_b;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Dis: public _mls_Formula {
  _mlsValue _mls_a;
  _mlsValue _mls_b;
  constexpr static inline const char *typeName = "Dis";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_a.print(); std::printf(", "); this->_mls_b.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_a); _mlsValue::destroy(this->_mls_b);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_a.asObject()->operator==(*other.cast<_mls_Dis>()->_mls_a.asObject()) && this->_mls_b.asObject()->operator==(*other.cast<_mls_Dis>()->_mls_b.asObject()); }
  static _mlsValue create(_mlsValue _mls_a, _mlsValue _mls_b) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Dis; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_a = _mls_a; _mlsVal->_mls_b = _mls_b;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Eqv: public _mls_Formula {
  _mlsValue _mls_a;
  _mlsValue _mls_b;
  constexpr static inline const char *typeName = "Eqv";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_a.print(); std::printf(", "); this->_mls_b.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_a); _mlsValue::destroy(this->_mls_b);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_a.asObject()->operator==(*other.cast<_mls_Eqv>()->_mls_a.asObject()) && this->_mls_b.asObject()->operator==(*other.cast<_mls_Eqv>()->_mls_b.asObject()); }
  static _mlsValue create(_mlsValue _mls_a, _mlsValue _mls_b) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Eqv; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_a = _mls_a; _mlsVal->_mls_b = _mls_b;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Imp: public _mls_Formula {
  _mlsValue _mls_a;
  _mlsValue _mls_b;
  constexpr static inline const char *typeName = "Imp";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_a.print(); std::printf(", "); this->_mls_b.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_a); _mlsValue::destroy(this->_mls_b);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_a.asObject()->operator==(*other.cast<_mls_Imp>()->_mls_a.asObject()) && this->_mls_b.asObject()->operator==(*other.cast<_mls_Imp>()->_mls_b.asObject()); }
  static _mlsValue create(_mlsValue _mls_a, _mlsValue _mls_b) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Imp; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_a = _mls_a; _mlsVal->_mls_b = _mls_b;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Lambda_clauses: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_clauses";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_clauses; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_disp: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_disp";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_disp; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_l: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_l";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_l; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_lambda: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lscomp: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_lscomp";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lscomp>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lscomp; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_red: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_red";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_red; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_uniclHelper: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_uniclHelper";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_uniclHelper; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_List: public _mlsObject {
  
  constexpr static inline const char *typeName = "List";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_List; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Cons: public _mls_List {
  _mlsValue _mls_head;
  _mlsValue _mls_tail;
  constexpr static inline const char *typeName = "Cons";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_head.print(); std::printf(", "); this->_mls_tail.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_head); _mlsValue::destroy(this->_mls_tail);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_head.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_head.asObject()) && this->_mls_tail.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_tail.asObject()); }
  static _mlsValue create(_mlsValue _mls_head, _mlsValue _mls_tail) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Cons; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_head = _mls_head; _mlsVal->_mls_tail = _mls_tail;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Nil: public _mls_List {
  
  constexpr static inline const char *typeName = "Nil";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Nil; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Not: public _mls_Formula {
  _mlsValue _mls_a;
  constexpr static inline const char *typeName = "Not";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_a.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_a);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_a.asObject()->operator==(*other.cast<_mls_Not>()->_mls_a.asObject()); }
  static _mlsValue create(_mlsValue _mls_a) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Not; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_a = _mls_a;  return _mlsValue(_mlsVal); }
  
};
struct _mls_StackFrame: public _mlsObject {
  
  constexpr static inline const char *typeName = "StackFrame";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_StackFrame; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Ast: public _mls_StackFrame {
  _mlsValue _mls_f;
  constexpr static inline const char *typeName = "Ast";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_f.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_f);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_f.asObject()->operator==(*other.cast<_mls_Ast>()->_mls_f.asObject()); }
  static _mlsValue create(_mlsValue _mls_f) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Ast; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_f = _mls_f;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Lex: public _mls_StackFrame {
  _mlsValue _mls_s;
  constexpr static inline const char *typeName = "Lex";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_s.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_s);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_s.asObject()->operator==(*other.cast<_mls_Lex>()->_mls_s.asObject()); }
  static _mlsValue create(_mlsValue _mls_s) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lex; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_s = _mls_s;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Sym: public _mls_Formula {
  _mlsValue _mls_a;
  constexpr static inline const char *typeName = "Sym";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_a.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_a);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_a.asObject()->operator==(*other.cast<_mls_Sym>()->_mls_a.asObject()); }
  static _mlsValue create(_mlsValue _mls_a) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Sym; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_a = _mls_a;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Tuple2: public _mlsObject {
  _mlsValue _mls_field0;
  _mlsValue _mls_field1;
  constexpr static inline const char *typeName = "Tuple2";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_field0.print(); std::printf(", "); this->_mls_field1.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_field0); _mlsValue::destroy(this->_mls_field1);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_field0.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field0.asObject()) && this->_mls_field1.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field1.asObject()); }
  static _mlsValue create(_mlsValue _mls_field0, _mlsValue _mls_field1) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Tuple2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_field0 = _mls_field0; _mlsVal->_mls_field1 = _mls_field1;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_append(_mlsValue _mls_xs, _mlsValue _mls_ys) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs)) {
    _mls_retval = _mls_ys;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs)) {
    auto _mls_x17 = _mlsValue::cast<_mls_Cons>(_mls_xs)->_mls_head;
    auto _mls_x18 = _mlsValue::cast<_mls_Cons>(_mls_xs)->_mls_tail;
    auto _mls_x19 = _mls_append(_mls_x18, _mls_ys);
    auto _mls_x20 = _mlsValue::create<_mls_Cons>(_mls_x17, _mls_x19);
    _mls_retval = _mls_x20;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_clauseHelper(_mlsValue _mls_x387, _mlsValue _mls_x389) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Dis>(_mls_x387)) {
    auto _mls_x391 = _mlsValue::cast<_mls_Dis>(_mls_x387)->_mls_a;
    auto _mls_x392 = _mlsValue::cast<_mls_Dis>(_mls_x387)->_mls_b;
    _mls_retval = _mls_clauseHelper_case0_sr_post(_mls_x392, _mls_x389, _mls_x391);
  } else if (_mlsValue::isValueOf<_mls_Sym>(_mls_x387)) {
    auto _mls_x390 = _mlsValue::cast<_mls_Sym>(_mls_x387)->_mls_a;
    _mls_retval = _mls_clauseHelper_case1_sr_post(_mls_x389, _mls_x390);
  } else if (_mlsValue::isValueOf<_mls_Not>(_mls_x387)) {
    auto _mls_x388 = _mlsValue::cast<_mls_Not>(_mls_x387)->_mls_a;
    _mls_retval = _mls_clauseHelper_case2_sr_post(_mls_x388, _mls_x389);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_clauseHelper_case0_sr_post(_mlsValue _mls_x393, _mlsValue _mls_x394, _mlsValue _mls_x395) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Dis>(_mls_x393)) {
    _mls_retval = _mls_clauseHelper_case0_sr_post_case0(_mls_x393, _mls_x394, _mls_x395);
  } else if (_mlsValue::isValueOf<_mls_Sym>(_mls_x393)) {
    _mls_retval = _mls_clauseHelper_case0_sr_post_case1(_mls_x393, _mls_x394, _mls_x395);
  } else if (_mlsValue::isValueOf<_mls_Not>(_mls_x393)) {
    _mls_retval = _mls_clauseHelper_case0_sr_post_case2(_mls_x393, _mls_x394, _mls_x395);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_clauseHelper_case0_sr_post_case0(_mlsValue _mls_x397, _mlsValue _mls_x399, _mlsValue _mls_x401) {
  _mlsValue _mls_retval;
  auto _mls_x396 = _mlsValue::cast<_mls_Dis>(_mls_x397)->_mls_a;
  auto _mls_x398 = _mlsValue::cast<_mls_Dis>(_mls_x397)->_mls_b;
  auto _mls_x400 = _mls_clauseHelper_case0_sr_post(_mls_x398, _mls_x399, _mls_x396);
  auto _mls_x402 = _mls_clauseHelper(_mls_x401, _mls_x400);
  _mls_retval = _mls_x402;
  return _mls_retval;
}
_mlsValue _mls_clauseHelper_case0_sr_post_case1(_mlsValue _mls_x404, _mlsValue _mls_x405, _mlsValue _mls_x407) {
  _mlsValue _mls_retval;
  auto _mls_x403 = _mlsValue::cast<_mls_Sym>(_mls_x404)->_mls_a;
  auto _mls_x406 = _mls_clauseHelper_case1_sr_post(_mls_x405, _mls_x403);
  auto _mls_x408 = _mls_clauseHelper(_mls_x407, _mls_x406);
  _mls_retval = _mls_x408;
  return _mls_retval;
}
_mlsValue _mls_clauseHelper_case0_sr_post_case2(_mlsValue _mls_x410, _mlsValue _mls_x411, _mlsValue _mls_x413) {
  _mlsValue _mls_retval;
  auto _mls_x409 = _mlsValue::cast<_mls_Not>(_mls_x410)->_mls_a;
  auto _mls_x412 = _mls_clauseHelper_case2_sr_post(_mls_x409, _mls_x411);
  auto _mls_x414 = _mls_clauseHelper(_mls_x413, _mls_x412);
  _mls_retval = _mls_x414;
  return _mls_retval;
}
_mlsValue _mls_clauseHelper_case1_sr_post(_mlsValue _mls_x415, _mlsValue _mls_x416) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x415)) {
    _mls_retval = _mls_clauseHelper_case1_sr_post_case0(_mls_x415, _mls_x416);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_clauseHelper_case1_sr_post_case0(_mlsValue _mls_x418, _mlsValue _mls_x420) {
  _mlsValue _mls_retval;
  auto _mls_x417 = _mlsValue::cast<_mls_Tuple2>(_mls_x418)->_mls_field0;
  auto _mls_x419 = _mlsValue::cast<_mls_Tuple2>(_mls_x418)->_mls_field1;
  auto _mls_x421 = _mls_insert(_mls_x420, _mls_x417);
  auto _mls_x422 = _mlsValue::create<_mls_Tuple2>(_mls_x421, _mls_x419);
  _mls_retval = _mls_x422;
  return _mls_retval;
}
_mlsValue _mls_clauseHelper_case2_sr_post(_mlsValue _mls_x423, _mlsValue _mls_x424) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Sym>(_mls_x423)) {
    _mls_retval = _mls_clauseHelper_case2_sr_post_case0(_mls_x423, _mls_x424);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_clauseHelper_case2_sr_post_case0(_mlsValue _mls_x426, _mlsValue _mls_x427) {
  _mlsValue _mls_retval;
  auto _mls_x425 = _mlsValue::cast<_mls_Sym>(_mls_x426)->_mls_a;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x427)) {
    auto _mls_x428 = _mlsValue::cast<_mls_Tuple2>(_mls_x427)->_mls_field0;
    auto _mls_x429 = _mlsValue::cast<_mls_Tuple2>(_mls_x427)->_mls_field1;
    auto _mls_x430 = _mls_insert(_mls_x425, _mls_x429);
    auto _mls_x431 = _mlsValue::create<_mls_Tuple2>(_mls_x428, _mls_x430);
    _mls_retval = _mls_x431;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue> _mls_clause_pre(_mlsValue _mls_x435) {
  std::tuple<_mlsValue, _mlsValue> _mls_retval;
  auto _mls_x432 = _mlsValue::create<_mls_Nil>();
  auto _mls_x433 = _mlsValue::create<_mls_Nil>();
  auto _mls_x434 = _mlsValue::create<_mls_Tuple2>(_mls_x432, _mls_x433);
  _mls_retval = std::make_tuple(_mls_x435, _mls_x434);
  return _mls_retval;
}
_mlsValue _mls_clauses(_mlsValue _mls_t) {
  _mlsValue _mls_retval;
  auto _mls_x41 = _mls_parse(_mls_t);
  if (_mlsValue::isValueOf<_mls_Sym>(_mls_x41)) {
    auto _mls_x463 = _mlsValue::cast<_mls_Sym>(_mls_x41)->_mls_a;
    auto _mls_x464 = _mls_elim_case0_sr_post(_mls_x463);
    _mls_retval = _mls_clauses_caller_post_caller_post_caller_post(_mls_x464);
  } else if (_mlsValue::isValueOf<_mls_Not>(_mls_x41)) {
    auto _mls_x460 = _mlsValue::cast<_mls_Not>(_mls_x41)->_mls_a;
    auto _mls_x461 = _mls_elim_case1_sr_post(_mls_x460);
    auto _mls_x462 = _mls_negin_case0(_mls_x461);
    _mls_retval = _mls_clauses_caller_post_caller_post(_mls_x462);
  } else if (_mlsValue::isValueOf<_mls_Dis>(_mls_x41)) {
    auto _mls_x454 = _mlsValue::cast<_mls_Dis>(_mls_x41)->_mls_a;
    auto _mls_x455 = _mlsValue::cast<_mls_Dis>(_mls_x41)->_mls_b;
    auto _mls_x456 = _mls_elim_case2_sr_post(_mls_x454, _mls_x455);
    auto _mls_x457 = _mlsValue::cast<_mls_Dis>(_mls_x456)->_mls_a;
    auto _mls_x458 = _mlsValue::cast<_mls_Dis>(_mls_x456)->_mls_b;
    auto _mls_x459 = _mls_negin_case1_sr_post(_mls_x457, _mls_x458);
    _mls_retval = _mls_clauses_caller_post_caller_post(_mls_x459);
  } else if (_mlsValue::isValueOf<_mls_Con>(_mls_x41)) {
    auto _mls_x448 = _mlsValue::cast<_mls_Con>(_mls_x41)->_mls_a;
    auto _mls_x449 = _mlsValue::cast<_mls_Con>(_mls_x41)->_mls_b;
    auto _mls_x450 = _mls_elim_case3_sr_post(_mls_x448, _mls_x449);
    auto _mls_x451 = _mlsValue::cast<_mls_Con>(_mls_x450)->_mls_a;
    auto _mls_x452 = _mlsValue::cast<_mls_Con>(_mls_x450)->_mls_b;
    auto _mls_x453 = _mls_negin_case2_sr_post(_mls_x451, _mls_x452);
    _mls_retval = _mls_clauses_caller_post_caller_post(_mls_x453);
  } else if (_mlsValue::isValueOf<_mls_Imp>(_mls_x41)) {
    auto _mls_x442 = _mlsValue::cast<_mls_Imp>(_mls_x41)->_mls_a;
    auto _mls_x443 = _mlsValue::cast<_mls_Imp>(_mls_x41)->_mls_b;
    auto _mls_x444 = _mls_elim_case4_sr_post(_mls_x442, _mls_x443);
    auto _mls_x445 = _mlsValue::cast<_mls_Dis>(_mls_x444)->_mls_a;
    auto _mls_x446 = _mlsValue::cast<_mls_Dis>(_mls_x444)->_mls_b;
    auto _mls_x447 = _mls_negin_case1_sr_post(_mls_x445, _mls_x446);
    _mls_retval = _mls_clauses_caller_post_caller_post(_mls_x447);
  } else if (_mlsValue::isValueOf<_mls_Eqv>(_mls_x41)) {
    auto _mls_x436 = _mlsValue::cast<_mls_Eqv>(_mls_x41)->_mls_a;
    auto _mls_x437 = _mlsValue::cast<_mls_Eqv>(_mls_x41)->_mls_b;
    auto _mls_x438 = _mls_elim_case5_sr_post(_mls_x436, _mls_x437);
    auto _mls_x439 = _mlsValue::cast<_mls_Con>(_mls_x438)->_mls_a;
    auto _mls_x440 = _mlsValue::cast<_mls_Con>(_mls_x438)->_mls_b;
    auto _mls_x441 = _mls_negin_case2_sr_post(_mls_x439, _mls_x440);
    _mls_retval = _mls_clauses_caller_post_caller_post(_mls_x441);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_clauses_caller_post_caller_post(_mlsValue _mls_x465) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Dis>(_mls_x465)) {
    auto _mls_x467 = _mls_disin_case0(_mls_x465);
    _mls_retval = _mls_clauses_caller_post_caller_post_caller_post(_mls_x467);
  } else if (_mlsValue::isValueOf<_mls_Con>(_mls_x465)) {
    auto _mls_x466 = _mls_disin_case1(_mls_x465);
    _mls_retval = _mls_clauses_caller_post_caller_post_caller_post(_mls_x466);
  } else {
    _mls_retval = _mls_clauses_caller_post_caller_post_caller_post(_mls_x465);
  }
  return _mls_retval;
}
_mlsValue _mls_clauses_caller_post_caller_post_caller_post(_mlsValue _mls_x468) {
  _mlsValue _mls_retval;
  auto _mls_x469 = _mls_split(_mls_x468);
  auto _mls_x470 = _mls_unicl(_mls_x469);
  auto _mls_x471 = _mlsValue::create<_mls_Lambda_disp>();
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x470)) {
    auto _mls_x474 = _mls_map_case0(_mls_x470, _mls_x471);
    auto _mls_x475 = _mls_concat(_mls_x474);
    _mls_retval = _mls_x475;
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x470)) {
    auto _mls_x472 = _mls_map_case1();
    auto _mls_x473 = _mls_concat(_mls_x472);
    _mls_retval = _mls_x473;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_concat(_mlsValue _mls_x476) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x476)) {
    _mls_retval = _mls_concat_case0();
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x476)) {
    auto _mls_x477 = _mlsValue::cast<_mls_Cons>(_mls_x476)->_mls_head;
    auto _mls_x478 = _mlsValue::cast<_mls_Cons>(_mls_x476)->_mls_tail;
    _mls_retval = _mls_concat_case1_sr_post(_mls_x478, _mls_x477);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_concat_case0() {
  _mlsValue _mls_retval;
  auto _mls_x479 = _mlsValue::create<_mls_Nil>();
  _mls_retval = _mls_x479;
  return _mls_retval;
}
_mlsValue _mls_concat_case1(_mlsValue _mls_x481) {
  _mlsValue _mls_retval;
  auto _mls_x480 = _mlsValue::cast<_mls_Cons>(_mls_x481)->_mls_head;
  auto _mls_x482 = _mlsValue::cast<_mls_Cons>(_mls_x481)->_mls_tail;
  _mls_retval = _mls_concat_case1_sr_post(_mls_x482, _mls_x480);
  return _mls_retval;
}
_mlsValue _mls_concat_case1_sr_post(_mlsValue _mls_x483, _mlsValue _mls_x485) {
  _mlsValue _mls_retval;
  auto _mls_x484 = _mls_concat(_mls_x483);
  auto _mls_x486 = _mls_append(_mls_x485, _mls_x484);
  _mls_retval = _mls_x486;
  return _mls_retval;
}
_mlsValue _mls_conjunct(_mlsValue _mls_p2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Con>(_mls_p2)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else {
    _mls_retval = _mlsValue::fromIntLit(0);
  }
  return _mls_retval;
}
_mlsValue _mls_disin(_mlsValue _mls_x487) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Dis>(_mls_x487)) {
    _mls_retval = _mls_disin_case01(_mls_x487);
  } else if (_mlsValue::isValueOf<_mls_Con>(_mls_x487)) {
    _mls_retval = _mls_disin_case11(_mls_x487);
  } else {
    _mls_retval = _mls_x487;
  }
  return _mls_retval;
}
_mlsValue _mls_disin_case0(_mlsValue _mls_x489) {
  _mlsValue _mls_retval;
  auto _mls_x488 = _mlsValue::cast<_mls_Dis>(_mls_x489)->_mls_a;
  auto _mls_x490 = _mlsValue::cast<_mls_Dis>(_mls_x489)->_mls_b;
  _mls_retval = _mls_disin_case0_sr_post(_mls_x490, _mls_x488);
  return _mls_retval;
}
_mlsValue _mls_disin_case01(_mlsValue _mls_x492) {
  _mlsValue _mls_retval;
  auto _mls_x491 = _mlsValue::cast<_mls_Dis>(_mls_x492)->_mls_a;
  auto _mls_x493 = _mlsValue::cast<_mls_Dis>(_mls_x492)->_mls_b;
  _mls_retval = _mls_disin_case0_sr_post(_mls_x493, _mls_x491);
  return _mls_retval;
}
_mlsValue _mls_disin_case0_caller_post(_mlsValue _mls_x495, _mlsValue _mls_x496, _mlsValue _mls_x498) {
  _mlsValue _mls_retval;
  auto _mls_x494 = _mlsValue::create<_mls_Dis>(_mls_x495, _mls_x496);
  auto _mls_x497 = _mls_disin_case01(_mls_x494);
  _mls_retval = _mls_disin_case0_caller_post_caller_post(_mls_x498, _mls_x497);
  return _mls_retval;
}
_mlsValue _mls_disin_case0_caller_post1(_mlsValue _mls_x499, _mlsValue _mls_x500) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Dis>(_mls_x499)) {
    auto _mls_x502 = _mls_disin_case01(_mls_x499);
    _mls_retval = _mls_disin_case0_caller_post_caller_post1(_mls_x500, _mls_x502);
  } else if (_mlsValue::isValueOf<_mls_Con>(_mls_x499)) {
    auto _mls_x501 = _mls_disin_case11(_mls_x499);
    _mls_retval = _mls_disin_case0_caller_post_caller_post1(_mls_x500, _mls_x501);
  } else {
    _mls_retval = _mls_disin_case0_caller_post_caller_post1(_mls_x500, _mls_x499);
  }
  return _mls_retval;
}
_mlsValue _mls_disin_case0_caller_post2(_mlsValue _mls_x504, _mlsValue _mls_x505, _mlsValue _mls_x507) {
  _mlsValue _mls_retval;
  auto _mls_x503 = _mlsValue::create<_mls_Dis>(_mls_x504, _mls_x505);
  auto _mls_x506 = _mls_disin_case01(_mls_x503);
  _mls_retval = _mls_disin_case0_caller_post_caller_post2(_mls_x507, _mls_x506);
  return _mls_retval;
}
_mlsValue _mls_disin_case0_caller_post_caller_post1(_mlsValue _mls_x508, _mlsValue _mls_x510) {
  _mlsValue _mls_retval;
  auto _mls_x509 = _mls_conjunct(_mls_x508);
  auto _mls_x511 = _mls_conjunct(_mls_x510);
  auto _mls_x512 = (_mls_x509 || _mls_x511);
  if (_mlsValue::isIntLit(_mls_x512, 1)) {
    auto _mls_x514 = _mlsValue::create<_mls_Dis>(_mls_x508, _mls_x510);
    auto _mls_x515 = _mls_disin(_mls_x514);
    _mls_retval = _mls_x515;
  } else {
    auto _mls_x513 = _mlsValue::create<_mls_Dis>(_mls_x508, _mls_x510);
    _mls_retval = _mls_x513;
  }
  return _mls_retval;
}
_mlsValue _mls_disin_case0_caller_post_caller_post(_mlsValue _mls_x517, _mlsValue _mls_x518) {
  _mlsValue _mls_retval;
  auto _mls_x516 = _mlsValue::create<_mls_Con>(_mls_x517, _mls_x518);
  _mls_retval = _mls_x516;
  return _mls_retval;
}
_mlsValue _mls_disin_case0_caller_post_caller_post2(_mlsValue _mls_x520, _mlsValue _mls_x521) {
  _mlsValue _mls_retval;
  auto _mls_x519 = _mlsValue::create<_mls_Con>(_mls_x520, _mls_x521);
  _mls_retval = _mls_x519;
  return _mls_retval;
}
_mlsValue _mls_disin_case0_sr_post(_mlsValue _mls_x522, _mlsValue _mls_x523) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Con>(_mls_x522)) {
    auto _mls_x530 = _mlsValue::cast<_mls_Con>(_mls_x522)->_mls_a;
    auto _mls_x531 = _mlsValue::cast<_mls_Con>(_mls_x522)->_mls_b;
    auto _mls_x532 = _mlsValue::create<_mls_Dis>(_mls_x523, _mls_x530);
    auto _mls_x533 = _mls_disin_case0(_mls_x532);
    _mls_retval = _mls_disin_case0_caller_post(_mls_x523, _mls_x531, _mls_x533);
  } else {
    if (_mlsValue::isValueOf<_mls_Con>(_mls_x523)) {
      auto _mls_x526 = _mlsValue::cast<_mls_Con>(_mls_x523)->_mls_a;
      auto _mls_x527 = _mlsValue::cast<_mls_Con>(_mls_x523)->_mls_b;
      auto _mls_x528 = _mlsValue::create<_mls_Dis>(_mls_x526, _mls_x522);
      auto _mls_x529 = _mls_disin_case0(_mls_x528);
      _mls_retval = _mls_disin_case0_caller_post2(_mls_x527, _mls_x522, _mls_x529);
    } else {
      if (_mlsValue::isValueOf<_mls_Dis>(_mls_x523)) {
        auto _mls_x525 = _mls_disin_case0(_mls_x523);
        _mls_retval = _mls_disin_case0_caller_post1(_mls_x522, _mls_x525);
      } else if (_mlsValue::isValueOf<_mls_Con>(_mls_x523)) {
        auto _mls_x524 = _mls_disin_case1(_mls_x523);
        _mls_retval = _mls_disin_case0_caller_post1(_mls_x522, _mls_x524);
      } else {
        _mls_retval = _mls_disin_case0_caller_post1(_mls_x522, _mls_x523);
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_disin_case11(_mlsValue _mls_x535) {
  _mlsValue _mls_retval;
  auto _mls_x534 = _mlsValue::cast<_mls_Con>(_mls_x535)->_mls_a;
  auto _mls_x536 = _mlsValue::cast<_mls_Con>(_mls_x535)->_mls_b;
  _mls_retval = _mls_disin_case1_sr_post(_mls_x534, _mls_x536);
  return _mls_retval;
}
_mlsValue _mls_disin_case1(_mlsValue _mls_x538) {
  _mlsValue _mls_retval;
  auto _mls_x537 = _mlsValue::cast<_mls_Con>(_mls_x538)->_mls_a;
  auto _mls_x539 = _mlsValue::cast<_mls_Con>(_mls_x538)->_mls_b;
  _mls_retval = _mls_disin_case1_sr_post(_mls_x537, _mls_x539);
  return _mls_retval;
}
_mlsValue _mls_disin_case1_sr_post(_mlsValue _mls_x540, _mlsValue _mls_x542) {
  _mlsValue _mls_retval;
  auto _mls_x541 = _mls_disin(_mls_x540);
  auto _mls_x543 = _mls_disin(_mls_x542);
  auto _mls_x544 = _mlsValue::create<_mls_Con>(_mls_x541, _mls_x543);
  _mls_retval = _mls_x544;
  return _mls_retval;
}
_mlsValue _mls_disp(_mlsValue _mls_l_r) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_l_r)) {
    auto _mls_x84 = _mlsValue::cast<_mls_Tuple2>(_mls_l_r)->_mls_field0;
    auto _mls_x85 = _mlsValue::cast<_mls_Tuple2>(_mls_l_r)->_mls_field1;
    auto _mls_x86 = _mls_listLen(_mls_x84);
    auto [_mls_x545, _mls_x546, _mls_x547] = _mls_replicate_pre(_mls_x86, _mlsValue::create<_mls_Str>(" "));
    if (_mlsValue::isIntLit(_mls_x545, 1)) {
      auto _mls_x561 = _mls_replicate_case0();
      if (_mlsValue::isValueOf<_mls_Cons>(_mls_x84)) {
        auto _mls_x571 = _mlsValue::cast<_mls_Cons>(_mls_x84)->_mls_head;
        auto _mls_x572 = _mlsValue::cast<_mls_Cons>(_mls_x84)->_mls_tail;
        auto _mls_x573 = _mls_interleave_case0_sr_post(_mls_x561, _mls_x572, _mls_x571);
        _mls_retval = _mls_disp_caller_post_post(_mls_x85, _mls_x573);
      } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x84)) {
        auto _mls_x562 = _mls_interleave_case1();
        auto [_mls_x563, _mls_x564, _mls_x565, _mls_x566, _mls_x567, _mls_x568] = _mls_disp_caller_post_post_pre(_mls_x85, _mls_x562);
        if (_mlsValue::isIntLit(_mls_x566, 1)) {
          auto _mls_x570 = _mls_replicate_case0();
          _mls_retval = _mls_disp_caller_post_post_caller_post(_mls_x570, _mls_x568, _mls_x565, _mls_x567);
        } else {
          auto _mls_x569 = _mls_replicate_default(_mls_x564, _mls_x563);
          _mls_retval = _mls_disp_caller_post_post_caller_post(_mls_x569, _mls_x568, _mls_x565, _mls_x567);
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      auto _mls_x548 = _mls_replicate_default(_mls_x546, _mls_x547);
      if (_mlsValue::isValueOf<_mls_Cons>(_mls_x84)) {
        auto _mls_x558 = _mlsValue::cast<_mls_Cons>(_mls_x84)->_mls_head;
        auto _mls_x559 = _mlsValue::cast<_mls_Cons>(_mls_x84)->_mls_tail;
        auto _mls_x560 = _mls_interleave_case0_sr_post(_mls_x548, _mls_x559, _mls_x558);
        _mls_retval = _mls_disp_caller_post_post(_mls_x85, _mls_x560);
      } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x84)) {
        auto _mls_x549 = _mls_interleave_case1();
        auto [_mls_x550, _mls_x551, _mls_x552, _mls_x553, _mls_x554, _mls_x555] = _mls_disp_caller_post_post_pre(_mls_x85, _mls_x549);
        if (_mlsValue::isIntLit(_mls_x553, 1)) {
          auto _mls_x557 = _mls_replicate_case0();
          _mls_retval = _mls_disp_caller_post_post_caller_post(_mls_x557, _mls_x555, _mls_x552, _mls_x554);
        } else {
          auto _mls_x556 = _mls_replicate_default(_mls_x551, _mls_x550);
          _mls_retval = _mls_disp_caller_post_post_caller_post(_mls_x556, _mls_x555, _mls_x552, _mls_x554);
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_disp_caller_post_post(_mlsValue _mls_x574, _mlsValue _mls_x575) {
  _mlsValue _mls_retval;
  auto [_mls_x576, _mls_x577, _mls_x578, _mls_x579, _mls_x580, _mls_x581] = _mls_disp_caller_post_post_pre(_mls_x574, _mls_x575);
  if (_mlsValue::isIntLit(_mls_x579, 1)) {
    auto _mls_x583 = _mls_replicate_case0();
    _mls_retval = _mls_disp_caller_post_post_caller_post(_mls_x583, _mls_x581, _mls_x578, _mls_x580);
  } else {
    auto _mls_x582 = _mls_replicate_default(_mls_x577, _mls_x576);
    _mls_retval = _mls_disp_caller_post_post_caller_post(_mls_x582, _mls_x581, _mls_x578, _mls_x580);
  }
  return _mls_retval;
}
_mlsValue _mls_disp_caller_post_post_caller_post(_mlsValue _mls_x584, _mlsValue _mls_x588, _mlsValue _mls_x586, _mlsValue _mls_x587) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x584)) {
    auto _mls_x589 = _mls_interleave_case0(_mls_x584, _mls_x588);
    _mls_retval = _mls_disp_caller_post_post_caller_post_caller_post(_mls_x589, _mls_x586, _mls_x587);
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x584)) {
    auto _mls_x585 = _mls_interleave_case1();
    _mls_retval = _mls_disp_caller_post_post_caller_post_caller_post(_mls_x585, _mls_x586, _mls_x587);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_disp_caller_post_post_caller_post_caller_post(_mlsValue _mls_x591, _mlsValue _mls_x593, _mlsValue _mls_x595) {
  _mlsValue _mls_retval;
  auto _mls_x590 = _mls_str_to_list(_mlsValue::create<_mls_Str>("\n"));
  auto _mls_x592 = _mls_append(_mls_x591, _mls_x590);
  auto _mls_x594 = _mls_append(_mls_x593, _mls_x592);
  auto _mls_x596 = _mls_append(_mls_x595, _mls_x594);
  _mls_retval = _mls_x596;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_disp_caller_post_post_pre(_mlsValue _mls_x598, _mlsValue _mls_x603) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x597 = _mls_str_to_list(_mlsValue::create<_mls_Str>("<="));
  auto _mls_x599 = _mls_listLen(_mls_x598);
  auto [_mls_x600, _mls_x601, _mls_x602] = _mls_replicate_pre(_mls_x599, _mlsValue::create<_mls_Str>(" "));
  _mls_retval = std::make_tuple(_mls_x602, _mls_x601, _mls_x597, _mls_x600, _mls_x603, _mls_x598);
  return _mls_retval;
}
_mlsValue _mls_elim(_mlsValue _mls_x604) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Sym>(_mls_x604)) {
    _mls_retval = _mls_elim_case0(_mls_x604);
  } else if (_mlsValue::isValueOf<_mls_Not>(_mls_x604)) {
    _mls_retval = _mls_elim_case1(_mls_x604);
  } else if (_mlsValue::isValueOf<_mls_Dis>(_mls_x604)) {
    _mls_retval = _mls_elim_case2(_mls_x604);
  } else if (_mlsValue::isValueOf<_mls_Con>(_mls_x604)) {
    _mls_retval = _mls_elim_case3(_mls_x604);
  } else if (_mlsValue::isValueOf<_mls_Imp>(_mls_x604)) {
    _mls_retval = _mls_elim_case4(_mls_x604);
  } else if (_mlsValue::isValueOf<_mls_Eqv>(_mls_x604)) {
    _mls_retval = _mls_elim_case5(_mls_x604);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_elim_case0(_mlsValue _mls_x606) {
  _mlsValue _mls_retval;
  auto _mls_x605 = _mlsValue::cast<_mls_Sym>(_mls_x606)->_mls_a;
  _mls_retval = _mls_elim_case0_sr_post(_mls_x605);
  return _mls_retval;
}
_mlsValue _mls_elim_case0_sr_post(_mlsValue _mls_x608) {
  _mlsValue _mls_retval;
  auto _mls_x607 = _mlsValue::create<_mls_Sym>(_mls_x608);
  _mls_retval = _mls_x607;
  return _mls_retval;
}
_mlsValue _mls_elim_case1(_mlsValue _mls_x610) {
  _mlsValue _mls_retval;
  auto _mls_x609 = _mlsValue::cast<_mls_Not>(_mls_x610)->_mls_a;
  _mls_retval = _mls_elim_case1_sr_post(_mls_x609);
  return _mls_retval;
}
_mlsValue _mls_elim_case1_sr_post(_mlsValue _mls_x611) {
  _mlsValue _mls_retval;
  auto _mls_x612 = _mls_elim(_mls_x611);
  auto _mls_x613 = _mlsValue::create<_mls_Not>(_mls_x612);
  _mls_retval = _mls_x613;
  return _mls_retval;
}
_mlsValue _mls_elim_case2(_mlsValue _mls_x615) {
  _mlsValue _mls_retval;
  auto _mls_x614 = _mlsValue::cast<_mls_Dis>(_mls_x615)->_mls_a;
  auto _mls_x616 = _mlsValue::cast<_mls_Dis>(_mls_x615)->_mls_b;
  _mls_retval = _mls_elim_case2_sr_post(_mls_x614, _mls_x616);
  return _mls_retval;
}
_mlsValue _mls_elim_case2_sr_post(_mlsValue _mls_x617, _mlsValue _mls_x619) {
  _mlsValue _mls_retval;
  auto _mls_x618 = _mls_elim(_mls_x617);
  auto _mls_x620 = _mls_elim(_mls_x619);
  auto _mls_x621 = _mlsValue::create<_mls_Dis>(_mls_x618, _mls_x620);
  _mls_retval = _mls_x621;
  return _mls_retval;
}
_mlsValue _mls_elim_case3(_mlsValue _mls_x623) {
  _mlsValue _mls_retval;
  auto _mls_x622 = _mlsValue::cast<_mls_Con>(_mls_x623)->_mls_a;
  auto _mls_x624 = _mlsValue::cast<_mls_Con>(_mls_x623)->_mls_b;
  _mls_retval = _mls_elim_case3_sr_post(_mls_x622, _mls_x624);
  return _mls_retval;
}
_mlsValue _mls_elim_case3_sr_post(_mlsValue _mls_x625, _mlsValue _mls_x627) {
  _mlsValue _mls_retval;
  auto _mls_x626 = _mls_elim(_mls_x625);
  auto _mls_x628 = _mls_elim(_mls_x627);
  auto _mls_x629 = _mlsValue::create<_mls_Con>(_mls_x626, _mls_x628);
  _mls_retval = _mls_x629;
  return _mls_retval;
}
_mlsValue _mls_elim_case4(_mlsValue _mls_x631) {
  _mlsValue _mls_retval;
  auto _mls_x630 = _mlsValue::cast<_mls_Imp>(_mls_x631)->_mls_a;
  auto _mls_x632 = _mlsValue::cast<_mls_Imp>(_mls_x631)->_mls_b;
  _mls_retval = _mls_elim_case4_sr_post(_mls_x630, _mls_x632);
  return _mls_retval;
}
_mlsValue _mls_elim_case4_sr_post(_mlsValue _mls_x633, _mlsValue _mls_x636) {
  _mlsValue _mls_retval;
  auto _mls_x634 = _mls_elim(_mls_x633);
  auto _mls_x635 = _mlsValue::create<_mls_Not>(_mls_x634);
  auto _mls_x637 = _mls_elim(_mls_x636);
  auto _mls_x638 = _mlsValue::create<_mls_Dis>(_mls_x635, _mls_x637);
  _mls_retval = _mls_x638;
  return _mls_retval;
}
_mlsValue _mls_elim_case5(_mlsValue _mls_x640) {
  _mlsValue _mls_retval;
  auto _mls_x639 = _mlsValue::cast<_mls_Eqv>(_mls_x640)->_mls_a;
  auto _mls_x641 = _mlsValue::cast<_mls_Eqv>(_mls_x640)->_mls_b;
  auto _mls_x642 = _mls_elim_case4_sr_post(_mls_x639, _mls_x641);
  _mls_retval = _mls_elim_case5_sr_post_caller_post(_mls_x641, _mls_x639, _mls_x642);
  return _mls_retval;
}
_mlsValue _mls_elim_case5_sr_post(_mlsValue _mls_x643, _mlsValue _mls_x644) {
  _mlsValue _mls_retval;
  auto _mls_x645 = _mls_elim_case4_sr_post(_mls_x643, _mls_x644);
  _mls_retval = _mls_elim_case5_sr_post_caller_post(_mls_x644, _mls_x643, _mls_x645);
  return _mls_retval;
}
_mlsValue _mls_elim_case5_sr_post_caller_post(_mlsValue _mls_x647, _mlsValue _mls_x648, _mlsValue _mls_x650) {
  _mlsValue _mls_retval;
  auto _mls_x646 = _mlsValue::create<_mls_Imp>(_mls_x647, _mls_x648);
  auto _mls_x649 = _mls_elim_case4(_mls_x646);
  _mls_retval = _mls_elim_case5_sr_post_caller_post_caller_post(_mls_x650, _mls_x649);
  return _mls_retval;
}
_mlsValue _mls_elim_case5_sr_post_caller_post_caller_post(_mlsValue _mls_x652, _mlsValue _mls_x653) {
  _mlsValue _mls_retval;
  auto _mls_x651 = _mlsValue::create<_mls_Con>(_mls_x652, _mls_x653);
  _mls_retval = _mls_x651;
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x125 = _mls_testClausify_nofib(_mlsValue::fromIntLit(200));
  _mls_retval = _mls_x125;
  return _mls_retval;
}
_mlsValue _mls_foldr(_mlsValue _mls_f1, _mlsValue _mls_z, _mlsValue _mls_xs1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs1)) {
    _mls_retval = _mls_z;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs1)) {
    auto _mls_x126 = _mlsValue::cast<_mls_Cons>(_mls_xs1)->_mls_head;
    auto _mls_x127 = _mlsValue::cast<_mls_Cons>(_mls_xs1)->_mls_tail;
    auto _mls_x128 = _mls_foldr(_mls_f1, _mls_z, _mls_x127);
    auto _mls_x129 = _mlsMethodCall<_mls_Callable>(_mls_f1)->_mls_apply2(_mls_x126, _mls_x128);
    _mls_retval = _mls_x129;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_inList(_mlsValue _mls_x133, _mlsValue _mls_ls3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls3)) {
    auto _mls_x130 = _mlsValue::cast<_mls_Cons>(_mls_ls3)->_mls_head;
    auto _mls_x131 = _mlsValue::cast<_mls_Cons>(_mls_ls3)->_mls_tail;
    auto _mls_x132 = (_mls_x133 == _mls_x130);
    if (_mlsValue::isIntLit(_mls_x132, 1)) {
      _mls_retval = _mlsValue::fromIntLit(1);
    } else {
      auto _mls_x134 = _mls_inList(_mls_x133, _mls_x131);
      _mls_retval = _mls_x134;
    }
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls3)) {
    _mls_retval = _mlsValue::fromIntLit(0);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_insert(_mlsValue _mls_x138, _mlsValue _mls_ys1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ys1)) {
    auto _mls_x145 = _mlsValue::create<_mls_Nil>();
    auto _mls_x146 = _mlsValue::create<_mls_Cons>(_mls_x138, _mls_x145);
    _mls_retval = _mls_x146;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ys1)) {
    auto _mls_x135 = _mlsValue::cast<_mls_Cons>(_mls_ys1)->_mls_head;
    auto _mls_x136 = _mlsValue::cast<_mls_Cons>(_mls_ys1)->_mls_tail;
    auto _mls_x654 = _mls_builtin_str_lt(_mls_x138, _mls_x135);
    if (_mlsValue::isIntLit(_mls_x654, 1)) {
      auto _mls_x143 = _mlsValue::create<_mls_Cons>(_mls_x135, _mls_x136);
      auto _mls_x144 = _mlsValue::create<_mls_Cons>(_mls_x138, _mls_x143);
      _mls_retval = _mls_x144;
    } else {
      auto _mls_x655 = _mls_builtin_str_gt(_mls_x138, _mls_x135);
      if (_mlsValue::isIntLit(_mls_x655, 1)) {
        auto _mls_x141 = _mls_insert(_mls_x138, _mls_x136);
        auto _mls_x142 = _mlsValue::create<_mls_Cons>(_mls_x135, _mls_x141);
        _mls_retval = _mls_x142;
      } else {
        auto _mls_x140 = _mlsValue::create<_mls_Cons>(_mls_x135, _mls_x136);
        _mls_retval = _mls_x140;
      }
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_interleave(_mlsValue _mls_x656, _mlsValue _mls_x657) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x656)) {
    _mls_retval = _mls_interleave_case0(_mls_x656, _mls_x657);
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x656)) {
    _mls_retval = _mls_interleave_case1();
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_interleave_case0(_mlsValue _mls_x659, _mlsValue _mls_x661) {
  _mlsValue _mls_retval;
  auto _mls_x658 = _mlsValue::cast<_mls_Cons>(_mls_x659)->_mls_head;
  auto _mls_x660 = _mlsValue::cast<_mls_Cons>(_mls_x659)->_mls_tail;
  _mls_retval = _mls_interleave_case0_sr_post(_mls_x661, _mls_x660, _mls_x658);
  return _mls_retval;
}
_mlsValue _mls_interleave_case0_sr_post(_mlsValue _mls_x662, _mlsValue _mls_x663, _mlsValue _mls_x666) {
  _mlsValue _mls_retval;
  auto _mls_x664 = _mls_interleave(_mls_x662, _mls_x663);
  auto _mls_x665 = _mlsValue::create<_mls_Cons>(_mls_x666, _mls_x664);
  _mls_retval = _mls_x665;
  return _mls_retval;
}
_mlsValue _mls_interleave_case1() {
  _mlsValue _mls_retval;
  auto _mls_x667 = _mlsValue::create<_mls_Nil>();
  _mls_retval = _mls_x667;
  return _mls_retval;
}
_mlsValue _mls_listLen(_mlsValue _mls_ls4) {
  _mlsValue _mls_retval;
  auto _mls_x152 = _mlsValue::create<_mls_Lambda_l>();
  auto _mls_x153 = _mlsMethodCall<_mls_Callable>(_mls_x152)->_mls_apply2(_mls_ls4, _mlsValue::fromIntLit(0));
  _mls_retval = _mls_x153;
  return _mls_retval;
}
_mlsValue _mls_list_to_str(_mlsValue _mls_xs4) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs4)) {
    _mls_retval = _mlsValue::create<_mls_Str>("");
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs4)) {
    auto _mls_x160 = _mlsValue::cast<_mls_Cons>(_mls_xs4)->_mls_head;
    auto _mls_x161 = _mlsValue::cast<_mls_Cons>(_mls_xs4)->_mls_tail;
    auto _mls_x162 = _mls_list_to_str(_mls_x161);
    auto _mls_x668 = _mls_builtin_str_concat(_mls_x160, _mls_x162);
    _mls_retval = _mls_x668;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_map(_mlsValue _mls_x670, _mlsValue _mls_x669) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x669)) {
    _mls_retval = _mls_map_case0(_mls_x669, _mls_x670);
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x669)) {
    _mls_retval = _mls_map_case1();
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_map_case0(_mlsValue _mls_x672, _mlsValue _mls_x674) {
  _mlsValue _mls_retval;
  auto _mls_x671 = _mlsValue::cast<_mls_Cons>(_mls_x672)->_mls_head;
  auto _mls_x673 = _mlsValue::cast<_mls_Cons>(_mls_x672)->_mls_tail;
  _mls_retval = _mls_map_case0_sr_post(_mls_x674, _mls_x671, _mls_x673);
  return _mls_retval;
}
_mlsValue _mls_map_case0_sr_post(_mlsValue _mls_x675, _mlsValue _mls_x676, _mlsValue _mls_x678) {
  _mlsValue _mls_retval;
  auto _mls_x677 = _mlsMethodCall<_mls_Callable>(_mls_x675)->_mls_apply1(_mls_x676);
  auto _mls_x679 = _mls_map(_mls_x675, _mls_x678);
  auto _mls_x680 = _mlsValue::create<_mls_Cons>(_mls_x677, _mls_x679);
  _mls_retval = _mls_x680;
  return _mls_retval;
}
_mlsValue _mls_map_case1() {
  _mlsValue _mls_retval;
  auto _mls_x681 = _mlsValue::create<_mls_Nil>();
  _mls_retval = _mls_x681;
  return _mls_retval;
}
_mlsValue _mls_negin(_mlsValue _mls_x682) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Not>(_mls_x682)) {
    _mls_retval = _mls_negin_case0(_mls_x682);
  } else if (_mlsValue::isValueOf<_mls_Dis>(_mls_x682)) {
    auto _mls_x685 = _mlsValue::cast<_mls_Dis>(_mls_x682)->_mls_a;
    auto _mls_x686 = _mlsValue::cast<_mls_Dis>(_mls_x682)->_mls_b;
    _mls_retval = _mls_negin_case1_sr_post(_mls_x685, _mls_x686);
  } else if (_mlsValue::isValueOf<_mls_Con>(_mls_x682)) {
    auto _mls_x683 = _mlsValue::cast<_mls_Con>(_mls_x682)->_mls_a;
    auto _mls_x684 = _mlsValue::cast<_mls_Con>(_mls_x682)->_mls_b;
    _mls_retval = _mls_negin_case2_sr_post(_mls_x683, _mls_x684);
  } else {
    _mls_retval = _mls_x682;
  }
  return _mls_retval;
}
_mlsValue _mls_negin_case0(_mlsValue _mls_x688) {
  _mlsValue _mls_retval;
  auto _mls_x687 = _mlsValue::cast<_mls_Not>(_mls_x688)->_mls_a;
  if (_mlsValue::isValueOf<_mls_Not>(_mls_x687)) {
    auto _mls_x697 = _mlsValue::cast<_mls_Not>(_mls_x687)->_mls_a;
    auto _mls_x698 = _mls_negin(_mls_x697);
    _mls_retval = _mls_x698;
  } else if (_mlsValue::isValueOf<_mls_Con>(_mls_x687)) {
    auto _mls_x693 = _mlsValue::cast<_mls_Con>(_mls_x687)->_mls_a;
    auto _mls_x694 = _mlsValue::cast<_mls_Con>(_mls_x687)->_mls_b;
    auto _mls_x695 = _mlsValue::create<_mls_Not>(_mls_x693);
    auto _mls_x696 = _mls_negin_case0(_mls_x695);
    _mls_retval = _mls_negin_case0_caller_post1(_mls_x694, _mls_x696);
  } else if (_mlsValue::isValueOf<_mls_Dis>(_mls_x687)) {
    auto _mls_x689 = _mlsValue::cast<_mls_Dis>(_mls_x687)->_mls_a;
    auto _mls_x690 = _mlsValue::cast<_mls_Dis>(_mls_x687)->_mls_b;
    auto _mls_x691 = _mlsValue::create<_mls_Not>(_mls_x689);
    auto _mls_x692 = _mls_negin_case0(_mls_x691);
    _mls_retval = _mls_negin_case0_caller_post(_mls_x690, _mls_x692);
  } else {
    _mls_retval = _mls_x688;
  }
  return _mls_retval;
}
_mlsValue _mls_negin_case0_caller_post(_mlsValue _mls_x700, _mlsValue _mls_x702) {
  _mlsValue _mls_retval;
  auto _mls_x699 = _mlsValue::create<_mls_Not>(_mls_x700);
  auto _mls_x701 = _mls_negin_case0(_mls_x699);
  _mls_retval = _mls_negin_case0_caller_post_caller_post(_mls_x702, _mls_x701);
  return _mls_retval;
}
_mlsValue _mls_negin_case0_caller_post1(_mlsValue _mls_x704, _mlsValue _mls_x706) {
  _mlsValue _mls_retval;
  auto _mls_x703 = _mlsValue::create<_mls_Not>(_mls_x704);
  auto _mls_x705 = _mls_negin_case0(_mls_x703);
  _mls_retval = _mls_negin_case0_caller_post_caller_post1(_mls_x706, _mls_x705);
  return _mls_retval;
}
_mlsValue _mls_negin_case0_caller_post_caller_post1(_mlsValue _mls_x708, _mlsValue _mls_x709) {
  _mlsValue _mls_retval;
  auto _mls_x707 = _mlsValue::create<_mls_Dis>(_mls_x708, _mls_x709);
  _mls_retval = _mls_x707;
  return _mls_retval;
}
_mlsValue _mls_negin_case0_caller_post_caller_post(_mlsValue _mls_x711, _mlsValue _mls_x712) {
  _mlsValue _mls_retval;
  auto _mls_x710 = _mlsValue::create<_mls_Con>(_mls_x711, _mls_x712);
  _mls_retval = _mls_x710;
  return _mls_retval;
}
_mlsValue _mls_negin_case1_sr_post(_mlsValue _mls_x713, _mlsValue _mls_x715) {
  _mlsValue _mls_retval;
  auto _mls_x714 = _mls_negin(_mls_x713);
  auto _mls_x716 = _mls_negin(_mls_x715);
  auto _mls_x717 = _mlsValue::create<_mls_Dis>(_mls_x714, _mls_x716);
  _mls_retval = _mls_x717;
  return _mls_retval;
}
_mlsValue _mls_negin_case2_sr_post(_mlsValue _mls_x718, _mlsValue _mls_x720) {
  _mlsValue _mls_retval;
  auto _mls_x719 = _mls_negin(_mls_x718);
  auto _mls_x721 = _mls_negin(_mls_x720);
  auto _mls_x722 = _mlsValue::create<_mls_Con>(_mls_x719, _mls_x721);
  _mls_retval = _mls_x722;
  return _mls_retval;
}
_mlsValue _mls_opri(_mlsValue _mls_c) {
  _mlsValue _mls_retval;
  auto _mls_x197 = (_mls_c == _mlsValue::create<_mls_Str>("("));
  if (_mlsValue::isIntLit(_mls_x197, 1)) {
    _mls_retval = _mlsValue::fromIntLit(0);
  } else {
    auto _mls_x198 = (_mls_c == _mlsValue::create<_mls_Str>("="));
    if (_mlsValue::isIntLit(_mls_x198, 1)) {
      _mls_retval = _mlsValue::fromIntLit(1);
    } else {
      auto _mls_x199 = (_mls_c == _mlsValue::create<_mls_Str>(">"));
      if (_mlsValue::isIntLit(_mls_x199, 1)) {
        _mls_retval = _mlsValue::fromIntLit(2);
      } else {
        auto _mls_x200 = (_mls_c == _mlsValue::create<_mls_Str>("|"));
        if (_mlsValue::isIntLit(_mls_x200, 1)) {
          _mls_retval = _mlsValue::fromIntLit(3);
        } else {
          auto _mls_x201 = (_mls_c == _mlsValue::create<_mls_Str>("&"));
          if (_mlsValue::isIntLit(_mls_x201, 1)) {
            _mls_retval = _mlsValue::fromIntLit(4);
          } else {
            auto _mls_x202 = (_mls_c == _mlsValue::create<_mls_Str>("~"));
            if (_mlsValue::isIntLit(_mls_x202, 1)) {
              _mls_retval = _mlsValue::fromIntLit(5);
            } else {
              _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
            }
          }
        }
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_parse(_mlsValue _mls_t1) {
  _mlsValue _mls_retval;
  auto _mls_x203 = _mlsValue::create<_mls_Nil>();
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_t1)) {
    auto _mls_x737 = _mls_redstar(_mls_x203);
    _mls_retval = _mls_parse_caller_post(_mls_x737);
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_t1)) {
    auto _mls_x723 = _mlsValue::cast<_mls_Cons>(_mls_t1)->_mls_head;
    auto _mls_x724 = _mlsValue::cast<_mls_Cons>(_mls_t1)->_mls_tail;
    if (_mls_Str::isStrLit(_mls_x723, " ")) {
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x724)) {
        auto _mls_x736 = _mls_redstar(_mls_x203);
        _mls_retval = _mls_parse_caller_post(_mls_x736);
      } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x724)) {
        auto _mls_x735 = _mls_parseHelper_case1(_mls_x724, _mls_x203);
        _mls_retval = _mls_parse_caller_post(_mls_x735);
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else if (_mls_Str::isStrLit(_mls_x723, "(")) {
      auto _mls_x734 = _mls_parseHelper_case1_sr_post_case1(_mls_x203, _mls_x724);
      _mls_retval = _mls_parse_caller_post(_mls_x734);
    } else if (_mls_Str::isStrLit(_mls_x723, ")")) {
      auto _mls_x731 = _mls_redstar(_mls_x203);
      if (_mlsValue::isValueOf<_mls_Cons>(_mls_x731)) {
        auto _mls_x733 = _mls_parseHelper_case1_sr_post_case2_case0(_mls_x731, _mls_x724, _mls_x723, _mls_x203);
        _mls_retval = _mls_parse_caller_post(_mls_x733);
      } else {
        auto _mls_x732 = _mls_parseHelper_case1_sr_post_case2_default(_mls_x723, _mls_x203, _mls_x724);
        _mls_retval = _mls_parse_caller_post(_mls_x732);
      }
    } else {
      auto [_mls_x725, _mls_x726, _mls_x727, _mls_x728] = _mls_parseHelper_case1_sr_post_default_pre(_mls_x723, _mls_x203, _mls_x724);
      if (_mlsValue::isIntLit(_mls_x725, 1)) {
        auto _mls_x730 = _mls_parseHelper_case1_sr_post_default_case0(_mls_x726, _mls_x727, _mls_x728);
        _mls_retval = _mls_parse_caller_post(_mls_x730);
      } else {
        auto _mls_x729 = _mls_parseHelper_case1_sr_post_default_default(_mls_x727, _mls_x726, _mls_x728);
        _mls_retval = _mls_parse_caller_post(_mls_x729);
      }
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_parseHelper(_mlsValue _mls_x738, _mlsValue _mls_x739) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x738)) {
    auto _mls_x740 = _mls_redstar(_mls_x739);
    _mls_retval = _mls_x740;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x738)) {
    _mls_retval = _mls_parseHelper_case1(_mls_x738, _mls_x739);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_parseHelper_case1(_mlsValue _mls_x742, _mlsValue _mls_x744) {
  _mlsValue _mls_retval;
  auto _mls_x741 = _mlsValue::cast<_mls_Cons>(_mls_x742)->_mls_head;
  auto _mls_x743 = _mlsValue::cast<_mls_Cons>(_mls_x742)->_mls_tail;
  _mls_retval = _mls_parseHelper_case1_sr_post(_mls_x741, _mls_x743, _mls_x744);
  return _mls_retval;
}
_mlsValue _mls_parseHelper_case1_sr_post(_mlsValue _mls_x745, _mlsValue _mls_x747, _mlsValue _mls_x746) {
  _mlsValue _mls_retval;
  if (_mls_Str::isStrLit(_mls_x745, " ")) {
    auto _mls_x748 = _mls_parseHelper(_mls_x747, _mls_x746);
    _mls_retval = _mls_x748;
  } else if (_mls_Str::isStrLit(_mls_x745, "(")) {
    _mls_retval = _mls_parseHelper_case1_sr_post_case1(_mls_x746, _mls_x747);
  } else if (_mls_Str::isStrLit(_mls_x745, ")")) {
    _mls_retval = _mls_parseHelper_case1_sr_post_case2(_mls_x746, _mls_x747, _mls_x745);
  } else {
    _mls_retval = _mls_parseHelper_case1_sr_post_default(_mls_x745, _mls_x746, _mls_x747);
  }
  return _mls_retval;
}
_mlsValue _mls_parseHelper_case1_sr_post_case1(_mlsValue _mls_x751, _mlsValue _mls_x752) {
  _mlsValue _mls_retval;
  auto _mls_x749 = _mlsValue::create<_mls_Lex>(_mlsValue::create<_mls_Str>("("));
  auto _mls_x750 = _mlsValue::create<_mls_Cons>(_mls_x749, _mls_x751);
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x752)) {
    auto _mls_x754 = _mls_redstar(_mls_x750);
    _mls_retval = _mls_x754;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x752)) {
    auto _mls_x753 = _mls_parseHelper_case1(_mls_x752, _mls_x750);
    _mls_retval = _mls_x753;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_parseHelper_case1_sr_post_case2(_mlsValue _mls_x755, _mlsValue _mls_x758, _mlsValue _mls_x757) {
  _mlsValue _mls_retval;
  auto _mls_x756 = _mls_redstar(_mls_x755);
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x756)) {
    _mls_retval = _mls_parseHelper_case1_sr_post_case2_case0(_mls_x756, _mls_x758, _mls_x757, _mls_x755);
  } else {
    _mls_retval = _mls_parseHelper_case1_sr_post_case2_default(_mls_x757, _mls_x755, _mls_x758);
  }
  return _mls_retval;
}
_mlsValue _mls_parseHelper_case1_sr_post_case2_case0(_mlsValue _mls_x760, _mlsValue _mls_x772, _mlsValue _mls_x763, _mlsValue _mls_x766) {
  _mlsValue _mls_retval;
  auto _mls_x759 = _mlsValue::cast<_mls_Cons>(_mls_x760)->_mls_head;
  auto _mls_x761 = _mlsValue::cast<_mls_Cons>(_mls_x760)->_mls_tail;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x761)) {
    auto _mls_x781 = _mlsValue::cast<_mls_Cons>(_mls_x761)->_mls_head;
    auto _mls_x782 = _mlsValue::cast<_mls_Cons>(_mls_x761)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Lex>(_mls_x781)) {
      auto _mls_x799 = _mlsValue::cast<_mls_Lex>(_mls_x781)->_mls_s;
      if (_mls_Str::isStrLit(_mls_x799, "(")) {
        auto _mls_x816 = _mlsValue::create<_mls_Cons>(_mls_x759, _mls_x782);
        auto _mls_x817 = _mls_parseHelper(_mls_x772, _mls_x816);
        _mls_retval = _mls_x817;
      } else {
        auto _mls_x800 = _mls_builtin_str_leq(_mlsValue::create<_mls_Str>("a"), _mls_x763);
        auto _mls_x801 = _mls_builtin_str_leq(_mls_x763, _mlsValue::create<_mls_Str>("z"));
        auto _mls_x802 = (_mls_x800 && _mls_x801);
        if (_mlsValue::isIntLit(_mls_x802, 1)) {
          auto _mls_x812 = _mlsValue::create<_mls_Sym>(_mls_x763);
          auto _mls_x813 = _mlsValue::create<_mls_Ast>(_mls_x812);
          auto _mls_x814 = _mlsValue::create<_mls_Cons>(_mls_x813, _mls_x766);
          auto _mls_x815 = _mls_parseHelper(_mls_x772, _mls_x814);
          _mls_retval = _mls_x815;
        } else {
          auto _mls_x803 = _mls_spri(_mls_x766);
          auto _mls_x804 = _mls_opri(_mls_x763);
          auto _mls_x805 = (_mls_x803 > _mls_x804);
          if (_mlsValue::isIntLit(_mls_x805, 1)) {
            auto _mls_x809 = _mlsValue::create<_mls_Cons>(_mls_x763, _mls_x772);
            auto _mls_x810 = _mls_red(_mls_x766);
            auto _mls_x811 = _mls_parseHelper(_mls_x809, _mls_x810);
            _mls_retval = _mls_x811;
          } else {
            auto _mls_x806 = _mlsValue::create<_mls_Lex>(_mls_x763);
            auto _mls_x807 = _mlsValue::create<_mls_Cons>(_mls_x806, _mls_x766);
            auto _mls_x808 = _mls_parseHelper(_mls_x772, _mls_x807);
            _mls_retval = _mls_x808;
          }
        }
      }
    } else {
      auto _mls_x783 = _mls_builtin_str_leq(_mlsValue::create<_mls_Str>("a"), _mls_x763);
      auto _mls_x784 = _mls_builtin_str_leq(_mls_x763, _mlsValue::create<_mls_Str>("z"));
      auto _mls_x785 = (_mls_x783 && _mls_x784);
      if (_mlsValue::isIntLit(_mls_x785, 1)) {
        auto _mls_x795 = _mlsValue::create<_mls_Sym>(_mls_x763);
        auto _mls_x796 = _mlsValue::create<_mls_Ast>(_mls_x795);
        auto _mls_x797 = _mlsValue::create<_mls_Cons>(_mls_x796, _mls_x766);
        auto _mls_x798 = _mls_parseHelper(_mls_x772, _mls_x797);
        _mls_retval = _mls_x798;
      } else {
        auto _mls_x786 = _mls_spri(_mls_x766);
        auto _mls_x787 = _mls_opri(_mls_x763);
        auto _mls_x788 = (_mls_x786 > _mls_x787);
        if (_mlsValue::isIntLit(_mls_x788, 1)) {
          auto _mls_x792 = _mlsValue::create<_mls_Cons>(_mls_x763, _mls_x772);
          auto _mls_x793 = _mls_red(_mls_x766);
          auto _mls_x794 = _mls_parseHelper(_mls_x792, _mls_x793);
          _mls_retval = _mls_x794;
        } else {
          auto _mls_x789 = _mlsValue::create<_mls_Lex>(_mls_x763);
          auto _mls_x790 = _mlsValue::create<_mls_Cons>(_mls_x789, _mls_x766);
          auto _mls_x791 = _mls_parseHelper(_mls_x772, _mls_x790);
          _mls_retval = _mls_x791;
        }
      }
    }
  } else {
    auto _mls_x762 = _mls_builtin_str_leq(_mlsValue::create<_mls_Str>("a"), _mls_x763);
    auto _mls_x764 = _mls_builtin_str_leq(_mls_x763, _mlsValue::create<_mls_Str>("z"));
    auto _mls_x765 = (_mls_x762 && _mls_x764);
    if (_mlsValue::isIntLit(_mls_x765, 1)) {
      auto _mls_x777 = _mlsValue::create<_mls_Sym>(_mls_x763);
      auto _mls_x778 = _mlsValue::create<_mls_Ast>(_mls_x777);
      auto _mls_x779 = _mlsValue::create<_mls_Cons>(_mls_x778, _mls_x766);
      auto _mls_x780 = _mls_parseHelper(_mls_x772, _mls_x779);
      _mls_retval = _mls_x780;
    } else {
      auto _mls_x767 = _mls_spri(_mls_x766);
      auto _mls_x768 = _mls_opri(_mls_x763);
      auto _mls_x769 = (_mls_x767 > _mls_x768);
      if (_mlsValue::isIntLit(_mls_x769, 1)) {
        auto _mls_x774 = _mlsValue::create<_mls_Cons>(_mls_x763, _mls_x772);
        auto _mls_x775 = _mls_red(_mls_x766);
        auto _mls_x776 = _mls_parseHelper(_mls_x774, _mls_x775);
        _mls_retval = _mls_x776;
      } else {
        auto _mls_x770 = _mlsValue::create<_mls_Lex>(_mls_x763);
        auto _mls_x771 = _mlsValue::create<_mls_Cons>(_mls_x770, _mls_x766);
        auto _mls_x773 = _mls_parseHelper(_mls_x772, _mls_x771);
        _mls_retval = _mls_x773;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_parseHelper_case1_sr_post_case2_default(_mlsValue _mls_x819, _mlsValue _mls_x822, _mlsValue _mls_x828) {
  _mlsValue _mls_retval;
  auto _mls_x818 = _mls_builtin_str_leq(_mlsValue::create<_mls_Str>("a"), _mls_x819);
  auto _mls_x820 = _mls_builtin_str_leq(_mls_x819, _mlsValue::create<_mls_Str>("z"));
  auto _mls_x821 = (_mls_x818 && _mls_x820);
  if (_mlsValue::isIntLit(_mls_x821, 1)) {
    auto _mls_x833 = _mlsValue::create<_mls_Sym>(_mls_x819);
    auto _mls_x834 = _mlsValue::create<_mls_Ast>(_mls_x833);
    auto _mls_x835 = _mlsValue::create<_mls_Cons>(_mls_x834, _mls_x822);
    auto _mls_x836 = _mls_parseHelper(_mls_x828, _mls_x835);
    _mls_retval = _mls_x836;
  } else {
    auto _mls_x823 = _mls_spri(_mls_x822);
    auto _mls_x824 = _mls_opri(_mls_x819);
    auto _mls_x825 = (_mls_x823 > _mls_x824);
    if (_mlsValue::isIntLit(_mls_x825, 1)) {
      auto _mls_x830 = _mlsValue::create<_mls_Cons>(_mls_x819, _mls_x828);
      auto _mls_x831 = _mls_red(_mls_x822);
      auto _mls_x832 = _mls_parseHelper(_mls_x830, _mls_x831);
      _mls_retval = _mls_x832;
    } else {
      auto _mls_x826 = _mlsValue::create<_mls_Lex>(_mls_x819);
      auto _mls_x827 = _mlsValue::create<_mls_Cons>(_mls_x826, _mls_x822);
      auto _mls_x829 = _mls_parseHelper(_mls_x828, _mls_x827);
      _mls_retval = _mls_x829;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_parseHelper_case1_sr_post_default(_mlsValue _mls_x837, _mlsValue _mls_x838, _mlsValue _mls_x839) {
  _mlsValue _mls_retval;
  auto [_mls_x840, _mls_x841, _mls_x842, _mls_x843] = _mls_parseHelper_case1_sr_post_default_pre(_mls_x837, _mls_x838, _mls_x839);
  if (_mlsValue::isIntLit(_mls_x840, 1)) {
    _mls_retval = _mls_parseHelper_case1_sr_post_default_case0(_mls_x841, _mls_x842, _mls_x843);
  } else {
    _mls_retval = _mls_parseHelper_case1_sr_post_default_default(_mls_x842, _mls_x841, _mls_x843);
  }
  return _mls_retval;
}
_mlsValue _mls_parseHelper_case1_sr_post_default_case0(_mlsValue _mls_x845, _mlsValue _mls_x848, _mlsValue _mls_x849) {
  _mlsValue _mls_retval;
  auto _mls_x844 = _mlsValue::create<_mls_Sym>(_mls_x845);
  auto _mls_x846 = _mlsValue::create<_mls_Ast>(_mls_x844);
  auto _mls_x847 = _mlsValue::create<_mls_Cons>(_mls_x846, _mls_x848);
  auto _mls_x850 = _mls_parseHelper(_mls_x849, _mls_x847);
  _mls_retval = _mls_x850;
  return _mls_retval;
}
_mlsValue _mls_parseHelper_case1_sr_post_default_default(_mlsValue _mls_x851, _mlsValue _mls_x853, _mlsValue _mls_x858) {
  _mlsValue _mls_retval;
  auto _mls_x852 = _mls_spri(_mls_x851);
  auto _mls_x854 = _mls_opri(_mls_x853);
  auto _mls_x855 = (_mls_x852 > _mls_x854);
  if (_mlsValue::isIntLit(_mls_x855, 1)) {
    auto _mls_x860 = _mlsValue::create<_mls_Cons>(_mls_x853, _mls_x858);
    auto _mls_x861 = _mls_red(_mls_x851);
    auto _mls_x862 = _mls_parseHelper(_mls_x860, _mls_x861);
    _mls_retval = _mls_x862;
  } else {
    auto _mls_x856 = _mlsValue::create<_mls_Lex>(_mls_x853);
    auto _mls_x857 = _mlsValue::create<_mls_Cons>(_mls_x856, _mls_x851);
    auto _mls_x859 = _mls_parseHelper(_mls_x858, _mls_x857);
    _mls_retval = _mls_x859;
  }
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_parseHelper_case1_sr_post_default_pre(_mlsValue _mls_x864, _mlsValue _mls_x867, _mlsValue _mls_x868) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x863 = _mls_builtin_str_leq(_mlsValue::create<_mls_Str>("a"), _mls_x864);
  auto _mls_x865 = _mls_builtin_str_leq(_mls_x864, _mlsValue::create<_mls_Str>("z"));
  auto _mls_x866 = (_mls_x863 && _mls_x865);
  _mls_retval = std::make_tuple(_mls_x866, _mls_x864, _mls_x867, _mls_x868);
  return _mls_retval;
}
_mlsValue _mls_parse_caller_post(_mlsValue _mls_x869) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x869)) {
    auto _mls_x870 = _mlsValue::cast<_mls_Cons>(_mls_x869)->_mls_head;
    auto _mls_x871 = _mlsValue::cast<_mls_Cons>(_mls_x869)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Ast>(_mls_x870)) {
      auto _mls_x872 = _mlsValue::cast<_mls_Ast>(_mls_x870)->_mls_f;
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x871)) {
        _mls_retval = _mls_x872;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_red(_mlsValue _mls_s3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_s3)) {
    auto _mls_x303 = _mlsValue::cast<_mls_Cons>(_mls_s3)->_mls_head;
    auto _mls_x304 = _mlsValue::cast<_mls_Cons>(_mls_s3)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Ast>(_mls_x303)) {
      auto _mls_x305 = _mlsValue::cast<_mls_Ast>(_mls_x303)->_mls_f;
      if (_mlsValue::isValueOf<_mls_Cons>(_mls_x304)) {
        auto _mls_x306 = _mlsValue::cast<_mls_Cons>(_mls_x304)->_mls_head;
        auto _mls_x307 = _mlsValue::cast<_mls_Cons>(_mls_x304)->_mls_tail;
        if (_mlsValue::isValueOf<_mls_Lex>(_mls_x306)) {
          auto _mls_x308 = _mlsValue::cast<_mls_Lex>(_mls_x306)->_mls_s;
          if (_mls_Str::isStrLit(_mls_x308, "=")) {
            if (_mlsValue::isValueOf<_mls_Cons>(_mls_x307)) {
              auto _mls_x330 = _mlsValue::cast<_mls_Cons>(_mls_x307)->_mls_head;
              auto _mls_x331 = _mlsValue::cast<_mls_Cons>(_mls_x307)->_mls_tail;
              if (_mlsValue::isValueOf<_mls_Ast>(_mls_x330)) {
                auto _mls_x332 = _mlsValue::cast<_mls_Ast>(_mls_x330)->_mls_f;
                auto _mls_x333 = _mlsValue::create<_mls_Eqv>(_mls_x332, _mls_x305);
                auto _mls_x334 = _mlsValue::create<_mls_Ast>(_mls_x333);
                auto _mls_x335 = _mlsValue::create<_mls_Cons>(_mls_x334, _mls_x331);
                _mls_retval = _mls_x335;
              } else {
                _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
              }
            } else {
              _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
            }
          } else if (_mls_Str::isStrLit(_mls_x308, ">")) {
            if (_mlsValue::isValueOf<_mls_Cons>(_mls_x307)) {
              auto _mls_x324 = _mlsValue::cast<_mls_Cons>(_mls_x307)->_mls_head;
              auto _mls_x325 = _mlsValue::cast<_mls_Cons>(_mls_x307)->_mls_tail;
              if (_mlsValue::isValueOf<_mls_Ast>(_mls_x324)) {
                auto _mls_x326 = _mlsValue::cast<_mls_Ast>(_mls_x324)->_mls_f;
                auto _mls_x327 = _mlsValue::create<_mls_Imp>(_mls_x326, _mls_x305);
                auto _mls_x328 = _mlsValue::create<_mls_Ast>(_mls_x327);
                auto _mls_x329 = _mlsValue::create<_mls_Cons>(_mls_x328, _mls_x325);
                _mls_retval = _mls_x329;
              } else {
                _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
              }
            } else {
              _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
            }
          } else if (_mls_Str::isStrLit(_mls_x308, "|")) {
            if (_mlsValue::isValueOf<_mls_Cons>(_mls_x307)) {
              auto _mls_x318 = _mlsValue::cast<_mls_Cons>(_mls_x307)->_mls_head;
              auto _mls_x319 = _mlsValue::cast<_mls_Cons>(_mls_x307)->_mls_tail;
              if (_mlsValue::isValueOf<_mls_Ast>(_mls_x318)) {
                auto _mls_x320 = _mlsValue::cast<_mls_Ast>(_mls_x318)->_mls_f;
                auto _mls_x321 = _mlsValue::create<_mls_Dis>(_mls_x320, _mls_x305);
                auto _mls_x322 = _mlsValue::create<_mls_Ast>(_mls_x321);
                auto _mls_x323 = _mlsValue::create<_mls_Cons>(_mls_x322, _mls_x319);
                _mls_retval = _mls_x323;
              } else {
                _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
              }
            } else {
              _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
            }
          } else if (_mls_Str::isStrLit(_mls_x308, "&")) {
            if (_mlsValue::isValueOf<_mls_Cons>(_mls_x307)) {
              auto _mls_x312 = _mlsValue::cast<_mls_Cons>(_mls_x307)->_mls_head;
              auto _mls_x313 = _mlsValue::cast<_mls_Cons>(_mls_x307)->_mls_tail;
              if (_mlsValue::isValueOf<_mls_Ast>(_mls_x312)) {
                auto _mls_x314 = _mlsValue::cast<_mls_Ast>(_mls_x312)->_mls_f;
                auto _mls_x315 = _mlsValue::create<_mls_Con>(_mls_x314, _mls_x305);
                auto _mls_x316 = _mlsValue::create<_mls_Ast>(_mls_x315);
                auto _mls_x317 = _mlsValue::create<_mls_Cons>(_mls_x316, _mls_x313);
                _mls_retval = _mls_x317;
              } else {
                _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
              }
            } else {
              _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
            }
          } else if (_mls_Str::isStrLit(_mls_x308, "~")) {
            auto _mls_x309 = _mlsValue::create<_mls_Not>(_mls_x305);
            auto _mls_x310 = _mlsValue::create<_mls_Ast>(_mls_x309);
            auto _mls_x311 = _mlsValue::create<_mls_Cons>(_mls_x310, _mls_x307);
            _mls_retval = _mls_x311;
          } else {
            _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
          }
        } else {
          _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_redstar(_mlsValue _mls_s4) {
  _mlsValue _mls_retval;
  auto _mls_x336 = _mlsValue::create<_mls_Lambda_lambda>();
  auto _mls_x337 = _mlsValue::create<_mls_Lambda_red>();
  auto _mls_x338 = _mls_while_(_mls_x336, _mls_x337, _mls_s4);
  _mls_retval = _mls_x338;
  return _mls_retval;
}
_mlsValue _mls_replicate(_mlsValue _mls_x873, _mlsValue _mls_x874) {
  _mlsValue _mls_retval;
  auto [_mls_x875, _mls_x876, _mls_x877] = _mls_replicate_pre(_mls_x873, _mls_x874);
  if (_mlsValue::isIntLit(_mls_x875, 1)) {
    _mls_retval = _mls_replicate_case0();
  } else {
    _mls_retval = _mls_replicate_default(_mls_x876, _mls_x877);
  }
  return _mls_retval;
}
_mlsValue _mls_replicate_case0() {
  _mlsValue _mls_retval;
  auto _mls_x878 = _mlsValue::create<_mls_Nil>();
  _mls_retval = _mls_x878;
  return _mls_retval;
}
_mlsValue _mls_replicate_default(_mlsValue _mls_x880, _mlsValue _mls_x881) {
  _mlsValue _mls_retval;
  auto _mls_x879 = (_mls_x880 - _mlsValue::fromIntLit(1));
  auto _mls_x882 = _mls_replicate(_mls_x879, _mls_x881);
  auto _mls_x883 = _mlsValue::create<_mls_Cons>(_mls_x881, _mls_x882);
  _mls_retval = _mls_x883;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_replicate_pre(_mlsValue _mls_x885, _mlsValue _mls_x886) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x884 = (_mls_x885 == _mlsValue::fromIntLit(0));
  _mls_retval = std::make_tuple(_mls_x884, _mls_x885, _mls_x886);
  return _mls_retval;
}
_mlsValue _mls_split(_mlsValue _mls_p6) {
  _mlsValue _mls_retval;
  auto _mls_x345 = _mlsValue::create<_mls_Nil>();
  auto _mls_x346 = _mls_splitHelper(_mls_p6, _mls_x345);
  _mls_retval = _mls_x346;
  return _mls_retval;
}
_mlsValue _mls_splitHelper(_mlsValue _mls_p7, _mlsValue _mls_a7) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Con>(_mls_p7)) {
    auto _mls_x348 = _mlsValue::cast<_mls_Con>(_mls_p7)->_mls_a;
    auto _mls_x349 = _mlsValue::cast<_mls_Con>(_mls_p7)->_mls_b;
    auto _mls_x350 = _mls_splitHelper(_mls_x349, _mls_a7);
    auto _mls_x351 = _mls_splitHelper(_mls_x348, _mls_x350);
    _mls_retval = _mls_x351;
  } else {
    auto _mls_x347 = _mlsValue::create<_mls_Cons>(_mls_p7, _mls_a7);
    _mls_retval = _mls_x347;
  }
  return _mls_retval;
}
_mlsValue _mls_spri(_mlsValue _mls_s5) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_s5)) {
    auto _mls_x352 = _mlsValue::cast<_mls_Cons>(_mls_s5)->_mls_head;
    auto _mls_x353 = _mlsValue::cast<_mls_Cons>(_mls_s5)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Ast>(_mls_x352)) {
      if (_mlsValue::isValueOf<_mls_Cons>(_mls_x353)) {
        auto _mls_x354 = _mlsValue::cast<_mls_Cons>(_mls_x353)->_mls_head;
        if (_mlsValue::isValueOf<_mls_Lex>(_mls_x354)) {
          auto _mls_x355 = _mlsValue::cast<_mls_Lex>(_mls_x354)->_mls_s;
          auto _mls_x356 = _mls_opri(_mls_x355);
          _mls_retval = _mls_x356;
        } else {
          _mls_retval = _mlsValue::fromIntLit(0);
        }
      } else {
        _mls_retval = _mlsValue::fromIntLit(0);
      }
    } else {
      _mls_retval = _mlsValue::fromIntLit(0);
    }
  } else {
    _mls_retval = _mlsValue::fromIntLit(0);
  }
  return _mls_retval;
}
_mlsValue _mls_str_to_list(_mlsValue _mls_x358) {
  _mlsValue _mls_retval;
  auto _mls_x887 = _mls_builtin_str_head(_mls_x358);
  if (_mlsValue::isValueOf<_mls_Unit>(_mls_x887)) {
    auto _mls_x363 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x363;
  } else {
    auto _mls_x888 = _mls_builtin_str_head(_mls_x358);
    auto _mls_x889 = _mls_builtin_str_tail(_mls_x358);
    auto _mls_x361 = _mls_str_to_list(_mls_x889);
    auto _mls_x362 = _mlsValue::create<_mls_Cons>(_mls_x888, _mls_x361);
    _mls_retval = _mls_x362;
  }
  return _mls_retval;
}
_mlsValue _mls_tautclause_case0_sr_post_pre(_mlsValue _mls_x891, _mlsValue _mls_x892) {
  _mlsValue _mls_retval;
  auto _mls_x890 = _mlsValue::create<_mls_Lambda_lscomp>(_mls_x891);
  auto _mls_x893 = _mlsMethodCall<_mls_Callable>(_mls_x890)->_mls_apply1(_mls_x892);
  _mls_retval = _mls_x893;
  return _mls_retval;
}
_mlsValue _mls_testClausify_nofib(_mlsValue _mls_n1) {
  _mlsValue _mls_retval;
  auto _mls_x370 = _mls_str_to_list(_mlsValue::create<_mls_Str>("(a = a = a) = (a = a = a) = (a = a = a)"));
  auto [_mls_x894, _mls_x895, _mls_x896] = _mls_replicate_pre(_mls_n1, _mls_x370);
  if (_mlsValue::isIntLit(_mls_x894, 1)) {
    auto _mls_x904 = _mls_replicate_case0();
    auto [_mls_x905, _mls_x906] = _mls_testClausify_nofib_caller_post_pre(_mls_x904);
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x906)) {
      auto _mls_x908 = _mlsValue::cast<_mls_Cons>(_mls_x906)->_mls_head;
      auto _mls_x909 = _mlsValue::cast<_mls_Cons>(_mls_x906)->_mls_tail;
      auto _mls_x910 = _mls_map_case0_sr_post(_mls_x905, _mls_x908, _mls_x909);
      _mls_retval = _mls_testClausify_nofib_caller_post_post(_mls_x910);
    } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x906)) {
      auto _mls_x907 = _mls_map_case1();
      _mls_retval = _mls_testClausify_nofib_caller_post_post_case0();
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    auto _mls_x897 = _mls_replicate_default(_mls_x895, _mls_x896);
    auto [_mls_x898, _mls_x899] = _mls_testClausify_nofib_caller_post_pre(_mls_x897);
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x899)) {
      auto _mls_x901 = _mlsValue::cast<_mls_Cons>(_mls_x899)->_mls_head;
      auto _mls_x902 = _mlsValue::cast<_mls_Cons>(_mls_x899)->_mls_tail;
      auto _mls_x903 = _mls_map_case0_sr_post(_mls_x898, _mls_x901, _mls_x902);
      _mls_retval = _mls_testClausify_nofib_caller_post_post(_mls_x903);
    } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x899)) {
      auto _mls_x900 = _mls_map_case1();
      _mls_retval = _mls_testClausify_nofib_caller_post_post_case0();
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  }
  return _mls_retval;
}
_mlsValue _mls_testClausify_nofib_caller_post_post(_mlsValue _mls_x911) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x911)) {
    _mls_retval = _mls_testClausify_nofib_caller_post_post_case0();
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x911)) {
    _mls_retval = _mls_testClausify_nofib_caller_post_post_case1(_mls_x911);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_testClausify_nofib_caller_post_post_case0() {
  _mlsValue _mls_retval;
  auto _mls_x912 = _mls_concat_case0();
  auto _mls_x913 = _mls_list_to_str(_mls_x912);
  _mls_retval = _mls_x913;
  return _mls_retval;
}
_mlsValue _mls_testClausify_nofib_caller_post_post_case1(_mlsValue _mls_x914) {
  _mlsValue _mls_retval;
  auto _mls_x915 = _mls_concat_case1(_mls_x914);
  auto _mls_x916 = _mls_list_to_str(_mls_x915);
  _mls_retval = _mls_x916;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue> _mls_testClausify_nofib_caller_post_pre(_mlsValue _mls_x918) {
  std::tuple<_mlsValue, _mlsValue> _mls_retval;
  auto _mls_x917 = _mlsValue::create<_mls_Lambda_clauses>();
  _mls_retval = std::make_tuple(_mls_x917, _mls_x918);
  return _mls_retval;
}
_mlsValue _mls_unicl(_mlsValue _mls_a8) {
  _mlsValue _mls_retval;
  auto _mls_x376 = _mlsValue::create<_mls_Lambda_uniclHelper>();
  auto _mls_x377 = _mlsValue::create<_mls_Nil>();
  auto _mls_x378 = _mls_foldr(_mls_x376, _mls_x377, _mls_a8);
  _mls_retval = _mls_x378;
  return _mls_retval;
}
_mlsValue _mls_uniclHelper(_mlsValue _mls_p8, _mlsValue _mls_x381) {
  _mlsValue _mls_retval;
  auto [_mls_x919, _mls_x920] = _mls_clause_pre(_mls_p8);
  if (_mlsValue::isValueOf<_mls_Dis>(_mls_x919)) {
    auto _mls_x925 = _mlsValue::cast<_mls_Dis>(_mls_x919)->_mls_a;
    auto _mls_x926 = _mlsValue::cast<_mls_Dis>(_mls_x919)->_mls_b;
    if (_mlsValue::isValueOf<_mls_Dis>(_mls_x926)) {
      auto _mls_x929 = _mls_clauseHelper_case0_sr_post_case0(_mls_x926, _mls_x920, _mls_x925);
      _mls_retval = _mls_uniclHelper_caller_post(_mls_x929, _mls_x381);
    } else if (_mlsValue::isValueOf<_mls_Sym>(_mls_x926)) {
      auto _mls_x928 = _mls_clauseHelper_case0_sr_post_case1(_mls_x926, _mls_x920, _mls_x925);
      _mls_retval = _mls_uniclHelper_caller_post(_mls_x928, _mls_x381);
    } else if (_mlsValue::isValueOf<_mls_Not>(_mls_x926)) {
      auto _mls_x927 = _mls_clauseHelper_case0_sr_post_case2(_mls_x926, _mls_x920, _mls_x925);
      _mls_retval = _mls_uniclHelper_caller_post(_mls_x927, _mls_x381);
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else if (_mlsValue::isValueOf<_mls_Sym>(_mls_x919)) {
    auto _mls_x923 = _mlsValue::cast<_mls_Sym>(_mls_x919)->_mls_a;
    auto _mls_x924 = _mls_clauseHelper_case1_sr_post_case0(_mls_x920, _mls_x923);
    _mls_retval = _mls_uniclHelper_caller_post(_mls_x924, _mls_x381);
  } else if (_mlsValue::isValueOf<_mls_Not>(_mls_x919)) {
    auto _mls_x921 = _mlsValue::cast<_mls_Not>(_mls_x919)->_mls_a;
    if (_mlsValue::isValueOf<_mls_Sym>(_mls_x921)) {
      auto _mls_x922 = _mls_clauseHelper_case2_sr_post_case0(_mls_x921, _mls_x920);
      _mls_retval = _mls_uniclHelper_caller_post(_mls_x922, _mls_x381);
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_uniclHelper_caller_post1(_mlsValue _mls_x930, _mlsValue _mls_x932, _mlsValue _mls_x931) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_x930, 1)) {
    _mls_retval = _mls_x932;
  } else {
    auto _mls_x933 = _mls_insert(_mls_x931, _mls_x932);
    _mls_retval = _mls_x933;
  }
  return _mls_retval;
}
_mlsValue _mls_uniclHelper_caller_post(_mlsValue _mls_x934, _mlsValue _mls_x938) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x934)) {
    auto _mls_x935 = _mlsValue::cast<_mls_Tuple2>(_mls_x934)->_mls_field0;
    auto _mls_x936 = _mlsValue::cast<_mls_Tuple2>(_mls_x934)->_mls_field1;
    auto _mls_x937 = _mls_tautclause_case0_sr_post_pre(_mls_x936, _mls_x935);
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x937)) {
      _mls_retval = _mls_uniclHelper_caller_post1(_mlsValue::fromIntLit(0), _mls_x938, _mls_x934);
    } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x937)) {
      _mls_retval = _mls_uniclHelper_caller_post1(_mlsValue::fromIntLit(1), _mls_x938, _mls_x934);
    } else {
      _mls_retval = _mls_uniclHelper_caller_post1(_mlsValue::fromIntLit(1), _mls_x938, _mls_x934);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_while_(_mlsValue _mls_p9, _mlsValue _mls_f3, _mlsValue _mls_x383) {
  _mlsValue _mls_retval;
  auto _mls_x384 = _mlsMethodCall<_mls_Callable>(_mls_p9)->_mls_apply1(_mls_x383);
  if (_mlsValue::isIntLit(_mls_x384, 1)) {
    auto _mls_x385 = _mlsMethodCall<_mls_Callable>(_mls_f3)->_mls_apply1(_mls_x383);
    auto _mls_x386 = _mls_while_(_mls_p9, _mls_f3, _mls_x385);
    _mls_retval = _mls_x386;
  } else {
    _mls_retval = _mls_x383;
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_clauses::_mls_apply1(_mlsValue _mls_arg) {
  _mlsValue _mls_retval;
  auto _mls_x = _mls_clauses(_mls_arg);
  _mls_retval = _mls_x;
  return _mls_retval;
}
_mlsValue _mls_Lambda_disp::_mls_apply1(_mlsValue _mls_arg1) {
  _mlsValue _mls_retval;
  auto _mls_x1 = _mls_disp(_mls_arg1);
  _mls_retval = _mls_x1;
  return _mls_retval;
}
_mlsValue _mls_Lambda_l::_mls_apply2(_mlsValue _mls_ls, _mlsValue _mls_a4) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls)) {
    _mls_retval = _mls_a4;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls)) {
    auto _mls_x2 = _mlsValue::cast<_mls_Cons>(_mls_ls)->_mls_head;
    auto _mls_x3 = _mlsValue::cast<_mls_Cons>(_mls_ls)->_mls_tail;
    auto _mls_x4 = (_mls_a4 + _mlsValue::fromIntLit(1));
    auto _mls_x5 = this->_mls_apply2(_mls_x3, _mls_x4);
    _mls_retval = _mls_x5;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda::_mls_apply1(_mlsValue _mls_s) {
  _mlsValue _mls_retval;
  auto _mls_x6 = _mls_spri(_mls_s);
  auto _mls_x7 = (_mls_x6 != _mlsValue::fromIntLit(0));
  _mls_retval = _mls_x7;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lscomp::_mls_apply1(_mlsValue _mls_ls1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls1)) {
    auto _mls_x14 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x14;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls1)) {
    auto _mls_x8 = _mlsValue::cast<_mls_Cons>(_mls_ls1)->_mls_head;
    auto _mls_x9 = _mlsValue::cast<_mls_Cons>(_mls_ls1)->_mls_tail;
    auto _mls_x10 = _mls_inList(_mls_x8, _mls_lam_arg0);
    if (_mlsValue::isIntLit(_mls_x10, 1)) {
      auto _mls_x12 = this->_mls_apply1(_mls_x9);
      auto _mls_x13 = _mlsValue::create<_mls_Cons>(_mls_x8, _mls_x12);
      _mls_retval = _mls_x13;
    } else {
      auto _mls_x11 = this->_mls_apply1(_mls_x9);
      _mls_retval = _mls_x11;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_red::_mls_apply1(_mlsValue _mls_arg2) {
  _mlsValue _mls_retval;
  auto _mls_x15 = _mls_red(_mls_arg2);
  _mls_retval = _mls_x15;
  return _mls_retval;
}
_mlsValue _mls_Lambda_uniclHelper::_mls_apply2(_mlsValue _mls_arg3, _mlsValue _mls_arg4) {
  _mlsValue _mls_retval;
  auto _mls_x16 = _mls_uniclHelper(_mls_arg3, _mls_arg4);
  _mls_retval = _mls_x16;
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
