#include "mlsprelude.h"
struct _mls_Color;
struct _mls_Black;
struct _mls_LamF;
struct _mls_Red;
struct _mls_Tree;
struct _mls_Leaf;
struct _mls_Node;
_mlsValue _mls_apply_f(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_apply_f_case0(_mlsValue, _mlsValue);
_mlsValue _mls_balance1(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_balance2(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_balance2_case0(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_balance2_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_balance2_default();
_mlsValue _mls_entry();
_mlsValue _mls_fold(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_fold_case1_sr_post_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_ins(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_ins_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_ins_caller_post1(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_ins_caller_post_case0(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_ins_caller_post_case01(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_ins_caller_post_default(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_ins_caller_post_default1(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_ins_case0(_mlsValue, _mlsValue);
_mlsValue _mls_ins_case1_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_ins_case1_sr_post_case0(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_ins_case1_sr_post_case1(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_ins_case1_sr_post_case1_case0(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_ins_case1_sr_post_case1_default(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_ins_case1_sr_post_case1_pre(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_insert(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_insert_caller_post_case0_case1_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_main();
_mlsValue _mls_mkMap(_mlsValue);
_mlsValue _mls_mkMapAux(_mlsValue, _mlsValue);
_mlsValue _mls_mkMapAux_default(_mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_mkMapAux_pre(_mlsValue, _mlsValue);
_mlsValue _mls_setBlack(_mlsValue);
_mlsValue _mls_setBlack_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
struct _mls_Color: public _mlsObject {
  
  constexpr static inline const char *typeName = "Color";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Color; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Black: public _mls_Color {
  
  constexpr static inline const char *typeName = "Black";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Black; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_LamF: public _mlsObject {
  
  constexpr static inline const char *typeName = "LamF";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_LamF; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Red: public _mls_Color {
  
  constexpr static inline const char *typeName = "Red";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Red; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Tree: public _mlsObject {
  
  constexpr static inline const char *typeName = "Tree";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Tree; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Leaf: public _mls_Tree {
  
  constexpr static inline const char *typeName = "Leaf";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Leaf; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Node: public _mls_Tree {
  _mlsValue _mls_color;
  _mlsValue _mls_left;
  _mlsValue _mls_key;
  _mlsValue _mls_value;
  _mlsValue _mls_right;
  constexpr static inline const char *typeName = "Node";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_color.print(); std::printf(", "); this->_mls_left.print(); std::printf(", "); this->_mls_key.print(); std::printf(", "); this->_mls_value.print(); std::printf(", "); this->_mls_right.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_color); _mlsValue::destroy(this->_mls_left); _mlsValue::destroy(this->_mls_key); _mlsValue::destroy(this->_mls_value); _mlsValue::destroy(this->_mls_right);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_color.asObject()->operator==(*other.cast<_mls_Node>()->_mls_color.asObject()) && this->_mls_left.asObject()->operator==(*other.cast<_mls_Node>()->_mls_left.asObject()) && this->_mls_key.asObject()->operator==(*other.cast<_mls_Node>()->_mls_key.asObject()) && this->_mls_value.asObject()->operator==(*other.cast<_mls_Node>()->_mls_value.asObject()) && this->_mls_right.asObject()->operator==(*other.cast<_mls_Node>()->_mls_right.asObject()); }
  static _mlsValue create(_mlsValue _mls_color, _mlsValue _mls_left, _mlsValue _mls_key, _mlsValue _mls_value, _mlsValue _mls_right) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Node; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_color = _mls_color; _mlsVal->_mls_left = _mls_left; _mlsVal->_mls_key = _mls_key; _mlsVal->_mls_value = _mls_value; _mlsVal->_mls_right = _mls_right;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_apply_f(_mlsValue _mls_x176, _mlsValue _mls_x180, _mlsValue _mls_x177, _mlsValue _mls_x178) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x174, _mls_x175;
  if (_mlsValue::isValueOf<_mls_LamF>(_mls_x176)) {
    _mls_x174 = _mls_x177;
    _mls_x175 = _mls_x178;
    goto _mls_apply_f_case0;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_apply_f_case0:
  {
    if (_mlsValue::isIntLit(_mls_x174, 1)) {
      auto _mls_x179 = (_mls_x175 + _mlsValue::fromIntLit(1));
      _mls_retval = _mls_x179;
    } else {
      _mls_retval = _mls_x175;
    }
    return _mls_retval;
  }
}
_mlsValue _mls_apply_f_case0(_mlsValue _mls_x174, _mlsValue _mls_x175) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_x174, 1)) {
    auto _mls_x179 = (_mls_x175 + _mlsValue::fromIntLit(1));
    _mls_retval = _mls_x179;
  } else {
    _mls_retval = _mls_x175;
  }
  return _mls_retval;
}
_mlsValue _mls_balance1(_mlsValue _mls_k, _mlsValue _mls_v, _mlsValue _mls_t1, _mlsValue _mls_t2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Node>(_mls_t2)) {
    auto _mls_x2 = _mlsValue::cast<_mls_Node>(_mls_t2)->_mls_left;
    auto _mls_x3 = _mlsValue::cast<_mls_Node>(_mls_t2)->_mls_key;
    auto _mls_x4 = _mlsValue::cast<_mls_Node>(_mls_t2)->_mls_value;
    auto _mls_x5 = _mlsValue::cast<_mls_Node>(_mls_t2)->_mls_right;
    if (_mlsValue::isValueOf<_mls_Node>(_mls_x2)) {
      auto _mls_x25 = _mlsValue::cast<_mls_Node>(_mls_x2)->_mls_color;
      auto _mls_x26 = _mlsValue::cast<_mls_Node>(_mls_x2)->_mls_left;
      auto _mls_x27 = _mlsValue::cast<_mls_Node>(_mls_x2)->_mls_key;
      auto _mls_x28 = _mlsValue::cast<_mls_Node>(_mls_x2)->_mls_value;
      auto _mls_x29 = _mlsValue::cast<_mls_Node>(_mls_x2)->_mls_right;
      if (_mlsValue::isValueOf<_mls_Red>(_mls_x25)) {
        auto _mls_x49 = _mlsValue::create<_mls_Black>();
        auto _mls_x50 = _mlsValue::create<_mls_Node>(_mls_x49, _mls_x26, _mls_x27, _mls_x28, _mls_x29);
        auto _mls_x51 = _mlsValue::create<_mls_Black>();
        auto _mls_x52 = _mlsValue::create<_mls_Node>(_mls_x51, _mls_x5, _mls_k, _mls_v, _mls_t1);
        auto _mls_x53 = _mlsValue::create<_mls_Red>();
        auto _mls_x54 = _mlsValue::create<_mls_Node>(_mls_x53, _mls_x50, _mls_x3, _mls_x4, _mls_x52);
        _mls_retval = _mls_x54;
      } else {
        if (_mlsValue::isValueOf<_mls_Node>(_mls_x5)) {
          auto _mls_x34 = _mlsValue::cast<_mls_Node>(_mls_x5)->_mls_color;
          auto _mls_x35 = _mlsValue::cast<_mls_Node>(_mls_x5)->_mls_left;
          auto _mls_x36 = _mlsValue::cast<_mls_Node>(_mls_x5)->_mls_key;
          auto _mls_x37 = _mlsValue::cast<_mls_Node>(_mls_x5)->_mls_value;
          auto _mls_x38 = _mlsValue::cast<_mls_Node>(_mls_x5)->_mls_right;
          if (_mlsValue::isValueOf<_mls_Red>(_mls_x34)) {
            auto _mls_x43 = _mlsValue::create<_mls_Black>();
            auto _mls_x44 = _mlsValue::create<_mls_Node>(_mls_x43, _mls_x2, _mls_x3, _mls_x4, _mls_x35);
            auto _mls_x45 = _mlsValue::create<_mls_Black>();
            auto _mls_x46 = _mlsValue::create<_mls_Node>(_mls_x45, _mls_x38, _mls_k, _mls_v, _mls_t1);
            auto _mls_x47 = _mlsValue::create<_mls_Red>();
            auto _mls_x48 = _mlsValue::create<_mls_Node>(_mls_x47, _mls_x44, _mls_x36, _mls_x37, _mls_x46);
            _mls_retval = _mls_x48;
          } else {
            auto _mls_x39 = _mlsValue::create<_mls_Red>();
            auto _mls_x40 = _mlsValue::create<_mls_Node>(_mls_x39, _mls_x2, _mls_x3, _mls_x4, _mls_x5);
            auto _mls_x41 = _mlsValue::create<_mls_Black>();
            auto _mls_x42 = _mlsValue::create<_mls_Node>(_mls_x41, _mls_x40, _mls_k, _mls_v, _mls_t1);
            _mls_retval = _mls_x42;
          }
        } else {
          auto _mls_x30 = _mlsValue::create<_mls_Red>();
          auto _mls_x31 = _mlsValue::create<_mls_Node>(_mls_x30, _mls_x2, _mls_x3, _mls_x4, _mls_x5);
          auto _mls_x32 = _mlsValue::create<_mls_Black>();
          auto _mls_x33 = _mlsValue::create<_mls_Node>(_mls_x32, _mls_x31, _mls_k, _mls_v, _mls_t1);
          _mls_retval = _mls_x33;
        }
      }
    } else {
      if (_mlsValue::isValueOf<_mls_Node>(_mls_x5)) {
        auto _mls_x10 = _mlsValue::cast<_mls_Node>(_mls_x5)->_mls_color;
        auto _mls_x11 = _mlsValue::cast<_mls_Node>(_mls_x5)->_mls_left;
        auto _mls_x12 = _mlsValue::cast<_mls_Node>(_mls_x5)->_mls_key;
        auto _mls_x13 = _mlsValue::cast<_mls_Node>(_mls_x5)->_mls_value;
        auto _mls_x14 = _mlsValue::cast<_mls_Node>(_mls_x5)->_mls_right;
        if (_mlsValue::isValueOf<_mls_Red>(_mls_x10)) {
          auto _mls_x19 = _mlsValue::create<_mls_Black>();
          auto _mls_x20 = _mlsValue::create<_mls_Node>(_mls_x19, _mls_x2, _mls_x3, _mls_x4, _mls_x11);
          auto _mls_x21 = _mlsValue::create<_mls_Black>();
          auto _mls_x22 = _mlsValue::create<_mls_Node>(_mls_x21, _mls_x14, _mls_k, _mls_v, _mls_t1);
          auto _mls_x23 = _mlsValue::create<_mls_Red>();
          auto _mls_x24 = _mlsValue::create<_mls_Node>(_mls_x23, _mls_x20, _mls_x12, _mls_x13, _mls_x22);
          _mls_retval = _mls_x24;
        } else {
          auto _mls_x15 = _mlsValue::create<_mls_Red>();
          auto _mls_x16 = _mlsValue::create<_mls_Node>(_mls_x15, _mls_x2, _mls_x3, _mls_x4, _mls_x5);
          auto _mls_x17 = _mlsValue::create<_mls_Black>();
          auto _mls_x18 = _mlsValue::create<_mls_Node>(_mls_x17, _mls_x16, _mls_k, _mls_v, _mls_t1);
          _mls_retval = _mls_x18;
        }
      } else {
        auto _mls_x6 = _mlsValue::create<_mls_Red>();
        auto _mls_x7 = _mlsValue::create<_mls_Node>(_mls_x6, _mls_x2, _mls_x3, _mls_x4, _mls_x5);
        auto _mls_x8 = _mlsValue::create<_mls_Black>();
        auto _mls_x9 = _mlsValue::create<_mls_Node>(_mls_x8, _mls_x7, _mls_k, _mls_v, _mls_t1);
        _mls_retval = _mls_x9;
      }
    }
  } else {
    auto _mls_x1 = _mlsValue::create<_mls_Leaf>();
    _mls_retval = _mls_x1;
  }
  return _mls_retval;
}
_mlsValue _mls_balance2(_mlsValue _mls_x193, _mlsValue _mls_x195, _mlsValue _mls_x194, _mlsValue _mls_x192) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x181, _mls_x182, _mls_x183, _mls_x184;
  _mlsValue _mls_x185, _mls_x186, _mls_x187, _mls_x188, _mls_x189, _mls_x190, _mls_x191;
  if (_mlsValue::isValueOf<_mls_Node>(_mls_x192)) {
    _mls_x181 = _mls_x192;
    _mls_x182 = _mls_x193;
    _mls_x183 = _mls_x194;
    _mls_x184 = _mls_x195;
    goto _mls_balance2_case0;
  } else {
    goto _mls_balance2_default;
  }
  return _mls_retval;
  _mls_balance2_case0:
  {
    auto _mls_x196 = _mlsValue::cast<_mls_Node>(_mls_x181)->_mls_left;
    auto _mls_x197 = _mlsValue::cast<_mls_Node>(_mls_x181)->_mls_key;
    auto _mls_x198 = _mlsValue::cast<_mls_Node>(_mls_x181)->_mls_value;
    auto _mls_x199 = _mlsValue::cast<_mls_Node>(_mls_x181)->_mls_right;
    _mls_x185 = _mls_x182;
    _mls_x186 = _mls_x199;
    _mls_x187 = _mls_x196;
    _mls_x188 = _mls_x197;
    _mls_x189 = _mls_x183;
    _mls_x190 = _mls_x184;
    _mls_x191 = _mls_x198;
    goto _mls_balance2_case0_sr_post;
    return _mls_retval;
  }
  _mls_balance2_default:
  {
    auto _mls_x200 = _mlsValue::create<_mls_Leaf>();
    _mls_retval = _mls_x200;
    return _mls_retval;
  }
  _mls_balance2_case0_sr_post:
  {
    if (_mlsValue::isValueOf<_mls_Node>(_mls_x187)) {
      auto _mls_x220 = _mlsValue::cast<_mls_Node>(_mls_x187)->_mls_color;
      auto _mls_x221 = _mlsValue::cast<_mls_Node>(_mls_x187)->_mls_left;
      auto _mls_x222 = _mlsValue::cast<_mls_Node>(_mls_x187)->_mls_key;
      auto _mls_x223 = _mlsValue::cast<_mls_Node>(_mls_x187)->_mls_value;
      auto _mls_x224 = _mlsValue::cast<_mls_Node>(_mls_x187)->_mls_right;
      if (_mlsValue::isValueOf<_mls_Red>(_mls_x220)) {
        auto _mls_x244 = _mlsValue::create<_mls_Black>();
        auto _mls_x245 = _mlsValue::create<_mls_Node>(_mls_x244, _mls_x185, _mls_x190, _mls_x189, _mls_x221);
        auto _mls_x246 = _mlsValue::create<_mls_Black>();
        auto _mls_x247 = _mlsValue::create<_mls_Node>(_mls_x246, _mls_x224, _mls_x188, _mls_x191, _mls_x186);
        auto _mls_x248 = _mlsValue::create<_mls_Red>();
        auto _mls_x249 = _mlsValue::create<_mls_Node>(_mls_x248, _mls_x245, _mls_x222, _mls_x223, _mls_x247);
        _mls_retval = _mls_x249;
      } else {
        if (_mlsValue::isValueOf<_mls_Node>(_mls_x186)) {
          auto _mls_x229 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_color;
          auto _mls_x230 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_left;
          auto _mls_x231 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_key;
          auto _mls_x232 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_value;
          auto _mls_x233 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_right;
          if (_mlsValue::isValueOf<_mls_Red>(_mls_x229)) {
            auto _mls_x238 = _mlsValue::create<_mls_Black>();
            auto _mls_x239 = _mlsValue::create<_mls_Node>(_mls_x238, _mls_x185, _mls_x190, _mls_x189, _mls_x187);
            auto _mls_x240 = _mlsValue::create<_mls_Black>();
            auto _mls_x241 = _mlsValue::create<_mls_Node>(_mls_x240, _mls_x230, _mls_x231, _mls_x232, _mls_x233);
            auto _mls_x242 = _mlsValue::create<_mls_Red>();
            auto _mls_x243 = _mlsValue::create<_mls_Node>(_mls_x242, _mls_x239, _mls_x188, _mls_x191, _mls_x241);
            _mls_retval = _mls_x243;
          } else {
            auto _mls_x234 = _mlsValue::create<_mls_Red>();
            auto _mls_x235 = _mlsValue::create<_mls_Node>(_mls_x234, _mls_x187, _mls_x188, _mls_x191, _mls_x186);
            auto _mls_x236 = _mlsValue::create<_mls_Black>();
            auto _mls_x237 = _mlsValue::create<_mls_Node>(_mls_x236, _mls_x185, _mls_x190, _mls_x189, _mls_x235);
            _mls_retval = _mls_x237;
          }
        } else {
          auto _mls_x225 = _mlsValue::create<_mls_Red>();
          auto _mls_x226 = _mlsValue::create<_mls_Node>(_mls_x225, _mls_x187, _mls_x188, _mls_x191, _mls_x186);
          auto _mls_x227 = _mlsValue::create<_mls_Black>();
          auto _mls_x228 = _mlsValue::create<_mls_Node>(_mls_x227, _mls_x185, _mls_x190, _mls_x189, _mls_x226);
          _mls_retval = _mls_x228;
        }
      }
    } else {
      if (_mlsValue::isValueOf<_mls_Node>(_mls_x186)) {
        auto _mls_x205 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_color;
        auto _mls_x206 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_left;
        auto _mls_x207 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_key;
        auto _mls_x208 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_value;
        auto _mls_x209 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_right;
        if (_mlsValue::isValueOf<_mls_Red>(_mls_x205)) {
          auto _mls_x214 = _mlsValue::create<_mls_Black>();
          auto _mls_x215 = _mlsValue::create<_mls_Node>(_mls_x214, _mls_x185, _mls_x190, _mls_x189, _mls_x187);
          auto _mls_x216 = _mlsValue::create<_mls_Black>();
          auto _mls_x217 = _mlsValue::create<_mls_Node>(_mls_x216, _mls_x206, _mls_x207, _mls_x208, _mls_x209);
          auto _mls_x218 = _mlsValue::create<_mls_Red>();
          auto _mls_x219 = _mlsValue::create<_mls_Node>(_mls_x218, _mls_x215, _mls_x188, _mls_x191, _mls_x217);
          _mls_retval = _mls_x219;
        } else {
          auto _mls_x210 = _mlsValue::create<_mls_Red>();
          auto _mls_x211 = _mlsValue::create<_mls_Node>(_mls_x210, _mls_x187, _mls_x188, _mls_x191, _mls_x186);
          auto _mls_x212 = _mlsValue::create<_mls_Black>();
          auto _mls_x213 = _mlsValue::create<_mls_Node>(_mls_x212, _mls_x185, _mls_x190, _mls_x189, _mls_x211);
          _mls_retval = _mls_x213;
        }
      } else {
        auto _mls_x201 = _mlsValue::create<_mls_Red>();
        auto _mls_x202 = _mlsValue::create<_mls_Node>(_mls_x201, _mls_x187, _mls_x188, _mls_x191, _mls_x186);
        auto _mls_x203 = _mlsValue::create<_mls_Black>();
        auto _mls_x204 = _mlsValue::create<_mls_Node>(_mls_x203, _mls_x185, _mls_x190, _mls_x189, _mls_x202);
        _mls_retval = _mls_x204;
      }
    }
    return _mls_retval;
  }
}
_mlsValue _mls_balance2_case0(_mlsValue _mls_x181, _mlsValue _mls_x182, _mlsValue _mls_x183, _mlsValue _mls_x184) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x185, _mls_x186, _mls_x187, _mls_x188, _mls_x189, _mls_x190, _mls_x191;
  auto _mls_x196 = _mlsValue::cast<_mls_Node>(_mls_x181)->_mls_left;
  auto _mls_x197 = _mlsValue::cast<_mls_Node>(_mls_x181)->_mls_key;
  auto _mls_x198 = _mlsValue::cast<_mls_Node>(_mls_x181)->_mls_value;
  auto _mls_x199 = _mlsValue::cast<_mls_Node>(_mls_x181)->_mls_right;
  _mls_x185 = _mls_x182;
  _mls_x186 = _mls_x199;
  _mls_x187 = _mls_x196;
  _mls_x188 = _mls_x197;
  _mls_x189 = _mls_x183;
  _mls_x190 = _mls_x184;
  _mls_x191 = _mls_x198;
  goto _mls_balance2_case0_sr_post;
  return _mls_retval;
  _mls_balance2_case0_sr_post:
  {
    if (_mlsValue::isValueOf<_mls_Node>(_mls_x187)) {
      auto _mls_x220 = _mlsValue::cast<_mls_Node>(_mls_x187)->_mls_color;
      auto _mls_x221 = _mlsValue::cast<_mls_Node>(_mls_x187)->_mls_left;
      auto _mls_x222 = _mlsValue::cast<_mls_Node>(_mls_x187)->_mls_key;
      auto _mls_x223 = _mlsValue::cast<_mls_Node>(_mls_x187)->_mls_value;
      auto _mls_x224 = _mlsValue::cast<_mls_Node>(_mls_x187)->_mls_right;
      if (_mlsValue::isValueOf<_mls_Red>(_mls_x220)) {
        auto _mls_x244 = _mlsValue::create<_mls_Black>();
        auto _mls_x245 = _mlsValue::create<_mls_Node>(_mls_x244, _mls_x185, _mls_x190, _mls_x189, _mls_x221);
        auto _mls_x246 = _mlsValue::create<_mls_Black>();
        auto _mls_x247 = _mlsValue::create<_mls_Node>(_mls_x246, _mls_x224, _mls_x188, _mls_x191, _mls_x186);
        auto _mls_x248 = _mlsValue::create<_mls_Red>();
        auto _mls_x249 = _mlsValue::create<_mls_Node>(_mls_x248, _mls_x245, _mls_x222, _mls_x223, _mls_x247);
        _mls_retval = _mls_x249;
      } else {
        if (_mlsValue::isValueOf<_mls_Node>(_mls_x186)) {
          auto _mls_x229 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_color;
          auto _mls_x230 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_left;
          auto _mls_x231 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_key;
          auto _mls_x232 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_value;
          auto _mls_x233 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_right;
          if (_mlsValue::isValueOf<_mls_Red>(_mls_x229)) {
            auto _mls_x238 = _mlsValue::create<_mls_Black>();
            auto _mls_x239 = _mlsValue::create<_mls_Node>(_mls_x238, _mls_x185, _mls_x190, _mls_x189, _mls_x187);
            auto _mls_x240 = _mlsValue::create<_mls_Black>();
            auto _mls_x241 = _mlsValue::create<_mls_Node>(_mls_x240, _mls_x230, _mls_x231, _mls_x232, _mls_x233);
            auto _mls_x242 = _mlsValue::create<_mls_Red>();
            auto _mls_x243 = _mlsValue::create<_mls_Node>(_mls_x242, _mls_x239, _mls_x188, _mls_x191, _mls_x241);
            _mls_retval = _mls_x243;
          } else {
            auto _mls_x234 = _mlsValue::create<_mls_Red>();
            auto _mls_x235 = _mlsValue::create<_mls_Node>(_mls_x234, _mls_x187, _mls_x188, _mls_x191, _mls_x186);
            auto _mls_x236 = _mlsValue::create<_mls_Black>();
            auto _mls_x237 = _mlsValue::create<_mls_Node>(_mls_x236, _mls_x185, _mls_x190, _mls_x189, _mls_x235);
            _mls_retval = _mls_x237;
          }
        } else {
          auto _mls_x225 = _mlsValue::create<_mls_Red>();
          auto _mls_x226 = _mlsValue::create<_mls_Node>(_mls_x225, _mls_x187, _mls_x188, _mls_x191, _mls_x186);
          auto _mls_x227 = _mlsValue::create<_mls_Black>();
          auto _mls_x228 = _mlsValue::create<_mls_Node>(_mls_x227, _mls_x185, _mls_x190, _mls_x189, _mls_x226);
          _mls_retval = _mls_x228;
        }
      }
    } else {
      if (_mlsValue::isValueOf<_mls_Node>(_mls_x186)) {
        auto _mls_x205 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_color;
        auto _mls_x206 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_left;
        auto _mls_x207 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_key;
        auto _mls_x208 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_value;
        auto _mls_x209 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_right;
        if (_mlsValue::isValueOf<_mls_Red>(_mls_x205)) {
          auto _mls_x214 = _mlsValue::create<_mls_Black>();
          auto _mls_x215 = _mlsValue::create<_mls_Node>(_mls_x214, _mls_x185, _mls_x190, _mls_x189, _mls_x187);
          auto _mls_x216 = _mlsValue::create<_mls_Black>();
          auto _mls_x217 = _mlsValue::create<_mls_Node>(_mls_x216, _mls_x206, _mls_x207, _mls_x208, _mls_x209);
          auto _mls_x218 = _mlsValue::create<_mls_Red>();
          auto _mls_x219 = _mlsValue::create<_mls_Node>(_mls_x218, _mls_x215, _mls_x188, _mls_x191, _mls_x217);
          _mls_retval = _mls_x219;
        } else {
          auto _mls_x210 = _mlsValue::create<_mls_Red>();
          auto _mls_x211 = _mlsValue::create<_mls_Node>(_mls_x210, _mls_x187, _mls_x188, _mls_x191, _mls_x186);
          auto _mls_x212 = _mlsValue::create<_mls_Black>();
          auto _mls_x213 = _mlsValue::create<_mls_Node>(_mls_x212, _mls_x185, _mls_x190, _mls_x189, _mls_x211);
          _mls_retval = _mls_x213;
        }
      } else {
        auto _mls_x201 = _mlsValue::create<_mls_Red>();
        auto _mls_x202 = _mlsValue::create<_mls_Node>(_mls_x201, _mls_x187, _mls_x188, _mls_x191, _mls_x186);
        auto _mls_x203 = _mlsValue::create<_mls_Black>();
        auto _mls_x204 = _mlsValue::create<_mls_Node>(_mls_x203, _mls_x185, _mls_x190, _mls_x189, _mls_x202);
        _mls_retval = _mls_x204;
      }
    }
    return _mls_retval;
  }
}
_mlsValue _mls_balance2_case0_sr_post(_mlsValue _mls_x185, _mlsValue _mls_x186, _mlsValue _mls_x187, _mlsValue _mls_x188, _mlsValue _mls_x189, _mlsValue _mls_x190, _mlsValue _mls_x191) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Node>(_mls_x187)) {
    auto _mls_x220 = _mlsValue::cast<_mls_Node>(_mls_x187)->_mls_color;
    auto _mls_x221 = _mlsValue::cast<_mls_Node>(_mls_x187)->_mls_left;
    auto _mls_x222 = _mlsValue::cast<_mls_Node>(_mls_x187)->_mls_key;
    auto _mls_x223 = _mlsValue::cast<_mls_Node>(_mls_x187)->_mls_value;
    auto _mls_x224 = _mlsValue::cast<_mls_Node>(_mls_x187)->_mls_right;
    if (_mlsValue::isValueOf<_mls_Red>(_mls_x220)) {
      auto _mls_x244 = _mlsValue::create<_mls_Black>();
      auto _mls_x245 = _mlsValue::create<_mls_Node>(_mls_x244, _mls_x185, _mls_x190, _mls_x189, _mls_x221);
      auto _mls_x246 = _mlsValue::create<_mls_Black>();
      auto _mls_x247 = _mlsValue::create<_mls_Node>(_mls_x246, _mls_x224, _mls_x188, _mls_x191, _mls_x186);
      auto _mls_x248 = _mlsValue::create<_mls_Red>();
      auto _mls_x249 = _mlsValue::create<_mls_Node>(_mls_x248, _mls_x245, _mls_x222, _mls_x223, _mls_x247);
      _mls_retval = _mls_x249;
    } else {
      if (_mlsValue::isValueOf<_mls_Node>(_mls_x186)) {
        auto _mls_x229 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_color;
        auto _mls_x230 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_left;
        auto _mls_x231 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_key;
        auto _mls_x232 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_value;
        auto _mls_x233 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_right;
        if (_mlsValue::isValueOf<_mls_Red>(_mls_x229)) {
          auto _mls_x238 = _mlsValue::create<_mls_Black>();
          auto _mls_x239 = _mlsValue::create<_mls_Node>(_mls_x238, _mls_x185, _mls_x190, _mls_x189, _mls_x187);
          auto _mls_x240 = _mlsValue::create<_mls_Black>();
          auto _mls_x241 = _mlsValue::create<_mls_Node>(_mls_x240, _mls_x230, _mls_x231, _mls_x232, _mls_x233);
          auto _mls_x242 = _mlsValue::create<_mls_Red>();
          auto _mls_x243 = _mlsValue::create<_mls_Node>(_mls_x242, _mls_x239, _mls_x188, _mls_x191, _mls_x241);
          _mls_retval = _mls_x243;
        } else {
          auto _mls_x234 = _mlsValue::create<_mls_Red>();
          auto _mls_x235 = _mlsValue::create<_mls_Node>(_mls_x234, _mls_x187, _mls_x188, _mls_x191, _mls_x186);
          auto _mls_x236 = _mlsValue::create<_mls_Black>();
          auto _mls_x237 = _mlsValue::create<_mls_Node>(_mls_x236, _mls_x185, _mls_x190, _mls_x189, _mls_x235);
          _mls_retval = _mls_x237;
        }
      } else {
        auto _mls_x225 = _mlsValue::create<_mls_Red>();
        auto _mls_x226 = _mlsValue::create<_mls_Node>(_mls_x225, _mls_x187, _mls_x188, _mls_x191, _mls_x186);
        auto _mls_x227 = _mlsValue::create<_mls_Black>();
        auto _mls_x228 = _mlsValue::create<_mls_Node>(_mls_x227, _mls_x185, _mls_x190, _mls_x189, _mls_x226);
        _mls_retval = _mls_x228;
      }
    }
  } else {
    if (_mlsValue::isValueOf<_mls_Node>(_mls_x186)) {
      auto _mls_x205 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_color;
      auto _mls_x206 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_left;
      auto _mls_x207 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_key;
      auto _mls_x208 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_value;
      auto _mls_x209 = _mlsValue::cast<_mls_Node>(_mls_x186)->_mls_right;
      if (_mlsValue::isValueOf<_mls_Red>(_mls_x205)) {
        auto _mls_x214 = _mlsValue::create<_mls_Black>();
        auto _mls_x215 = _mlsValue::create<_mls_Node>(_mls_x214, _mls_x185, _mls_x190, _mls_x189, _mls_x187);
        auto _mls_x216 = _mlsValue::create<_mls_Black>();
        auto _mls_x217 = _mlsValue::create<_mls_Node>(_mls_x216, _mls_x206, _mls_x207, _mls_x208, _mls_x209);
        auto _mls_x218 = _mlsValue::create<_mls_Red>();
        auto _mls_x219 = _mlsValue::create<_mls_Node>(_mls_x218, _mls_x215, _mls_x188, _mls_x191, _mls_x217);
        _mls_retval = _mls_x219;
      } else {
        auto _mls_x210 = _mlsValue::create<_mls_Red>();
        auto _mls_x211 = _mlsValue::create<_mls_Node>(_mls_x210, _mls_x187, _mls_x188, _mls_x191, _mls_x186);
        auto _mls_x212 = _mlsValue::create<_mls_Black>();
        auto _mls_x213 = _mlsValue::create<_mls_Node>(_mls_x212, _mls_x185, _mls_x190, _mls_x189, _mls_x211);
        _mls_retval = _mls_x213;
      }
    } else {
      auto _mls_x201 = _mlsValue::create<_mls_Red>();
      auto _mls_x202 = _mlsValue::create<_mls_Node>(_mls_x201, _mls_x187, _mls_x188, _mls_x191, _mls_x186);
      auto _mls_x203 = _mlsValue::create<_mls_Black>();
      auto _mls_x204 = _mlsValue::create<_mls_Node>(_mls_x203, _mls_x185, _mls_x190, _mls_x189, _mls_x202);
      _mls_retval = _mls_x204;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_balance2_default() {
  _mlsValue _mls_retval;
  auto _mls_x200 = _mlsValue::create<_mls_Leaf>();
  _mls_retval = _mls_x200;
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x109 = _mls_main();
  _mls_retval = _mls_x109;
  return _mls_retval;
}
_mlsValue _mls_fold(_mlsValue _mls_x260, _mlsValue _mls_x255, _mlsValue _mls_x261) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x250, _mls_x251, _mls_x252, _mls_x253, _mls_x254;
  if (_mlsValue::isValueOf<_mls_Leaf>(_mls_x255)) {
    _mls_retval = _mls_x261;
  } else if (_mlsValue::isValueOf<_mls_Node>(_mls_x255)) {
    auto _mls_x256 = _mlsValue::cast<_mls_Node>(_mls_x255)->_mls_left;
    auto _mls_x257 = _mlsValue::cast<_mls_Node>(_mls_x255)->_mls_key;
    auto _mls_x258 = _mlsValue::cast<_mls_Node>(_mls_x255)->_mls_value;
    auto _mls_x259 = _mlsValue::cast<_mls_Node>(_mls_x255)->_mls_right;
    auto _mls_x262 = _mls_fold(_mls_x260, _mls_x256, _mls_x261);
    _mls_x250 = _mls_x262;
    _mls_x251 = _mls_x260;
    _mls_x252 = _mls_x258;
    _mls_x253 = _mls_x257;
    _mls_x254 = _mls_x259;
    goto _mls_fold_case1_sr_post_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_fold_case1_sr_post_post:
  {
    auto _mls_x263 = _mls_apply_f(_mls_x251, _mls_x253, _mls_x252, _mls_x250);
    auto _mls_x264 = _mls_fold(_mls_x251, _mls_x254, _mls_x263);
    _mls_retval = _mls_x264;
    return _mls_retval;
  }
}
_mlsValue _mls_fold_case1_sr_post_post(_mlsValue _mls_x250, _mlsValue _mls_x251, _mlsValue _mls_x252, _mlsValue _mls_x253, _mlsValue _mls_x254) {
  _mlsValue _mls_retval;
  auto _mls_x263 = _mls_apply_f(_mls_x251, _mls_x253, _mls_x252, _mls_x250);
  auto _mls_x264 = _mls_fold(_mls_x251, _mls_x254, _mls_x263);
  _mls_retval = _mls_x264;
  return _mls_retval;
}
_mlsValue _mls_ins(_mlsValue _mls_x343, _mlsValue _mls_x342, _mlsValue _mls_x336) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x265, _mls_x266;
  _mlsValue _mls_x267, _mls_x268, _mls_x269, _mls_x270, _mls_x271, _mls_x272, _mls_x273;
  _mlsValue _mls_x274, _mls_x275, _mls_x276, _mls_x277, _mls_x278, _mls_x279;
  _mlsValue _mls_x280, _mls_x281, _mls_x282, _mls_x283, _mls_x284, _mls_x285;
  _mlsValue _mls_x286, _mls_x287, _mls_x288, _mls_x289, _mls_x290, _mls_x291;
  _mlsValue _mls_x292, _mls_x293, _mls_x294, _mls_x295, _mls_x296, _mls_x297;
  _mlsValue _mls_x298, _mls_x299, _mls_x300, _mls_x301, _mls_x302, _mls_x303, _mls_x304;
  _mlsValue _mls_x305, _mls_x306, _mls_x307, _mls_x308, _mls_x309, _mls_x310;
  _mlsValue _mls_x311, _mls_x312, _mls_x313, _mls_x314, _mls_x315, _mls_x316, _mls_x317;
  _mlsValue _mls_x318, _mls_x319, _mls_x320, _mls_x321, _mls_x322, _mls_x323;
  _mlsValue _mls_x324, _mls_x325, _mls_x326, _mls_x327, _mls_x328, _mls_x329;
  _mlsValue _mls_x330, _mls_x331, _mls_x332, _mls_x333, _mls_x334, _mls_x335;
  if (_mlsValue::isValueOf<_mls_Leaf>(_mls_x336)) {
    _mls_x265 = _mls_x343;
    _mls_x266 = _mls_x342;
    goto _mls_ins_case0;
  } else if (_mlsValue::isValueOf<_mls_Node>(_mls_x336)) {
    auto _mls_x337 = _mlsValue::cast<_mls_Node>(_mls_x336)->_mls_color;
    auto _mls_x338 = _mlsValue::cast<_mls_Node>(_mls_x336)->_mls_left;
    auto _mls_x339 = _mlsValue::cast<_mls_Node>(_mls_x336)->_mls_key;
    auto _mls_x340 = _mlsValue::cast<_mls_Node>(_mls_x336)->_mls_value;
    auto _mls_x341 = _mlsValue::cast<_mls_Node>(_mls_x336)->_mls_right;
    _mls_x267 = _mls_x341;
    _mls_x268 = _mls_x342;
    _mls_x269 = _mls_x340;
    _mls_x270 = _mls_x337;
    _mls_x271 = _mls_x339;
    _mls_x272 = _mls_x343;
    _mls_x273 = _mls_x338;
    goto _mls_ins_case1_sr_post;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_ins_case0:
  {
    auto _mls_x344 = _mlsValue::create<_mls_Red>();
    auto _mls_x345 = _mlsValue::create<_mls_Leaf>();
    auto _mls_x346 = _mlsValue::create<_mls_Leaf>();
    auto _mls_x347 = _mlsValue::create<_mls_Node>(_mls_x344, _mls_x345, _mls_x265, _mls_x266, _mls_x346);
    _mls_retval = _mls_x347;
    return _mls_retval;
  }
  _mls_ins_case1_sr_post:
  {
    if (_mlsValue::isValueOf<_mls_Red>(_mls_x270)) {
      _mls_x274 = _mls_x271;
      _mls_x275 = _mls_x273;
      _mls_x276 = _mls_x272;
      _mls_x277 = _mls_x268;
      _mls_x278 = _mls_x267;
      _mls_x279 = _mls_x269;
      goto _mls_ins_case1_sr_post_case0;
    } else if (_mlsValue::isValueOf<_mls_Black>(_mls_x270)) {
      _mls_x280 = _mls_x271;
      _mls_x281 = _mls_x273;
      _mls_x282 = _mls_x272;
      _mls_x283 = _mls_x268;
      _mls_x284 = _mls_x267;
      _mls_x285 = _mls_x269;
      goto _mls_ins_case1_sr_post_case1;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_ins_case1_sr_post_case0:
  {
    auto _mls_x348 = (_mls_x276 < _mls_x274);
    if (_mlsValue::isIntLit(_mls_x348, 1)) {
      auto _mls_x355 = _mls_ins(_mls_x276, _mls_x277, _mls_x275);
      auto _mls_x356 = _mlsValue::create<_mls_Red>();
      auto _mls_x357 = _mlsValue::create<_mls_Node>(_mls_x356, _mls_x355, _mls_x274, _mls_x279, _mls_x278);
      _mls_retval = _mls_x357;
    } else {
      auto _mls_x349 = (_mls_x276 == _mls_x274);
      if (_mlsValue::isIntLit(_mls_x349, 1)) {
        auto _mls_x353 = _mlsValue::create<_mls_Red>();
        auto _mls_x354 = _mlsValue::create<_mls_Node>(_mls_x353, _mls_x275, _mls_x276, _mls_x277, _mls_x278);
        _mls_retval = _mls_x354;
      } else {
        auto _mls_x350 = _mls_ins(_mls_x276, _mls_x277, _mls_x278);
        auto _mls_x351 = _mlsValue::create<_mls_Red>();
        auto _mls_x352 = _mlsValue::create<_mls_Node>(_mls_x351, _mls_x275, _mls_x274, _mls_x279, _mls_x350);
        _mls_retval = _mls_x352;
      }
    }
    return _mls_retval;
  }
  _mls_ins_case1_sr_post_case1:
  {
    auto [_mls_x358, _mls_x359, _mls_x360, _mls_x361, _mls_x362, _mls_x363, _mls_x364] = _mls_ins_case1_sr_post_case1_pre(_mls_x280, _mls_x281, _mls_x282, _mls_x283, _mls_x284, _mls_x285);
    if (_mlsValue::isIntLit(_mls_x360, 1)) {
      _mls_x286 = _mls_x358;
      _mls_x287 = _mls_x359;
      _mls_x288 = _mls_x361;
      _mls_x289 = _mls_x362;
      _mls_x290 = _mls_x363;
      _mls_x291 = _mls_x364;
      goto _mls_ins_case1_sr_post_case1_case0;
    } else {
      _mls_x292 = _mls_x358;
      _mls_x293 = _mls_x359;
      _mls_x294 = _mls_x361;
      _mls_x295 = _mls_x362;
      _mls_x296 = _mls_x363;
      _mls_x297 = _mls_x364;
      goto _mls_ins_case1_sr_post_case1_default;
    }
    return _mls_retval;
  }
  _mls_ins_case1_sr_post_case1_case0:
  {
    if (_mlsValue::isValueOf<_mls_Node>(_mls_x288)) {
      auto _mls_x365 = _mlsValue::cast<_mls_Node>(_mls_x288)->_mls_color;
      if (_mlsValue::isValueOf<_mls_Red>(_mls_x365)) {
        _mls_x298 = _mls_x286;
        _mls_x299 = _mls_x290;
        _mls_x300 = _mls_x288;
        _mls_x301 = _mls_x289;
        _mls_x302 = _mls_x291;
        _mls_x303 = _mls_x287;
        _mls_x304 = _mlsValue::fromIntLit(1);
        goto _mls_ins_caller_post;
      } else {
        _mls_x298 = _mls_x286;
        _mls_x299 = _mls_x290;
        _mls_x300 = _mls_x288;
        _mls_x301 = _mls_x289;
        _mls_x302 = _mls_x291;
        _mls_x303 = _mls_x287;
        _mls_x304 = _mlsValue::fromIntLit(0);
        goto _mls_ins_caller_post;
      }
    } else {
      _mls_x305 = _mls_x290;
      _mls_x306 = _mls_x289;
      _mls_x307 = _mls_x287;
      _mls_x308 = _mls_x286;
      _mls_x309 = _mls_x291;
      _mls_x310 = _mls_x288;
      goto _mls_ins_caller_post_default;
    }
    return _mls_retval;
  }
  _mls_ins_case1_sr_post_case1_default:
  {
    auto _mls_x366 = (_mls_x297 == _mls_x293);
    if (_mlsValue::isIntLit(_mls_x366, 1)) {
      auto _mls_x368 = _mlsValue::create<_mls_Black>();
      auto _mls_x369 = _mlsValue::create<_mls_Node>(_mls_x368, _mls_x294, _mls_x297, _mls_x296, _mls_x292);
      _mls_retval = _mls_x369;
    } else {
      if (_mlsValue::isValueOf<_mls_Node>(_mls_x292)) {
        auto _mls_x367 = _mlsValue::cast<_mls_Node>(_mls_x292)->_mls_color;
        if (_mlsValue::isValueOf<_mls_Red>(_mls_x367)) {
          _mls_x311 = _mlsValue::fromIntLit(1);
          _mls_x312 = _mls_x292;
          _mls_x313 = _mls_x296;
          _mls_x314 = _mls_x293;
          _mls_x315 = _mls_x294;
          _mls_x316 = _mls_x295;
          _mls_x317 = _mls_x297;
          goto _mls_ins_caller_post1;
        } else {
          _mls_x311 = _mlsValue::fromIntLit(0);
          _mls_x312 = _mls_x292;
          _mls_x313 = _mls_x296;
          _mls_x314 = _mls_x293;
          _mls_x315 = _mls_x294;
          _mls_x316 = _mls_x295;
          _mls_x317 = _mls_x297;
          goto _mls_ins_caller_post1;
        }
      } else {
        _mls_x318 = _mls_x292;
        _mls_x319 = _mls_x294;
        _mls_x320 = _mls_x293;
        _mls_x321 = _mls_x296;
        _mls_x322 = _mls_x295;
        _mls_x323 = _mls_x297;
        goto _mls_ins_caller_post_default1;
      }
    }
    return _mls_retval;
  }
  _mls_ins_caller_post:
  {
    if (_mlsValue::isIntLit(_mls_x304, 1)) {
      _mls_x324 = _mls_x299;
      _mls_x325 = _mls_x301;
      _mls_x326 = _mls_x303;
      _mls_x327 = _mls_x298;
      _mls_x328 = _mls_x302;
      _mls_x329 = _mls_x300;
      goto _mls_ins_caller_post_case0;
    } else {
      _mls_x305 = _mls_x299;
      _mls_x306 = _mls_x301;
      _mls_x307 = _mls_x303;
      _mls_x308 = _mls_x298;
      _mls_x309 = _mls_x302;
      _mls_x310 = _mls_x300;
      goto _mls_ins_caller_post_default;
    }
    return _mls_retval;
  }
  _mls_ins_caller_post_default:
  {
    auto _mls_x370 = _mls_ins(_mls_x309, _mls_x305, _mls_x310);
    auto _mls_x371 = _mlsValue::create<_mls_Black>();
    auto _mls_x372 = _mlsValue::create<_mls_Node>(_mls_x371, _mls_x370, _mls_x307, _mls_x306, _mls_x308);
    _mls_retval = _mls_x372;
    return _mls_retval;
  }
  _mls_ins_caller_post1:
  {
    if (_mlsValue::isIntLit(_mls_x311, 1)) {
      _mls_x330 = _mls_x312;
      _mls_x331 = _mls_x315;
      _mls_x332 = _mls_x314;
      _mls_x333 = _mls_x313;
      _mls_x334 = _mls_x316;
      _mls_x335 = _mls_x317;
      goto _mls_ins_caller_post_case01;
    } else {
      _mls_x318 = _mls_x312;
      _mls_x319 = _mls_x315;
      _mls_x320 = _mls_x314;
      _mls_x321 = _mls_x313;
      _mls_x322 = _mls_x316;
      _mls_x323 = _mls_x317;
      goto _mls_ins_caller_post_default1;
    }
    return _mls_retval;
  }
  _mls_ins_caller_post_default1:
  {
    auto _mls_x373 = _mls_ins(_mls_x323, _mls_x321, _mls_x318);
    auto _mls_x374 = _mlsValue::create<_mls_Black>();
    auto _mls_x375 = _mlsValue::create<_mls_Node>(_mls_x374, _mls_x319, _mls_x320, _mls_x322, _mls_x373);
    _mls_retval = _mls_x375;
    return _mls_retval;
  }
  _mls_ins_caller_post_case0:
  {
    auto _mls_x376 = _mls_ins(_mls_x328, _mls_x324, _mls_x327);
    auto _mls_x377 = _mls_balance1(_mls_x326, _mls_x325, _mls_x376, _mls_x329);
    _mls_retval = _mls_x377;
    return _mls_retval;
  }
  _mls_ins_caller_post_case01:
  {
    if (_mlsValue::isValueOf<_mls_Leaf>(_mls_x330)) {
      auto _mls_x396 = _mls_ins_case0(_mls_x335, _mls_x333);
      auto _mls_x397 = _mlsValue::cast<_mls_Node>(_mls_x396)->_mls_left;
      auto _mls_x398 = _mlsValue::cast<_mls_Node>(_mls_x396)->_mls_key;
      auto _mls_x399 = _mlsValue::cast<_mls_Node>(_mls_x396)->_mls_value;
      auto _mls_x400 = _mlsValue::cast<_mls_Node>(_mls_x396)->_mls_right;
      auto _mls_x401 = _mls_balance2_case0_sr_post(_mls_x331, _mls_x400, _mls_x397, _mls_x398, _mls_x334, _mls_x332, _mls_x399);
      _mls_retval = _mls_x401;
    } else if (_mlsValue::isValueOf<_mls_Node>(_mls_x330)) {
      auto _mls_x378 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_color;
      auto _mls_x379 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_left;
      auto _mls_x380 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_key;
      auto _mls_x381 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_value;
      auto _mls_x382 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_right;
      if (_mlsValue::isValueOf<_mls_Red>(_mls_x378)) {
        auto _mls_x394 = _mls_ins_case1_sr_post_case0(_mls_x380, _mls_x379, _mls_x335, _mls_x333, _mls_x382, _mls_x381);
        auto _mls_x395 = _mls_balance2_case0(_mls_x394, _mls_x331, _mls_x334, _mls_x332);
        _mls_retval = _mls_x395;
      } else if (_mlsValue::isValueOf<_mls_Black>(_mls_x378)) {
        auto [_mls_x383, _mls_x384, _mls_x385, _mls_x386, _mls_x387, _mls_x388, _mls_x389] = _mls_ins_case1_sr_post_case1_pre(_mls_x380, _mls_x379, _mls_x335, _mls_x333, _mls_x382, _mls_x381);
        if (_mlsValue::isIntLit(_mls_x385, 1)) {
          auto _mls_x392 = _mls_ins_case1_sr_post_case1_case0(_mls_x383, _mls_x384, _mls_x386, _mls_x387, _mls_x388, _mls_x389);
          auto _mls_x393 = _mls_balance2(_mls_x331, _mls_x332, _mls_x334, _mls_x392);
          _mls_retval = _mls_x393;
        } else {
          auto _mls_x390 = _mls_ins_case1_sr_post_case1_default(_mls_x383, _mls_x384, _mls_x386, _mls_x387, _mls_x388, _mls_x389);
          auto _mls_x391 = _mls_balance2(_mls_x331, _mls_x332, _mls_x334, _mls_x390);
          _mls_retval = _mls_x391;
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_ins_caller_post(_mlsValue _mls_x298, _mlsValue _mls_x299, _mlsValue _mls_x300, _mlsValue _mls_x301, _mlsValue _mls_x302, _mlsValue _mls_x303, _mlsValue _mls_x304) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x324, _mls_x325, _mls_x326, _mls_x327, _mls_x328, _mls_x329;
  _mlsValue _mls_x305, _mls_x306, _mls_x307, _mls_x308, _mls_x309, _mls_x310;
  if (_mlsValue::isIntLit(_mls_x304, 1)) {
    _mls_x324 = _mls_x299;
    _mls_x325 = _mls_x301;
    _mls_x326 = _mls_x303;
    _mls_x327 = _mls_x298;
    _mls_x328 = _mls_x302;
    _mls_x329 = _mls_x300;
    goto _mls_ins_caller_post_case0;
  } else {
    _mls_x305 = _mls_x299;
    _mls_x306 = _mls_x301;
    _mls_x307 = _mls_x303;
    _mls_x308 = _mls_x298;
    _mls_x309 = _mls_x302;
    _mls_x310 = _mls_x300;
    goto _mls_ins_caller_post_default;
  }
  return _mls_retval;
  _mls_ins_caller_post_case0:
  {
    auto _mls_x376 = _mls_ins(_mls_x328, _mls_x324, _mls_x327);
    auto _mls_x377 = _mls_balance1(_mls_x326, _mls_x325, _mls_x376, _mls_x329);
    _mls_retval = _mls_x377;
    return _mls_retval;
  }
  _mls_ins_caller_post_default:
  {
    auto _mls_x370 = _mls_ins(_mls_x309, _mls_x305, _mls_x310);
    auto _mls_x371 = _mlsValue::create<_mls_Black>();
    auto _mls_x372 = _mlsValue::create<_mls_Node>(_mls_x371, _mls_x370, _mls_x307, _mls_x306, _mls_x308);
    _mls_retval = _mls_x372;
    return _mls_retval;
  }
}
_mlsValue _mls_ins_caller_post1(_mlsValue _mls_x311, _mlsValue _mls_x312, _mlsValue _mls_x313, _mlsValue _mls_x314, _mlsValue _mls_x315, _mlsValue _mls_x316, _mlsValue _mls_x317) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x330, _mls_x331, _mls_x332, _mls_x333, _mls_x334, _mls_x335;
  _mlsValue _mls_x318, _mls_x319, _mls_x320, _mls_x321, _mls_x322, _mls_x323;
  if (_mlsValue::isIntLit(_mls_x311, 1)) {
    _mls_x330 = _mls_x312;
    _mls_x331 = _mls_x315;
    _mls_x332 = _mls_x314;
    _mls_x333 = _mls_x313;
    _mls_x334 = _mls_x316;
    _mls_x335 = _mls_x317;
    goto _mls_ins_caller_post_case01;
  } else {
    _mls_x318 = _mls_x312;
    _mls_x319 = _mls_x315;
    _mls_x320 = _mls_x314;
    _mls_x321 = _mls_x313;
    _mls_x322 = _mls_x316;
    _mls_x323 = _mls_x317;
    goto _mls_ins_caller_post_default1;
  }
  return _mls_retval;
  _mls_ins_caller_post_case01:
  {
    if (_mlsValue::isValueOf<_mls_Leaf>(_mls_x330)) {
      auto _mls_x396 = _mls_ins_case0(_mls_x335, _mls_x333);
      auto _mls_x397 = _mlsValue::cast<_mls_Node>(_mls_x396)->_mls_left;
      auto _mls_x398 = _mlsValue::cast<_mls_Node>(_mls_x396)->_mls_key;
      auto _mls_x399 = _mlsValue::cast<_mls_Node>(_mls_x396)->_mls_value;
      auto _mls_x400 = _mlsValue::cast<_mls_Node>(_mls_x396)->_mls_right;
      auto _mls_x401 = _mls_balance2_case0_sr_post(_mls_x331, _mls_x400, _mls_x397, _mls_x398, _mls_x334, _mls_x332, _mls_x399);
      _mls_retval = _mls_x401;
    } else if (_mlsValue::isValueOf<_mls_Node>(_mls_x330)) {
      auto _mls_x378 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_color;
      auto _mls_x379 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_left;
      auto _mls_x380 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_key;
      auto _mls_x381 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_value;
      auto _mls_x382 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_right;
      if (_mlsValue::isValueOf<_mls_Red>(_mls_x378)) {
        auto _mls_x394 = _mls_ins_case1_sr_post_case0(_mls_x380, _mls_x379, _mls_x335, _mls_x333, _mls_x382, _mls_x381);
        auto _mls_x395 = _mls_balance2_case0(_mls_x394, _mls_x331, _mls_x334, _mls_x332);
        _mls_retval = _mls_x395;
      } else if (_mlsValue::isValueOf<_mls_Black>(_mls_x378)) {
        auto [_mls_x383, _mls_x384, _mls_x385, _mls_x386, _mls_x387, _mls_x388, _mls_x389] = _mls_ins_case1_sr_post_case1_pre(_mls_x380, _mls_x379, _mls_x335, _mls_x333, _mls_x382, _mls_x381);
        if (_mlsValue::isIntLit(_mls_x385, 1)) {
          auto _mls_x392 = _mls_ins_case1_sr_post_case1_case0(_mls_x383, _mls_x384, _mls_x386, _mls_x387, _mls_x388, _mls_x389);
          auto _mls_x393 = _mls_balance2(_mls_x331, _mls_x332, _mls_x334, _mls_x392);
          _mls_retval = _mls_x393;
        } else {
          auto _mls_x390 = _mls_ins_case1_sr_post_case1_default(_mls_x383, _mls_x384, _mls_x386, _mls_x387, _mls_x388, _mls_x389);
          auto _mls_x391 = _mls_balance2(_mls_x331, _mls_x332, _mls_x334, _mls_x390);
          _mls_retval = _mls_x391;
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
  _mls_ins_caller_post_default1:
  {
    auto _mls_x373 = _mls_ins(_mls_x323, _mls_x321, _mls_x318);
    auto _mls_x374 = _mlsValue::create<_mls_Black>();
    auto _mls_x375 = _mlsValue::create<_mls_Node>(_mls_x374, _mls_x319, _mls_x320, _mls_x322, _mls_x373);
    _mls_retval = _mls_x375;
    return _mls_retval;
  }
}
_mlsValue _mls_ins_caller_post_case0(_mlsValue _mls_x324, _mlsValue _mls_x325, _mlsValue _mls_x326, _mlsValue _mls_x327, _mlsValue _mls_x328, _mlsValue _mls_x329) {
  _mlsValue _mls_retval;
  auto _mls_x376 = _mls_ins(_mls_x328, _mls_x324, _mls_x327);
  auto _mls_x377 = _mls_balance1(_mls_x326, _mls_x325, _mls_x376, _mls_x329);
  _mls_retval = _mls_x377;
  return _mls_retval;
}
_mlsValue _mls_ins_caller_post_case01(_mlsValue _mls_x330, _mlsValue _mls_x331, _mlsValue _mls_x332, _mlsValue _mls_x333, _mlsValue _mls_x334, _mlsValue _mls_x335) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Leaf>(_mls_x330)) {
    auto _mls_x396 = _mls_ins_case0(_mls_x335, _mls_x333);
    auto _mls_x397 = _mlsValue::cast<_mls_Node>(_mls_x396)->_mls_left;
    auto _mls_x398 = _mlsValue::cast<_mls_Node>(_mls_x396)->_mls_key;
    auto _mls_x399 = _mlsValue::cast<_mls_Node>(_mls_x396)->_mls_value;
    auto _mls_x400 = _mlsValue::cast<_mls_Node>(_mls_x396)->_mls_right;
    auto _mls_x401 = _mls_balance2_case0_sr_post(_mls_x331, _mls_x400, _mls_x397, _mls_x398, _mls_x334, _mls_x332, _mls_x399);
    _mls_retval = _mls_x401;
  } else if (_mlsValue::isValueOf<_mls_Node>(_mls_x330)) {
    auto _mls_x378 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_color;
    auto _mls_x379 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_left;
    auto _mls_x380 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_key;
    auto _mls_x381 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_value;
    auto _mls_x382 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_right;
    if (_mlsValue::isValueOf<_mls_Red>(_mls_x378)) {
      auto _mls_x394 = _mls_ins_case1_sr_post_case0(_mls_x380, _mls_x379, _mls_x335, _mls_x333, _mls_x382, _mls_x381);
      auto _mls_x395 = _mls_balance2_case0(_mls_x394, _mls_x331, _mls_x334, _mls_x332);
      _mls_retval = _mls_x395;
    } else if (_mlsValue::isValueOf<_mls_Black>(_mls_x378)) {
      auto [_mls_x383, _mls_x384, _mls_x385, _mls_x386, _mls_x387, _mls_x388, _mls_x389] = _mls_ins_case1_sr_post_case1_pre(_mls_x380, _mls_x379, _mls_x335, _mls_x333, _mls_x382, _mls_x381);
      if (_mlsValue::isIntLit(_mls_x385, 1)) {
        auto _mls_x392 = _mls_ins_case1_sr_post_case1_case0(_mls_x383, _mls_x384, _mls_x386, _mls_x387, _mls_x388, _mls_x389);
        auto _mls_x393 = _mls_balance2(_mls_x331, _mls_x332, _mls_x334, _mls_x392);
        _mls_retval = _mls_x393;
      } else {
        auto _mls_x390 = _mls_ins_case1_sr_post_case1_default(_mls_x383, _mls_x384, _mls_x386, _mls_x387, _mls_x388, _mls_x389);
        auto _mls_x391 = _mls_balance2(_mls_x331, _mls_x332, _mls_x334, _mls_x390);
        _mls_retval = _mls_x391;
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_ins_caller_post_default(_mlsValue _mls_x305, _mlsValue _mls_x306, _mlsValue _mls_x307, _mlsValue _mls_x308, _mlsValue _mls_x309, _mlsValue _mls_x310) {
  _mlsValue _mls_retval;
  auto _mls_x370 = _mls_ins(_mls_x309, _mls_x305, _mls_x310);
  auto _mls_x371 = _mlsValue::create<_mls_Black>();
  auto _mls_x372 = _mlsValue::create<_mls_Node>(_mls_x371, _mls_x370, _mls_x307, _mls_x306, _mls_x308);
  _mls_retval = _mls_x372;
  return _mls_retval;
}
_mlsValue _mls_ins_caller_post_default1(_mlsValue _mls_x318, _mlsValue _mls_x319, _mlsValue _mls_x320, _mlsValue _mls_x321, _mlsValue _mls_x322, _mlsValue _mls_x323) {
  _mlsValue _mls_retval;
  auto _mls_x373 = _mls_ins(_mls_x323, _mls_x321, _mls_x318);
  auto _mls_x374 = _mlsValue::create<_mls_Black>();
  auto _mls_x375 = _mlsValue::create<_mls_Node>(_mls_x374, _mls_x319, _mls_x320, _mls_x322, _mls_x373);
  _mls_retval = _mls_x375;
  return _mls_retval;
}
_mlsValue _mls_ins_case0(_mlsValue _mls_x265, _mlsValue _mls_x266) {
  _mlsValue _mls_retval;
  auto _mls_x344 = _mlsValue::create<_mls_Red>();
  auto _mls_x345 = _mlsValue::create<_mls_Leaf>();
  auto _mls_x346 = _mlsValue::create<_mls_Leaf>();
  auto _mls_x347 = _mlsValue::create<_mls_Node>(_mls_x344, _mls_x345, _mls_x265, _mls_x266, _mls_x346);
  _mls_retval = _mls_x347;
  return _mls_retval;
}
_mlsValue _mls_ins_case1_sr_post(_mlsValue _mls_x267, _mlsValue _mls_x268, _mlsValue _mls_x269, _mlsValue _mls_x270, _mlsValue _mls_x271, _mlsValue _mls_x272, _mlsValue _mls_x273) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x274, _mls_x275, _mls_x276, _mls_x277, _mls_x278, _mls_x279;
  _mlsValue _mls_x280, _mls_x281, _mls_x282, _mls_x283, _mls_x284, _mls_x285;
  _mlsValue _mls_x286, _mls_x287, _mls_x288, _mls_x289, _mls_x290, _mls_x291;
  _mlsValue _mls_x292, _mls_x293, _mls_x294, _mls_x295, _mls_x296, _mls_x297;
  _mlsValue _mls_x298, _mls_x299, _mls_x300, _mls_x301, _mls_x302, _mls_x303, _mls_x304;
  _mlsValue _mls_x305, _mls_x306, _mls_x307, _mls_x308, _mls_x309, _mls_x310;
  _mlsValue _mls_x311, _mls_x312, _mls_x313, _mls_x314, _mls_x315, _mls_x316, _mls_x317;
  _mlsValue _mls_x318, _mls_x319, _mls_x320, _mls_x321, _mls_x322, _mls_x323;
  _mlsValue _mls_x324, _mls_x325, _mls_x326, _mls_x327, _mls_x328, _mls_x329;
  _mlsValue _mls_x330, _mls_x331, _mls_x332, _mls_x333, _mls_x334, _mls_x335;
  if (_mlsValue::isValueOf<_mls_Red>(_mls_x270)) {
    _mls_x274 = _mls_x271;
    _mls_x275 = _mls_x273;
    _mls_x276 = _mls_x272;
    _mls_x277 = _mls_x268;
    _mls_x278 = _mls_x267;
    _mls_x279 = _mls_x269;
    goto _mls_ins_case1_sr_post_case0;
  } else if (_mlsValue::isValueOf<_mls_Black>(_mls_x270)) {
    _mls_x280 = _mls_x271;
    _mls_x281 = _mls_x273;
    _mls_x282 = _mls_x272;
    _mls_x283 = _mls_x268;
    _mls_x284 = _mls_x267;
    _mls_x285 = _mls_x269;
    goto _mls_ins_case1_sr_post_case1;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_ins_case1_sr_post_case0:
  {
    auto _mls_x348 = (_mls_x276 < _mls_x274);
    if (_mlsValue::isIntLit(_mls_x348, 1)) {
      auto _mls_x355 = _mls_ins(_mls_x276, _mls_x277, _mls_x275);
      auto _mls_x356 = _mlsValue::create<_mls_Red>();
      auto _mls_x357 = _mlsValue::create<_mls_Node>(_mls_x356, _mls_x355, _mls_x274, _mls_x279, _mls_x278);
      _mls_retval = _mls_x357;
    } else {
      auto _mls_x349 = (_mls_x276 == _mls_x274);
      if (_mlsValue::isIntLit(_mls_x349, 1)) {
        auto _mls_x353 = _mlsValue::create<_mls_Red>();
        auto _mls_x354 = _mlsValue::create<_mls_Node>(_mls_x353, _mls_x275, _mls_x276, _mls_x277, _mls_x278);
        _mls_retval = _mls_x354;
      } else {
        auto _mls_x350 = _mls_ins(_mls_x276, _mls_x277, _mls_x278);
        auto _mls_x351 = _mlsValue::create<_mls_Red>();
        auto _mls_x352 = _mlsValue::create<_mls_Node>(_mls_x351, _mls_x275, _mls_x274, _mls_x279, _mls_x350);
        _mls_retval = _mls_x352;
      }
    }
    return _mls_retval;
  }
  _mls_ins_case1_sr_post_case1:
  {
    auto [_mls_x358, _mls_x359, _mls_x360, _mls_x361, _mls_x362, _mls_x363, _mls_x364] = _mls_ins_case1_sr_post_case1_pre(_mls_x280, _mls_x281, _mls_x282, _mls_x283, _mls_x284, _mls_x285);
    if (_mlsValue::isIntLit(_mls_x360, 1)) {
      _mls_x286 = _mls_x358;
      _mls_x287 = _mls_x359;
      _mls_x288 = _mls_x361;
      _mls_x289 = _mls_x362;
      _mls_x290 = _mls_x363;
      _mls_x291 = _mls_x364;
      goto _mls_ins_case1_sr_post_case1_case0;
    } else {
      _mls_x292 = _mls_x358;
      _mls_x293 = _mls_x359;
      _mls_x294 = _mls_x361;
      _mls_x295 = _mls_x362;
      _mls_x296 = _mls_x363;
      _mls_x297 = _mls_x364;
      goto _mls_ins_case1_sr_post_case1_default;
    }
    return _mls_retval;
  }
  _mls_ins_case1_sr_post_case1_case0:
  {
    if (_mlsValue::isValueOf<_mls_Node>(_mls_x288)) {
      auto _mls_x365 = _mlsValue::cast<_mls_Node>(_mls_x288)->_mls_color;
      if (_mlsValue::isValueOf<_mls_Red>(_mls_x365)) {
        _mls_x298 = _mls_x286;
        _mls_x299 = _mls_x290;
        _mls_x300 = _mls_x288;
        _mls_x301 = _mls_x289;
        _mls_x302 = _mls_x291;
        _mls_x303 = _mls_x287;
        _mls_x304 = _mlsValue::fromIntLit(1);
        goto _mls_ins_caller_post;
      } else {
        _mls_x298 = _mls_x286;
        _mls_x299 = _mls_x290;
        _mls_x300 = _mls_x288;
        _mls_x301 = _mls_x289;
        _mls_x302 = _mls_x291;
        _mls_x303 = _mls_x287;
        _mls_x304 = _mlsValue::fromIntLit(0);
        goto _mls_ins_caller_post;
      }
    } else {
      _mls_x305 = _mls_x290;
      _mls_x306 = _mls_x289;
      _mls_x307 = _mls_x287;
      _mls_x308 = _mls_x286;
      _mls_x309 = _mls_x291;
      _mls_x310 = _mls_x288;
      goto _mls_ins_caller_post_default;
    }
    return _mls_retval;
  }
  _mls_ins_case1_sr_post_case1_default:
  {
    auto _mls_x366 = (_mls_x297 == _mls_x293);
    if (_mlsValue::isIntLit(_mls_x366, 1)) {
      auto _mls_x368 = _mlsValue::create<_mls_Black>();
      auto _mls_x369 = _mlsValue::create<_mls_Node>(_mls_x368, _mls_x294, _mls_x297, _mls_x296, _mls_x292);
      _mls_retval = _mls_x369;
    } else {
      if (_mlsValue::isValueOf<_mls_Node>(_mls_x292)) {
        auto _mls_x367 = _mlsValue::cast<_mls_Node>(_mls_x292)->_mls_color;
        if (_mlsValue::isValueOf<_mls_Red>(_mls_x367)) {
          _mls_x311 = _mlsValue::fromIntLit(1);
          _mls_x312 = _mls_x292;
          _mls_x313 = _mls_x296;
          _mls_x314 = _mls_x293;
          _mls_x315 = _mls_x294;
          _mls_x316 = _mls_x295;
          _mls_x317 = _mls_x297;
          goto _mls_ins_caller_post1;
        } else {
          _mls_x311 = _mlsValue::fromIntLit(0);
          _mls_x312 = _mls_x292;
          _mls_x313 = _mls_x296;
          _mls_x314 = _mls_x293;
          _mls_x315 = _mls_x294;
          _mls_x316 = _mls_x295;
          _mls_x317 = _mls_x297;
          goto _mls_ins_caller_post1;
        }
      } else {
        _mls_x318 = _mls_x292;
        _mls_x319 = _mls_x294;
        _mls_x320 = _mls_x293;
        _mls_x321 = _mls_x296;
        _mls_x322 = _mls_x295;
        _mls_x323 = _mls_x297;
        goto _mls_ins_caller_post_default1;
      }
    }
    return _mls_retval;
  }
  _mls_ins_caller_post:
  {
    if (_mlsValue::isIntLit(_mls_x304, 1)) {
      _mls_x324 = _mls_x299;
      _mls_x325 = _mls_x301;
      _mls_x326 = _mls_x303;
      _mls_x327 = _mls_x298;
      _mls_x328 = _mls_x302;
      _mls_x329 = _mls_x300;
      goto _mls_ins_caller_post_case0;
    } else {
      _mls_x305 = _mls_x299;
      _mls_x306 = _mls_x301;
      _mls_x307 = _mls_x303;
      _mls_x308 = _mls_x298;
      _mls_x309 = _mls_x302;
      _mls_x310 = _mls_x300;
      goto _mls_ins_caller_post_default;
    }
    return _mls_retval;
  }
  _mls_ins_caller_post_default:
  {
    auto _mls_x370 = _mls_ins(_mls_x309, _mls_x305, _mls_x310);
    auto _mls_x371 = _mlsValue::create<_mls_Black>();
    auto _mls_x372 = _mlsValue::create<_mls_Node>(_mls_x371, _mls_x370, _mls_x307, _mls_x306, _mls_x308);
    _mls_retval = _mls_x372;
    return _mls_retval;
  }
  _mls_ins_caller_post1:
  {
    if (_mlsValue::isIntLit(_mls_x311, 1)) {
      _mls_x330 = _mls_x312;
      _mls_x331 = _mls_x315;
      _mls_x332 = _mls_x314;
      _mls_x333 = _mls_x313;
      _mls_x334 = _mls_x316;
      _mls_x335 = _mls_x317;
      goto _mls_ins_caller_post_case01;
    } else {
      _mls_x318 = _mls_x312;
      _mls_x319 = _mls_x315;
      _mls_x320 = _mls_x314;
      _mls_x321 = _mls_x313;
      _mls_x322 = _mls_x316;
      _mls_x323 = _mls_x317;
      goto _mls_ins_caller_post_default1;
    }
    return _mls_retval;
  }
  _mls_ins_caller_post_default1:
  {
    auto _mls_x373 = _mls_ins(_mls_x323, _mls_x321, _mls_x318);
    auto _mls_x374 = _mlsValue::create<_mls_Black>();
    auto _mls_x375 = _mlsValue::create<_mls_Node>(_mls_x374, _mls_x319, _mls_x320, _mls_x322, _mls_x373);
    _mls_retval = _mls_x375;
    return _mls_retval;
  }
  _mls_ins_caller_post_case0:
  {
    auto _mls_x376 = _mls_ins(_mls_x328, _mls_x324, _mls_x327);
    auto _mls_x377 = _mls_balance1(_mls_x326, _mls_x325, _mls_x376, _mls_x329);
    _mls_retval = _mls_x377;
    return _mls_retval;
  }
  _mls_ins_caller_post_case01:
  {
    if (_mlsValue::isValueOf<_mls_Leaf>(_mls_x330)) {
      auto _mls_x396 = _mls_ins_case0(_mls_x335, _mls_x333);
      auto _mls_x397 = _mlsValue::cast<_mls_Node>(_mls_x396)->_mls_left;
      auto _mls_x398 = _mlsValue::cast<_mls_Node>(_mls_x396)->_mls_key;
      auto _mls_x399 = _mlsValue::cast<_mls_Node>(_mls_x396)->_mls_value;
      auto _mls_x400 = _mlsValue::cast<_mls_Node>(_mls_x396)->_mls_right;
      auto _mls_x401 = _mls_balance2_case0_sr_post(_mls_x331, _mls_x400, _mls_x397, _mls_x398, _mls_x334, _mls_x332, _mls_x399);
      _mls_retval = _mls_x401;
    } else if (_mlsValue::isValueOf<_mls_Node>(_mls_x330)) {
      auto _mls_x378 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_color;
      auto _mls_x379 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_left;
      auto _mls_x380 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_key;
      auto _mls_x381 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_value;
      auto _mls_x382 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_right;
      if (_mlsValue::isValueOf<_mls_Red>(_mls_x378)) {
        auto _mls_x394 = _mls_ins_case1_sr_post_case0(_mls_x380, _mls_x379, _mls_x335, _mls_x333, _mls_x382, _mls_x381);
        auto _mls_x395 = _mls_balance2_case0(_mls_x394, _mls_x331, _mls_x334, _mls_x332);
        _mls_retval = _mls_x395;
      } else if (_mlsValue::isValueOf<_mls_Black>(_mls_x378)) {
        auto [_mls_x383, _mls_x384, _mls_x385, _mls_x386, _mls_x387, _mls_x388, _mls_x389] = _mls_ins_case1_sr_post_case1_pre(_mls_x380, _mls_x379, _mls_x335, _mls_x333, _mls_x382, _mls_x381);
        if (_mlsValue::isIntLit(_mls_x385, 1)) {
          auto _mls_x392 = _mls_ins_case1_sr_post_case1_case0(_mls_x383, _mls_x384, _mls_x386, _mls_x387, _mls_x388, _mls_x389);
          auto _mls_x393 = _mls_balance2(_mls_x331, _mls_x332, _mls_x334, _mls_x392);
          _mls_retval = _mls_x393;
        } else {
          auto _mls_x390 = _mls_ins_case1_sr_post_case1_default(_mls_x383, _mls_x384, _mls_x386, _mls_x387, _mls_x388, _mls_x389);
          auto _mls_x391 = _mls_balance2(_mls_x331, _mls_x332, _mls_x334, _mls_x390);
          _mls_retval = _mls_x391;
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_ins_case1_sr_post_case0(_mlsValue _mls_x274, _mlsValue _mls_x275, _mlsValue _mls_x276, _mlsValue _mls_x277, _mlsValue _mls_x278, _mlsValue _mls_x279) {
  _mlsValue _mls_retval;
  auto _mls_x348 = (_mls_x276 < _mls_x274);
  if (_mlsValue::isIntLit(_mls_x348, 1)) {
    auto _mls_x355 = _mls_ins(_mls_x276, _mls_x277, _mls_x275);
    auto _mls_x356 = _mlsValue::create<_mls_Red>();
    auto _mls_x357 = _mlsValue::create<_mls_Node>(_mls_x356, _mls_x355, _mls_x274, _mls_x279, _mls_x278);
    _mls_retval = _mls_x357;
  } else {
    auto _mls_x349 = (_mls_x276 == _mls_x274);
    if (_mlsValue::isIntLit(_mls_x349, 1)) {
      auto _mls_x353 = _mlsValue::create<_mls_Red>();
      auto _mls_x354 = _mlsValue::create<_mls_Node>(_mls_x353, _mls_x275, _mls_x276, _mls_x277, _mls_x278);
      _mls_retval = _mls_x354;
    } else {
      auto _mls_x350 = _mls_ins(_mls_x276, _mls_x277, _mls_x278);
      auto _mls_x351 = _mlsValue::create<_mls_Red>();
      auto _mls_x352 = _mlsValue::create<_mls_Node>(_mls_x351, _mls_x275, _mls_x274, _mls_x279, _mls_x350);
      _mls_retval = _mls_x352;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_ins_case1_sr_post_case1(_mlsValue _mls_x280, _mlsValue _mls_x281, _mlsValue _mls_x282, _mlsValue _mls_x283, _mlsValue _mls_x284, _mlsValue _mls_x285) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x286, _mls_x287, _mls_x288, _mls_x289, _mls_x290, _mls_x291;
  _mlsValue _mls_x292, _mls_x293, _mls_x294, _mls_x295, _mls_x296, _mls_x297;
  _mlsValue _mls_x298, _mls_x299, _mls_x300, _mls_x301, _mls_x302, _mls_x303, _mls_x304;
  _mlsValue _mls_x305, _mls_x306, _mls_x307, _mls_x308, _mls_x309, _mls_x310;
  _mlsValue _mls_x311, _mls_x312, _mls_x313, _mls_x314, _mls_x315, _mls_x316, _mls_x317;
  _mlsValue _mls_x318, _mls_x319, _mls_x320, _mls_x321, _mls_x322, _mls_x323;
  _mlsValue _mls_x324, _mls_x325, _mls_x326, _mls_x327, _mls_x328, _mls_x329;
  _mlsValue _mls_x330, _mls_x331, _mls_x332, _mls_x333, _mls_x334, _mls_x335;
  auto [_mls_x358, _mls_x359, _mls_x360, _mls_x361, _mls_x362, _mls_x363, _mls_x364] = _mls_ins_case1_sr_post_case1_pre(_mls_x280, _mls_x281, _mls_x282, _mls_x283, _mls_x284, _mls_x285);
  if (_mlsValue::isIntLit(_mls_x360, 1)) {
    _mls_x286 = _mls_x358;
    _mls_x287 = _mls_x359;
    _mls_x288 = _mls_x361;
    _mls_x289 = _mls_x362;
    _mls_x290 = _mls_x363;
    _mls_x291 = _mls_x364;
    goto _mls_ins_case1_sr_post_case1_case0;
  } else {
    _mls_x292 = _mls_x358;
    _mls_x293 = _mls_x359;
    _mls_x294 = _mls_x361;
    _mls_x295 = _mls_x362;
    _mls_x296 = _mls_x363;
    _mls_x297 = _mls_x364;
    goto _mls_ins_case1_sr_post_case1_default;
  }
  return _mls_retval;
  _mls_ins_case1_sr_post_case1_case0:
  {
    if (_mlsValue::isValueOf<_mls_Node>(_mls_x288)) {
      auto _mls_x365 = _mlsValue::cast<_mls_Node>(_mls_x288)->_mls_color;
      if (_mlsValue::isValueOf<_mls_Red>(_mls_x365)) {
        _mls_x298 = _mls_x286;
        _mls_x299 = _mls_x290;
        _mls_x300 = _mls_x288;
        _mls_x301 = _mls_x289;
        _mls_x302 = _mls_x291;
        _mls_x303 = _mls_x287;
        _mls_x304 = _mlsValue::fromIntLit(1);
        goto _mls_ins_caller_post;
      } else {
        _mls_x298 = _mls_x286;
        _mls_x299 = _mls_x290;
        _mls_x300 = _mls_x288;
        _mls_x301 = _mls_x289;
        _mls_x302 = _mls_x291;
        _mls_x303 = _mls_x287;
        _mls_x304 = _mlsValue::fromIntLit(0);
        goto _mls_ins_caller_post;
      }
    } else {
      _mls_x305 = _mls_x290;
      _mls_x306 = _mls_x289;
      _mls_x307 = _mls_x287;
      _mls_x308 = _mls_x286;
      _mls_x309 = _mls_x291;
      _mls_x310 = _mls_x288;
      goto _mls_ins_caller_post_default;
    }
    return _mls_retval;
  }
  _mls_ins_case1_sr_post_case1_default:
  {
    auto _mls_x366 = (_mls_x297 == _mls_x293);
    if (_mlsValue::isIntLit(_mls_x366, 1)) {
      auto _mls_x368 = _mlsValue::create<_mls_Black>();
      auto _mls_x369 = _mlsValue::create<_mls_Node>(_mls_x368, _mls_x294, _mls_x297, _mls_x296, _mls_x292);
      _mls_retval = _mls_x369;
    } else {
      if (_mlsValue::isValueOf<_mls_Node>(_mls_x292)) {
        auto _mls_x367 = _mlsValue::cast<_mls_Node>(_mls_x292)->_mls_color;
        if (_mlsValue::isValueOf<_mls_Red>(_mls_x367)) {
          _mls_x311 = _mlsValue::fromIntLit(1);
          _mls_x312 = _mls_x292;
          _mls_x313 = _mls_x296;
          _mls_x314 = _mls_x293;
          _mls_x315 = _mls_x294;
          _mls_x316 = _mls_x295;
          _mls_x317 = _mls_x297;
          goto _mls_ins_caller_post1;
        } else {
          _mls_x311 = _mlsValue::fromIntLit(0);
          _mls_x312 = _mls_x292;
          _mls_x313 = _mls_x296;
          _mls_x314 = _mls_x293;
          _mls_x315 = _mls_x294;
          _mls_x316 = _mls_x295;
          _mls_x317 = _mls_x297;
          goto _mls_ins_caller_post1;
        }
      } else {
        _mls_x318 = _mls_x292;
        _mls_x319 = _mls_x294;
        _mls_x320 = _mls_x293;
        _mls_x321 = _mls_x296;
        _mls_x322 = _mls_x295;
        _mls_x323 = _mls_x297;
        goto _mls_ins_caller_post_default1;
      }
    }
    return _mls_retval;
  }
  _mls_ins_caller_post:
  {
    if (_mlsValue::isIntLit(_mls_x304, 1)) {
      _mls_x324 = _mls_x299;
      _mls_x325 = _mls_x301;
      _mls_x326 = _mls_x303;
      _mls_x327 = _mls_x298;
      _mls_x328 = _mls_x302;
      _mls_x329 = _mls_x300;
      goto _mls_ins_caller_post_case0;
    } else {
      _mls_x305 = _mls_x299;
      _mls_x306 = _mls_x301;
      _mls_x307 = _mls_x303;
      _mls_x308 = _mls_x298;
      _mls_x309 = _mls_x302;
      _mls_x310 = _mls_x300;
      goto _mls_ins_caller_post_default;
    }
    return _mls_retval;
  }
  _mls_ins_caller_post_default:
  {
    auto _mls_x370 = _mls_ins(_mls_x309, _mls_x305, _mls_x310);
    auto _mls_x371 = _mlsValue::create<_mls_Black>();
    auto _mls_x372 = _mlsValue::create<_mls_Node>(_mls_x371, _mls_x370, _mls_x307, _mls_x306, _mls_x308);
    _mls_retval = _mls_x372;
    return _mls_retval;
  }
  _mls_ins_caller_post1:
  {
    if (_mlsValue::isIntLit(_mls_x311, 1)) {
      _mls_x330 = _mls_x312;
      _mls_x331 = _mls_x315;
      _mls_x332 = _mls_x314;
      _mls_x333 = _mls_x313;
      _mls_x334 = _mls_x316;
      _mls_x335 = _mls_x317;
      goto _mls_ins_caller_post_case01;
    } else {
      _mls_x318 = _mls_x312;
      _mls_x319 = _mls_x315;
      _mls_x320 = _mls_x314;
      _mls_x321 = _mls_x313;
      _mls_x322 = _mls_x316;
      _mls_x323 = _mls_x317;
      goto _mls_ins_caller_post_default1;
    }
    return _mls_retval;
  }
  _mls_ins_caller_post_default1:
  {
    auto _mls_x373 = _mls_ins(_mls_x323, _mls_x321, _mls_x318);
    auto _mls_x374 = _mlsValue::create<_mls_Black>();
    auto _mls_x375 = _mlsValue::create<_mls_Node>(_mls_x374, _mls_x319, _mls_x320, _mls_x322, _mls_x373);
    _mls_retval = _mls_x375;
    return _mls_retval;
  }
  _mls_ins_caller_post_case0:
  {
    auto _mls_x376 = _mls_ins(_mls_x328, _mls_x324, _mls_x327);
    auto _mls_x377 = _mls_balance1(_mls_x326, _mls_x325, _mls_x376, _mls_x329);
    _mls_retval = _mls_x377;
    return _mls_retval;
  }
  _mls_ins_caller_post_case01:
  {
    if (_mlsValue::isValueOf<_mls_Leaf>(_mls_x330)) {
      auto _mls_x396 = _mls_ins_case0(_mls_x335, _mls_x333);
      auto _mls_x397 = _mlsValue::cast<_mls_Node>(_mls_x396)->_mls_left;
      auto _mls_x398 = _mlsValue::cast<_mls_Node>(_mls_x396)->_mls_key;
      auto _mls_x399 = _mlsValue::cast<_mls_Node>(_mls_x396)->_mls_value;
      auto _mls_x400 = _mlsValue::cast<_mls_Node>(_mls_x396)->_mls_right;
      auto _mls_x401 = _mls_balance2_case0_sr_post(_mls_x331, _mls_x400, _mls_x397, _mls_x398, _mls_x334, _mls_x332, _mls_x399);
      _mls_retval = _mls_x401;
    } else if (_mlsValue::isValueOf<_mls_Node>(_mls_x330)) {
      auto _mls_x378 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_color;
      auto _mls_x379 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_left;
      auto _mls_x380 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_key;
      auto _mls_x381 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_value;
      auto _mls_x382 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_right;
      if (_mlsValue::isValueOf<_mls_Red>(_mls_x378)) {
        auto _mls_x394 = _mls_ins_case1_sr_post_case0(_mls_x380, _mls_x379, _mls_x335, _mls_x333, _mls_x382, _mls_x381);
        auto _mls_x395 = _mls_balance2_case0(_mls_x394, _mls_x331, _mls_x334, _mls_x332);
        _mls_retval = _mls_x395;
      } else if (_mlsValue::isValueOf<_mls_Black>(_mls_x378)) {
        auto [_mls_x383, _mls_x384, _mls_x385, _mls_x386, _mls_x387, _mls_x388, _mls_x389] = _mls_ins_case1_sr_post_case1_pre(_mls_x380, _mls_x379, _mls_x335, _mls_x333, _mls_x382, _mls_x381);
        if (_mlsValue::isIntLit(_mls_x385, 1)) {
          auto _mls_x392 = _mls_ins_case1_sr_post_case1_case0(_mls_x383, _mls_x384, _mls_x386, _mls_x387, _mls_x388, _mls_x389);
          auto _mls_x393 = _mls_balance2(_mls_x331, _mls_x332, _mls_x334, _mls_x392);
          _mls_retval = _mls_x393;
        } else {
          auto _mls_x390 = _mls_ins_case1_sr_post_case1_default(_mls_x383, _mls_x384, _mls_x386, _mls_x387, _mls_x388, _mls_x389);
          auto _mls_x391 = _mls_balance2(_mls_x331, _mls_x332, _mls_x334, _mls_x390);
          _mls_retval = _mls_x391;
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
_mlsValue _mls_ins_case1_sr_post_case1_case0(_mlsValue _mls_x286, _mlsValue _mls_x287, _mlsValue _mls_x288, _mlsValue _mls_x289, _mlsValue _mls_x290, _mlsValue _mls_x291) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x298, _mls_x299, _mls_x300, _mls_x301, _mls_x302, _mls_x303, _mls_x304;
  _mlsValue _mls_x305, _mls_x306, _mls_x307, _mls_x308, _mls_x309, _mls_x310;
  _mlsValue _mls_x324, _mls_x325, _mls_x326, _mls_x327, _mls_x328, _mls_x329;
  if (_mlsValue::isValueOf<_mls_Node>(_mls_x288)) {
    auto _mls_x365 = _mlsValue::cast<_mls_Node>(_mls_x288)->_mls_color;
    if (_mlsValue::isValueOf<_mls_Red>(_mls_x365)) {
      _mls_x298 = _mls_x286;
      _mls_x299 = _mls_x290;
      _mls_x300 = _mls_x288;
      _mls_x301 = _mls_x289;
      _mls_x302 = _mls_x291;
      _mls_x303 = _mls_x287;
      _mls_x304 = _mlsValue::fromIntLit(1);
      goto _mls_ins_caller_post;
    } else {
      _mls_x298 = _mls_x286;
      _mls_x299 = _mls_x290;
      _mls_x300 = _mls_x288;
      _mls_x301 = _mls_x289;
      _mls_x302 = _mls_x291;
      _mls_x303 = _mls_x287;
      _mls_x304 = _mlsValue::fromIntLit(0);
      goto _mls_ins_caller_post;
    }
  } else {
    _mls_x305 = _mls_x290;
    _mls_x306 = _mls_x289;
    _mls_x307 = _mls_x287;
    _mls_x308 = _mls_x286;
    _mls_x309 = _mls_x291;
    _mls_x310 = _mls_x288;
    goto _mls_ins_caller_post_default;
  }
  return _mls_retval;
  _mls_ins_caller_post:
  {
    if (_mlsValue::isIntLit(_mls_x304, 1)) {
      _mls_x324 = _mls_x299;
      _mls_x325 = _mls_x301;
      _mls_x326 = _mls_x303;
      _mls_x327 = _mls_x298;
      _mls_x328 = _mls_x302;
      _mls_x329 = _mls_x300;
      goto _mls_ins_caller_post_case0;
    } else {
      _mls_x305 = _mls_x299;
      _mls_x306 = _mls_x301;
      _mls_x307 = _mls_x303;
      _mls_x308 = _mls_x298;
      _mls_x309 = _mls_x302;
      _mls_x310 = _mls_x300;
      goto _mls_ins_caller_post_default;
    }
    return _mls_retval;
  }
  _mls_ins_caller_post_default:
  {
    auto _mls_x370 = _mls_ins(_mls_x309, _mls_x305, _mls_x310);
    auto _mls_x371 = _mlsValue::create<_mls_Black>();
    auto _mls_x372 = _mlsValue::create<_mls_Node>(_mls_x371, _mls_x370, _mls_x307, _mls_x306, _mls_x308);
    _mls_retval = _mls_x372;
    return _mls_retval;
  }
  _mls_ins_caller_post_case0:
  {
    auto _mls_x376 = _mls_ins(_mls_x328, _mls_x324, _mls_x327);
    auto _mls_x377 = _mls_balance1(_mls_x326, _mls_x325, _mls_x376, _mls_x329);
    _mls_retval = _mls_x377;
    return _mls_retval;
  }
}
_mlsValue _mls_ins_case1_sr_post_case1_default(_mlsValue _mls_x292, _mlsValue _mls_x293, _mlsValue _mls_x294, _mlsValue _mls_x295, _mlsValue _mls_x296, _mlsValue _mls_x297) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x311, _mls_x312, _mls_x313, _mls_x314, _mls_x315, _mls_x316, _mls_x317;
  _mlsValue _mls_x318, _mls_x319, _mls_x320, _mls_x321, _mls_x322, _mls_x323;
  _mlsValue _mls_x330, _mls_x331, _mls_x332, _mls_x333, _mls_x334, _mls_x335;
  auto _mls_x366 = (_mls_x297 == _mls_x293);
  if (_mlsValue::isIntLit(_mls_x366, 1)) {
    auto _mls_x368 = _mlsValue::create<_mls_Black>();
    auto _mls_x369 = _mlsValue::create<_mls_Node>(_mls_x368, _mls_x294, _mls_x297, _mls_x296, _mls_x292);
    _mls_retval = _mls_x369;
  } else {
    if (_mlsValue::isValueOf<_mls_Node>(_mls_x292)) {
      auto _mls_x367 = _mlsValue::cast<_mls_Node>(_mls_x292)->_mls_color;
      if (_mlsValue::isValueOf<_mls_Red>(_mls_x367)) {
        _mls_x311 = _mlsValue::fromIntLit(1);
        _mls_x312 = _mls_x292;
        _mls_x313 = _mls_x296;
        _mls_x314 = _mls_x293;
        _mls_x315 = _mls_x294;
        _mls_x316 = _mls_x295;
        _mls_x317 = _mls_x297;
        goto _mls_ins_caller_post1;
      } else {
        _mls_x311 = _mlsValue::fromIntLit(0);
        _mls_x312 = _mls_x292;
        _mls_x313 = _mls_x296;
        _mls_x314 = _mls_x293;
        _mls_x315 = _mls_x294;
        _mls_x316 = _mls_x295;
        _mls_x317 = _mls_x297;
        goto _mls_ins_caller_post1;
      }
    } else {
      _mls_x318 = _mls_x292;
      _mls_x319 = _mls_x294;
      _mls_x320 = _mls_x293;
      _mls_x321 = _mls_x296;
      _mls_x322 = _mls_x295;
      _mls_x323 = _mls_x297;
      goto _mls_ins_caller_post_default1;
    }
  }
  return _mls_retval;
  _mls_ins_caller_post1:
  {
    if (_mlsValue::isIntLit(_mls_x311, 1)) {
      _mls_x330 = _mls_x312;
      _mls_x331 = _mls_x315;
      _mls_x332 = _mls_x314;
      _mls_x333 = _mls_x313;
      _mls_x334 = _mls_x316;
      _mls_x335 = _mls_x317;
      goto _mls_ins_caller_post_case01;
    } else {
      _mls_x318 = _mls_x312;
      _mls_x319 = _mls_x315;
      _mls_x320 = _mls_x314;
      _mls_x321 = _mls_x313;
      _mls_x322 = _mls_x316;
      _mls_x323 = _mls_x317;
      goto _mls_ins_caller_post_default1;
    }
    return _mls_retval;
  }
  _mls_ins_caller_post_default1:
  {
    auto _mls_x373 = _mls_ins(_mls_x323, _mls_x321, _mls_x318);
    auto _mls_x374 = _mlsValue::create<_mls_Black>();
    auto _mls_x375 = _mlsValue::create<_mls_Node>(_mls_x374, _mls_x319, _mls_x320, _mls_x322, _mls_x373);
    _mls_retval = _mls_x375;
    return _mls_retval;
  }
  _mls_ins_caller_post_case01:
  {
    if (_mlsValue::isValueOf<_mls_Leaf>(_mls_x330)) {
      auto _mls_x396 = _mls_ins_case0(_mls_x335, _mls_x333);
      auto _mls_x397 = _mlsValue::cast<_mls_Node>(_mls_x396)->_mls_left;
      auto _mls_x398 = _mlsValue::cast<_mls_Node>(_mls_x396)->_mls_key;
      auto _mls_x399 = _mlsValue::cast<_mls_Node>(_mls_x396)->_mls_value;
      auto _mls_x400 = _mlsValue::cast<_mls_Node>(_mls_x396)->_mls_right;
      auto _mls_x401 = _mls_balance2_case0_sr_post(_mls_x331, _mls_x400, _mls_x397, _mls_x398, _mls_x334, _mls_x332, _mls_x399);
      _mls_retval = _mls_x401;
    } else if (_mlsValue::isValueOf<_mls_Node>(_mls_x330)) {
      auto _mls_x378 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_color;
      auto _mls_x379 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_left;
      auto _mls_x380 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_key;
      auto _mls_x381 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_value;
      auto _mls_x382 = _mlsValue::cast<_mls_Node>(_mls_x330)->_mls_right;
      if (_mlsValue::isValueOf<_mls_Red>(_mls_x378)) {
        auto _mls_x394 = _mls_ins_case1_sr_post_case0(_mls_x380, _mls_x379, _mls_x335, _mls_x333, _mls_x382, _mls_x381);
        auto _mls_x395 = _mls_balance2_case0(_mls_x394, _mls_x331, _mls_x334, _mls_x332);
        _mls_retval = _mls_x395;
      } else if (_mlsValue::isValueOf<_mls_Black>(_mls_x378)) {
        auto [_mls_x383, _mls_x384, _mls_x385, _mls_x386, _mls_x387, _mls_x388, _mls_x389] = _mls_ins_case1_sr_post_case1_pre(_mls_x380, _mls_x379, _mls_x335, _mls_x333, _mls_x382, _mls_x381);
        if (_mlsValue::isIntLit(_mls_x385, 1)) {
          auto _mls_x392 = _mls_ins_case1_sr_post_case1_case0(_mls_x383, _mls_x384, _mls_x386, _mls_x387, _mls_x388, _mls_x389);
          auto _mls_x393 = _mls_balance2(_mls_x331, _mls_x332, _mls_x334, _mls_x392);
          _mls_retval = _mls_x393;
        } else {
          auto _mls_x390 = _mls_ins_case1_sr_post_case1_default(_mls_x383, _mls_x384, _mls_x386, _mls_x387, _mls_x388, _mls_x389);
          auto _mls_x391 = _mls_balance2(_mls_x331, _mls_x332, _mls_x334, _mls_x390);
          _mls_retval = _mls_x391;
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
    return _mls_retval;
  }
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_ins_case1_sr_post_case1_pre(_mlsValue _mls_x404, _mlsValue _mls_x406, _mlsValue _mls_x403, _mlsValue _mls_x408, _mlsValue _mls_x405, _mlsValue _mls_x407) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x402 = (_mls_x403 < _mls_x404);
  _mls_retval = std::make_tuple(_mls_x405, _mls_x404, _mls_x402, _mls_x406, _mls_x407, _mls_x408, _mls_x403);
  return _mls_retval;
}
_mlsValue _mls_insert(_mlsValue _mls_k2, _mlsValue _mls_v2, _mlsValue _mls_t4) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x409, _mls_x410, _mls_x411, _mls_x412, _mls_x413, _mls_x414, _mls_x415;
  if (_mlsValue::isValueOf<_mls_Node>(_mls_t4)) {
    auto _mls_x423 = _mlsValue::cast<_mls_Node>(_mls_t4)->_mls_color;
    if (_mlsValue::isValueOf<_mls_Red>(_mls_x423)) {
      auto _mls_x430 = _mlsValue::cast<_mls_Node>(_mls_t4)->_mls_color;
      auto _mls_x431 = _mlsValue::cast<_mls_Node>(_mls_t4)->_mls_left;
      auto _mls_x432 = _mlsValue::cast<_mls_Node>(_mls_t4)->_mls_key;
      auto _mls_x433 = _mlsValue::cast<_mls_Node>(_mls_t4)->_mls_value;
      auto _mls_x434 = _mlsValue::cast<_mls_Node>(_mls_t4)->_mls_right;
      _mls_x409 = _mls_x431;
      _mls_x410 = _mls_x432;
      _mls_x411 = _mls_k2;
      _mls_x412 = _mls_x433;
      _mls_x413 = _mls_v2;
      _mls_x414 = _mls_x430;
      _mls_x415 = _mls_x434;
      goto _mls_insert_caller_post_case0_case1_sr_post;
    } else {
      auto _mls_x424 = _mlsValue::cast<_mls_Node>(_mls_t4)->_mls_color;
      auto _mls_x425 = _mlsValue::cast<_mls_Node>(_mls_t4)->_mls_left;
      auto _mls_x426 = _mlsValue::cast<_mls_Node>(_mls_t4)->_mls_key;
      auto _mls_x427 = _mlsValue::cast<_mls_Node>(_mls_t4)->_mls_value;
      auto _mls_x428 = _mlsValue::cast<_mls_Node>(_mls_t4)->_mls_right;
      auto _mls_x429 = _mls_ins_case1_sr_post(_mls_x428, _mls_v2, _mls_x427, _mls_x424, _mls_x426, _mls_k2, _mls_x425);
      _mls_retval = _mls_x429;
    }
  } else {
    if (_mlsValue::isValueOf<_mls_Leaf>(_mls_t4)) {
      auto _mls_x422 = _mls_ins_case0(_mls_k2, _mls_v2);
      _mls_retval = _mls_x422;
    } else if (_mlsValue::isValueOf<_mls_Node>(_mls_t4)) {
      auto _mls_x416 = _mlsValue::cast<_mls_Node>(_mls_t4)->_mls_color;
      auto _mls_x417 = _mlsValue::cast<_mls_Node>(_mls_t4)->_mls_left;
      auto _mls_x418 = _mlsValue::cast<_mls_Node>(_mls_t4)->_mls_key;
      auto _mls_x419 = _mlsValue::cast<_mls_Node>(_mls_t4)->_mls_value;
      auto _mls_x420 = _mlsValue::cast<_mls_Node>(_mls_t4)->_mls_right;
      auto _mls_x421 = _mls_ins_case1_sr_post(_mls_x420, _mls_v2, _mls_x419, _mls_x416, _mls_x418, _mls_k2, _mls_x417);
      _mls_retval = _mls_x421;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  }
  return _mls_retval;
  _mls_insert_caller_post_case0_case1_sr_post:
  {
    auto _mls_x435 = _mls_ins_case1_sr_post(_mls_x415, _mls_x413, _mls_x412, _mls_x414, _mls_x410, _mls_x411, _mls_x409);
    auto _mls_x436 = _mls_setBlack(_mls_x435);
    _mls_retval = _mls_x436;
    return _mls_retval;
  }
}
_mlsValue _mls_insert_caller_post_case0_case1_sr_post(_mlsValue _mls_x409, _mlsValue _mls_x410, _mlsValue _mls_x411, _mlsValue _mls_x412, _mlsValue _mls_x413, _mlsValue _mls_x414, _mlsValue _mls_x415) {
  _mlsValue _mls_retval;
  auto _mls_x435 = _mls_ins_case1_sr_post(_mls_x415, _mls_x413, _mls_x412, _mls_x414, _mls_x410, _mls_x411, _mls_x409);
  auto _mls_x436 = _mls_setBlack(_mls_x435);
  _mls_retval = _mls_x436;
  return _mls_retval;
}
_mlsValue _mls_main() {
  _mlsValue _mls_retval;
  auto _mls_x157 = _mls_mkMap(_mlsValue::fromIntLit(6000));
  auto _mls_x158 = _mlsValue::create<_mls_LamF>();
  if (_mlsValue::isValueOf<_mls_Leaf>(_mls_x157)) {
    _mls_retval = _mlsValue::fromIntLit(0);
  } else if (_mlsValue::isValueOf<_mls_Node>(_mls_x157)) {
    auto _mls_x437 = _mlsValue::cast<_mls_Node>(_mls_x157)->_mls_left;
    auto _mls_x438 = _mlsValue::cast<_mls_Node>(_mls_x157)->_mls_key;
    auto _mls_x439 = _mlsValue::cast<_mls_Node>(_mls_x157)->_mls_value;
    auto _mls_x440 = _mlsValue::cast<_mls_Node>(_mls_x157)->_mls_right;
    if (_mlsValue::isValueOf<_mls_Leaf>(_mls_x437)) {
      auto _mls_x448 = _mls_apply_f_case0(_mls_x439, _mlsValue::fromIntLit(0));
      auto _mls_x449 = _mls_fold(_mls_x158, _mls_x440, _mls_x448);
      _mls_retval = _mls_x449;
    } else if (_mlsValue::isValueOf<_mls_Node>(_mls_x437)) {
      auto _mls_x441 = _mlsValue::cast<_mls_Node>(_mls_x437)->_mls_left;
      auto _mls_x442 = _mlsValue::cast<_mls_Node>(_mls_x437)->_mls_key;
      auto _mls_x443 = _mlsValue::cast<_mls_Node>(_mls_x437)->_mls_value;
      auto _mls_x444 = _mlsValue::cast<_mls_Node>(_mls_x437)->_mls_right;
      auto _mls_x445 = _mls_fold(_mls_x158, _mls_x441, _mlsValue::fromIntLit(0));
      auto _mls_x446 = _mls_fold_case1_sr_post_post(_mls_x445, _mls_x158, _mls_x443, _mls_x442, _mls_x444);
      auto _mls_x447 = _mls_fold_case1_sr_post_post(_mls_x446, _mls_x158, _mls_x439, _mls_x438, _mls_x440);
      _mls_retval = _mls_x447;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_mkMap(_mlsValue _mls_n) {
  _mlsValue _mls_retval;
  auto _mls_x160 = _mlsValue::create<_mls_Leaf>();
  auto [_mls_x450, _mls_x451, _mls_x452] = _mls_mkMapAux_pre(_mls_n, _mls_x160);
  if (_mlsValue::isIntLit(_mls_x450, 1)) {
    _mls_retval = _mls_x451;
  } else {
    auto _mls_x453 = _mls_mkMapAux_default(_mls_x452, _mls_x451);
    _mls_retval = _mls_x453;
  }
  return _mls_retval;
}
_mlsValue _mls_mkMapAux(_mlsValue _mls_x456, _mlsValue _mls_x457) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x454, _mls_x455;
  auto [_mls_x458, _mls_x459, _mls_x460] = _mls_mkMapAux_pre(_mls_x456, _mls_x457);
  if (_mlsValue::isIntLit(_mls_x458, 1)) {
    _mls_retval = _mls_x459;
  } else {
    _mls_x454 = _mls_x460;
    _mls_x455 = _mls_x459;
    goto _mls_mkMapAux_default;
  }
  return _mls_retval;
  _mls_mkMapAux_default:
  {
    auto _mls_x461 = (_mls_x454 - _mlsValue::fromIntLit(1));
    auto _mls_x462 = (_mls_x454 % _mlsValue::fromIntLit(10));
    auto _mls_x463 = (_mls_x462 == _mlsValue::fromIntLit(0));
    auto _mls_x464 = _mls_insert(_mls_x454, _mls_x463, _mls_x455);
    auto _mls_x465 = _mls_mkMapAux(_mls_x461, _mls_x464);
    _mls_retval = _mls_x465;
    return _mls_retval;
  }
}
_mlsValue _mls_mkMapAux_default(_mlsValue _mls_x454, _mlsValue _mls_x455) {
  _mlsValue _mls_retval;
  auto _mls_x461 = (_mls_x454 - _mlsValue::fromIntLit(1));
  auto _mls_x462 = (_mls_x454 % _mlsValue::fromIntLit(10));
  auto _mls_x463 = (_mls_x462 == _mlsValue::fromIntLit(0));
  auto _mls_x464 = _mls_insert(_mls_x454, _mls_x463, _mls_x455);
  auto _mls_x465 = _mls_mkMapAux(_mls_x461, _mls_x464);
  _mls_retval = _mls_x465;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_mkMapAux_pre(_mlsValue _mls_x467, _mlsValue _mls_x468) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x466 = (_mls_x467 == _mlsValue::fromIntLit(0));
  _mls_retval = std::make_tuple(_mls_x466, _mls_x468, _mls_x467);
  return _mls_retval;
}
_mlsValue _mls_setBlack(_mlsValue _mls_x473) {
  _mlsValue _mls_retval;
  _mlsValue _mls_x469, _mls_x470, _mls_x471, _mls_x472;
  if (_mlsValue::isValueOf<_mls_Node>(_mls_x473)) {
    auto _mls_x474 = _mlsValue::cast<_mls_Node>(_mls_x473)->_mls_left;
    auto _mls_x475 = _mlsValue::cast<_mls_Node>(_mls_x473)->_mls_key;
    auto _mls_x476 = _mlsValue::cast<_mls_Node>(_mls_x473)->_mls_value;
    auto _mls_x477 = _mlsValue::cast<_mls_Node>(_mls_x473)->_mls_right;
    _mls_x469 = _mls_x474;
    _mls_x470 = _mls_x475;
    _mls_x471 = _mls_x476;
    _mls_x472 = _mls_x477;
    goto _mls_setBlack_case0_sr_post;
  } else {
    _mls_retval = _mls_x473;
  }
  return _mls_retval;
  _mls_setBlack_case0_sr_post:
  {
    auto _mls_x478 = _mlsValue::create<_mls_Black>();
    auto _mls_x479 = _mlsValue::create<_mls_Node>(_mls_x478, _mls_x469, _mls_x470, _mls_x471, _mls_x472);
    _mls_retval = _mls_x479;
    return _mls_retval;
  }
}
_mlsValue _mls_setBlack_case0_sr_post(_mlsValue _mls_x469, _mlsValue _mls_x470, _mlsValue _mls_x471, _mlsValue _mls_x472) {
  _mlsValue _mls_retval;
  auto _mls_x478 = _mlsValue::create<_mls_Black>();
  auto _mls_x479 = _mlsValue::create<_mls_Node>(_mls_x478, _mls_x469, _mls_x470, _mls_x471, _mls_x472);
  _mls_retval = _mls_x479;
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
