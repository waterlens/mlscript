#include "mlsprelude.h"
struct _mls_Formula;
struct _mls_Con;
struct _mls_Dis;
struct _mls_Eqv;
struct _mls_Imp;
struct _mls_Lambda_clauses;
struct _mls_Lambda_disp;
struct _mls_Lambda_l;
struct _mls_Lambda_lambda;
struct _mls_Lambda_lscomp;
struct _mls_Lambda_red;
struct _mls_Lambda_uniclHelper;
struct _mls_List;
struct _mls_Cons;
struct _mls_Nil;
struct _mls_Not;
struct _mls_StackFrame;
struct _mls_Ast;
struct _mls_Lex;
struct _mls_Sym;
struct _mls_Tuple2;
_mlsValue _mls_append(_mlsValue, _mlsValue);
_mlsValue _mls_clause(_mlsValue);
_mlsValue _mls_clauseHelper(_mlsValue, _mlsValue);
_mlsValue _mls_clauses(_mlsValue);
_mlsValue _mls_concat(_mlsValue);
_mlsValue _mls_conjunct(_mlsValue);
_mlsValue _mls_disin(_mlsValue);
_mlsValue _mls_disp(_mlsValue);
_mlsValue _mls_elim(_mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_foldr(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_inList(_mlsValue, _mlsValue);
_mlsValue _mls_insert(_mlsValue, _mlsValue);
_mlsValue _mls_interleave(_mlsValue, _mlsValue);
_mlsValue _mls_listLen(_mlsValue);
_mlsValue _mls_listNeq(_mlsValue, _mlsValue);
_mlsValue _mls_list_to_str(_mlsValue);
_mlsValue _mls_map(_mlsValue, _mlsValue);
_mlsValue _mls_negin(_mlsValue);
_mlsValue _mls_opri(_mlsValue);
_mlsValue _mls_parse(_mlsValue);
_mlsValue _mls_parseHelper(_mlsValue, _mlsValue);
_mlsValue _mls_red(_mlsValue);
_mlsValue _mls_redstar(_mlsValue);
_mlsValue _mls_replicate(_mlsValue, _mlsValue);
_mlsValue _mls_split(_mlsValue);
_mlsValue _mls_splitHelper(_mlsValue, _mlsValue);
_mlsValue _mls_spri(_mlsValue);
_mlsValue _mls_str_to_list(_mlsValue);
_mlsValue _mls_tautclause(_mlsValue);
_mlsValue _mls_testClausify_nofib(_mlsValue);
_mlsValue _mls_unicl(_mlsValue);
_mlsValue _mls_uniclHelper(_mlsValue, _mlsValue);
_mlsValue _mls_while_(_mlsValue, _mlsValue, _mlsValue);
struct _mls_Formula: public _mlsObject {
  
  constexpr static inline const char *typeName = "Formula";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Formula; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Con: public _mls_Formula {
  _mlsValue _mls_a;
  _mlsValue _mls_b;
  constexpr static inline const char *typeName = "Con";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_a.print(); std::printf(", "); this->_mls_b.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_a); _mlsValue::destroy(this->_mls_b);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_a.asObject()->operator==(*other.cast<_mls_Con>()->_mls_a.asObject()) && this->_mls_b.asObject()->operator==(*other.cast<_mls_Con>()->_mls_b.asObject()); }
  static _mlsValue create(_mlsValue _mls_a, _mlsValue _mls_b) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Con; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_a = _mls_a; _mlsVal->_mls_b = _mls_b;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Dis: public _mls_Formula {
  _mlsValue _mls_a;
  _mlsValue _mls_b;
  constexpr static inline const char *typeName = "Dis";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_a.print(); std::printf(", "); this->_mls_b.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_a); _mlsValue::destroy(this->_mls_b);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_a.asObject()->operator==(*other.cast<_mls_Dis>()->_mls_a.asObject()) && this->_mls_b.asObject()->operator==(*other.cast<_mls_Dis>()->_mls_b.asObject()); }
  static _mlsValue create(_mlsValue _mls_a, _mlsValue _mls_b) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Dis; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_a = _mls_a; _mlsVal->_mls_b = _mls_b;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Eqv: public _mls_Formula {
  _mlsValue _mls_a;
  _mlsValue _mls_b;
  constexpr static inline const char *typeName = "Eqv";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_a.print(); std::printf(", "); this->_mls_b.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_a); _mlsValue::destroy(this->_mls_b);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_a.asObject()->operator==(*other.cast<_mls_Eqv>()->_mls_a.asObject()) && this->_mls_b.asObject()->operator==(*other.cast<_mls_Eqv>()->_mls_b.asObject()); }
  static _mlsValue create(_mlsValue _mls_a, _mlsValue _mls_b) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Eqv; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_a = _mls_a; _mlsVal->_mls_b = _mls_b;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Imp: public _mls_Formula {
  _mlsValue _mls_a;
  _mlsValue _mls_b;
  constexpr static inline const char *typeName = "Imp";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_a.print(); std::printf(", "); this->_mls_b.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_a); _mlsValue::destroy(this->_mls_b);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_a.asObject()->operator==(*other.cast<_mls_Imp>()->_mls_a.asObject()) && this->_mls_b.asObject()->operator==(*other.cast<_mls_Imp>()->_mls_b.asObject()); }
  static _mlsValue create(_mlsValue _mls_a, _mlsValue _mls_b) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Imp; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_a = _mls_a; _mlsVal->_mls_b = _mls_b;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Lambda_clauses: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_clauses";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_clauses; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_disp: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_disp";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_disp; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_l: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_l";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_l; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_lambda: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lscomp: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_lscomp";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lscomp>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lscomp; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_red: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_red";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_red; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_uniclHelper: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_uniclHelper";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_uniclHelper; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_List: public _mlsObject {
  
  constexpr static inline const char *typeName = "List";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_List; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Cons: public _mls_List {
  _mlsValue _mls_head;
  _mlsValue _mls_tail;
  constexpr static inline const char *typeName = "Cons";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_head.print(); std::printf(", "); this->_mls_tail.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_head); _mlsValue::destroy(this->_mls_tail);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_head.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_head.asObject()) && this->_mls_tail.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_tail.asObject()); }
  static _mlsValue create(_mlsValue _mls_head, _mlsValue _mls_tail) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Cons; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_head = _mls_head; _mlsVal->_mls_tail = _mls_tail;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Nil: public _mls_List {
  
  constexpr static inline const char *typeName = "Nil";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Nil; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Not: public _mls_Formula {
  _mlsValue _mls_a;
  constexpr static inline const char *typeName = "Not";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_a.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_a);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_a.asObject()->operator==(*other.cast<_mls_Not>()->_mls_a.asObject()); }
  static _mlsValue create(_mlsValue _mls_a) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Not; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_a = _mls_a;  return _mlsValue(_mlsVal); }
  
};
struct _mls_StackFrame: public _mlsObject {
  
  constexpr static inline const char *typeName = "StackFrame";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_StackFrame; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Ast: public _mls_StackFrame {
  _mlsValue _mls_f;
  constexpr static inline const char *typeName = "Ast";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_f.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_f);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_f.asObject()->operator==(*other.cast<_mls_Ast>()->_mls_f.asObject()); }
  static _mlsValue create(_mlsValue _mls_f) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Ast; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_f = _mls_f;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Lex: public _mls_StackFrame {
  _mlsValue _mls_s;
  constexpr static inline const char *typeName = "Lex";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_s.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_s);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_s.asObject()->operator==(*other.cast<_mls_Lex>()->_mls_s.asObject()); }
  static _mlsValue create(_mlsValue _mls_s) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lex; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_s = _mls_s;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Sym: public _mls_Formula {
  _mlsValue _mls_a;
  constexpr static inline const char *typeName = "Sym";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_a.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_a);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_a.asObject()->operator==(*other.cast<_mls_Sym>()->_mls_a.asObject()); }
  static _mlsValue create(_mlsValue _mls_a) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Sym; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_a = _mls_a;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Tuple2: public _mlsObject {
  _mlsValue _mls_field0;
  _mlsValue _mls_field1;
  constexpr static inline const char *typeName = "Tuple2";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_field0.print(); std::printf(", "); this->_mls_field1.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_field0); _mlsValue::destroy(this->_mls_field1);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_field0.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field0.asObject()) && this->_mls_field1.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field1.asObject()); }
  static _mlsValue create(_mlsValue _mls_field0, _mlsValue _mls_field1) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Tuple2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_field0 = _mls_field0; _mlsVal->_mls_field1 = _mls_field1;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_append(_mlsValue _mls_xs, _mlsValue _mls_ys) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs)) {
    _mls_retval = _mls_ys;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs)) {
    auto _mls_x17 = _mlsValue::cast<_mls_Cons>(_mls_xs)->_mls_head;
    auto _mls_x18 = _mlsValue::cast<_mls_Cons>(_mls_xs)->_mls_tail;
    auto _mls_x19 = _mls_append(_mls_x18, _mls_ys);
    auto _mls_x20 = _mlsValue::create<_mls_Cons>(_mls_x17, _mls_x19);
    _mls_retval = _mls_x20;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_clause(_mlsValue _mls_p) {
  _mlsValue _mls_retval;
  auto _mls_x21 = _mlsValue::create<_mls_Nil>();
  auto _mls_x22 = _mlsValue::create<_mls_Nil>();
  auto _mls_x23 = _mlsValue::create<_mls_Tuple2>(_mls_x21, _mls_x22);
  auto _mls_x24 = _mls_clauseHelper(_mls_p, _mls_x23);
  _mls_retval = _mls_x24;
  return _mls_retval;
}
_mlsValue _mls_clauseHelper(_mlsValue _mls_p1, _mlsValue _mls_x27) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Dis>(_mls_p1)) {
    auto _mls_x37 = _mlsValue::cast<_mls_Dis>(_mls_p1)->_mls_a;
    auto _mls_x38 = _mlsValue::cast<_mls_Dis>(_mls_p1)->_mls_b;
    auto _mls_x39 = _mls_clauseHelper(_mls_x38, _mls_x27);
    auto _mls_x40 = _mls_clauseHelper(_mls_x37, _mls_x39);
    _mls_retval = _mls_x40;
  } else if (_mlsValue::isValueOf<_mls_Sym>(_mls_p1)) {
    auto _mls_x32 = _mlsValue::cast<_mls_Sym>(_mls_p1)->_mls_a;
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x27)) {
      auto _mls_x33 = _mlsValue::cast<_mls_Tuple2>(_mls_x27)->_mls_field0;
      auto _mls_x34 = _mlsValue::cast<_mls_Tuple2>(_mls_x27)->_mls_field1;
      auto _mls_x35 = _mls_insert(_mls_x32, _mls_x33);
      auto _mls_x36 = _mlsValue::create<_mls_Tuple2>(_mls_x35, _mls_x34);
      _mls_retval = _mls_x36;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else if (_mlsValue::isValueOf<_mls_Not>(_mls_p1)) {
    auto _mls_x25 = _mlsValue::cast<_mls_Not>(_mls_p1)->_mls_a;
    if (_mlsValue::isValueOf<_mls_Sym>(_mls_x25)) {
      auto _mls_x26 = _mlsValue::cast<_mls_Sym>(_mls_x25)->_mls_a;
      if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x27)) {
        auto _mls_x28 = _mlsValue::cast<_mls_Tuple2>(_mls_x27)->_mls_field0;
        auto _mls_x29 = _mlsValue::cast<_mls_Tuple2>(_mls_x27)->_mls_field1;
        auto _mls_x30 = _mls_insert(_mls_x26, _mls_x29);
        auto _mls_x31 = _mlsValue::create<_mls_Tuple2>(_mls_x28, _mls_x30);
        _mls_retval = _mls_x31;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_clauses(_mlsValue _mls_t) {
  _mlsValue _mls_retval;
  auto _mls_x41 = _mls_parse(_mls_t);
  auto _mls_x42 = _mls_elim(_mls_x41);
  auto _mls_x43 = _mls_negin(_mls_x42);
  auto _mls_x44 = _mls_disin(_mls_x43);
  auto _mls_x45 = _mls_split(_mls_x44);
  auto _mls_x46 = _mls_unicl(_mls_x45);
  auto _mls_x47 = _mlsValue::create<_mls_Lambda_disp>();
  auto _mls_x48 = _mls_map(_mls_x47, _mls_x46);
  auto _mls_x49 = _mls_concat(_mls_x48);
  _mls_retval = _mls_x49;
  return _mls_retval;
}
_mlsValue _mls_concat(_mlsValue _mls_ls2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls2)) {
    auto _mls_x54 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x54;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls2)) {
    auto _mls_x50 = _mlsValue::cast<_mls_Cons>(_mls_ls2)->_mls_head;
    auto _mls_x51 = _mlsValue::cast<_mls_Cons>(_mls_ls2)->_mls_tail;
    auto _mls_x52 = _mls_concat(_mls_x51);
    auto _mls_x53 = _mls_append(_mls_x50, _mls_x52);
    _mls_retval = _mls_x53;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_conjunct(_mlsValue _mls_p2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Con>(_mls_p2)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else {
    _mls_retval = _mlsValue::fromIntLit(0);
  }
  return _mls_retval;
}
_mlsValue _mls_disin(_mlsValue _mls_p3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Dis>(_mls_p3)) {
    auto _mls_x60 = _mlsValue::cast<_mls_Dis>(_mls_p3)->_mls_a;
    auto _mls_x61 = _mlsValue::cast<_mls_Dis>(_mls_p3)->_mls_b;
    if (_mlsValue::isValueOf<_mls_Con>(_mls_x61)) {
      auto _mls_x77 = _mlsValue::cast<_mls_Con>(_mls_x61)->_mls_a;
      auto _mls_x78 = _mlsValue::cast<_mls_Con>(_mls_x61)->_mls_b;
      auto _mls_x79 = _mlsValue::create<_mls_Dis>(_mls_x60, _mls_x77);
      auto _mls_x80 = _mls_disin(_mls_x79);
      auto _mls_x81 = _mlsValue::create<_mls_Dis>(_mls_x60, _mls_x78);
      auto _mls_x82 = _mls_disin(_mls_x81);
      auto _mls_x83 = _mlsValue::create<_mls_Con>(_mls_x80, _mls_x82);
      _mls_retval = _mls_x83;
    } else {
      if (_mlsValue::isValueOf<_mls_Con>(_mls_x60)) {
        auto _mls_x70 = _mlsValue::cast<_mls_Con>(_mls_x60)->_mls_a;
        auto _mls_x71 = _mlsValue::cast<_mls_Con>(_mls_x60)->_mls_b;
        auto _mls_x72 = _mlsValue::create<_mls_Dis>(_mls_x70, _mls_x61);
        auto _mls_x73 = _mls_disin(_mls_x72);
        auto _mls_x74 = _mlsValue::create<_mls_Dis>(_mls_x71, _mls_x61);
        auto _mls_x75 = _mls_disin(_mls_x74);
        auto _mls_x76 = _mlsValue::create<_mls_Con>(_mls_x73, _mls_x75);
        _mls_retval = _mls_x76;
      } else {
        auto _mls_x62 = _mls_disin(_mls_x60);
        auto _mls_x63 = _mls_disin(_mls_x61);
        auto _mls_x64 = _mls_conjunct(_mls_x62);
        auto _mls_x65 = _mls_conjunct(_mls_x63);
        auto _mls_x66 = (_mls_x64 || _mls_x65);
        if (_mlsValue::isIntLit(_mls_x66, 1)) {
          auto _mls_x68 = _mlsValue::create<_mls_Dis>(_mls_x62, _mls_x63);
          auto _mls_x69 = _mls_disin(_mls_x68);
          _mls_retval = _mls_x69;
        } else {
          auto _mls_x67 = _mlsValue::create<_mls_Dis>(_mls_x62, _mls_x63);
          _mls_retval = _mls_x67;
        }
      }
    }
  } else if (_mlsValue::isValueOf<_mls_Con>(_mls_p3)) {
    auto _mls_x55 = _mlsValue::cast<_mls_Con>(_mls_p3)->_mls_a;
    auto _mls_x56 = _mlsValue::cast<_mls_Con>(_mls_p3)->_mls_b;
    auto _mls_x57 = _mls_disin(_mls_x55);
    auto _mls_x58 = _mls_disin(_mls_x56);
    auto _mls_x59 = _mlsValue::create<_mls_Con>(_mls_x57, _mls_x58);
    _mls_retval = _mls_x59;
  } else {
    _mls_retval = _mls_p3;
  }
  return _mls_retval;
}
_mlsValue _mls_disp(_mlsValue _mls_l_r) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_l_r)) {
    auto _mls_x84 = _mlsValue::cast<_mls_Tuple2>(_mls_l_r)->_mls_field0;
    auto _mls_x85 = _mlsValue::cast<_mls_Tuple2>(_mls_l_r)->_mls_field1;
    auto _mls_x86 = _mls_listLen(_mls_x84);
    auto _mls_x87 = _mls_replicate(_mls_x86, _mlsValue::create<_mls_Str>(" "));
    auto _mls_x88 = _mls_interleave(_mls_x84, _mls_x87);
    auto _mls_x89 = _mls_str_to_list(_mlsValue::create<_mls_Str>("<="));
    auto _mls_x90 = _mls_listLen(_mls_x85);
    auto _mls_x91 = _mls_replicate(_mls_x90, _mlsValue::create<_mls_Str>(" "));
    auto _mls_x92 = _mls_interleave(_mls_x91, _mls_x85);
    auto _mls_x93 = _mls_str_to_list(_mlsValue::create<_mls_Str>("\n"));
    auto _mls_x94 = _mls_append(_mls_x92, _mls_x93);
    auto _mls_x95 = _mls_append(_mls_x89, _mls_x94);
    auto _mls_x96 = _mls_append(_mls_x88, _mls_x95);
    _mls_retval = _mls_x96;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_elim(_mlsValue _mls_p4) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Sym>(_mls_p4)) {
    auto _mls_x123 = _mlsValue::cast<_mls_Sym>(_mls_p4)->_mls_a;
    auto _mls_x124 = _mlsValue::create<_mls_Sym>(_mls_x123);
    _mls_retval = _mls_x124;
  } else if (_mlsValue::isValueOf<_mls_Not>(_mls_p4)) {
    auto _mls_x120 = _mlsValue::cast<_mls_Not>(_mls_p4)->_mls_a;
    auto _mls_x121 = _mls_elim(_mls_x120);
    auto _mls_x122 = _mlsValue::create<_mls_Not>(_mls_x121);
    _mls_retval = _mls_x122;
  } else if (_mlsValue::isValueOf<_mls_Dis>(_mls_p4)) {
    auto _mls_x115 = _mlsValue::cast<_mls_Dis>(_mls_p4)->_mls_a;
    auto _mls_x116 = _mlsValue::cast<_mls_Dis>(_mls_p4)->_mls_b;
    auto _mls_x117 = _mls_elim(_mls_x115);
    auto _mls_x118 = _mls_elim(_mls_x116);
    auto _mls_x119 = _mlsValue::create<_mls_Dis>(_mls_x117, _mls_x118);
    _mls_retval = _mls_x119;
  } else if (_mlsValue::isValueOf<_mls_Con>(_mls_p4)) {
    auto _mls_x110 = _mlsValue::cast<_mls_Con>(_mls_p4)->_mls_a;
    auto _mls_x111 = _mlsValue::cast<_mls_Con>(_mls_p4)->_mls_b;
    auto _mls_x112 = _mls_elim(_mls_x110);
    auto _mls_x113 = _mls_elim(_mls_x111);
    auto _mls_x114 = _mlsValue::create<_mls_Con>(_mls_x112, _mls_x113);
    _mls_retval = _mls_x114;
  } else if (_mlsValue::isValueOf<_mls_Imp>(_mls_p4)) {
    auto _mls_x104 = _mlsValue::cast<_mls_Imp>(_mls_p4)->_mls_a;
    auto _mls_x105 = _mlsValue::cast<_mls_Imp>(_mls_p4)->_mls_b;
    auto _mls_x106 = _mls_elim(_mls_x104);
    auto _mls_x107 = _mlsValue::create<_mls_Not>(_mls_x106);
    auto _mls_x108 = _mls_elim(_mls_x105);
    auto _mls_x109 = _mlsValue::create<_mls_Dis>(_mls_x107, _mls_x108);
    _mls_retval = _mls_x109;
  } else if (_mlsValue::isValueOf<_mls_Eqv>(_mls_p4)) {
    auto _mls_x97 = _mlsValue::cast<_mls_Eqv>(_mls_p4)->_mls_a;
    auto _mls_x98 = _mlsValue::cast<_mls_Eqv>(_mls_p4)->_mls_b;
    auto _mls_x99 = _mlsValue::create<_mls_Imp>(_mls_x97, _mls_x98);
    auto _mls_x100 = _mls_elim(_mls_x99);
    auto _mls_x101 = _mlsValue::create<_mls_Imp>(_mls_x98, _mls_x97);
    auto _mls_x102 = _mls_elim(_mls_x101);
    auto _mls_x103 = _mlsValue::create<_mls_Con>(_mls_x100, _mls_x102);
    _mls_retval = _mls_x103;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x125 = _mls_testClausify_nofib(_mlsValue::fromIntLit(200));
  _mls_retval = _mls_x125;
  return _mls_retval;
}
_mlsValue _mls_foldr(_mlsValue _mls_f1, _mlsValue _mls_z, _mlsValue _mls_xs1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs1)) {
    _mls_retval = _mls_z;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs1)) {
    auto _mls_x126 = _mlsValue::cast<_mls_Cons>(_mls_xs1)->_mls_head;
    auto _mls_x127 = _mlsValue::cast<_mls_Cons>(_mls_xs1)->_mls_tail;
    auto _mls_x128 = _mls_foldr(_mls_f1, _mls_z, _mls_x127);
    auto _mls_x129 = _mlsMethodCall<_mls_Callable>(_mls_f1)->_mls_apply2(_mls_x126, _mls_x128);
    _mls_retval = _mls_x129;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_inList(_mlsValue _mls_x133, _mlsValue _mls_ls3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls3)) {
    auto _mls_x130 = _mlsValue::cast<_mls_Cons>(_mls_ls3)->_mls_head;
    auto _mls_x131 = _mlsValue::cast<_mls_Cons>(_mls_ls3)->_mls_tail;
    auto _mls_x132 = (_mls_x133 == _mls_x130);
    if (_mlsValue::isIntLit(_mls_x132, 1)) {
      _mls_retval = _mlsValue::fromIntLit(1);
    } else {
      auto _mls_x134 = _mls_inList(_mls_x133, _mls_x131);
      _mls_retval = _mls_x134;
    }
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls3)) {
    _mls_retval = _mlsValue::fromIntLit(0);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_insert(_mlsValue _mls_x138, _mlsValue _mls_ys1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ys1)) {
    auto _mls_x145 = _mlsValue::create<_mls_Nil>();
    auto _mls_x146 = _mlsValue::create<_mls_Cons>(_mls_x138, _mls_x145);
    _mls_retval = _mls_x146;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ys1)) {
    auto _mls_x135 = _mlsValue::cast<_mls_Cons>(_mls_ys1)->_mls_head;
    auto _mls_x136 = _mlsValue::cast<_mls_Cons>(_mls_ys1)->_mls_tail;
    auto _mls_x137 = _mls_builtin_str_lt(_mls_x138, _mls_x135);
    if (_mlsValue::isIntLit(_mls_x137, 1)) {
      auto _mls_x143 = _mlsValue::create<_mls_Cons>(_mls_x135, _mls_x136);
      auto _mls_x144 = _mlsValue::create<_mls_Cons>(_mls_x138, _mls_x143);
      _mls_retval = _mls_x144;
    } else {
      auto _mls_x139 = _mls_builtin_str_gt(_mls_x138, _mls_x135);
      if (_mlsValue::isIntLit(_mls_x139, 1)) {
        auto _mls_x141 = _mls_insert(_mls_x138, _mls_x136);
        auto _mls_x142 = _mlsValue::create<_mls_Cons>(_mls_x135, _mls_x141);
        _mls_retval = _mls_x142;
      } else {
        auto _mls_x140 = _mlsValue::create<_mls_Cons>(_mls_x135, _mls_x136);
        _mls_retval = _mls_x140;
      }
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_interleave(_mlsValue _mls_xs2, _mlsValue _mls_ys2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs2)) {
    auto _mls_x148 = _mlsValue::cast<_mls_Cons>(_mls_xs2)->_mls_head;
    auto _mls_x149 = _mlsValue::cast<_mls_Cons>(_mls_xs2)->_mls_tail;
    auto _mls_x150 = _mls_interleave(_mls_ys2, _mls_x149);
    auto _mls_x151 = _mlsValue::create<_mls_Cons>(_mls_x148, _mls_x150);
    _mls_retval = _mls_x151;
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs2)) {
    auto _mls_x147 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x147;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_listLen(_mlsValue _mls_ls4) {
  _mlsValue _mls_retval;
  auto _mls_x152 = _mlsValue::create<_mls_Lambda_l>();
  auto _mls_x153 = _mlsMethodCall<_mls_Callable>(_mls_x152)->_mls_apply2(_mls_ls4, _mlsValue::fromIntLit(0));
  _mls_retval = _mls_x153;
  return _mls_retval;
}
_mlsValue _mls_listNeq(_mlsValue _mls_xs3, _mlsValue _mls_ys3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs3)) {
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_ys3)) {
      _mls_retval = _mlsValue::fromIntLit(0);
    } else {
      _mls_retval = _mlsValue::fromIntLit(1);
    }
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs3)) {
    auto _mls_x154 = _mlsValue::cast<_mls_Cons>(_mls_xs3)->_mls_head;
    auto _mls_x155 = _mlsValue::cast<_mls_Cons>(_mls_xs3)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_ys3)) {
      auto _mls_x156 = _mlsValue::cast<_mls_Cons>(_mls_ys3)->_mls_head;
      auto _mls_x157 = _mlsValue::cast<_mls_Cons>(_mls_ys3)->_mls_tail;
      auto _mls_x158 = (_mls_x154 == _mls_x156);
      if (_mlsValue::isIntLit(_mls_x158, 1)) {
        auto _mls_x159 = _mls_listNeq(_mls_x155, _mls_x157);
        _mls_retval = _mls_x159;
      } else {
        _mls_retval = _mlsValue::fromIntLit(1);
      }
    } else {
      _mls_retval = _mlsValue::fromIntLit(1);
    }
  } else {
    _mls_retval = _mlsValue::fromIntLit(1);
  }
  return _mls_retval;
}
_mlsValue _mls_list_to_str(_mlsValue _mls_xs4) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs4)) {
    _mls_retval = _mlsValue::create<_mls_Str>("");
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs4)) {
    auto _mls_x160 = _mlsValue::cast<_mls_Cons>(_mls_xs4)->_mls_head;
    auto _mls_x161 = _mlsValue::cast<_mls_Cons>(_mls_xs4)->_mls_tail;
    auto _mls_x162 = _mls_list_to_str(_mls_x161);
    auto _mls_x163 = _mls_builtin_str_concat(_mls_x160, _mls_x162);
    _mls_retval = _mls_x163;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_map(_mlsValue _mls_f2, _mlsValue _mls_xs5) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs5)) {
    auto _mls_x165 = _mlsValue::cast<_mls_Cons>(_mls_xs5)->_mls_head;
    auto _mls_x166 = _mlsValue::cast<_mls_Cons>(_mls_xs5)->_mls_tail;
    auto _mls_x167 = _mlsMethodCall<_mls_Callable>(_mls_f2)->_mls_apply1(_mls_x165);
    auto _mls_x168 = _mls_map(_mls_f2, _mls_x166);
    auto _mls_x169 = _mlsValue::create<_mls_Cons>(_mls_x167, _mls_x168);
    _mls_retval = _mls_x169;
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs5)) {
    auto _mls_x164 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x164;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_negin(_mlsValue _mls_p5) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Not>(_mls_p5)) {
    auto _mls_x180 = _mlsValue::cast<_mls_Not>(_mls_p5)->_mls_a;
    if (_mlsValue::isValueOf<_mls_Not>(_mls_x180)) {
      auto _mls_x195 = _mlsValue::cast<_mls_Not>(_mls_x180)->_mls_a;
      auto _mls_x196 = _mls_negin(_mls_x195);
      _mls_retval = _mls_x196;
    } else if (_mlsValue::isValueOf<_mls_Con>(_mls_x180)) {
      auto _mls_x188 = _mlsValue::cast<_mls_Con>(_mls_x180)->_mls_a;
      auto _mls_x189 = _mlsValue::cast<_mls_Con>(_mls_x180)->_mls_b;
      auto _mls_x190 = _mlsValue::create<_mls_Not>(_mls_x188);
      auto _mls_x191 = _mls_negin(_mls_x190);
      auto _mls_x192 = _mlsValue::create<_mls_Not>(_mls_x189);
      auto _mls_x193 = _mls_negin(_mls_x192);
      auto _mls_x194 = _mlsValue::create<_mls_Dis>(_mls_x191, _mls_x193);
      _mls_retval = _mls_x194;
    } else if (_mlsValue::isValueOf<_mls_Dis>(_mls_x180)) {
      auto _mls_x181 = _mlsValue::cast<_mls_Dis>(_mls_x180)->_mls_a;
      auto _mls_x182 = _mlsValue::cast<_mls_Dis>(_mls_x180)->_mls_b;
      auto _mls_x183 = _mlsValue::create<_mls_Not>(_mls_x181);
      auto _mls_x184 = _mls_negin(_mls_x183);
      auto _mls_x185 = _mlsValue::create<_mls_Not>(_mls_x182);
      auto _mls_x186 = _mls_negin(_mls_x185);
      auto _mls_x187 = _mlsValue::create<_mls_Con>(_mls_x184, _mls_x186);
      _mls_retval = _mls_x187;
    } else {
      _mls_retval = _mls_p5;
    }
  } else if (_mlsValue::isValueOf<_mls_Dis>(_mls_p5)) {
    auto _mls_x175 = _mlsValue::cast<_mls_Dis>(_mls_p5)->_mls_a;
    auto _mls_x176 = _mlsValue::cast<_mls_Dis>(_mls_p5)->_mls_b;
    auto _mls_x177 = _mls_negin(_mls_x175);
    auto _mls_x178 = _mls_negin(_mls_x176);
    auto _mls_x179 = _mlsValue::create<_mls_Dis>(_mls_x177, _mls_x178);
    _mls_retval = _mls_x179;
  } else if (_mlsValue::isValueOf<_mls_Con>(_mls_p5)) {
    auto _mls_x170 = _mlsValue::cast<_mls_Con>(_mls_p5)->_mls_a;
    auto _mls_x171 = _mlsValue::cast<_mls_Con>(_mls_p5)->_mls_b;
    auto _mls_x172 = _mls_negin(_mls_x170);
    auto _mls_x173 = _mls_negin(_mls_x171);
    auto _mls_x174 = _mlsValue::create<_mls_Con>(_mls_x172, _mls_x173);
    _mls_retval = _mls_x174;
  } else {
    _mls_retval = _mls_p5;
  }
  return _mls_retval;
}
_mlsValue _mls_opri(_mlsValue _mls_c) {
  _mlsValue _mls_retval;
  auto _mls_x197 = (_mls_c == _mlsValue::create<_mls_Str>("("));
  if (_mlsValue::isIntLit(_mls_x197, 1)) {
    _mls_retval = _mlsValue::fromIntLit(0);
  } else {
    auto _mls_x198 = (_mls_c == _mlsValue::create<_mls_Str>("="));
    if (_mlsValue::isIntLit(_mls_x198, 1)) {
      _mls_retval = _mlsValue::fromIntLit(1);
    } else {
      auto _mls_x199 = (_mls_c == _mlsValue::create<_mls_Str>(">"));
      if (_mlsValue::isIntLit(_mls_x199, 1)) {
        _mls_retval = _mlsValue::fromIntLit(2);
      } else {
        auto _mls_x200 = (_mls_c == _mlsValue::create<_mls_Str>("|"));
        if (_mlsValue::isIntLit(_mls_x200, 1)) {
          _mls_retval = _mlsValue::fromIntLit(3);
        } else {
          auto _mls_x201 = (_mls_c == _mlsValue::create<_mls_Str>("&"));
          if (_mlsValue::isIntLit(_mls_x201, 1)) {
            _mls_retval = _mlsValue::fromIntLit(4);
          } else {
            auto _mls_x202 = (_mls_c == _mlsValue::create<_mls_Str>("~"));
            if (_mlsValue::isIntLit(_mls_x202, 1)) {
              _mls_retval = _mlsValue::fromIntLit(5);
            } else {
              _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
            }
          }
        }
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_parse(_mlsValue _mls_t1) {
  _mlsValue _mls_retval;
  auto _mls_x203 = _mlsValue::create<_mls_Nil>();
  auto _mls_x204 = _mls_parseHelper(_mls_t1, _mls_x203);
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x204)) {
    auto _mls_x205 = _mlsValue::cast<_mls_Cons>(_mls_x204)->_mls_head;
    auto _mls_x206 = _mlsValue::cast<_mls_Cons>(_mls_x204)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Ast>(_mls_x205)) {
      auto _mls_x207 = _mlsValue::cast<_mls_Ast>(_mls_x205)->_mls_f;
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x206)) {
        _mls_retval = _mls_x207;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_parseHelper(_mlsValue _mls_t2, _mlsValue _mls_s2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_t2)) {
    auto _mls_x302 = _mls_redstar(_mls_s2);
    _mls_retval = _mls_x302;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_t2)) {
    auto _mls_x208 = _mlsValue::cast<_mls_Cons>(_mls_t2)->_mls_head;
    auto _mls_x209 = _mlsValue::cast<_mls_Cons>(_mls_t2)->_mls_tail;
    if (_mls_Str::isStrLit(_mls_x208, " ")) {
      auto _mls_x301 = _mls_parseHelper(_mls_x209, _mls_s2);
      _mls_retval = _mls_x301;
    } else if (_mls_Str::isStrLit(_mls_x208, "(")) {
      auto _mls_x298 = _mlsValue::create<_mls_Lex>(_mlsValue::create<_mls_Str>("("));
      auto _mls_x299 = _mlsValue::create<_mls_Cons>(_mls_x298, _mls_s2);
      auto _mls_x300 = _mls_parseHelper(_mls_x209, _mls_x299);
      _mls_retval = _mls_x300;
    } else if (_mls_Str::isStrLit(_mls_x208, ")")) {
      auto _mls_x226 = _mls_redstar(_mls_s2);
      if (_mlsValue::isValueOf<_mls_Cons>(_mls_x226)) {
        auto _mls_x243 = _mlsValue::cast<_mls_Cons>(_mls_x226)->_mls_head;
        auto _mls_x244 = _mlsValue::cast<_mls_Cons>(_mls_x226)->_mls_tail;
        if (_mlsValue::isValueOf<_mls_Cons>(_mls_x244)) {
          auto _mls_x261 = _mlsValue::cast<_mls_Cons>(_mls_x244)->_mls_head;
          auto _mls_x262 = _mlsValue::cast<_mls_Cons>(_mls_x244)->_mls_tail;
          if (_mlsValue::isValueOf<_mls_Lex>(_mls_x261)) {
            auto _mls_x279 = _mlsValue::cast<_mls_Lex>(_mls_x261)->_mls_s;
            if (_mls_Str::isStrLit(_mls_x279, "(")) {
              auto _mls_x296 = _mlsValue::create<_mls_Cons>(_mls_x243, _mls_x262);
              auto _mls_x297 = _mls_parseHelper(_mls_x209, _mls_x296);
              _mls_retval = _mls_x297;
            } else {
              auto _mls_x280 = _mls_builtin_str_leq(_mlsValue::create<_mls_Str>("a"), _mls_x208);
              auto _mls_x281 = _mls_builtin_str_leq(_mls_x208, _mlsValue::create<_mls_Str>("z"));
              auto _mls_x282 = (_mls_x280 && _mls_x281);
              if (_mlsValue::isIntLit(_mls_x282, 1)) {
                auto _mls_x292 = _mlsValue::create<_mls_Sym>(_mls_x208);
                auto _mls_x293 = _mlsValue::create<_mls_Ast>(_mls_x292);
                auto _mls_x294 = _mlsValue::create<_mls_Cons>(_mls_x293, _mls_s2);
                auto _mls_x295 = _mls_parseHelper(_mls_x209, _mls_x294);
                _mls_retval = _mls_x295;
              } else {
                auto _mls_x283 = _mls_spri(_mls_s2);
                auto _mls_x284 = _mls_opri(_mls_x208);
                auto _mls_x285 = (_mls_x283 > _mls_x284);
                if (_mlsValue::isIntLit(_mls_x285, 1)) {
                  auto _mls_x289 = _mlsValue::create<_mls_Cons>(_mls_x208, _mls_x209);
                  auto _mls_x290 = _mls_red(_mls_s2);
                  auto _mls_x291 = _mls_parseHelper(_mls_x289, _mls_x290);
                  _mls_retval = _mls_x291;
                } else {
                  auto _mls_x286 = _mlsValue::create<_mls_Lex>(_mls_x208);
                  auto _mls_x287 = _mlsValue::create<_mls_Cons>(_mls_x286, _mls_s2);
                  auto _mls_x288 = _mls_parseHelper(_mls_x209, _mls_x287);
                  _mls_retval = _mls_x288;
                }
              }
            }
          } else {
            auto _mls_x263 = _mls_builtin_str_leq(_mlsValue::create<_mls_Str>("a"), _mls_x208);
            auto _mls_x264 = _mls_builtin_str_leq(_mls_x208, _mlsValue::create<_mls_Str>("z"));
            auto _mls_x265 = (_mls_x263 && _mls_x264);
            if (_mlsValue::isIntLit(_mls_x265, 1)) {
              auto _mls_x275 = _mlsValue::create<_mls_Sym>(_mls_x208);
              auto _mls_x276 = _mlsValue::create<_mls_Ast>(_mls_x275);
              auto _mls_x277 = _mlsValue::create<_mls_Cons>(_mls_x276, _mls_s2);
              auto _mls_x278 = _mls_parseHelper(_mls_x209, _mls_x277);
              _mls_retval = _mls_x278;
            } else {
              auto _mls_x266 = _mls_spri(_mls_s2);
              auto _mls_x267 = _mls_opri(_mls_x208);
              auto _mls_x268 = (_mls_x266 > _mls_x267);
              if (_mlsValue::isIntLit(_mls_x268, 1)) {
                auto _mls_x272 = _mlsValue::create<_mls_Cons>(_mls_x208, _mls_x209);
                auto _mls_x273 = _mls_red(_mls_s2);
                auto _mls_x274 = _mls_parseHelper(_mls_x272, _mls_x273);
                _mls_retval = _mls_x274;
              } else {
                auto _mls_x269 = _mlsValue::create<_mls_Lex>(_mls_x208);
                auto _mls_x270 = _mlsValue::create<_mls_Cons>(_mls_x269, _mls_s2);
                auto _mls_x271 = _mls_parseHelper(_mls_x209, _mls_x270);
                _mls_retval = _mls_x271;
              }
            }
          }
        } else {
          auto _mls_x245 = _mls_builtin_str_leq(_mlsValue::create<_mls_Str>("a"), _mls_x208);
          auto _mls_x246 = _mls_builtin_str_leq(_mls_x208, _mlsValue::create<_mls_Str>("z"));
          auto _mls_x247 = (_mls_x245 && _mls_x246);
          if (_mlsValue::isIntLit(_mls_x247, 1)) {
            auto _mls_x257 = _mlsValue::create<_mls_Sym>(_mls_x208);
            auto _mls_x258 = _mlsValue::create<_mls_Ast>(_mls_x257);
            auto _mls_x259 = _mlsValue::create<_mls_Cons>(_mls_x258, _mls_s2);
            auto _mls_x260 = _mls_parseHelper(_mls_x209, _mls_x259);
            _mls_retval = _mls_x260;
          } else {
            auto _mls_x248 = _mls_spri(_mls_s2);
            auto _mls_x249 = _mls_opri(_mls_x208);
            auto _mls_x250 = (_mls_x248 > _mls_x249);
            if (_mlsValue::isIntLit(_mls_x250, 1)) {
              auto _mls_x254 = _mlsValue::create<_mls_Cons>(_mls_x208, _mls_x209);
              auto _mls_x255 = _mls_red(_mls_s2);
              auto _mls_x256 = _mls_parseHelper(_mls_x254, _mls_x255);
              _mls_retval = _mls_x256;
            } else {
              auto _mls_x251 = _mlsValue::create<_mls_Lex>(_mls_x208);
              auto _mls_x252 = _mlsValue::create<_mls_Cons>(_mls_x251, _mls_s2);
              auto _mls_x253 = _mls_parseHelper(_mls_x209, _mls_x252);
              _mls_retval = _mls_x253;
            }
          }
        }
      } else {
        auto _mls_x227 = _mls_builtin_str_leq(_mlsValue::create<_mls_Str>("a"), _mls_x208);
        auto _mls_x228 = _mls_builtin_str_leq(_mls_x208, _mlsValue::create<_mls_Str>("z"));
        auto _mls_x229 = (_mls_x227 && _mls_x228);
        if (_mlsValue::isIntLit(_mls_x229, 1)) {
          auto _mls_x239 = _mlsValue::create<_mls_Sym>(_mls_x208);
          auto _mls_x240 = _mlsValue::create<_mls_Ast>(_mls_x239);
          auto _mls_x241 = _mlsValue::create<_mls_Cons>(_mls_x240, _mls_s2);
          auto _mls_x242 = _mls_parseHelper(_mls_x209, _mls_x241);
          _mls_retval = _mls_x242;
        } else {
          auto _mls_x230 = _mls_spri(_mls_s2);
          auto _mls_x231 = _mls_opri(_mls_x208);
          auto _mls_x232 = (_mls_x230 > _mls_x231);
          if (_mlsValue::isIntLit(_mls_x232, 1)) {
            auto _mls_x236 = _mlsValue::create<_mls_Cons>(_mls_x208, _mls_x209);
            auto _mls_x237 = _mls_red(_mls_s2);
            auto _mls_x238 = _mls_parseHelper(_mls_x236, _mls_x237);
            _mls_retval = _mls_x238;
          } else {
            auto _mls_x233 = _mlsValue::create<_mls_Lex>(_mls_x208);
            auto _mls_x234 = _mlsValue::create<_mls_Cons>(_mls_x233, _mls_s2);
            auto _mls_x235 = _mls_parseHelper(_mls_x209, _mls_x234);
            _mls_retval = _mls_x235;
          }
        }
      }
    } else {
      auto _mls_x210 = _mls_builtin_str_leq(_mlsValue::create<_mls_Str>("a"), _mls_x208);
      auto _mls_x211 = _mls_builtin_str_leq(_mls_x208, _mlsValue::create<_mls_Str>("z"));
      auto _mls_x212 = (_mls_x210 && _mls_x211);
      if (_mlsValue::isIntLit(_mls_x212, 1)) {
        auto _mls_x222 = _mlsValue::create<_mls_Sym>(_mls_x208);
        auto _mls_x223 = _mlsValue::create<_mls_Ast>(_mls_x222);
        auto _mls_x224 = _mlsValue::create<_mls_Cons>(_mls_x223, _mls_s2);
        auto _mls_x225 = _mls_parseHelper(_mls_x209, _mls_x224);
        _mls_retval = _mls_x225;
      } else {
        auto _mls_x213 = _mls_spri(_mls_s2);
        auto _mls_x214 = _mls_opri(_mls_x208);
        auto _mls_x215 = (_mls_x213 > _mls_x214);
        if (_mlsValue::isIntLit(_mls_x215, 1)) {
          auto _mls_x219 = _mlsValue::create<_mls_Cons>(_mls_x208, _mls_x209);
          auto _mls_x220 = _mls_red(_mls_s2);
          auto _mls_x221 = _mls_parseHelper(_mls_x219, _mls_x220);
          _mls_retval = _mls_x221;
        } else {
          auto _mls_x216 = _mlsValue::create<_mls_Lex>(_mls_x208);
          auto _mls_x217 = _mlsValue::create<_mls_Cons>(_mls_x216, _mls_s2);
          auto _mls_x218 = _mls_parseHelper(_mls_x209, _mls_x217);
          _mls_retval = _mls_x218;
        }
      }
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_red(_mlsValue _mls_s3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_s3)) {
    auto _mls_x303 = _mlsValue::cast<_mls_Cons>(_mls_s3)->_mls_head;
    auto _mls_x304 = _mlsValue::cast<_mls_Cons>(_mls_s3)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Ast>(_mls_x303)) {
      auto _mls_x305 = _mlsValue::cast<_mls_Ast>(_mls_x303)->_mls_f;
      if (_mlsValue::isValueOf<_mls_Cons>(_mls_x304)) {
        auto _mls_x306 = _mlsValue::cast<_mls_Cons>(_mls_x304)->_mls_head;
        auto _mls_x307 = _mlsValue::cast<_mls_Cons>(_mls_x304)->_mls_tail;
        if (_mlsValue::isValueOf<_mls_Lex>(_mls_x306)) {
          auto _mls_x308 = _mlsValue::cast<_mls_Lex>(_mls_x306)->_mls_s;
          if (_mls_Str::isStrLit(_mls_x308, "=")) {
            if (_mlsValue::isValueOf<_mls_Cons>(_mls_x307)) {
              auto _mls_x330 = _mlsValue::cast<_mls_Cons>(_mls_x307)->_mls_head;
              auto _mls_x331 = _mlsValue::cast<_mls_Cons>(_mls_x307)->_mls_tail;
              if (_mlsValue::isValueOf<_mls_Ast>(_mls_x330)) {
                auto _mls_x332 = _mlsValue::cast<_mls_Ast>(_mls_x330)->_mls_f;
                auto _mls_x333 = _mlsValue::create<_mls_Eqv>(_mls_x332, _mls_x305);
                auto _mls_x334 = _mlsValue::create<_mls_Ast>(_mls_x333);
                auto _mls_x335 = _mlsValue::create<_mls_Cons>(_mls_x334, _mls_x331);
                _mls_retval = _mls_x335;
              } else {
                _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
              }
            } else {
              _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
            }
          } else if (_mls_Str::isStrLit(_mls_x308, ">")) {
            if (_mlsValue::isValueOf<_mls_Cons>(_mls_x307)) {
              auto _mls_x324 = _mlsValue::cast<_mls_Cons>(_mls_x307)->_mls_head;
              auto _mls_x325 = _mlsValue::cast<_mls_Cons>(_mls_x307)->_mls_tail;
              if (_mlsValue::isValueOf<_mls_Ast>(_mls_x324)) {
                auto _mls_x326 = _mlsValue::cast<_mls_Ast>(_mls_x324)->_mls_f;
                auto _mls_x327 = _mlsValue::create<_mls_Imp>(_mls_x326, _mls_x305);
                auto _mls_x328 = _mlsValue::create<_mls_Ast>(_mls_x327);
                auto _mls_x329 = _mlsValue::create<_mls_Cons>(_mls_x328, _mls_x325);
                _mls_retval = _mls_x329;
              } else {
                _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
              }
            } else {
              _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
            }
          } else if (_mls_Str::isStrLit(_mls_x308, "|")) {
            if (_mlsValue::isValueOf<_mls_Cons>(_mls_x307)) {
              auto _mls_x318 = _mlsValue::cast<_mls_Cons>(_mls_x307)->_mls_head;
              auto _mls_x319 = _mlsValue::cast<_mls_Cons>(_mls_x307)->_mls_tail;
              if (_mlsValue::isValueOf<_mls_Ast>(_mls_x318)) {
                auto _mls_x320 = _mlsValue::cast<_mls_Ast>(_mls_x318)->_mls_f;
                auto _mls_x321 = _mlsValue::create<_mls_Dis>(_mls_x320, _mls_x305);
                auto _mls_x322 = _mlsValue::create<_mls_Ast>(_mls_x321);
                auto _mls_x323 = _mlsValue::create<_mls_Cons>(_mls_x322, _mls_x319);
                _mls_retval = _mls_x323;
              } else {
                _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
              }
            } else {
              _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
            }
          } else if (_mls_Str::isStrLit(_mls_x308, "&")) {
            if (_mlsValue::isValueOf<_mls_Cons>(_mls_x307)) {
              auto _mls_x312 = _mlsValue::cast<_mls_Cons>(_mls_x307)->_mls_head;
              auto _mls_x313 = _mlsValue::cast<_mls_Cons>(_mls_x307)->_mls_tail;
              if (_mlsValue::isValueOf<_mls_Ast>(_mls_x312)) {
                auto _mls_x314 = _mlsValue::cast<_mls_Ast>(_mls_x312)->_mls_f;
                auto _mls_x315 = _mlsValue::create<_mls_Con>(_mls_x314, _mls_x305);
                auto _mls_x316 = _mlsValue::create<_mls_Ast>(_mls_x315);
                auto _mls_x317 = _mlsValue::create<_mls_Cons>(_mls_x316, _mls_x313);
                _mls_retval = _mls_x317;
              } else {
                _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
              }
            } else {
              _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
            }
          } else if (_mls_Str::isStrLit(_mls_x308, "~")) {
            auto _mls_x309 = _mlsValue::create<_mls_Not>(_mls_x305);
            auto _mls_x310 = _mlsValue::create<_mls_Ast>(_mls_x309);
            auto _mls_x311 = _mlsValue::create<_mls_Cons>(_mls_x310, _mls_x307);
            _mls_retval = _mls_x311;
          } else {
            _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
          }
        } else {
          _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_redstar(_mlsValue _mls_s4) {
  _mlsValue _mls_retval;
  auto _mls_x336 = _mlsValue::create<_mls_Lambda_lambda>();
  auto _mls_x337 = _mlsValue::create<_mls_Lambda_red>();
  auto _mls_x338 = _mls_while_(_mls_x336, _mls_x337, _mls_s4);
  _mls_retval = _mls_x338;
  return _mls_retval;
}
_mlsValue _mls_replicate(_mlsValue _mls_n, _mlsValue _mls_x341) {
  _mlsValue _mls_retval;
  auto _mls_x339 = (_mls_n == _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x339, 1)) {
    auto _mls_x344 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x344;
  } else {
    auto _mls_x340 = (_mls_n - _mlsValue::fromIntLit(1));
    auto _mls_x342 = _mls_replicate(_mls_x340, _mls_x341);
    auto _mls_x343 = _mlsValue::create<_mls_Cons>(_mls_x341, _mls_x342);
    _mls_retval = _mls_x343;
  }
  return _mls_retval;
}
_mlsValue _mls_split(_mlsValue _mls_p6) {
  _mlsValue _mls_retval;
  auto _mls_x345 = _mlsValue::create<_mls_Nil>();
  auto _mls_x346 = _mls_splitHelper(_mls_p6, _mls_x345);
  _mls_retval = _mls_x346;
  return _mls_retval;
}
_mlsValue _mls_splitHelper(_mlsValue _mls_p7, _mlsValue _mls_a7) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Con>(_mls_p7)) {
    auto _mls_x348 = _mlsValue::cast<_mls_Con>(_mls_p7)->_mls_a;
    auto _mls_x349 = _mlsValue::cast<_mls_Con>(_mls_p7)->_mls_b;
    auto _mls_x350 = _mls_splitHelper(_mls_x349, _mls_a7);
    auto _mls_x351 = _mls_splitHelper(_mls_x348, _mls_x350);
    _mls_retval = _mls_x351;
  } else {
    auto _mls_x347 = _mlsValue::create<_mls_Cons>(_mls_p7, _mls_a7);
    _mls_retval = _mls_x347;
  }
  return _mls_retval;
}
_mlsValue _mls_spri(_mlsValue _mls_s5) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_s5)) {
    auto _mls_x352 = _mlsValue::cast<_mls_Cons>(_mls_s5)->_mls_head;
    auto _mls_x353 = _mlsValue::cast<_mls_Cons>(_mls_s5)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Ast>(_mls_x352)) {
      if (_mlsValue::isValueOf<_mls_Cons>(_mls_x353)) {
        auto _mls_x354 = _mlsValue::cast<_mls_Cons>(_mls_x353)->_mls_head;
        if (_mlsValue::isValueOf<_mls_Lex>(_mls_x354)) {
          auto _mls_x355 = _mlsValue::cast<_mls_Lex>(_mls_x354)->_mls_s;
          auto _mls_x356 = _mls_opri(_mls_x355);
          _mls_retval = _mls_x356;
        } else {
          _mls_retval = _mlsValue::fromIntLit(0);
        }
      } else {
        _mls_retval = _mlsValue::fromIntLit(0);
      }
    } else {
      _mls_retval = _mlsValue::fromIntLit(0);
    }
  } else {
    _mls_retval = _mlsValue::fromIntLit(0);
  }
  return _mls_retval;
}
_mlsValue _mls_str_to_list(_mlsValue _mls_x358) {
  _mlsValue _mls_retval;
  auto _mls_x357 = _mls_builtin_str_head(_mls_x358);
  if (_mlsValue::isValueOf<_mls_Unit>(_mls_x357)) {
    auto _mls_x363 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x363;
  } else {
    auto _mls_x359 = _mls_builtin_str_head(_mls_x358);
    auto _mls_x360 = _mls_builtin_str_tail(_mls_x358);
    auto _mls_x361 = _mls_str_to_list(_mls_x360);
    auto _mls_x362 = _mlsValue::create<_mls_Cons>(_mls_x359, _mls_x361);
    _mls_retval = _mls_x362;
  }
  return _mls_retval;
}
_mlsValue _mls_tautclause(_mlsValue _mls_c_a) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_c_a)) {
    auto _mls_x364 = _mlsValue::cast<_mls_Tuple2>(_mls_c_a)->_mls_field0;
    auto _mls_x365 = _mlsValue::cast<_mls_Tuple2>(_mls_c_a)->_mls_field1;
    auto _mls_x366 = _mlsValue::create<_mls_Lambda_lscomp>(_mls_x365);
    auto _mls_x367 = _mlsMethodCall<_mls_Callable>(_mls_x366)->_mls_apply1(_mls_x364);
    auto _mls_x368 = _mlsValue::create<_mls_Nil>();
    auto _mls_x369 = _mls_listNeq(_mls_x367, _mls_x368);
    _mls_retval = _mls_x369;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_testClausify_nofib(_mlsValue _mls_n1) {
  _mlsValue _mls_retval;
  auto _mls_x370 = _mls_str_to_list(_mlsValue::create<_mls_Str>("(a = a = a) = (a = a = a) = (a = a = a)"));
  auto _mls_x371 = _mls_replicate(_mls_n1, _mls_x370);
  auto _mls_x372 = _mlsValue::create<_mls_Lambda_clauses>();
  auto _mls_x373 = _mls_map(_mls_x372, _mls_x371);
  auto _mls_x374 = _mls_concat(_mls_x373);
  auto _mls_x375 = _mls_list_to_str(_mls_x374);
  _mls_retval = _mls_x375;
  return _mls_retval;
}
_mlsValue _mls_unicl(_mlsValue _mls_a8) {
  _mlsValue _mls_retval;
  auto _mls_x376 = _mlsValue::create<_mls_Lambda_uniclHelper>();
  auto _mls_x377 = _mlsValue::create<_mls_Nil>();
  auto _mls_x378 = _mls_foldr(_mls_x376, _mls_x377, _mls_a8);
  _mls_retval = _mls_x378;
  return _mls_retval;
}
_mlsValue _mls_uniclHelper(_mlsValue _mls_p8, _mlsValue _mls_x381) {
  _mlsValue _mls_retval;
  auto _mls_x379 = _mls_clause(_mls_p8);
  auto _mls_x380 = _mls_tautclause(_mls_x379);
  if (_mlsValue::isIntLit(_mls_x380, 1)) {
    _mls_retval = _mls_x381;
  } else {
    auto _mls_x382 = _mls_insert(_mls_x379, _mls_x381);
    _mls_retval = _mls_x382;
  }
  return _mls_retval;
}
_mlsValue _mls_while_(_mlsValue _mls_p9, _mlsValue _mls_f3, _mlsValue _mls_x383) {
  _mlsValue _mls_retval;
  auto _mls_x384 = _mlsMethodCall<_mls_Callable>(_mls_p9)->_mls_apply1(_mls_x383);
  if (_mlsValue::isIntLit(_mls_x384, 1)) {
    auto _mls_x385 = _mlsMethodCall<_mls_Callable>(_mls_f3)->_mls_apply1(_mls_x383);
    auto _mls_x386 = _mls_while_(_mls_p9, _mls_f3, _mls_x385);
    _mls_retval = _mls_x386;
  } else {
    _mls_retval = _mls_x383;
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_clauses::_mls_apply1(_mlsValue _mls_arg) {
  _mlsValue _mls_retval;
  auto _mls_x = _mls_clauses(_mls_arg);
  _mls_retval = _mls_x;
  return _mls_retval;
}
_mlsValue _mls_Lambda_disp::_mls_apply1(_mlsValue _mls_arg1) {
  _mlsValue _mls_retval;
  auto _mls_x1 = _mls_disp(_mls_arg1);
  _mls_retval = _mls_x1;
  return _mls_retval;
}
_mlsValue _mls_Lambda_l::_mls_apply2(_mlsValue _mls_ls, _mlsValue _mls_a4) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls)) {
    _mls_retval = _mls_a4;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls)) {
    auto _mls_x2 = _mlsValue::cast<_mls_Cons>(_mls_ls)->_mls_head;
    auto _mls_x3 = _mlsValue::cast<_mls_Cons>(_mls_ls)->_mls_tail;
    auto _mls_x4 = (_mls_a4 + _mlsValue::fromIntLit(1));
    auto _mls_x5 = this->_mls_apply2(_mls_x3, _mls_x4);
    _mls_retval = _mls_x5;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda::_mls_apply1(_mlsValue _mls_s) {
  _mlsValue _mls_retval;
  auto _mls_x6 = _mls_spri(_mls_s);
  auto _mls_x7 = (_mls_x6 != _mlsValue::fromIntLit(0));
  _mls_retval = _mls_x7;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lscomp::_mls_apply1(_mlsValue _mls_ls1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls1)) {
    auto _mls_x14 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x14;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls1)) {
    auto _mls_x8 = _mlsValue::cast<_mls_Cons>(_mls_ls1)->_mls_head;
    auto _mls_x9 = _mlsValue::cast<_mls_Cons>(_mls_ls1)->_mls_tail;
    auto _mls_x10 = _mls_inList(_mls_x8, _mls_lam_arg0);
    if (_mlsValue::isIntLit(_mls_x10, 1)) {
      auto _mls_x12 = this->_mls_apply1(_mls_x9);
      auto _mls_x13 = _mlsValue::create<_mls_Cons>(_mls_x8, _mls_x12);
      _mls_retval = _mls_x13;
    } else {
      auto _mls_x11 = this->_mls_apply1(_mls_x9);
      _mls_retval = _mls_x11;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_red::_mls_apply1(_mlsValue _mls_arg2) {
  _mlsValue _mls_retval;
  auto _mls_x15 = _mls_red(_mls_arg2);
  _mls_retval = _mls_x15;
  return _mls_retval;
}
_mlsValue _mls_Lambda_uniclHelper::_mls_apply2(_mlsValue _mls_arg3, _mlsValue _mls_arg4) {
  _mlsValue _mls_retval;
  auto _mls_x16 = _mls_uniclHelper(_mls_arg3, _mls_arg4);
  _mls_retval = _mls_x16;
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
