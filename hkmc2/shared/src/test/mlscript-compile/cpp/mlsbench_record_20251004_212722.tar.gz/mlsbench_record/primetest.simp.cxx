#include "mlsprelude.h"
struct _mls_Lambda_f;
struct _mls_Lambda_g;
struct _mls_Lambda_lambda;
struct _mls_Lambda_lambda1;
struct _mls_Lambda_lambda2;
struct _mls_Lambda_lambda3;
struct _mls_Lambda_lambda4;
struct _mls_List;
struct _mls_Cons;
struct _mls_Nil;
struct _mls_Tuple2;
struct _mls_Tuple3;
_mlsValue _mls_break_(_mlsValue, _mlsValue);
_mlsValue _mls_chop(_mlsValue, _mlsValue);
_mlsValue _mls_chop_(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_divMod(_mlsValue, _mlsValue);
_mlsValue _mls_doInput(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_doLine(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_even(_mlsValue);
_mlsValue _mls_findKQ(_mlsValue);
_mlsValue _mls_findKQ_f(_mlsValue, _mlsValue);
_mlsValue _mls_foldl(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_generateRands(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_intDiv(_mlsValue, _mlsValue);
_mlsValue _mls_intMod(_mlsValue, _mlsValue);
_mlsValue _mls_int_val_of_char(_mlsValue);
_mlsValue _mls_int_val_of_string_f(_mlsValue, _mlsValue);
_mlsValue _mls_is_iter(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_iterate_square(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_j1(_mlsValue, _mlsValue);
_mlsValue _mls_j(_mlsValue, _mlsValue);
_mlsValue _mls_j2(_mlsValue, _mlsValue);
_mlsValue _mls_l2(_mlsValue, _mlsValue);
_mlsValue _mls_lines(_mlsValue);
_mlsValue _mls_makeNumber(_mlsValue, _mlsValue);
_mlsValue _mls_map(_mlsValue, _mlsValue);
_mlsValue _mls_multiTest(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_multiTest_mTest(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_nextRand(_mlsValue, _mlsValue);
_mlsValue _mls_powerMod(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_random(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_repeatProcess(_mlsValue, _mlsValue);
_mlsValue _mls_singleTest(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_singleTestX(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_singleTestX_square(_mlsValue, _mlsValue);
_mlsValue _mls_singleTestX_witness(_mlsValue, _mlsValue);
_mlsValue _mls_str_to_list(_mlsValue);
_mlsValue _mls_testPrimetest_nofib(_mlsValue);
_mlsValue _mls_uniform(_mlsValue, _mlsValue);
struct _mls_Lambda_f: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_f";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_f>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_f; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply3(_mlsValue, _mlsValue, _mlsValue);
};
struct _mls_Lambda_g: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  _mlsValue _mls_lam_arg1;
  _mlsValue _mls_lam_arg2;
  constexpr static inline const char *typeName = "Lambda_g";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print(); std::printf(", "); this->_mls_lam_arg1.print(); std::printf(", "); this->_mls_lam_arg2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0); _mlsValue::destroy(this->_mls_lam_arg1); _mlsValue::destroy(this->_mls_lam_arg2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_g>()->_mls_lam_arg0.asObject()) && this->_mls_lam_arg1.asObject()->operator==(*other.cast<_mls_Lambda_g>()->_mls_lam_arg1.asObject()) && this->_mls_lam_arg2.asObject()->operator==(*other.cast<_mls_Lambda_g>()->_mls_lam_arg2.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0, _mlsValue _mls_lam_arg1, _mlsValue _mls_lam_arg2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_g; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0; _mlsVal->_mls_lam_arg1 = _mls_lam_arg1; _mlsVal->_mls_lam_arg2 = _mls_lam_arg2;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_lambda: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda1: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda1>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda1; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_lambda2: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda2>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_lambda3: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda3; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda4: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda4>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda4; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_List: public _mlsObject {
  
  constexpr static inline const char *typeName = "List";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_List; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Cons: public _mls_List {
  _mlsValue _mls_head;
  _mlsValue _mls_tail;
  constexpr static inline const char *typeName = "Cons";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_head.print(); std::printf(", "); this->_mls_tail.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_head); _mlsValue::destroy(this->_mls_tail);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_head.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_head.asObject()) && this->_mls_tail.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_tail.asObject()); }
  static _mlsValue create(_mlsValue _mls_head, _mlsValue _mls_tail) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Cons; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_head = _mls_head; _mlsVal->_mls_tail = _mls_tail;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Nil: public _mls_List {
  
  constexpr static inline const char *typeName = "Nil";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Nil; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Tuple2: public _mlsObject {
  _mlsValue _mls_field0;
  _mlsValue _mls_field1;
  constexpr static inline const char *typeName = "Tuple2";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_field0.print(); std::printf(", "); this->_mls_field1.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_field0); _mlsValue::destroy(this->_mls_field1);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_field0.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field0.asObject()) && this->_mls_field1.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field1.asObject()); }
  static _mlsValue create(_mlsValue _mls_field0, _mlsValue _mls_field1) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Tuple2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_field0 = _mls_field0; _mlsVal->_mls_field1 = _mls_field1;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Tuple3: public _mlsObject {
  _mlsValue _mls_field0;
  _mlsValue _mls_field1;
  _mlsValue _mls_field2;
  constexpr static inline const char *typeName = "Tuple3";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_field0.print(); std::printf(", "); this->_mls_field1.print(); std::printf(", "); this->_mls_field2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_field0); _mlsValue::destroy(this->_mls_field1); _mlsValue::destroy(this->_mls_field2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_field0.asObject()->operator==(*other.cast<_mls_Tuple3>()->_mls_field0.asObject()) && this->_mls_field1.asObject()->operator==(*other.cast<_mls_Tuple3>()->_mls_field1.asObject()) && this->_mls_field2.asObject()->operator==(*other.cast<_mls_Tuple3>()->_mls_field2.asObject()); }
  static _mlsValue create(_mlsValue _mls_field0, _mlsValue _mls_field1, _mlsValue _mls_field2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Tuple3; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_field0 = _mls_field0; _mlsVal->_mls_field1 = _mls_field1; _mlsVal->_mls_field2 = _mls_field2;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_break_(_mlsValue _mls_p, _mlsValue _mls_ls) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls)) {
    auto _mls_x33 = _mlsValue::create<_mls_Nil>();
    auto _mls_x34 = _mlsValue::create<_mls_Nil>();
    auto _mls_x35 = _mlsValue::create<_mls_Tuple2>(_mls_x33, _mls_x34);
    _mls_retval = _mls_x35;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls)) {
    auto _mls_x22 = _mlsValue::cast<_mls_Cons>(_mls_ls)->_mls_head;
    auto _mls_x23 = _mlsValue::cast<_mls_Cons>(_mls_ls)->_mls_tail;
    auto _mls_x24 = _mlsMethodCall<_mls_Callable>(_mls_p)->_mls_apply1(_mls_x22);
    if (_mlsValue::isIntLit(_mls_x24, 1)) {
      auto _mls_x30 = _mlsValue::create<_mls_Cons>(_mls_x22, _mls_x23);
      auto _mls_x31 = _mlsValue::create<_mls_Nil>();
      auto _mls_x32 = _mlsValue::create<_mls_Tuple2>(_mls_x31, _mls_x30);
      _mls_retval = _mls_x32;
    } else {
      auto _mls_x25 = _mls_break_(_mls_p, _mls_x23);
      if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x25)) {
        auto _mls_x26 = _mlsValue::cast<_mls_Tuple2>(_mls_x25)->_mls_field0;
        auto _mls_x27 = _mlsValue::cast<_mls_Tuple2>(_mls_x25)->_mls_field1;
        auto _mls_x28 = _mlsValue::create<_mls_Cons>(_mls_x22, _mls_x26);
        auto _mls_x29 = _mlsValue::create<_mls_Tuple2>(_mls_x28, _mls_x27);
        _mls_retval = _mls_x29;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_chop(_mlsValue _mls_b2, _mlsValue _mls_n) {
  _mlsValue _mls_retval;
  auto _mls_x36 = _mlsValue::create<_mls_Nil>();
  auto _mls_x37 = _mls_chop_(_mls_x36, _mls_n, _mls_b2);
  _mls_retval = _mls_x37;
  return _mls_retval;
}
_mlsValue _mls_chop_(_mlsValue _mls_a3, _mlsValue _mls_n1, _mlsValue _mls_b3) {
  _mlsValue _mls_retval;
  auto _mls_x38 = _mls_divMod(_mls_n1, _mls_b3);
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x38)) {
    auto _mls_x39 = _mlsValue::cast<_mls_Tuple2>(_mls_x38)->_mls_field0;
    auto _mls_x40 = _mlsValue::cast<_mls_Tuple2>(_mls_x38)->_mls_field1;
    auto _mls_x41 = (_mls_n1 == _mlsValue::fromIntLit(0));
    if (_mlsValue::isIntLit(_mls_x41, 1)) {
      _mls_retval = _mls_a3;
    } else {
      auto _mls_x42 = _mlsValue::create<_mls_Cons>(_mls_x40, _mls_a3);
      auto _mls_x43 = _mls_chop_(_mls_x42, _mls_x39, _mls_b3);
      _mls_retval = _mls_x43;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_divMod(_mlsValue _mls_a4, _mlsValue _mls_b4) {
  _mlsValue _mls_retval;
  auto _mls_x44 = _mls_builtin_floor_div(_mls_a4, _mls_b4);
  auto _mls_x45 = _mls_builtin_floor_mod(_mls_a4, _mls_b4);
  auto _mls_x46 = _mlsValue::create<_mls_Tuple2>(_mls_x44, _mls_x45);
  _mls_retval = _mls_x46;
  return _mls_retval;
}
_mlsValue _mls_doInput(_mlsValue _mls_s1, _mlsValue _mls_s2, _mlsValue _mls_lls) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_lls)) {
    auto _mls_x51 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x51;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_lls)) {
    auto _mls_x47 = _mlsValue::cast<_mls_Cons>(_mls_lls)->_mls_head;
    auto _mls_x48 = _mlsValue::cast<_mls_Cons>(_mls_lls)->_mls_tail;
    auto _mls_x49 = _mlsValue::create<_mls_Lambda_lambda1>(_mls_x48);
    auto _mls_x50 = _mls_doLine(_mls_x47, _mls_x49, _mls_s1, _mls_s2);
    _mls_retval = _mls_x50;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_doLine(_mlsValue _mls_cs, _mlsValue _mls_cont, _mlsValue _mls_s11, _mlsValue _mls_s21) {
  _mlsValue _mls_retval;
  auto _mls_x52 = _mls_int_val_of_string_f(_mls_cs, _mlsValue::fromIntLit(0));
  auto _mls_x53 = _mls_multiTest(_mlsValue::fromIntLit(100), _mls_s11, _mls_s21, _mls_x52);
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x53)) {
    auto _mls_x54 = _mlsValue::cast<_mls_Tuple3>(_mls_x53)->_mls_field0;
    auto _mls_x55 = _mlsValue::cast<_mls_Tuple3>(_mls_x53)->_mls_field1;
    auto _mls_x56 = _mlsValue::cast<_mls_Tuple3>(_mls_x53)->_mls_field2;
    if (_mlsValue::isIntLit(_mls_x54, 1)) {
      auto _mls_x59 = _mlsMethodCall<_mls_Callable>(_mls_cont)->_mls_apply2(_mls_x55, _mls_x56);
      auto _mls_x60 = _mlsValue::create<_mls_Cons>(_mlsValue::create<_mls_Str>("Probably prime"), _mls_x59);
      _mls_retval = _mls_x60;
    } else {
      auto _mls_x57 = _mlsMethodCall<_mls_Callable>(_mls_cont)->_mls_apply2(_mls_x55, _mls_x56);
      auto _mls_x58 = _mlsValue::create<_mls_Cons>(_mlsValue::create<_mls_Str>("Composite"), _mls_x57);
      _mls_retval = _mls_x58;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x61 = _mls_testPrimetest_nofib(_mlsValue::fromIntLit(0));
  _mls_retval = _mls_x61;
  return _mls_retval;
}
_mlsValue _mls_even(_mlsValue _mls_x63) {
  _mlsValue _mls_retval;
  auto _mls_x62 = _mls_builtin_floor_mod(_mls_x63, _mlsValue::fromIntLit(2));
  auto _mls_x64 = (_mls_x62 == _mlsValue::fromIntLit(0));
  _mls_retval = _mls_x64;
  return _mls_retval;
}
_mlsValue _mls_findKQ(_mlsValue _mls_n2) {
  _mlsValue _mls_retval;
  auto _mls_x65 = (_mls_n2 - _mlsValue::fromIntLit(1));
  auto _mls_x66 = _mls_findKQ_f(_mlsValue::fromIntLit(0), _mls_x65);
  _mls_retval = _mls_x66;
  return _mls_retval;
}
_mlsValue _mls_findKQ_f(_mlsValue _mls_k, _mlsValue _mls_q) {
  _mlsValue _mls_retval;
  auto _mls_x67 = _mls_divMod(_mls_q, _mlsValue::fromIntLit(2));
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x67)) {
    auto _mls_x68 = _mlsValue::cast<_mls_Tuple2>(_mls_x67)->_mls_field0;
    auto _mls_x69 = _mlsValue::cast<_mls_Tuple2>(_mls_x67)->_mls_field1;
    auto _mls_x70 = (_mls_x69 == _mlsValue::fromIntLit(0));
    if (_mlsValue::isIntLit(_mls_x70, 1)) {
      auto _mls_x72 = (_mls_k + _mlsValue::fromIntLit(1));
      auto _mls_x73 = _mls_findKQ_f(_mls_x72, _mls_x68);
      _mls_retval = _mls_x73;
    } else {
      auto _mls_x71 = _mlsValue::create<_mls_Tuple2>(_mls_k, _mls_q);
      _mls_retval = _mls_x71;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_foldl(_mlsValue _mls_f, _mlsValue _mls_a5, _mlsValue _mls_xs) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs)) {
    _mls_retval = _mls_a5;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs)) {
    auto _mls_x74 = _mlsValue::cast<_mls_Cons>(_mls_xs)->_mls_head;
    auto _mls_x75 = _mlsValue::cast<_mls_Cons>(_mls_xs)->_mls_tail;
    auto _mls_x76 = _mlsMethodCall<_mls_Callable>(_mls_f)->_mls_apply2(_mls_a5, _mls_x74);
    auto _mls_x77 = _mls_foldl(_mls_f, _mls_x76, _mls_x75);
    _mls_retval = _mls_x77;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_generateRands(_mlsValue _mls_count, _mlsValue _mls_s12, _mlsValue _mls_s22, _mlsValue _mls_acc) {
  _mlsValue _mls_retval;
  auto _mls_x78 = (_mls_count == _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x78, 1)) {
    auto _mls_x86 = _mlsValue::create<_mls_Tuple3>(_mls_acc, _mls_s12, _mls_s22);
    _mls_retval = _mls_x86;
  } else {
    auto _mls_x79 = _mls_nextRand(_mls_s12, _mls_s22);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x79)) {
      auto _mls_x80 = _mlsValue::cast<_mls_Tuple3>(_mls_x79)->_mls_field0;
      auto _mls_x81 = _mlsValue::cast<_mls_Tuple3>(_mls_x79)->_mls_field1;
      auto _mls_x82 = _mlsValue::cast<_mls_Tuple3>(_mls_x79)->_mls_field2;
      auto _mls_x83 = (_mls_count - _mlsValue::fromIntLit(1));
      auto _mls_x84 = _mlsValue::create<_mls_Cons>(_mls_x80, _mls_acc);
      auto _mls_x85 = _mls_generateRands(_mls_x83, _mls_x81, _mls_x82, _mls_x84);
      _mls_retval = _mls_x85;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  }
  return _mls_retval;
}
_mlsValue _mls_intDiv(_mlsValue _mls_a6, _mlsValue _mls_b5) {
  _mlsValue _mls_retval;
  auto _mls_x87 = _mls_builtin_floor_div(_mls_a6, _mls_b5);
  _mls_retval = _mls_x87;
  return _mls_retval;
}
_mlsValue _mls_intMod(_mlsValue _mls_a7, _mlsValue _mls_b6) {
  _mlsValue _mls_retval;
  auto _mls_x88 = _mls_builtin_floor_mod(_mls_a7, _mls_b6);
  _mls_retval = _mls_x88;
  return _mls_retval;
}
_mlsValue _mls_int_val_of_char(_mlsValue _mls_x90) {
  _mlsValue _mls_retval;
  auto _mls_x89 = _mls_builtin_char2int(_mls_x90);
  auto _mls_x91 = (_mls_x89 - _mlsValue::fromIntLit(48));
  _mls_retval = _mls_x91;
  return _mls_retval;
}
_mlsValue _mls_int_val_of_string_f(_mlsValue _mls_l, _mlsValue _mls_a8) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_l)) {
    _mls_retval = _mls_a8;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_l)) {
    auto _mls_x92 = _mlsValue::cast<_mls_Cons>(_mls_l)->_mls_head;
    auto _mls_x93 = _mlsValue::cast<_mls_Cons>(_mls_l)->_mls_tail;
    auto _mls_x94 = (_mlsValue::fromIntLit(10) * _mls_a8);
    auto _mls_x95 = _mls_int_val_of_char(_mls_x92);
    auto _mls_x96 = (_mls_x94 + _mls_x95);
    auto _mls_x97 = _mls_int_val_of_string_f(_mls_x93, _mls_x96);
    _mls_retval = _mls_x97;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_is_iter(_mlsValue _mls_n3, _mlsValue _mls_acc1, _mlsValue _mls_v, _mlsValue _mls_f1) {
  _mlsValue _mls_retval;
  auto _mls_x98 = (_mls_n3 == _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x98, 1)) {
    _mls_retval = _mls_acc1;
  } else {
    auto _mls_x99 = (_mls_n3 - _mlsValue::fromIntLit(1));
    auto _mls_x100 = _mlsValue::create<_mls_Cons>(_mls_v, _mls_acc1);
    auto _mls_x101 = _mlsMethodCall<_mls_Callable>(_mls_f1)->_mls_apply1(_mls_v);
    auto _mls_x102 = _mls_is_iter(_mls_x99, _mls_x100, _mls_x101, _mls_f1);
    _mls_retval = _mls_x102;
  }
  return _mls_retval;
}
_mlsValue _mls_iterate_square(_mlsValue _mls_f2, _mlsValue _mls_x104, _mlsValue _mls_k1) {
  _mlsValue _mls_retval;
  auto _mls_x103 = _mlsValue::create<_mls_Nil>();
  auto _mls_x105 = _mls_is_iter(_mls_k1, _mls_x103, _mls_x104, _mls_f2);
  _mls_retval = _mls_x105;
  return _mls_retval;
}
_mlsValue _mls_j1(_mlsValue _mls_tmp1, _mlsValue _mls_s23) {
  _mlsValue _mls_retval;
  _mlsValue _mls_s1__, _mls_tmp;
  auto _mls_x106 = _mls_builtin_floor_div(_mls_s23, _mlsValue::fromIntLit(52774));
  auto _mls_x107 = (_mls_x106 * _mlsValue::fromIntLit(52774));
  auto _mls_x108 = (_mls_s23 - _mls_x107);
  auto _mls_x109 = (_mlsValue::fromIntLit(40692) * _mls_x108);
  auto _mls_x110 = (_mls_x106 * _mlsValue::fromIntLit(3791));
  auto _mls_x111 = (_mls_x109 - _mls_x110);
  auto _mls_x112 = (_mls_x111 < _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x112, 1)) {
    auto _mls_x113 = (_mls_x111 + _mlsValue::fromIntLit(2147483399));
    _mls_s1__ = _mls_tmp1;
    _mls_tmp = _mls_x113;
    goto _mls_j;
  } else {
    _mls_s1__ = _mls_tmp1;
    _mls_tmp = _mls_x111;
    goto _mls_j;
  }
  return _mls_retval;
  _mls_j:
  {
    auto _mls_x114 = (_mls_s1__ - _mls_tmp);
    auto _mls_x115 = (_mls_x114 < _mlsValue::fromIntLit(1));
    if (_mlsValue::isIntLit(_mls_x115, 1)) {
      auto _mls_x117 = (_mls_x114 + _mlsValue::fromIntLit(2147483562));
      auto _mls_x118 = _mlsValue::create<_mls_Tuple3>(_mls_x117, _mls_s1__, _mls_tmp);
      _mls_retval = _mls_x118;
    } else {
      auto _mls_x116 = _mlsValue::create<_mls_Tuple3>(_mls_x114, _mls_s1__, _mls_tmp);
      _mls_retval = _mls_x116;
    }
    return _mls_retval;
  }
}
_mlsValue _mls_j(_mlsValue _mls_s1__, _mlsValue _mls_tmp) {
  _mlsValue _mls_retval;
  auto _mls_x114 = (_mls_s1__ - _mls_tmp);
  auto _mls_x115 = (_mls_x114 < _mlsValue::fromIntLit(1));
  if (_mlsValue::isIntLit(_mls_x115, 1)) {
    auto _mls_x117 = (_mls_x114 + _mlsValue::fromIntLit(2147483562));
    auto _mls_x118 = _mlsValue::create<_mls_Tuple3>(_mls_x117, _mls_s1__, _mls_tmp);
    _mls_retval = _mls_x118;
  } else {
    auto _mls_x116 = _mlsValue::create<_mls_Tuple3>(_mls_x114, _mls_s1__, _mls_tmp);
    _mls_retval = _mls_x116;
  }
  return _mls_retval;
}
_mlsValue _mls_j2(_mlsValue _mls_tmp2, _mlsValue _mls_l1) {
  _mlsValue _mls_retval;
  auto _mls_x119 = _mlsValue::create<_mls_Cons>(_mls_l1, _mls_tmp2);
  _mls_retval = _mls_x119;
  return _mls_retval;
}
_mlsValue _mls_l2(_mlsValue _mls_ls1, _mlsValue _mls_a9) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls1)) {
    _mls_retval = _mls_a9;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls1)) {
    auto _mls_x120 = _mlsValue::cast<_mls_Cons>(_mls_ls1)->_mls_tail;
    auto _mls_x121 = (_mls_a9 + _mlsValue::fromIntLit(1));
    auto _mls_x122 = _mls_l2(_mls_x120, _mls_x121);
    _mls_retval = _mls_x122;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_lines(_mlsValue _mls_s) {
  _mlsValue _mls_retval;
  _mlsValue _mls_tmp2, _mls_l1;
  auto _mls_x123 = _mlsValue::create<_mls_Lambda_lambda3>();
  auto _mls_x124 = _mls_break_(_mls_x123, _mls_s);
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x124)) {
    auto _mls_x125 = _mlsValue::cast<_mls_Tuple2>(_mls_x124)->_mls_field0;
    auto _mls_x126 = _mlsValue::cast<_mls_Tuple2>(_mls_x124)->_mls_field1;
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x126)) {
      auto _mls_x129 = _mlsValue::create<_mls_Nil>();
      _mls_tmp2 = _mls_x129;
      _mls_l1 = _mls_x125;
      goto _mls_j2;
    } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x126)) {
      auto _mls_x127 = _mlsValue::cast<_mls_Cons>(_mls_x126)->_mls_tail;
      auto _mls_x128 = _mls_lines(_mls_x127);
      _mls_tmp2 = _mls_x128;
      _mls_l1 = _mls_x125;
      goto _mls_j2;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
  _mls_j2:
  {
    auto _mls_x119 = _mlsValue::create<_mls_Cons>(_mls_l1, _mls_tmp2);
    _mls_retval = _mls_x119;
    return _mls_retval;
  }
}
_mlsValue _mls_makeNumber(_mlsValue _mls_b7, _mlsValue _mls_ls2) {
  _mlsValue _mls_retval;
  auto _mls_x130 = _mlsValue::create<_mls_Lambda_lambda2>(_mls_b7);
  auto _mls_x131 = _mls_foldl(_mls_x130, _mlsValue::fromIntLit(0), _mls_ls2);
  _mls_retval = _mls_x131;
  return _mls_retval;
}
_mlsValue _mls_map(_mlsValue _mls_f3, _mlsValue _mls_xs1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs1)) {
    auto _mls_x133 = _mlsValue::cast<_mls_Cons>(_mls_xs1)->_mls_head;
    auto _mls_x134 = _mlsValue::cast<_mls_Cons>(_mls_xs1)->_mls_tail;
    auto _mls_x135 = _mlsMethodCall<_mls_Callable>(_mls_f3)->_mls_apply1(_mls_x133);
    auto _mls_x136 = _mls_map(_mls_f3, _mls_x134);
    auto _mls_x137 = _mlsValue::create<_mls_Cons>(_mls_x135, _mls_x136);
    _mls_retval = _mls_x137;
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs1)) {
    auto _mls_x132 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x132;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_multiTest(_mlsValue _mls_k2, _mlsValue _mls_s13, _mlsValue _mls_s24, _mlsValue _mls_n4) {
  _mlsValue _mls_retval;
  auto _mls_x138 = (_mls_n4 <= _mlsValue::fromIntLit(1));
  auto _mls_x139 = _mls_even(_mls_n4);
  auto _mls_x140 = (_mls_x138 || _mls_x139);
  if (_mlsValue::isIntLit(_mls_x140, 1)) {
    auto _mls_x142 = (_mls_n4 == _mlsValue::fromIntLit(2));
    auto _mls_x143 = _mlsValue::create<_mls_Tuple3>(_mls_x142, _mls_s13, _mls_s24);
    _mls_retval = _mls_x143;
  } else {
    auto _mls_x141 = _mls_multiTest_mTest(_mls_k2, _mls_s13, _mls_s24, _mls_n4);
    _mls_retval = _mls_x141;
  }
  return _mls_retval;
}
_mlsValue _mls_multiTest_mTest(_mlsValue _mls_k3, _mlsValue _mls_s14, _mlsValue _mls_s25, _mlsValue _mls_n5) {
  _mlsValue _mls_retval;
  auto _mls_x144 = (_mls_k3 == _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x144, 1)) {
    auto _mls_x153 = _mlsValue::create<_mls_Tuple3>(_mlsValue::fromIntLit(1), _mls_s14, _mls_s25);
    _mls_retval = _mls_x153;
  } else {
    auto _mls_x145 = _mls_findKQ(_mls_n5);
    auto _mls_x146 = _mls_singleTest(_mls_n5, _mls_x145, _mls_s14, _mls_s25);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x146)) {
      auto _mls_x147 = _mlsValue::cast<_mls_Tuple3>(_mls_x146)->_mls_field0;
      auto _mls_x148 = _mlsValue::cast<_mls_Tuple3>(_mls_x146)->_mls_field1;
      auto _mls_x149 = _mlsValue::cast<_mls_Tuple3>(_mls_x146)->_mls_field2;
      if (_mlsValue::isIntLit(_mls_x147, 1)) {
        auto _mls_x151 = (_mls_k3 - _mlsValue::fromIntLit(1));
        auto _mls_x152 = _mls_multiTest_mTest(_mls_x151, _mls_x148, _mls_x149, _mls_n5);
        _mls_retval = _mls_x152;
      } else {
        auto _mls_x150 = _mlsValue::create<_mls_Tuple3>(_mlsValue::fromIntLit(0), _mls_x148, _mls_x149);
        _mls_retval = _mls_x150;
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  }
  return _mls_retval;
}
_mlsValue _mls_nextRand(_mlsValue _mls_s15, _mlsValue _mls_s26) {
  _mlsValue _mls_retval;
  _mlsValue _mls_tmp1, _mls_s23;
  _mlsValue _mls_s1__, _mls_tmp;
  auto _mls_x154 = _mls_builtin_floor_div(_mls_s15, _mlsValue::fromIntLit(53668));
  auto _mls_x155 = (_mls_x154 * _mlsValue::fromIntLit(53668));
  auto _mls_x156 = (_mls_s15 - _mls_x155);
  auto _mls_x157 = (_mlsValue::fromIntLit(40014) * _mls_x156);
  auto _mls_x158 = (_mls_x154 * _mlsValue::fromIntLit(12211));
  auto _mls_x159 = (_mls_x157 - _mls_x158);
  auto _mls_x160 = (_mls_x159 < _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x160, 1)) {
    auto _mls_x161 = (_mls_x159 + _mlsValue::fromIntLit(2147483563));
    _mls_tmp1 = _mls_x161;
    _mls_s23 = _mls_s26;
    goto _mls_j1;
  } else {
    _mls_tmp1 = _mls_x159;
    _mls_s23 = _mls_s26;
    goto _mls_j1;
  }
  return _mls_retval;
  _mls_j1:
  {
    auto _mls_x106 = _mls_builtin_floor_div(_mls_s23, _mlsValue::fromIntLit(52774));
    auto _mls_x107 = (_mls_x106 * _mlsValue::fromIntLit(52774));
    auto _mls_x108 = (_mls_s23 - _mls_x107);
    auto _mls_x109 = (_mlsValue::fromIntLit(40692) * _mls_x108);
    auto _mls_x110 = (_mls_x106 * _mlsValue::fromIntLit(3791));
    auto _mls_x111 = (_mls_x109 - _mls_x110);
    auto _mls_x112 = (_mls_x111 < _mlsValue::fromIntLit(0));
    if (_mlsValue::isIntLit(_mls_x112, 1)) {
      auto _mls_x113 = (_mls_x111 + _mlsValue::fromIntLit(2147483399));
      _mls_s1__ = _mls_tmp1;
      _mls_tmp = _mls_x113;
      goto _mls_j;
    } else {
      _mls_s1__ = _mls_tmp1;
      _mls_tmp = _mls_x111;
      goto _mls_j;
    }
    return _mls_retval;
  }
  _mls_j:
  {
    auto _mls_x114 = (_mls_s1__ - _mls_tmp);
    auto _mls_x115 = (_mls_x114 < _mlsValue::fromIntLit(1));
    if (_mlsValue::isIntLit(_mls_x115, 1)) {
      auto _mls_x117 = (_mls_x114 + _mlsValue::fromIntLit(2147483562));
      auto _mls_x118 = _mlsValue::create<_mls_Tuple3>(_mls_x117, _mls_s1__, _mls_tmp);
      _mls_retval = _mls_x118;
    } else {
      auto _mls_x116 = _mlsValue::create<_mls_Tuple3>(_mls_x114, _mls_s1__, _mls_tmp);
      _mls_retval = _mls_x116;
    }
    return _mls_retval;
  }
}
_mlsValue _mls_powerMod(_mlsValue _mls_a10, _mlsValue _mls_b8, _mlsValue _mls_m) {
  _mlsValue _mls_retval;
  auto _mls_x162 = _mlsValue::create<_mls_Lambda_f>(_mls_m);
  auto _mls_x163 = (_mls_b8 == _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x163, 1)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else {
    auto _mls_x164 = _mls_builtin_floor_mod(_mls_a10, _mls_m);
    auto _mls_x165 = (_mls_b8 - _mlsValue::fromIntLit(1));
    auto _mls_x166 = _mlsMethodCall<_mls_Callable>(_mls_x162)->_mls_apply3(_mls_x164, _mls_x165, _mls_x164);
    _mls_retval = _mls_x166;
  }
  return _mls_retval;
}
_mlsValue _mls_random(_mlsValue _mls_n6, _mlsValue _mls_s16, _mlsValue _mls_s27) {
  _mlsValue _mls_retval;
  auto _mls_x167 = _mls_chop(_mlsValue::fromIntLit(65536), _mls_n6);
  auto _mls_x168 = _mls_l2(_mls_x167, _mlsValue::fromIntLit(0));
  auto _mls_x169 = _mlsValue::create<_mls_Nil>();
  auto _mls_x170 = _mls_generateRands(_mls_x168, _mls_s16, _mls_s27, _mls_x169);
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x170)) {
    auto _mls_x171 = _mlsValue::cast<_mls_Tuple3>(_mls_x170)->_mls_field0;
    auto _mls_x172 = _mlsValue::cast<_mls_Tuple3>(_mls_x170)->_mls_field1;
    auto _mls_x173 = _mlsValue::cast<_mls_Tuple3>(_mls_x170)->_mls_field2;
    auto _mls_x174 = _mls_uniform(_mls_x167, _mls_x171);
    auto _mls_x175 = _mls_makeNumber(_mlsValue::fromIntLit(65536), _mls_x174);
    auto _mls_x176 = _mlsValue::create<_mls_Tuple3>(_mls_x175, _mls_x172, _mls_x173);
    _mls_retval = _mls_x176;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_repeatProcess(_mlsValue _mls_n7, _mlsValue _mls_acc2) {
  _mlsValue _mls_retval;
  auto _mls_x177 = (_mls_n7 == _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x177, 1)) {
    _mls_retval = _mls_acc2;
  } else {
    auto _mls_x178 = _mls_str_to_list(_mlsValue::create<_mls_Str>("17|24|48|47|1317|8901|97|101|103|107|109|113|127|131|137|139|149|151|157|163|167|173|179|181|191|193|197|199|211|223|227|229|233|239|241|251|257|263|269|271|277|281|283|293|307|311|313|317|331|337|347|349|353|359|367|373|379|383|389|397|401|409|419|421|431|433|439|443|449|457|461|463|467|479|487|491|499|503|509|521|523|541|547|557|563|569|571|577|587|593|599|601|607|613|617|619|631|641|643|647|653|659|661|673|677|683|691|701|709|719|727|733|739|743|751|757|761|769|773|787|797|809|811|821|823|827|829|839|853|857|859|863|877|881|883|887|907|911|919|929|937|941|947|953|967|971|977|983|991|997"));
    auto _mls_x179 = _mls_lines(_mls_x178);
    auto _mls_x180 = (_mls_n7 - _mlsValue::fromIntLit(1));
    auto _mls_x181 = _mls_doInput(_mlsValue::fromIntLit(111), _mlsValue::fromIntLit(47), _mls_x179);
    auto _mls_x182 = _mlsValue::create<_mls_Cons>(_mls_x181, _mls_acc2);
    auto _mls_x183 = _mls_repeatProcess(_mls_x180, _mls_x182);
    _mls_retval = _mls_x183;
  }
  return _mls_retval;
}
_mlsValue _mls_singleTest(_mlsValue _mls_n8, _mlsValue _mls_kq, _mlsValue _mls_s17, _mlsValue _mls_s28) {
  _mlsValue _mls_retval;
  auto _mls_x184 = (_mls_n8 - _mlsValue::fromIntLit(2));
  auto _mls_x185 = _mls_random(_mls_x184, _mls_s17, _mls_s28);
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x185)) {
    auto _mls_x186 = _mlsValue::cast<_mls_Tuple3>(_mls_x185)->_mls_field0;
    auto _mls_x187 = _mlsValue::cast<_mls_Tuple3>(_mls_x185)->_mls_field1;
    auto _mls_x188 = _mlsValue::cast<_mls_Tuple3>(_mls_x185)->_mls_field2;
    auto _mls_x189 = (_mlsValue::fromIntLit(2) + _mls_x186);
    auto _mls_x190 = _mls_singleTestX(_mls_n8, _mls_kq, _mls_x189);
    auto _mls_x191 = _mlsValue::create<_mls_Tuple3>(_mls_x190, _mls_x187, _mls_x188);
    _mls_retval = _mls_x191;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_singleTestX(_mlsValue _mls_n9, _mlsValue _mls_kq1, _mlsValue _mls_x194) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_kq1)) {
    auto _mls_x192 = _mlsValue::cast<_mls_Tuple2>(_mls_kq1)->_mls_field0;
    auto _mls_x193 = _mlsValue::cast<_mls_Tuple2>(_mls_kq1)->_mls_field1;
    auto _mls_x195 = _mls_powerMod(_mls_x194, _mls_x193, _mls_n9);
    auto _mls_x196 = _mlsValue::create<_mls_Lambda_lambda4>(_mls_n9);
    auto _mls_x197 = _mls_iterate_square(_mls_x196, _mls_x195, _mls_x192);
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x197)) {
      auto _mls_x198 = _mlsValue::cast<_mls_Cons>(_mls_x197)->_mls_head;
      auto _mls_x199 = _mlsValue::cast<_mls_Cons>(_mls_x197)->_mls_tail;
      auto _mls_x200 = (_mls_x198 == _mlsValue::fromIntLit(1));
      auto _mls_x201 = (_mls_n9 - _mlsValue::fromIntLit(1));
      auto _mls_x202 = (_mls_x198 == _mls_x201);
      auto _mls_x203 = (_mls_x200 || _mls_x202);
      auto _mls_x204 = _mls_singleTestX_witness(_mls_x199, _mls_n9);
      auto _mls_x205 = (_mls_x203 || _mls_x204);
      _mls_retval = _mls_x205;
    } else {
      _mls_retval = _mlsValue::fromIntLit(0);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_singleTestX_square(_mlsValue _mls_x207, _mlsValue _mls_n10) {
  _mlsValue _mls_retval;
  auto _mls_x206 = (_mls_x207 * _mls_x207);
  auto _mls_x208 = _mls_builtin_floor_mod(_mls_x206, _mls_n10);
  _mls_retval = _mls_x208;
  return _mls_retval;
}
_mlsValue _mls_singleTestX_witness(_mlsValue _mls_ls3, _mlsValue _mls_n11) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls3)) {
    _mls_retval = _mlsValue::fromIntLit(0);
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls3)) {
    auto _mls_x209 = _mlsValue::cast<_mls_Cons>(_mls_ls3)->_mls_head;
    auto _mls_x210 = _mlsValue::cast<_mls_Cons>(_mls_ls3)->_mls_tail;
    auto _mls_x211 = (_mls_n11 - _mlsValue::fromIntLit(1));
    auto _mls_x212 = (_mls_x209 == _mls_x211);
    if (_mlsValue::isIntLit(_mls_x212, 1)) {
      _mls_retval = _mlsValue::fromIntLit(1);
    } else {
      auto _mls_x213 = (_mls_x209 == _mlsValue::fromIntLit(1));
      if (_mlsValue::isIntLit(_mls_x213, 1)) {
        _mls_retval = _mlsValue::fromIntLit(0);
      } else {
        auto _mls_x214 = _mls_singleTestX_witness(_mls_x210, _mls_n11);
        _mls_retval = _mls_x214;
      }
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_str_to_list(_mlsValue _mls_x216) {
  _mlsValue _mls_retval;
  auto _mls_x215 = _mls_builtin_str_head(_mls_x216);
  if (_mlsValue::isValueOf<_mls_Unit>(_mls_x215)) {
    auto _mls_x221 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x221;
  } else {
    auto _mls_x217 = _mls_builtin_str_head(_mls_x216);
    auto _mls_x218 = _mls_builtin_str_tail(_mls_x216);
    auto _mls_x219 = _mls_str_to_list(_mls_x218);
    auto _mls_x220 = _mlsValue::create<_mls_Cons>(_mls_x217, _mls_x219);
    _mls_retval = _mls_x220;
  }
  return _mls_retval;
}
_mlsValue _mls_testPrimetest_nofib(_mlsValue _mls_d) {
  _mlsValue _mls_retval;
  auto _mls_x222 = _mlsValue::create<_mls_Nil>();
  auto _mls_x223 = _mls_repeatProcess(_mlsValue::fromIntLit(100), _mls_x222);
  _mls_retval = _mls_x223;
  return _mls_retval;
}
_mlsValue _mls_uniform(_mlsValue _mls_nns, _mlsValue _mls_rrs) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_nns)) {
    auto _mls_x224 = _mlsValue::cast<_mls_Cons>(_mls_nns)->_mls_head;
    auto _mls_x225 = _mlsValue::cast<_mls_Cons>(_mls_nns)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x225)) {
      if (_mlsValue::isValueOf<_mls_Cons>(_mls_rrs)) {
        auto _mls_x236 = _mlsValue::cast<_mls_Cons>(_mls_rrs)->_mls_head;
        auto _mls_x237 = _mls_builtin_floor_mod(_mls_x236, _mls_x224);
        auto _mls_x238 = _mlsValue::create<_mls_Nil>();
        auto _mls_x239 = _mlsValue::create<_mls_Cons>(_mls_x237, _mls_x238);
        _mls_retval = _mls_x239;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      if (_mlsValue::isValueOf<_mls_Cons>(_mls_rrs)) {
        auto _mls_x226 = _mlsValue::cast<_mls_Cons>(_mls_rrs)->_mls_head;
        auto _mls_x227 = _mlsValue::cast<_mls_Cons>(_mls_rrs)->_mls_tail;
        auto _mls_x228 = (_mls_x224 + _mlsValue::fromIntLit(1));
        auto _mls_x229 = _mls_builtin_floor_mod(_mls_x226, _mls_x228);
        auto _mls_x230 = (_mls_x229 == _mls_x224);
        if (_mlsValue::isIntLit(_mls_x230, 1)) {
          auto _mls_x234 = _mls_uniform(_mls_x225, _mls_x227);
          auto _mls_x235 = _mlsValue::create<_mls_Cons>(_mls_x229, _mls_x234);
          _mls_retval = _mls_x235;
        } else {
          auto _mls_x231 = _mlsValue::create<_mls_Lambda_lambda>();
          auto _mls_x232 = _mls_map(_mls_x231, _mls_x227);
          auto _mls_x233 = _mlsValue::create<_mls_Cons>(_mls_x229, _mls_x232);
          _mls_retval = _mls_x233;
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_f::_mls_apply3(_mlsValue _mls_a, _mlsValue _mls_b, _mlsValue _mls_c) {
  _mlsValue _mls_retval;
  auto _mls_x = _mlsValue::create<_mls_Lambda_g>(_mls_c, _mls_lam_arg0, _mlsValue(this, _mlsValue::inc_ref_tag{}));
  auto _mls_x1 = (_mls_b == _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x1, 1)) {
    _mls_retval = _mls_c;
  } else {
    auto _mls_x2 = _mlsMethodCall<_mls_Callable>(_mls_x)->_mls_apply2(_mls_a, _mls_b);
    _mls_retval = _mls_x2;
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_g::_mls_apply2(_mlsValue _mls_a1, _mlsValue _mls_b1) {
  _mlsValue _mls_retval;
  auto _mls_x3 = _mls_even(_mls_b1);
  if (_mlsValue::isIntLit(_mls_x3, 1)) {
    auto _mls_x8 = (_mls_a1 * _mls_a1);
    auto _mls_x9 = _mls_intMod(_mls_x8, _mls_lam_arg1);
    auto _mls_x10 = _mls_intDiv(_mls_b1, _mlsValue::fromIntLit(2));
    auto _mls_x11 = this->_mls_apply2(_mls_x9, _mls_x10);
    _mls_retval = _mls_x11;
  } else {
    auto _mls_x4 = (_mls_b1 - _mlsValue::fromIntLit(1));
    auto _mls_x5 = (_mls_a1 * _mls_lam_arg0);
    auto _mls_x6 = _mls_intMod(_mls_x5, _mls_lam_arg1);
    auto _mls_x7 = _mlsMethodCall<_mls_Callable>(_mls_lam_arg2)->_mls_apply3(_mls_a1, _mls_x4, _mls_x6);
    _mls_retval = _mls_x7;
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda::_mls_apply1(_mlsValue _mls_x12) {
  _mlsValue _mls_retval;
  auto _mls_x13 = _mls_intMod(_mls_x12, _mlsValue::fromIntLit(65536));
  _mls_retval = _mls_x13;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda1::_mls_apply2(_mlsValue _mls_s1_, _mlsValue _mls_s2_) {
  _mlsValue _mls_retval;
  auto _mls_x14 = _mls_doInput(_mls_s1_, _mls_s2_, _mls_lam_arg0);
  _mls_retval = _mls_x14;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda2::_mls_apply2(_mlsValue _mls_a2, _mlsValue _mls_x17) {
  _mlsValue _mls_retval;
  auto _mls_x15 = (_mls_a2 * _mls_lam_arg0);
  auto _mls_x16 = (_mls_x15 + _mls_x17);
  _mls_retval = _mls_x16;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda3::_mls_apply1(_mlsValue _mls_x19) {
  _mlsValue _mls_retval;
  auto _mls_x18 = (_mls_x19 == _mlsValue::create<_mls_Str>("|"));
  _mls_retval = _mls_x18;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda4::_mls_apply1(_mlsValue _mls_x20) {
  _mlsValue _mls_retval;
  auto _mls_x21 = _mls_singleTestX_square(_mls_x20, _mls_lam_arg0);
  _mls_retval = _mls_x21;
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
