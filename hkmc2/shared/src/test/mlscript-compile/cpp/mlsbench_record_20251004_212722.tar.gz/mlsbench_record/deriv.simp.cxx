#include "mlsprelude.h"
struct _mls_Expr;
struct _mls_Add;
struct _mls_LamDeriv;
struct _mls_Ln;
struct _mls_Mul;
struct _mls_Pow;
struct _mls_Val;
struct _mls_Var;
_mlsValue _mls_add(_mlsValue, _mlsValue);
_mlsValue _mls_apply2(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_count(_mlsValue);
_mlsValue _mls_d(_mlsValue, _mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_j(_mlsValue, _mlsValue);
_mlsValue _mls_ln(_mlsValue);
_mlsValue _mls_main(_mlsValue);
_mlsValue _mls_mul(_mlsValue, _mlsValue);
_mlsValue _mls_nestAux(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_pow(_mlsValue, _mlsValue);
_mlsValue _mls_pown(_mlsValue, _mlsValue);
struct _mls_Expr: public _mlsObject {
  
  constexpr static inline const char *typeName = "Expr";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Expr; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Add: public _mls_Expr {
  _mlsValue _mls_e1;
  _mlsValue _mls_e2;
  constexpr static inline const char *typeName = "Add";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e1.print(); std::printf(", "); this->_mls_e2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e1); _mlsValue::destroy(this->_mls_e2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e1.asObject()->operator==(*other.cast<_mls_Add>()->_mls_e1.asObject()) && this->_mls_e2.asObject()->operator==(*other.cast<_mls_Add>()->_mls_e2.asObject()); }
  static _mlsValue create(_mlsValue _mls_e1, _mlsValue _mls_e2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Add; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e1 = _mls_e1; _mlsVal->_mls_e2 = _mls_e2;  return _mlsValue(_mlsVal); }
  
};
struct _mls_LamDeriv: public _mlsObject {
  
  constexpr static inline const char *typeName = "LamDeriv";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_LamDeriv; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Ln: public _mls_Expr {
  _mlsValue _mls_e;
  constexpr static inline const char *typeName = "Ln";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e.asObject()->operator==(*other.cast<_mls_Ln>()->_mls_e.asObject()); }
  static _mlsValue create(_mlsValue _mls_e) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Ln; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e = _mls_e;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Mul: public _mls_Expr {
  _mlsValue _mls_e1;
  _mlsValue _mls_e2;
  constexpr static inline const char *typeName = "Mul";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e1.print(); std::printf(", "); this->_mls_e2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e1); _mlsValue::destroy(this->_mls_e2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e1.asObject()->operator==(*other.cast<_mls_Mul>()->_mls_e1.asObject()) && this->_mls_e2.asObject()->operator==(*other.cast<_mls_Mul>()->_mls_e2.asObject()); }
  static _mlsValue create(_mlsValue _mls_e1, _mlsValue _mls_e2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Mul; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e1 = _mls_e1; _mlsVal->_mls_e2 = _mls_e2;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Pow: public _mls_Expr {
  _mlsValue _mls_e1;
  _mlsValue _mls_e2;
  constexpr static inline const char *typeName = "Pow";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e1.print(); std::printf(", "); this->_mls_e2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e1); _mlsValue::destroy(this->_mls_e2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e1.asObject()->operator==(*other.cast<_mls_Pow>()->_mls_e1.asObject()) && this->_mls_e2.asObject()->operator==(*other.cast<_mls_Pow>()->_mls_e2.asObject()); }
  static _mlsValue create(_mlsValue _mls_e1, _mlsValue _mls_e2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Pow; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e1 = _mls_e1; _mlsVal->_mls_e2 = _mls_e2;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Val: public _mls_Expr {
  _mlsValue _mls_n;
  constexpr static inline const char *typeName = "Val";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_n.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_n);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_n.asObject()->operator==(*other.cast<_mls_Val>()->_mls_n.asObject()); }
  static _mlsValue create(_mlsValue _mls_n) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Val; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_n = _mls_n;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Var: public _mls_Expr {
  _mlsValue _mls_x;
  constexpr static inline const char *typeName = "Var";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_x.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_x);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_x.asObject()->operator==(*other.cast<_mls_Var>()->_mls_x.asObject()); }
  static _mlsValue create(_mlsValue _mls_x) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Var; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_x = _mls_x;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_add(_mlsValue _mls_e13, _mlsValue _mls_e23) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_e13)) {
    auto _mls_x20 = _mlsValue::cast<_mls_Val>(_mls_e13)->_mls_n;
    if (_mlsValue::isValueOf<_mls_Val>(_mls_e23)) {
      auto _mls_x29 = _mlsValue::cast<_mls_Val>(_mls_e23)->_mls_n;
      auto _mls_x30 = (_mls_x20 + _mls_x29);
      auto _mls_x31 = _mlsValue::create<_mls_Val>(_mls_x30);
      _mls_retval = _mls_x31;
    } else {
      if (_mlsValue::isIntLit(_mls_x20, 0)) {
        _mls_retval = _mls_e23;
      } else {
        if (_mlsValue::isValueOf<_mls_Add>(_mls_e23)) {
          auto _mls_x22 = _mlsValue::cast<_mls_Add>(_mls_e23)->_mls_e1;
          auto _mls_x23 = _mlsValue::cast<_mls_Add>(_mls_e23)->_mls_e2;
          if (_mlsValue::isValueOf<_mls_Val>(_mls_x22)) {
            auto _mls_x25 = _mlsValue::cast<_mls_Val>(_mls_x22)->_mls_n;
            auto _mls_x26 = (_mls_x20 + _mls_x25);
            auto _mls_x27 = _mlsValue::create<_mls_Val>(_mls_x26);
            auto _mls_x28 = _mls_add(_mls_x27, _mls_x23);
            _mls_retval = _mls_x28;
          } else {
            auto _mls_x24 = _mlsValue::create<_mls_Add>(_mls_e13, _mls_e23);
            _mls_retval = _mls_x24;
          }
        } else {
          auto _mls_x21 = _mlsValue::create<_mls_Add>(_mls_e13, _mls_e23);
          _mls_retval = _mls_x21;
        }
      }
    }
  } else {
    if (_mlsValue::isValueOf<_mls_Val>(_mls_e23)) {
      auto _mls_x17 = _mlsValue::cast<_mls_Val>(_mls_e23)->_mls_n;
      if (_mlsValue::isIntLit(_mls_x17, 0)) {
        _mls_retval = _mls_e13;
      } else {
        auto _mls_x18 = _mlsValue::create<_mls_Val>(_mls_x17);
        auto _mls_x19 = _mls_add(_mls_x18, _mls_e13);
        _mls_retval = _mls_x19;
      }
    } else if (_mlsValue::isValueOf<_mls_Add>(_mls_e23)) {
      auto _mls_x6 = _mlsValue::cast<_mls_Add>(_mls_e23)->_mls_e1;
      auto _mls_x7 = _mlsValue::cast<_mls_Add>(_mls_e23)->_mls_e2;
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x6)) {
        auto _mls_x13 = _mlsValue::cast<_mls_Val>(_mls_x6)->_mls_n;
        auto _mls_x14 = _mlsValue::create<_mls_Val>(_mls_x13);
        auto _mls_x15 = _mls_add(_mls_e13, _mls_x7);
        auto _mls_x16 = _mls_add(_mls_x14, _mls_x15);
        _mls_retval = _mls_x16;
      } else {
        if (_mlsValue::isValueOf<_mls_Add>(_mls_e13)) {
          auto _mls_x9 = _mlsValue::cast<_mls_Add>(_mls_e13)->_mls_e1;
          auto _mls_x10 = _mlsValue::cast<_mls_Add>(_mls_e13)->_mls_e2;
          auto _mls_x11 = _mls_add(_mls_x10, _mls_e23);
          auto _mls_x12 = _mls_add(_mls_x9, _mls_x11);
          _mls_retval = _mls_x12;
        } else {
          auto _mls_x8 = _mlsValue::create<_mls_Add>(_mls_e13, _mls_e23);
          _mls_retval = _mls_x8;
        }
      }
    } else {
      if (_mlsValue::isValueOf<_mls_Add>(_mls_e13)) {
        auto _mls_x2 = _mlsValue::cast<_mls_Add>(_mls_e13)->_mls_e1;
        auto _mls_x3 = _mlsValue::cast<_mls_Add>(_mls_e13)->_mls_e2;
        auto _mls_x4 = _mls_add(_mls_x3, _mls_e23);
        auto _mls_x5 = _mls_add(_mls_x2, _mls_x4);
        _mls_retval = _mls_x5;
      } else {
        auto _mls_x1 = _mlsValue::create<_mls_Add>(_mls_e13, _mls_e23);
        _mls_retval = _mls_x1;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_apply2(_mlsValue _mls_f, _mlsValue _mls_a, _mlsValue _mls_b) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_LamDeriv>(_mls_f)) {
    auto _mls_x32 = _mls_d(_mlsValue::create<_mls_Str>("x"), _mls_b);
    _mls_retval = _mls_x32;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_count(_mlsValue _mls_e3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_e3)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else if (_mlsValue::isValueOf<_mls_Var>(_mls_e3)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_e3)) {
    auto _mls_x45 = _mlsValue::cast<_mls_Add>(_mls_e3)->_mls_e1;
    auto _mls_x46 = _mlsValue::cast<_mls_Add>(_mls_e3)->_mls_e2;
    auto _mls_x47 = _mls_count(_mls_x45);
    auto _mls_x48 = _mls_count(_mls_x46);
    auto _mls_x49 = (_mls_x47 + _mls_x48);
    _mls_retval = _mls_x49;
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_e3)) {
    auto _mls_x40 = _mlsValue::cast<_mls_Mul>(_mls_e3)->_mls_e1;
    auto _mls_x41 = _mlsValue::cast<_mls_Mul>(_mls_e3)->_mls_e2;
    auto _mls_x42 = _mls_count(_mls_x40);
    auto _mls_x43 = _mls_count(_mls_x41);
    auto _mls_x44 = (_mls_x42 + _mls_x43);
    _mls_retval = _mls_x44;
  } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_e3)) {
    auto _mls_x35 = _mlsValue::cast<_mls_Pow>(_mls_e3)->_mls_e1;
    auto _mls_x36 = _mlsValue::cast<_mls_Pow>(_mls_e3)->_mls_e2;
    auto _mls_x37 = _mls_count(_mls_x35);
    auto _mls_x38 = _mls_count(_mls_x36);
    auto _mls_x39 = (_mls_x37 + _mls_x38);
    _mls_retval = _mls_x39;
  } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_e3)) {
    auto _mls_x33 = _mlsValue::cast<_mls_Ln>(_mls_e3)->_mls_e;
    auto _mls_x34 = _mls_count(_mls_x33);
    _mls_retval = _mls_x34;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_d(_mlsValue _mls_x51, _mlsValue _mls_e4) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_e4)) {
    auto _mls_x87 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
    _mls_retval = _mls_x87;
  } else if (_mlsValue::isValueOf<_mls_Var>(_mls_e4)) {
    auto _mls_x83 = _mlsValue::cast<_mls_Var>(_mls_e4)->_mls_x;
    auto _mls_x84 = (_mls_x51 == _mls_x83);
    if (_mlsValue::isIntLit(_mls_x84, 1)) {
      auto _mls_x86 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(1));
      _mls_retval = _mls_x86;
    } else {
      auto _mls_x85 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
      _mls_retval = _mls_x85;
    }
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_e4)) {
    auto _mls_x78 = _mlsValue::cast<_mls_Add>(_mls_e4)->_mls_e1;
    auto _mls_x79 = _mlsValue::cast<_mls_Add>(_mls_e4)->_mls_e2;
    auto _mls_x80 = _mls_d(_mls_x51, _mls_x78);
    auto _mls_x81 = _mls_d(_mls_x51, _mls_x79);
    auto _mls_x82 = _mls_add(_mls_x80, _mls_x81);
    _mls_retval = _mls_x82;
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_e4)) {
    auto _mls_x71 = _mlsValue::cast<_mls_Mul>(_mls_e4)->_mls_e1;
    auto _mls_x72 = _mlsValue::cast<_mls_Mul>(_mls_e4)->_mls_e2;
    auto _mls_x73 = _mls_d(_mls_x51, _mls_x72);
    auto _mls_x74 = _mls_mul(_mls_x71, _mls_x73);
    auto _mls_x75 = _mls_d(_mls_x51, _mls_x71);
    auto _mls_x76 = _mls_mul(_mls_x72, _mls_x75);
    auto _mls_x77 = _mls_add(_mls_x74, _mls_x76);
    _mls_retval = _mls_x77;
  } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_e4)) {
    auto _mls_x57 = _mlsValue::cast<_mls_Pow>(_mls_e4)->_mls_e1;
    auto _mls_x58 = _mlsValue::cast<_mls_Pow>(_mls_e4)->_mls_e2;
    auto _mls_x59 = _mls_pow(_mls_x57, _mls_x58);
    auto _mls_x60 = _mls_d(_mls_x51, _mls_x57);
    auto _mls_x61 = _mls_mul(_mls_x58, _mls_x60);
    auto _mls_x62 = (-_mlsValue::fromIntLit(1));
    auto _mls_x63 = _mlsValue::create<_mls_Val>(_mls_x62);
    auto _mls_x64 = _mls_pow(_mls_x57, _mls_x63);
    auto _mls_x65 = _mls_mul(_mls_x61, _mls_x64);
    auto _mls_x66 = _mls_ln(_mls_x57);
    auto _mls_x67 = _mls_d(_mls_x51, _mls_x58);
    auto _mls_x68 = _mls_mul(_mls_x66, _mls_x67);
    auto _mls_x69 = _mls_add(_mls_x65, _mls_x68);
    auto _mls_x70 = _mls_mul(_mls_x59, _mls_x69);
    _mls_retval = _mls_x70;
  } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_e4)) {
    auto _mls_x50 = _mlsValue::cast<_mls_Ln>(_mls_e4)->_mls_e;
    auto _mls_x52 = _mls_d(_mls_x51, _mls_x50);
    auto _mls_x53 = (-_mlsValue::fromIntLit(1));
    auto _mls_x54 = _mlsValue::create<_mls_Val>(_mls_x53);
    auto _mls_x55 = _mls_pow(_mls_x50, _mls_x54);
    auto _mls_x56 = _mls_mul(_mls_x52, _mls_x55);
    _mls_retval = _mls_x56;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x88 = _mls_main(_mlsValue::fromIntLit(10));
  _mls_retval = _mls_x88;
  return _mls_retval;
}
_mlsValue _mls_j(_mlsValue _mls_tmp, _mlsValue _mls_tmp1) {
  _mlsValue _mls_retval;
  auto _mls_x89 = (_mls_tmp * _mls_tmp1);
  _mls_retval = _mls_x89;
  return _mls_retval;
}
_mlsValue _mls_ln(_mlsValue _mls_e5) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_e5)) {
    auto _mls_x91 = _mlsValue::cast<_mls_Val>(_mls_e5)->_mls_n;
    if (_mlsValue::isIntLit(_mls_x91, 1)) {
      auto _mls_x93 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
      _mls_retval = _mls_x93;
    } else {
      auto _mls_x92 = _mlsValue::create<_mls_Ln>(_mls_e5);
      _mls_retval = _mls_x92;
    }
  } else {
    auto _mls_x90 = _mlsValue::create<_mls_Ln>(_mls_e5);
    _mls_retval = _mls_x90;
  }
  return _mls_retval;
}
_mlsValue _mls_main(_mlsValue _mls_n1) {
  _mlsValue _mls_retval;
  auto _mls_x94 = _mlsValue::create<_mls_Var>(_mlsValue::create<_mls_Str>("x"));
  auto _mls_x95 = _mls_pow(_mls_x94, _mls_x94);
  auto _mls_x96 = _mlsValue::create<_mls_LamDeriv>();
  auto _mls_x97 = _mls_nestAux(_mls_n1, _mls_x96, _mls_n1, _mls_x95);
  auto _mls_x98 = _mls_count(_mls_x97);
  _mls_retval = _mls_x98;
  return _mls_retval;
}
_mlsValue _mls_mul(_mlsValue _mls_e14, _mlsValue _mls_e24) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_e14)) {
    auto _mls_x119 = _mlsValue::cast<_mls_Val>(_mls_e14)->_mls_n;
    if (_mlsValue::isValueOf<_mls_Val>(_mls_e24)) {
      auto _mls_x129 = _mlsValue::cast<_mls_Val>(_mls_e24)->_mls_n;
      auto _mls_x130 = (_mls_x119 * _mls_x129);
      auto _mls_x131 = _mlsValue::create<_mls_Val>(_mls_x130);
      _mls_retval = _mls_x131;
    } else {
      if (_mlsValue::isIntLit(_mls_x119, 0)) {
        auto _mls_x128 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
        _mls_retval = _mls_x128;
      } else if (_mlsValue::isIntLit(_mls_x119, 1)) {
        _mls_retval = _mls_e24;
      } else {
        if (_mlsValue::isValueOf<_mls_Mul>(_mls_e24)) {
          auto _mls_x121 = _mlsValue::cast<_mls_Mul>(_mls_e24)->_mls_e1;
          auto _mls_x122 = _mlsValue::cast<_mls_Mul>(_mls_e24)->_mls_e2;
          if (_mlsValue::isValueOf<_mls_Val>(_mls_x121)) {
            auto _mls_x124 = _mlsValue::cast<_mls_Val>(_mls_x121)->_mls_n;
            auto _mls_x125 = (_mls_x119 * _mls_x124);
            auto _mls_x126 = _mlsValue::create<_mls_Val>(_mls_x125);
            auto _mls_x127 = _mls_mul(_mls_x126, _mls_x122);
            _mls_retval = _mls_x127;
          } else {
            auto _mls_x123 = _mlsValue::create<_mls_Mul>(_mls_e14, _mls_e24);
            _mls_retval = _mls_x123;
          }
        } else {
          auto _mls_x120 = _mlsValue::create<_mls_Mul>(_mls_e14, _mls_e24);
          _mls_retval = _mls_x120;
        }
      }
    }
  } else {
    if (_mlsValue::isValueOf<_mls_Val>(_mls_e24)) {
      auto _mls_x115 = _mlsValue::cast<_mls_Val>(_mls_e24)->_mls_n;
      if (_mlsValue::isIntLit(_mls_x115, 0)) {
        auto _mls_x118 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
        _mls_retval = _mls_x118;
      } else if (_mlsValue::isIntLit(_mls_x115, 1)) {
        _mls_retval = _mls_e14;
      } else {
        auto _mls_x116 = _mlsValue::create<_mls_Val>(_mls_x115);
        auto _mls_x117 = _mls_mul(_mls_x116, _mls_e14);
        _mls_retval = _mls_x117;
      }
    } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_e24)) {
      auto _mls_x104 = _mlsValue::cast<_mls_Mul>(_mls_e24)->_mls_e1;
      auto _mls_x105 = _mlsValue::cast<_mls_Mul>(_mls_e24)->_mls_e2;
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x104)) {
        auto _mls_x111 = _mlsValue::cast<_mls_Val>(_mls_x104)->_mls_n;
        auto _mls_x112 = _mlsValue::create<_mls_Val>(_mls_x111);
        auto _mls_x113 = _mls_mul(_mls_e14, _mls_x105);
        auto _mls_x114 = _mls_mul(_mls_x112, _mls_x113);
        _mls_retval = _mls_x114;
      } else {
        if (_mlsValue::isValueOf<_mls_Mul>(_mls_e14)) {
          auto _mls_x107 = _mlsValue::cast<_mls_Mul>(_mls_e14)->_mls_e1;
          auto _mls_x108 = _mlsValue::cast<_mls_Mul>(_mls_e14)->_mls_e2;
          auto _mls_x109 = _mls_mul(_mls_x108, _mls_e24);
          auto _mls_x110 = _mls_mul(_mls_x107, _mls_x109);
          _mls_retval = _mls_x110;
        } else {
          auto _mls_x106 = _mlsValue::create<_mls_Mul>(_mls_e14, _mls_e24);
          _mls_retval = _mls_x106;
        }
      }
    } else {
      if (_mlsValue::isValueOf<_mls_Mul>(_mls_e14)) {
        auto _mls_x100 = _mlsValue::cast<_mls_Mul>(_mls_e14)->_mls_e1;
        auto _mls_x101 = _mlsValue::cast<_mls_Mul>(_mls_e14)->_mls_e2;
        auto _mls_x102 = _mls_mul(_mls_x101, _mls_e24);
        auto _mls_x103 = _mls_mul(_mls_x100, _mls_x102);
        _mls_retval = _mls_x103;
      } else {
        auto _mls_x99 = _mlsValue::create<_mls_Mul>(_mls_e14, _mls_e24);
        _mls_retval = _mls_x99;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_nestAux(_mlsValue _mls_s, _mlsValue _mls_f1, _mlsValue _mls_n2, _mlsValue _mls_e6) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_n2, 0)) {
    _mls_retval = _mls_e6;
  } else {
    auto _mls_x132 = (_mls_s - _mls_n2);
    auto _mls_x133 = _mls_apply2(_mls_f1, _mls_x132, _mls_e6);
    auto _mls_x134 = (_mls_n2 - _mlsValue::fromIntLit(1));
    auto _mls_x135 = _mls_nestAux(_mls_s, _mls_f1, _mls_x134, _mls_x133);
    _mls_retval = _mls_x135;
  }
  return _mls_retval;
}
_mlsValue _mls_pow(_mlsValue _mls_e15, _mlsValue _mls_e25) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_e15)) {
    auto _mls_x140 = _mlsValue::cast<_mls_Val>(_mls_e15)->_mls_n;
    if (_mlsValue::isValueOf<_mls_Val>(_mls_e25)) {
      auto _mls_x143 = _mlsValue::cast<_mls_Val>(_mls_e25)->_mls_n;
      auto _mls_x144 = _mls_pown(_mls_x140, _mls_x143);
      auto _mls_x145 = _mlsValue::create<_mls_Val>(_mls_x144);
      _mls_retval = _mls_x145;
    } else {
      if (_mlsValue::isIntLit(_mls_x140, 0)) {
        auto _mls_x142 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
        _mls_retval = _mls_x142;
      } else {
        auto _mls_x141 = _mlsValue::create<_mls_Pow>(_mls_e15, _mls_e25);
        _mls_retval = _mls_x141;
      }
    }
  } else {
    if (_mlsValue::isValueOf<_mls_Val>(_mls_e25)) {
      auto _mls_x137 = _mlsValue::cast<_mls_Val>(_mls_e25)->_mls_n;
      if (_mlsValue::isIntLit(_mls_x137, 0)) {
        auto _mls_x139 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(1));
        _mls_retval = _mls_x139;
      } else if (_mlsValue::isIntLit(_mls_x137, 1)) {
        _mls_retval = _mls_e15;
      } else {
        auto _mls_x138 = _mlsValue::create<_mls_Pow>(_mls_e15, _mls_e25);
        _mls_retval = _mls_x138;
      }
    } else {
      auto _mls_x136 = _mlsValue::create<_mls_Pow>(_mls_e15, _mls_e25);
      _mls_retval = _mls_x136;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_pown(_mlsValue _mls_x147, _mlsValue _mls_n3) {
  _mlsValue _mls_retval;
  _mlsValue _mls_tmp, _mls_tmp1;
  if (_mlsValue::isIntLit(_mls_n3, 0)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else if (_mlsValue::isIntLit(_mls_n3, 1)) {
    _mls_retval = _mls_x147;
  } else {
    auto _mls_x146 = (_mls_n3 / _mlsValue::fromIntLit(2));
    auto _mls_x148 = _mls_pown(_mls_x147, _mls_x146);
    auto _mls_x149 = (_mls_x148 * _mls_x148);
    auto _mls_x150 = (_mls_n3 % _mlsValue::fromIntLit(2));
    auto _mls_x151 = (_mls_x150 == _mlsValue::fromIntLit(0));
    if (_mlsValue::isIntLit(_mls_x151, 1)) {
      _mls_tmp = _mls_x149;
      _mls_tmp1 = _mlsValue::fromIntLit(1);
      goto _mls_j;
    } else {
      _mls_tmp = _mls_x149;
      _mls_tmp1 = _mls_x147;
      goto _mls_j;
    }
  }
  return _mls_retval;
  _mls_j:
  {
    auto _mls_x89 = (_mls_tmp * _mls_tmp1);
    _mls_retval = _mls_x89;
    return _mls_retval;
  }
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
