#include "mlsprelude.h"
struct _mls_List;
struct _mls_Cons;
struct _mls_Nil;
_mlsValue _mls_extend(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_length(_mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_find_solution_default_caller_post_pre(_mlsValue, _mlsValue);
_mlsValue _mls_safe_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_find_solution_default(_mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_safe_case0_sr_post_pre(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_append_safe_caller_post_case0_pre(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_find_solution_default_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_find_solution_case0();
_mlsValue _mls_append_safe(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_queens(_mlsValue);
_mlsValue _mls_append_safe_caller_post_case0(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_safe_case0_sr_post_default(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_append_safe_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_find_solution_pre(_mlsValue, _mlsValue);
_mlsValue _mls_length_case0_sr_post(_mlsValue);
_mlsValue _mls_safe(_mlsValue, _mlsValue, _mlsValue);
struct _mls_List: public _mlsObject {
  
  constexpr static inline const char *typeName = "List";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_List; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Cons: public _mls_List {
  _mlsValue _mls_head;
  _mlsValue _mls_tail;
  constexpr static inline const char *typeName = "Cons";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_head.print(); std::printf(", "); this->_mls_tail.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_head); _mlsValue::destroy(this->_mls_tail);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_head.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_head.asObject()) && this->_mls_tail.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_tail.asObject()); }
  static _mlsValue create(_mlsValue _mls_head, _mlsValue _mls_tail) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Cons; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_head = _mls_head; _mlsVal->_mls_tail = _mls_tail;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Nil: public _mls_List {
  
  constexpr static inline const char *typeName = "Nil";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Nil; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_find_solution_default_caller_post_pre(_mlsValue _mls_x97, _mlsValue _mls_x98) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x96 = _mlsValue::create<_mls_Nil>();
  _mls_retval = std::make_tuple(_mls_x97, _mls_x96, _mls_x98);
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x35 = _mls_queens(_mlsValue::fromIntLit(8));
  _mls_retval = _mls_x35;
  return _mls_retval;
}
_mlsValue _mls_append_safe_caller_post_case0(_mlsValue _mls_x71, _mlsValue _mls_x72, _mlsValue _mls_x73) {
  _mlsValue _mls_retval;
  auto [_mls_x74, _mls_x75, _mls_x76] = _mls_append_safe_caller_post_case0_pre(_mls_x71, _mls_x72, _mls_x73);
  auto _mls_x77 = _mls_append_safe(_mls_x74, _mls_x75, _mls_x76);
  _mls_retval = _mls_x77;
  return _mls_retval;
}
_mlsValue _mls_length(_mlsValue _mls_x115) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x115)) {
    auto _mls_x116 = _mlsValue::cast<_mls_Cons>(_mls_x115)->_mls_tail;
    _mls_retval = _mls_length_case0_sr_post(_mls_x116);
  } else {
    _mls_retval = _mlsValue::fromIntLit(0);
  }
  return _mls_retval;
}
_mlsValue _mls_find_solution_default_caller_post(_mlsValue _mls_x128, _mlsValue _mls_x129) {
  _mlsValue _mls_retval;
  auto [_mls_x130, _mls_x131, _mls_x132] = _mls_find_solution_default_caller_post_pre(_mls_x128, _mls_x129);
  auto _mls_x133 = _mls_extend(_mls_x130, _mls_x131, _mls_x132);
  _mls_retval = _mls_x133;
  return _mls_retval;
}
_mlsValue _mls_find_solution_case0() {
  _mlsValue _mls_retval;
  auto _mls_x47 = _mlsValue::create<_mls_Nil>();
  auto _mls_x48 = _mlsValue::create<_mls_Nil>();
  auto _mls_x49 = _mlsValue::create<_mls_Cons>(_mls_x47, _mls_x48);
  _mls_retval = _mls_x49;
  return _mls_retval;
}
_mlsValue _mls_append_safe(_mlsValue _mls_queen2, _mlsValue _mls_xs1, _mlsValue _mls_xss) {
  _mlsValue _mls_retval;
  auto _mls_x24 = (_mls_queen2 <= _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x24, 1)) {
    _mls_retval = _mls_xss;
  } else {
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs1)) {
      auto _mls_x121 = _mlsValue::cast<_mls_Cons>(_mls_xs1)->_mls_head;
      auto _mls_x122 = _mlsValue::cast<_mls_Cons>(_mls_xs1)->_mls_tail;
      auto [_mls_x123, _mls_x124, _mls_x125, _mls_x126] = _mls_safe_case0_sr_post_pre(_mls_queen2, _mls_x121, _mlsValue::fromIntLit(1), _mls_x122);
      if (_mlsValue::isIntLit(_mls_x123, 1)) {
        _mls_retval = _mls_append_safe_caller_post(_mlsValue::fromIntLit(1), _mls_queen2, _mls_xs1, _mls_xss);
      } else {
        auto _mls_x127 = _mls_safe_case0_sr_post_default(_mls_x124, _mls_x125, _mls_x126);
        _mls_retval = _mls_append_safe_caller_post(_mls_x127, _mls_queen2, _mls_xs1, _mls_xss);
      }
    } else {
      auto [_mls_x117, _mls_x118, _mls_x119] = _mls_append_safe_caller_post_case0_pre(_mls_queen2, _mls_xs1, _mls_xss);
      auto _mls_x120 = _mls_append_safe(_mls_x117, _mls_x118, _mls_x119);
      _mls_retval = _mls_x120;
    }
  }
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_safe_case0_sr_post_pre(_mlsValue _mls_x37, _mlsValue _mls_x38, _mlsValue _mls_x40, _mlsValue _mls_x46) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x36 = (_mls_x37 != _mls_x38);
  auto _mls_x39 = (_mls_x38 + _mls_x40);
  auto _mls_x41 = (_mls_x37 != _mls_x39);
  auto _mls_x42 = (_mls_x36 && _mls_x41);
  auto _mls_x43 = (_mls_x38 - _mls_x40);
  auto _mls_x44 = (_mls_x37 != _mls_x43);
  auto _mls_x45 = (_mls_x42 && _mls_x44);
  _mls_retval = std::make_tuple(_mls_x45, _mls_x40, _mls_x37, _mls_x46);
  return _mls_retval;
}
_mlsValue _mls_safe(_mlsValue _mls_x113, _mlsValue _mls_x114, _mlsValue _mls_x110) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x110)) {
    auto _mls_x111 = _mlsValue::cast<_mls_Cons>(_mls_x110)->_mls_head;
    auto _mls_x112 = _mlsValue::cast<_mls_Cons>(_mls_x110)->_mls_tail;
    _mls_retval = _mls_safe_case0_sr_post(_mls_x113, _mls_x111, _mls_x114, _mls_x112);
  } else {
    _mls_retval = _mlsValue::fromIntLit(1);
  }
  return _mls_retval;
}
_mlsValue _mls_length_case0_sr_post(_mlsValue _mls_x62) {
  _mlsValue _mls_retval;
  auto _mls_x63 = _mls_length(_mls_x62);
  auto _mls_x64 = (_mlsValue::fromIntLit(1) + _mls_x63);
  _mls_retval = _mls_x64;
  return _mls_retval;
}
_mlsValue _mls_find_solution_default(_mlsValue _mls_x51, _mlsValue _mls_x52) {
  _mlsValue _mls_retval;
  auto _mls_x50 = (_mls_x51 - _mlsValue::fromIntLit(1));
  auto [_mls_x53, _mls_x54, _mls_x55] = _mls_find_solution_pre(_mls_x52, _mls_x50);
  if (_mlsValue::isIntLit(_mls_x53, 1)) {
    auto _mls_x57 = _mls_find_solution_case0();
    auto [_mls_x58, _mls_x59, _mls_x60] = _mls_find_solution_default_caller_post_pre(_mls_x52, _mls_x57);
    auto _mls_x61 = _mls_extend(_mls_x58, _mls_x59, _mls_x60);
    _mls_retval = _mls_x61;
  } else {
    auto _mls_x56 = _mls_find_solution_default(_mls_x54, _mls_x55);
    _mls_retval = _mls_find_solution_default_caller_post(_mls_x52, _mls_x56);
  }
  return _mls_retval;
}
_mlsValue _mls_queens(_mlsValue _mls_n1) {
  _mlsValue _mls_retval;
  auto [_mls_x102, _mls_x103, _mls_x104] = _mls_find_solution_pre(_mls_n1, _mls_n1);
  if (_mlsValue::isIntLit(_mls_x102, 1)) {
    auto _mls_x107 = _mls_find_solution_case0();
    auto _mls_x108 = _mlsValue::cast<_mls_Cons>(_mls_x107)->_mls_tail;
    auto _mls_x109 = _mls_length_case0_sr_post(_mls_x108);
    _mls_retval = _mls_x109;
  } else {
    auto _mls_x105 = _mls_find_solution_default(_mls_x103, _mls_x104);
    auto _mls_x106 = _mls_length(_mls_x105);
    _mls_retval = _mls_x106;
  }
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_find_solution_pre(_mlsValue _mls_x101, _mlsValue _mls_x100) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x99 = (_mls_x100 == _mlsValue::fromIntLit(0));
  _mls_retval = std::make_tuple(_mls_x99, _mls_x100, _mls_x101);
  return _mls_retval;
}
_mlsValue _mls_safe_case0_sr_post(_mlsValue _mls_x88, _mlsValue _mls_x89, _mlsValue _mls_x90, _mlsValue _mls_x91) {
  _mlsValue _mls_retval;
  auto [_mls_x92, _mls_x93, _mls_x94, _mls_x95] = _mls_safe_case0_sr_post_pre(_mls_x88, _mls_x89, _mls_x90, _mls_x91);
  if (_mlsValue::isIntLit(_mls_x92, 1)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else {
    _mls_retval = _mls_safe_case0_sr_post_default(_mls_x93, _mls_x94, _mls_x95);
  }
  return _mls_retval;
}
_mlsValue _mls_extend(_mlsValue _mls_queen3, _mlsValue _mls_acc, _mlsValue _mls_xss1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_xss1)) {
    auto _mls_x31 = _mlsValue::cast<_mls_Cons>(_mls_xss1)->_mls_head;
    auto _mls_x32 = _mlsValue::cast<_mls_Cons>(_mls_xss1)->_mls_tail;
    auto _mls_x33 = _mls_append_safe(_mls_queen3, _mls_x31, _mls_acc);
    auto _mls_x34 = _mls_extend(_mls_queen3, _mls_x33, _mls_x32);
    _mls_retval = _mls_x34;
  } else {
    _mls_retval = _mls_acc;
  }
  return _mls_retval;
}
_mlsValue _mls_safe_case0_sr_post_default(_mlsValue _mls_x79, _mlsValue _mls_x80, _mlsValue _mls_x81) {
  _mlsValue _mls_retval;
  auto _mls_x78 = (_mls_x79 + _mlsValue::fromIntLit(1));
  auto _mls_x82 = _mls_safe(_mls_x80, _mls_x78, _mls_x81);
  _mls_retval = _mls_x82;
  return _mls_retval;
}
_mlsValue _mls_append_safe_caller_post(_mlsValue _mls_x83, _mlsValue _mls_x84, _mlsValue _mls_x85, _mlsValue _mls_x86) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_x83, 1)) {
    _mls_retval = _mls_append_safe_caller_post_case0(_mls_x84, _mls_x85, _mls_x86);
  } else {
    auto _mls_x87 = _mls_append_safe(_mls_x84, _mls_x85, _mls_x86);
    _mls_retval = _mls_x87;
  }
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_append_safe_caller_post_case0_pre(_mlsValue _mls_x66, _mlsValue _mls_x68, _mlsValue _mls_x70) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x65 = (_mls_x66 - _mlsValue::fromIntLit(1));
  auto _mls_x67 = _mlsValue::create<_mls_Cons>(_mls_x66, _mls_x68);
  auto _mls_x69 = _mlsValue::create<_mls_Cons>(_mls_x67, _mls_x70);
  _mls_retval = std::make_tuple(_mls_x65, _mls_x68, _mls_x69);
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
