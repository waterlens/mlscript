#include "mlsprelude.h"
struct _mls_Expr;
struct _mls_Var;
struct _mls_Val;
struct _mls_Ln;
struct _mls_Pow;
struct _mls_LamDeriv;
struct _mls_Add;
struct _mls_Mul;
_mlsValue _mls_add(_mlsValue, _mlsValue);
_mlsValue _mls_add_case01(_mlsValue, _mlsValue);
_mlsValue _mls_add_case0(_mlsValue, _mlsValue);
_mlsValue _mls_add_default(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_case0(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_case01(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_case11(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_case1(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_default(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_default1(_mlsValue, _mlsValue);
_mlsValue _mls_count(_mlsValue);
_mlsValue _mls_d(_mlsValue, _mlsValue);
_mlsValue _mls_d_case0();
_mlsValue _mls_d_case1(_mlsValue, _mlsValue);
_mlsValue _mls_d_case1_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_d_case2(_mlsValue, _mlsValue);
_mlsValue _mls_d_case2_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case3(_mlsValue, _mlsValue);
_mlsValue _mls_d_case3_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case4(_mlsValue, _mlsValue);
_mlsValue _mls_d_case4_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case4_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case4_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case5(_mlsValue, _mlsValue);
_mlsValue _mls_d_case5_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_j(_mlsValue, _mlsValue);
_mlsValue _mls_ln(_mlsValue);
_mlsValue _mls_main(_mlsValue);
_mlsValue _mls_main_caller_post_default(_mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_main_caller_post_pre(_mlsValue, _mlsValue);
_mlsValue _mls_mul(_mlsValue, _mlsValue);
_mlsValue _mls_mul_case0(_mlsValue, _mlsValue);
_mlsValue _mls_mul_case01(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_case01(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_case0(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_case11(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_case1(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_default1(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_default(_mlsValue, _mlsValue);
_mlsValue _mls_nestAux(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_nestAux_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_nestAux_caller_post_pre(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_nestAux_default(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_pow(_mlsValue, _mlsValue);
_mlsValue _mls_pow_case0(_mlsValue, _mlsValue);
_mlsValue _mls_pow_default(_mlsValue, _mlsValue);
_mlsValue _mls_pow_default_case0(_mlsValue, _mlsValue);
_mlsValue _mls_pow_default_default(_mlsValue, _mlsValue);
_mlsValue _mls_pown(_mlsValue, _mlsValue);
struct _mls_Expr: public _mlsObject {
  
  constexpr static inline const char *typeName = "Expr";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Expr; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Var: public _mls_Expr {
  _mlsValue _mls_x;
  constexpr static inline const char *typeName = "Var";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_x.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_x);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_x.asObject()->operator==(*other.cast<_mls_Var>()->_mls_x.asObject()); }
  static _mlsValue create(_mlsValue _mls_x) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Var; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_x = _mls_x;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Val: public _mls_Expr {
  _mlsValue _mls_n;
  constexpr static inline const char *typeName = "Val";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_n.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_n);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_n.asObject()->operator==(*other.cast<_mls_Val>()->_mls_n.asObject()); }
  static _mlsValue create(_mlsValue _mls_n) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Val; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_n = _mls_n;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Ln: public _mls_Expr {
  _mlsValue _mls_e;
  constexpr static inline const char *typeName = "Ln";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e.asObject()->operator==(*other.cast<_mls_Ln>()->_mls_e.asObject()); }
  static _mlsValue create(_mlsValue _mls_e) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Ln; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e = _mls_e;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Pow: public _mls_Expr {
  _mlsValue _mls_e1;
  _mlsValue _mls_e2;
  constexpr static inline const char *typeName = "Pow";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e1.print(); std::printf(", "); this->_mls_e2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e1); _mlsValue::destroy(this->_mls_e2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e1.asObject()->operator==(*other.cast<_mls_Pow>()->_mls_e1.asObject()) && this->_mls_e2.asObject()->operator==(*other.cast<_mls_Pow>()->_mls_e2.asObject()); }
  static _mlsValue create(_mlsValue _mls_e1, _mlsValue _mls_e2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Pow; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e1 = _mls_e1; _mlsVal->_mls_e2 = _mls_e2;  return _mlsValue(_mlsVal); }
  
};
struct _mls_LamDeriv: public _mlsObject {
  
  constexpr static inline const char *typeName = "LamDeriv";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_LamDeriv; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Add: public _mls_Expr {
  _mlsValue _mls_e1;
  _mlsValue _mls_e2;
  constexpr static inline const char *typeName = "Add";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e1.print(); std::printf(", "); this->_mls_e2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e1); _mlsValue::destroy(this->_mls_e2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e1.asObject()->operator==(*other.cast<_mls_Add>()->_mls_e1.asObject()) && this->_mls_e2.asObject()->operator==(*other.cast<_mls_Add>()->_mls_e2.asObject()); }
  static _mlsValue create(_mlsValue _mls_e1, _mlsValue _mls_e2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Add; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e1 = _mls_e1; _mlsVal->_mls_e2 = _mls_e2;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Mul: public _mls_Expr {
  _mlsValue _mls_e1;
  _mlsValue _mls_e2;
  constexpr static inline const char *typeName = "Mul";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e1.print(); std::printf(", "); this->_mls_e2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e1); _mlsValue::destroy(this->_mls_e2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e1.asObject()->operator==(*other.cast<_mls_Mul>()->_mls_e1.asObject()) && this->_mls_e2.asObject()->operator==(*other.cast<_mls_Mul>()->_mls_e2.asObject()); }
  static _mlsValue create(_mlsValue _mls_e1, _mlsValue _mls_e2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Mul; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e1 = _mls_e1; _mlsVal->_mls_e2 = _mls_e2;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_add(_mlsValue _mls_x, _mlsValue _mls_x153) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x)) {
    _mls_retval = _mls_add_case0(_mls_x, _mls_x153);
  } else {
    _mls_retval = _mls_add_default(_mls_x153, _mls_x);
  }
  return _mls_retval;
}
_mlsValue _mls_add_case01(_mlsValue _mls_x155, _mlsValue _mls_x156) {
  _mlsValue _mls_retval;
  auto _mls_x154 = _mlsValue::cast<_mls_Val>(_mls_x155)->_mls_n;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x156)) {
    auto _mls_x165 = _mlsValue::cast<_mls_Val>(_mls_x156)->_mls_n;
    auto _mls_x166 = (_mls_x154 + _mls_x165);
    auto _mls_x167 = _mlsValue::create<_mls_Val>(_mls_x166);
    _mls_retval = _mls_x167;
  } else {
    if (_mlsValue::isIntLit(_mls_x154, 0)) {
      _mls_retval = _mls_x156;
    } else {
      if (_mlsValue::isValueOf<_mls_Add>(_mls_x156)) {
        auto _mls_x158 = _mlsValue::cast<_mls_Add>(_mls_x156)->_mls_e1;
        auto _mls_x159 = _mlsValue::cast<_mls_Add>(_mls_x156)->_mls_e2;
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x158)) {
          auto _mls_x161 = _mlsValue::cast<_mls_Val>(_mls_x158)->_mls_n;
          auto _mls_x162 = (_mls_x154 + _mls_x161);
          auto _mls_x163 = _mlsValue::create<_mls_Val>(_mls_x162);
          auto _mls_x164 = _mls_add_case0(_mls_x163, _mls_x159);
          _mls_retval = _mls_x164;
        } else {
          auto _mls_x160 = _mlsValue::create<_mls_Add>(_mls_x155, _mls_x156);
          _mls_retval = _mls_x160;
        }
      } else {
        auto _mls_x157 = _mlsValue::create<_mls_Add>(_mls_x155, _mls_x156);
        _mls_retval = _mls_x157;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_add_case0(_mlsValue _mls_x169, _mlsValue _mls_x170) {
  _mlsValue _mls_retval;
  auto _mls_x168 = _mlsValue::cast<_mls_Val>(_mls_x169)->_mls_n;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x170)) {
    auto _mls_x179 = _mlsValue::cast<_mls_Val>(_mls_x170)->_mls_n;
    auto _mls_x180 = (_mls_x168 + _mls_x179);
    auto _mls_x181 = _mlsValue::create<_mls_Val>(_mls_x180);
    _mls_retval = _mls_x181;
  } else {
    if (_mlsValue::isIntLit(_mls_x168, 0)) {
      _mls_retval = _mls_x170;
    } else {
      if (_mlsValue::isValueOf<_mls_Add>(_mls_x170)) {
        auto _mls_x172 = _mlsValue::cast<_mls_Add>(_mls_x170)->_mls_e1;
        auto _mls_x173 = _mlsValue::cast<_mls_Add>(_mls_x170)->_mls_e2;
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x172)) {
          auto _mls_x175 = _mlsValue::cast<_mls_Val>(_mls_x172)->_mls_n;
          auto _mls_x176 = (_mls_x168 + _mls_x175);
          auto _mls_x177 = _mlsValue::create<_mls_Val>(_mls_x176);
          auto _mls_x178 = _mls_add_case01(_mls_x177, _mls_x173);
          _mls_retval = _mls_x178;
        } else {
          auto _mls_x174 = _mlsValue::create<_mls_Add>(_mls_x169, _mls_x170);
          _mls_retval = _mls_x174;
        }
      } else {
        auto _mls_x171 = _mlsValue::create<_mls_Add>(_mls_x169, _mls_x170);
        _mls_retval = _mls_x171;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_add_default(_mlsValue _mls_x182, _mlsValue _mls_x183) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x182)) {
    _mls_retval = _mls_add_default_case0(_mls_x182, _mls_x183);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x182)) {
    _mls_retval = _mls_add_default_case1(_mls_x182, _mls_x183);
  } else {
    _mls_retval = _mls_add_default_default(_mls_x183, _mls_x182);
  }
  return _mls_retval;
}
_mlsValue _mls_add_default_case0(_mlsValue _mls_x185, _mlsValue _mls_x187) {
  _mlsValue _mls_retval;
  auto _mls_x184 = _mlsValue::cast<_mls_Val>(_mls_x185)->_mls_n;
  if (_mlsValue::isIntLit(_mls_x184, 0)) {
    _mls_retval = _mls_x187;
  } else {
    auto _mls_x186 = _mlsValue::create<_mls_Val>(_mls_x184);
    auto _mls_x188 = _mls_add_case01(_mls_x186, _mls_x187);
    _mls_retval = _mls_x188;
  }
  return _mls_retval;
}
_mlsValue _mls_add_default_case01(_mlsValue _mls_x190, _mlsValue _mls_x192) {
  _mlsValue _mls_retval;
  auto _mls_x189 = _mlsValue::cast<_mls_Val>(_mls_x190)->_mls_n;
  if (_mlsValue::isIntLit(_mls_x189, 0)) {
    _mls_retval = _mls_x192;
  } else {
    auto _mls_x191 = _mlsValue::create<_mls_Val>(_mls_x189);
    auto _mls_x193 = _mls_add_case0(_mls_x191, _mls_x192);
    _mls_retval = _mls_x193;
  }
  return _mls_retval;
}
_mlsValue _mls_add_default_case11(_mlsValue _mls_x195, _mlsValue _mls_x197) {
  _mlsValue _mls_retval;
  auto _mls_x194 = _mlsValue::cast<_mls_Add>(_mls_x195)->_mls_e1;
  auto _mls_x196 = _mlsValue::cast<_mls_Add>(_mls_x195)->_mls_e2;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x194)) {
    auto _mls_x205 = _mlsValue::cast<_mls_Val>(_mls_x194)->_mls_n;
    auto _mls_x206 = _mlsValue::create<_mls_Val>(_mls_x205);
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x197)) {
      auto _mls_x209 = _mls_add_case0(_mls_x197, _mls_x196);
      auto _mls_x210 = _mls_add(_mls_x206, _mls_x209);
      _mls_retval = _mls_x210;
    } else {
      auto _mls_x207 = _mls_add_default(_mls_x196, _mls_x197);
      auto _mls_x208 = _mls_add(_mls_x206, _mls_x207);
      _mls_retval = _mls_x208;
    }
  } else {
    if (_mlsValue::isValueOf<_mls_Add>(_mls_x197)) {
      auto _mls_x199 = _mlsValue::cast<_mls_Add>(_mls_x197)->_mls_e1;
      auto _mls_x200 = _mlsValue::cast<_mls_Add>(_mls_x197)->_mls_e2;
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x200)) {
        auto _mls_x203 = _mls_add_case0(_mls_x200, _mls_x195);
        auto _mls_x204 = _mls_add(_mls_x199, _mls_x203);
        _mls_retval = _mls_x204;
      } else {
        auto _mls_x201 = _mls_add_default(_mls_x195, _mls_x200);
        auto _mls_x202 = _mls_add(_mls_x199, _mls_x201);
        _mls_retval = _mls_x202;
      }
    } else {
      auto _mls_x198 = _mlsValue::create<_mls_Add>(_mls_x197, _mls_x195);
      _mls_retval = _mls_x198;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_add_default_case1(_mlsValue _mls_x212, _mlsValue _mls_x214) {
  _mlsValue _mls_retval;
  auto _mls_x211 = _mlsValue::cast<_mls_Add>(_mls_x212)->_mls_e1;
  auto _mls_x213 = _mlsValue::cast<_mls_Add>(_mls_x212)->_mls_e2;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x211)) {
    auto _mls_x222 = _mlsValue::cast<_mls_Val>(_mls_x211)->_mls_n;
    auto _mls_x223 = _mlsValue::create<_mls_Val>(_mls_x222);
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x214)) {
      auto _mls_x230 = _mls_add_case01(_mls_x214, _mls_x213);
      auto _mls_x231 = _mls_add(_mls_x223, _mls_x230);
      _mls_retval = _mls_x231;
    } else {
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x213)) {
        auto _mls_x228 = _mls_add_default_case01(_mls_x213, _mls_x214);
        auto _mls_x229 = _mls_add(_mls_x223, _mls_x228);
        _mls_retval = _mls_x229;
      } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x213)) {
        auto _mls_x226 = _mls_add_default_case11(_mls_x213, _mls_x214);
        auto _mls_x227 = _mls_add(_mls_x223, _mls_x226);
        _mls_retval = _mls_x227;
      } else {
        auto _mls_x224 = _mls_add_default_default1(_mls_x214, _mls_x213);
        auto _mls_x225 = _mls_add(_mls_x223, _mls_x224);
        _mls_retval = _mls_x225;
      }
    }
  } else {
    if (_mlsValue::isValueOf<_mls_Add>(_mls_x214)) {
      auto _mls_x216 = _mlsValue::cast<_mls_Add>(_mls_x214)->_mls_e1;
      auto _mls_x217 = _mlsValue::cast<_mls_Add>(_mls_x214)->_mls_e2;
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x217)) {
        auto _mls_x220 = _mls_add_case01(_mls_x217, _mls_x212);
        auto _mls_x221 = _mls_add(_mls_x216, _mls_x220);
        _mls_retval = _mls_x221;
      } else {
        auto _mls_x218 = _mls_add_default_case11(_mls_x212, _mls_x217);
        auto _mls_x219 = _mls_add(_mls_x216, _mls_x218);
        _mls_retval = _mls_x219;
      }
    } else {
      auto _mls_x215 = _mlsValue::create<_mls_Add>(_mls_x214, _mls_x212);
      _mls_retval = _mls_x215;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_add_default_default(_mlsValue _mls_x232, _mlsValue _mls_x234) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_x232)) {
    auto _mls_x235 = _mlsValue::cast<_mls_Add>(_mls_x232)->_mls_e1;
    auto _mls_x236 = _mlsValue::cast<_mls_Add>(_mls_x232)->_mls_e2;
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x236)) {
      auto _mls_x243 = _mls_add_case01(_mls_x236, _mls_x234);
      auto _mls_x244 = _mls_add(_mls_x235, _mls_x243);
      _mls_retval = _mls_x244;
    } else {
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x234)) {
        auto _mls_x241 = _mls_add_default_case01(_mls_x234, _mls_x236);
        auto _mls_x242 = _mls_add(_mls_x235, _mls_x241);
        _mls_retval = _mls_x242;
      } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x234)) {
        auto _mls_x239 = _mls_add_default_case11(_mls_x234, _mls_x236);
        auto _mls_x240 = _mls_add(_mls_x235, _mls_x239);
        _mls_retval = _mls_x240;
      } else {
        auto _mls_x237 = _mls_add_default_default1(_mls_x236, _mls_x234);
        auto _mls_x238 = _mls_add(_mls_x235, _mls_x237);
        _mls_retval = _mls_x238;
      }
    }
  } else {
    auto _mls_x233 = _mlsValue::create<_mls_Add>(_mls_x232, _mls_x234);
    _mls_retval = _mls_x233;
  }
  return _mls_retval;
}
_mlsValue _mls_add_default_default1(_mlsValue _mls_x245, _mlsValue _mls_x247) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_x245)) {
    auto _mls_x248 = _mlsValue::cast<_mls_Add>(_mls_x245)->_mls_e1;
    auto _mls_x249 = _mlsValue::cast<_mls_Add>(_mls_x245)->_mls_e2;
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x249)) {
      auto _mls_x252 = _mls_add_case0(_mls_x249, _mls_x247);
      auto _mls_x253 = _mls_add(_mls_x248, _mls_x252);
      _mls_retval = _mls_x253;
    } else {
      auto _mls_x250 = _mls_add_default(_mls_x247, _mls_x249);
      auto _mls_x251 = _mls_add(_mls_x248, _mls_x250);
      _mls_retval = _mls_x251;
    }
  } else {
    auto _mls_x246 = _mlsValue::create<_mls_Add>(_mls_x245, _mls_x247);
    _mls_retval = _mls_x246;
  }
  return _mls_retval;
}
_mlsValue _mls_count(_mlsValue _mls_e3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_e3)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else if (_mlsValue::isValueOf<_mls_Var>(_mls_e3)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_e3)) {
    auto _mls_x45 = _mlsValue::cast<_mls_Add>(_mls_e3)->_mls_e1;
    auto _mls_x46 = _mlsValue::cast<_mls_Add>(_mls_e3)->_mls_e2;
    auto _mls_x47 = _mls_count(_mls_x45);
    auto _mls_x48 = _mls_count(_mls_x46);
    auto _mls_x49 = (_mls_x47 + _mls_x48);
    _mls_retval = _mls_x49;
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_e3)) {
    auto _mls_x40 = _mlsValue::cast<_mls_Mul>(_mls_e3)->_mls_e1;
    auto _mls_x41 = _mlsValue::cast<_mls_Mul>(_mls_e3)->_mls_e2;
    auto _mls_x42 = _mls_count(_mls_x40);
    auto _mls_x43 = _mls_count(_mls_x41);
    auto _mls_x44 = (_mls_x42 + _mls_x43);
    _mls_retval = _mls_x44;
  } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_e3)) {
    auto _mls_x35 = _mlsValue::cast<_mls_Pow>(_mls_e3)->_mls_e1;
    auto _mls_x36 = _mlsValue::cast<_mls_Pow>(_mls_e3)->_mls_e2;
    auto _mls_x37 = _mls_count(_mls_x35);
    auto _mls_x38 = _mls_count(_mls_x36);
    auto _mls_x39 = (_mls_x37 + _mls_x38);
    _mls_retval = _mls_x39;
  } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_e3)) {
    auto _mls_x33 = _mlsValue::cast<_mls_Ln>(_mls_e3)->_mls_e;
    auto _mls_x34 = _mls_count(_mls_x33);
    _mls_retval = _mls_x34;
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_d(_mlsValue _mls_x256, _mlsValue _mls_x254) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x254)) {
    _mls_retval = _mls_d_case0();
  } else if (_mlsValue::isValueOf<_mls_Var>(_mls_x254)) {
    auto _mls_x263 = _mlsValue::cast<_mls_Var>(_mls_x254)->_mls_x;
    _mls_retval = _mls_d_case1_sr_post(_mls_x256, _mls_x263);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x254)) {
    auto _mls_x261 = _mlsValue::cast<_mls_Add>(_mls_x254)->_mls_e1;
    auto _mls_x262 = _mlsValue::cast<_mls_Add>(_mls_x254)->_mls_e2;
    _mls_retval = _mls_d_case2_sr_post(_mls_x256, _mls_x261, _mls_x262);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x254)) {
    auto _mls_x259 = _mlsValue::cast<_mls_Mul>(_mls_x254)->_mls_e1;
    auto _mls_x260 = _mlsValue::cast<_mls_Mul>(_mls_x254)->_mls_e2;
    _mls_retval = _mls_d_case3_sr_post(_mls_x256, _mls_x260, _mls_x259);
  } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_x254)) {
    auto _mls_x257 = _mlsValue::cast<_mls_Pow>(_mls_x254)->_mls_e1;
    auto _mls_x258 = _mlsValue::cast<_mls_Pow>(_mls_x254)->_mls_e2;
    _mls_retval = _mls_d_case4_sr_post(_mls_x257, _mls_x258, _mls_x256);
  } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_x254)) {
    auto _mls_x255 = _mlsValue::cast<_mls_Ln>(_mls_x254)->_mls_e;
    _mls_retval = _mls_d_case5_sr_post(_mls_x256, _mls_x255);
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_d_case0() {
  _mlsValue _mls_retval;
  auto _mls_x264 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
  _mls_retval = _mls_x264;
  return _mls_retval;
}
_mlsValue _mls_d_case1(_mlsValue _mls_x266, _mlsValue _mls_x267) {
  _mlsValue _mls_retval;
  auto _mls_x265 = _mlsValue::cast<_mls_Var>(_mls_x266)->_mls_x;
  _mls_retval = _mls_d_case1_sr_post(_mls_x267, _mls_x265);
  return _mls_retval;
}
_mlsValue _mls_d_case1_sr_post(_mlsValue _mls_x269, _mlsValue _mls_x270) {
  _mlsValue _mls_retval;
  auto _mls_x268 = (_mls_x269 == _mls_x270);
  if (_mlsValue::isIntLit(_mls_x268, 1)) {
    auto _mls_x272 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(1));
    _mls_retval = _mls_x272;
  } else {
    auto _mls_x271 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
    _mls_retval = _mls_x271;
  }
  return _mls_retval;
}
_mlsValue _mls_d_case2(_mlsValue _mls_x274, _mlsValue _mls_x276) {
  _mlsValue _mls_retval;
  auto _mls_x273 = _mlsValue::cast<_mls_Add>(_mls_x274)->_mls_e1;
  auto _mls_x275 = _mlsValue::cast<_mls_Add>(_mls_x274)->_mls_e2;
  _mls_retval = _mls_d_case2_sr_post(_mls_x276, _mls_x273, _mls_x275);
  return _mls_retval;
}
_mlsValue _mls_d_case2_sr_post(_mlsValue _mls_x277, _mlsValue _mls_x278, _mlsValue _mls_x280) {
  _mlsValue _mls_retval;
  auto _mls_x279 = _mls_d(_mls_x277, _mls_x278);
  auto _mls_x281 = _mls_d(_mls_x277, _mls_x280);
  auto _mls_x282 = _mls_add(_mls_x279, _mls_x281);
  _mls_retval = _mls_x282;
  return _mls_retval;
}
_mlsValue _mls_d_case3(_mlsValue _mls_x284, _mlsValue _mls_x286) {
  _mlsValue _mls_retval;
  auto _mls_x283 = _mlsValue::cast<_mls_Mul>(_mls_x284)->_mls_e1;
  auto _mls_x285 = _mlsValue::cast<_mls_Mul>(_mls_x284)->_mls_e2;
  _mls_retval = _mls_d_case3_sr_post(_mls_x286, _mls_x285, _mls_x283);
  return _mls_retval;
}
_mlsValue _mls_d_case3_sr_post(_mlsValue _mls_x287, _mlsValue _mls_x288, _mlsValue _mls_x290) {
  _mlsValue _mls_retval;
  auto _mls_x289 = _mls_d(_mls_x287, _mls_x288);
  auto _mls_x291 = _mls_mul(_mls_x290, _mls_x289);
  auto _mls_x292 = _mls_d(_mls_x287, _mls_x290);
  auto _mls_x293 = _mls_mul(_mls_x288, _mls_x292);
  auto _mls_x294 = _mls_add(_mls_x291, _mls_x293);
  _mls_retval = _mls_x294;
  return _mls_retval;
}
_mlsValue _mls_d_case4(_mlsValue _mls_x296, _mlsValue _mls_x298) {
  _mlsValue _mls_retval;
  auto _mls_x295 = _mlsValue::cast<_mls_Pow>(_mls_x296)->_mls_e1;
  auto _mls_x297 = _mlsValue::cast<_mls_Pow>(_mls_x296)->_mls_e2;
  _mls_retval = _mls_d_case4_sr_post(_mls_x295, _mls_x297, _mls_x298);
  return _mls_retval;
}
_mlsValue _mls_d_case4_caller_post(_mlsValue _mls_x306, _mlsValue _mls_x299, _mlsValue _mls_x300, _mlsValue _mls_x307, _mlsValue _mls_x304) {
  _mlsValue _mls_retval;
  auto _mls_x301 = _mls_mul(_mls_x299, _mls_x300);
  auto _mls_x302 = (-_mlsValue::fromIntLit(1));
  auto _mls_x303 = _mlsValue::create<_mls_Val>(_mls_x302);
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x304)) {
    auto _mls_x308 = _mls_pow_case0(_mls_x304, _mls_x303);
    _mls_retval = _mls_d_case4_caller_post_caller_post(_mls_x299, _mls_x308, _mls_x306, _mls_x301, _mls_x307, _mls_x304);
  } else {
    auto _mls_x305 = _mls_pow_default(_mls_x303, _mls_x304);
    _mls_retval = _mls_d_case4_caller_post_caller_post(_mls_x299, _mls_x305, _mls_x306, _mls_x301, _mls_x307, _mls_x304);
  }
  return _mls_retval;
}
_mlsValue _mls_d_case4_caller_post_caller_post(_mlsValue _mls_x315, _mlsValue _mls_x310, _mlsValue _mls_x319, _mlsValue _mls_x309, _mlsValue _mls_x314, _mlsValue _mls_x312) {
  _mlsValue _mls_retval;
  auto _mls_x311 = _mls_mul(_mls_x309, _mls_x310);
  auto _mls_x313 = _mls_ln(_mls_x312);
  auto _mls_x316 = _mls_d(_mls_x314, _mls_x315);
  auto _mls_x317 = _mls_mul(_mls_x313, _mls_x316);
  auto _mls_x318 = _mls_add(_mls_x311, _mls_x317);
  auto _mls_x320 = _mls_mul(_mls_x319, _mls_x318);
  _mls_retval = _mls_x320;
  return _mls_retval;
}
_mlsValue _mls_d_case4_sr_post(_mlsValue _mls_x321, _mlsValue _mls_x322, _mlsValue _mls_x324) {
  _mlsValue _mls_retval;
  auto _mls_x323 = _mls_pow(_mls_x321, _mls_x322);
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x321)) {
    auto _mls_x330 = _mls_d_case0();
    _mls_retval = _mls_d_case4_caller_post(_mls_x323, _mls_x322, _mls_x330, _mls_x324, _mls_x321);
  } else if (_mlsValue::isValueOf<_mls_Var>(_mls_x321)) {
    auto _mls_x329 = _mls_d_case1(_mls_x321, _mls_x324);
    _mls_retval = _mls_d_case4_caller_post(_mls_x323, _mls_x322, _mls_x329, _mls_x324, _mls_x321);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x321)) {
    auto _mls_x328 = _mls_d_case2(_mls_x321, _mls_x324);
    _mls_retval = _mls_d_case4_caller_post(_mls_x323, _mls_x322, _mls_x328, _mls_x324, _mls_x321);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x321)) {
    auto _mls_x327 = _mls_d_case3(_mls_x321, _mls_x324);
    _mls_retval = _mls_d_case4_caller_post(_mls_x323, _mls_x322, _mls_x327, _mls_x324, _mls_x321);
  } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_x321)) {
    auto _mls_x326 = _mls_d_case4(_mls_x321, _mls_x324);
    _mls_retval = _mls_d_case4_caller_post(_mls_x323, _mls_x322, _mls_x326, _mls_x324, _mls_x321);
  } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_x321)) {
    auto _mls_x325 = _mls_d_case5(_mls_x321, _mls_x324);
    _mls_retval = _mls_d_case4_caller_post(_mls_x323, _mls_x322, _mls_x325, _mls_x324, _mls_x321);
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_d_case5(_mlsValue _mls_x332, _mlsValue _mls_x333) {
  _mlsValue _mls_retval;
  auto _mls_x331 = _mlsValue::cast<_mls_Ln>(_mls_x332)->_mls_e;
  _mls_retval = _mls_d_case5_sr_post(_mls_x333, _mls_x331);
  return _mls_retval;
}
_mlsValue _mls_d_case5_sr_post(_mlsValue _mls_x334, _mlsValue _mls_x335) {
  _mlsValue _mls_retval;
  auto _mls_x336 = _mls_d(_mls_x334, _mls_x335);
  auto _mls_x337 = (-_mlsValue::fromIntLit(1));
  auto _mls_x338 = _mlsValue::create<_mls_Val>(_mls_x337);
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x335)) {
    auto _mls_x341 = _mls_pow_case0(_mls_x335, _mls_x338);
    auto _mls_x342 = _mls_mul(_mls_x336, _mls_x341);
    _mls_retval = _mls_x342;
  } else {
    auto _mls_x339 = _mls_pow_default(_mls_x338, _mls_x335);
    auto _mls_x340 = _mls_mul(_mls_x336, _mls_x339);
    _mls_retval = _mls_x340;
  }
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x88 = _mls_main(_mlsValue::fromIntLit(10));
  _mls_retval = _mls_x88;
  return _mls_retval;
}
_mlsValue _mls_j(_mlsValue _mls_tmp, _mlsValue _mls_tmp1) {
  _mlsValue _mls_retval;
  auto _mls_x89 = (_mls_tmp * _mls_tmp1);
  _mls_retval = _mls_x89;
  return _mls_retval;
}
_mlsValue _mls_ln(_mlsValue _mls_e5) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_e5)) {
    auto _mls_x91 = _mlsValue::cast<_mls_Val>(_mls_e5)->_mls_n;
    if (_mlsValue::isIntLit(_mls_x91, 1)) {
      auto _mls_x93 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
      _mls_retval = _mls_x93;
    } else {
      auto _mls_x92 = _mlsValue::create<_mls_Ln>(_mls_e5);
      _mls_retval = _mls_x92;
    }
  } else {
    auto _mls_x90 = _mlsValue::create<_mls_Ln>(_mls_e5);
    _mls_retval = _mls_x90;
  }
  return _mls_retval;
}
_mlsValue _mls_main(_mlsValue _mls_n1) {
  _mlsValue _mls_retval;
  auto _mls_x94 = _mlsValue::create<_mls_Var>(_mlsValue::create<_mls_Str>("x"));
  auto _mls_x343 = _mls_pow_default_default(_mls_x94, _mls_x94);
  auto [_mls_x344, _mls_x345, _mls_x346] = _mls_main_caller_post_pre(_mls_n1, _mls_x343);
  if (_mlsValue::isIntLit(_mls_x344, 0)) {
    auto _mls_x347 = _mls_count(_mls_x345);
    _mls_retval = _mls_x347;
  } else {
    _mls_retval = _mls_main_caller_post_default(_mls_x346, _mls_x345, _mls_x344);
  }
  return _mls_retval;
}
_mlsValue _mls_main_caller_post_default(_mlsValue _mls_x348, _mlsValue _mls_x349, _mlsValue _mls_x350) {
  _mlsValue _mls_retval;
  auto _mls_x351 = _mls_nestAux_default(_mls_x348, _mls_x349, _mls_x350, _mls_x350);
  auto _mls_x352 = _mls_count(_mls_x351);
  _mls_retval = _mls_x352;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_main_caller_post_pre(_mlsValue _mls_x354, _mlsValue _mls_x355) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x353 = _mlsValue::create<_mls_LamDeriv>();
  _mls_retval = std::make_tuple(_mls_x354, _mls_x355, _mls_x353);
  return _mls_retval;
}
_mlsValue _mls_mul(_mlsValue _mls_x356, _mlsValue _mls_x357) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x356)) {
    _mls_retval = _mls_mul_case0(_mls_x356, _mls_x357);
  } else {
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x357)) {
      _mls_retval = _mls_mul_default_case0(_mls_x357, _mls_x356);
    } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x357)) {
      _mls_retval = _mls_mul_default_case1(_mls_x357, _mls_x356);
    } else {
      _mls_retval = _mls_mul_default_default(_mls_x356, _mls_x357);
    }
  }
  return _mls_retval;
}
_mlsValue _mls_mul_case0(_mlsValue _mls_x359, _mlsValue _mls_x360) {
  _mlsValue _mls_retval;
  auto _mls_x358 = _mlsValue::cast<_mls_Val>(_mls_x359)->_mls_n;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x360)) {
    auto _mls_x370 = _mlsValue::cast<_mls_Val>(_mls_x360)->_mls_n;
    auto _mls_x371 = (_mls_x358 * _mls_x370);
    auto _mls_x372 = _mlsValue::create<_mls_Val>(_mls_x371);
    _mls_retval = _mls_x372;
  } else {
    if (_mlsValue::isIntLit(_mls_x358, 0)) {
      auto _mls_x369 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
      _mls_retval = _mls_x369;
    } else if (_mlsValue::isIntLit(_mls_x358, 1)) {
      _mls_retval = _mls_x360;
    } else {
      if (_mlsValue::isValueOf<_mls_Mul>(_mls_x360)) {
        auto _mls_x362 = _mlsValue::cast<_mls_Mul>(_mls_x360)->_mls_e1;
        auto _mls_x363 = _mlsValue::cast<_mls_Mul>(_mls_x360)->_mls_e2;
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x362)) {
          auto _mls_x365 = _mlsValue::cast<_mls_Val>(_mls_x362)->_mls_n;
          auto _mls_x366 = (_mls_x358 * _mls_x365);
          auto _mls_x367 = _mlsValue::create<_mls_Val>(_mls_x366);
          auto _mls_x368 = _mls_mul_case01(_mls_x367, _mls_x363);
          _mls_retval = _mls_x368;
        } else {
          auto _mls_x364 = _mlsValue::create<_mls_Mul>(_mls_x359, _mls_x360);
          _mls_retval = _mls_x364;
        }
      } else {
        auto _mls_x361 = _mlsValue::create<_mls_Mul>(_mls_x359, _mls_x360);
        _mls_retval = _mls_x361;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_mul_case01(_mlsValue _mls_x374, _mlsValue _mls_x375) {
  _mlsValue _mls_retval;
  auto _mls_x373 = _mlsValue::cast<_mls_Val>(_mls_x374)->_mls_n;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x375)) {
    auto _mls_x385 = _mlsValue::cast<_mls_Val>(_mls_x375)->_mls_n;
    auto _mls_x386 = (_mls_x373 * _mls_x385);
    auto _mls_x387 = _mlsValue::create<_mls_Val>(_mls_x386);
    _mls_retval = _mls_x387;
  } else {
    if (_mlsValue::isIntLit(_mls_x373, 0)) {
      auto _mls_x384 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
      _mls_retval = _mls_x384;
    } else if (_mlsValue::isIntLit(_mls_x373, 1)) {
      _mls_retval = _mls_x375;
    } else {
      if (_mlsValue::isValueOf<_mls_Mul>(_mls_x375)) {
        auto _mls_x377 = _mlsValue::cast<_mls_Mul>(_mls_x375)->_mls_e1;
        auto _mls_x378 = _mlsValue::cast<_mls_Mul>(_mls_x375)->_mls_e2;
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x377)) {
          auto _mls_x380 = _mlsValue::cast<_mls_Val>(_mls_x377)->_mls_n;
          auto _mls_x381 = (_mls_x373 * _mls_x380);
          auto _mls_x382 = _mlsValue::create<_mls_Val>(_mls_x381);
          auto _mls_x383 = _mls_mul_case0(_mls_x382, _mls_x378);
          _mls_retval = _mls_x383;
        } else {
          auto _mls_x379 = _mlsValue::create<_mls_Mul>(_mls_x374, _mls_x375);
          _mls_retval = _mls_x379;
        }
      } else {
        auto _mls_x376 = _mlsValue::create<_mls_Mul>(_mls_x374, _mls_x375);
        _mls_retval = _mls_x376;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default(_mlsValue _mls_x388, _mlsValue _mls_x389) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x388)) {
    _mls_retval = _mls_mul_default_case0(_mls_x388, _mls_x389);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x388)) {
    _mls_retval = _mls_mul_default_case1(_mls_x388, _mls_x389);
  } else {
    _mls_retval = _mls_mul_default_default(_mls_x389, _mls_x388);
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default_case01(_mlsValue _mls_x391, _mlsValue _mls_x393) {
  _mlsValue _mls_retval;
  auto _mls_x390 = _mlsValue::cast<_mls_Val>(_mls_x391)->_mls_n;
  if (_mlsValue::isIntLit(_mls_x390, 0)) {
    auto _mls_x395 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
    _mls_retval = _mls_x395;
  } else if (_mlsValue::isIntLit(_mls_x390, 1)) {
    _mls_retval = _mls_x393;
  } else {
    auto _mls_x392 = _mlsValue::create<_mls_Val>(_mls_x390);
    auto _mls_x394 = _mls_mul_case0(_mls_x392, _mls_x393);
    _mls_retval = _mls_x394;
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default_case0(_mlsValue _mls_x397, _mlsValue _mls_x399) {
  _mlsValue _mls_retval;
  auto _mls_x396 = _mlsValue::cast<_mls_Val>(_mls_x397)->_mls_n;
  if (_mlsValue::isIntLit(_mls_x396, 0)) {
    auto _mls_x401 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
    _mls_retval = _mls_x401;
  } else if (_mlsValue::isIntLit(_mls_x396, 1)) {
    _mls_retval = _mls_x399;
  } else {
    auto _mls_x398 = _mlsValue::create<_mls_Val>(_mls_x396);
    auto _mls_x400 = _mls_mul_case01(_mls_x398, _mls_x399);
    _mls_retval = _mls_x400;
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default_case11(_mlsValue _mls_x403, _mlsValue _mls_x405) {
  _mlsValue _mls_retval;
  auto _mls_x402 = _mlsValue::cast<_mls_Mul>(_mls_x403)->_mls_e1;
  auto _mls_x404 = _mlsValue::cast<_mls_Mul>(_mls_x403)->_mls_e2;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x402)) {
    auto _mls_x413 = _mlsValue::cast<_mls_Val>(_mls_x402)->_mls_n;
    auto _mls_x414 = _mlsValue::create<_mls_Val>(_mls_x413);
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x405)) {
      auto _mls_x417 = _mls_mul_case0(_mls_x405, _mls_x404);
      auto _mls_x418 = _mls_mul(_mls_x414, _mls_x417);
      _mls_retval = _mls_x418;
    } else {
      auto _mls_x415 = _mls_mul_default(_mls_x404, _mls_x405);
      auto _mls_x416 = _mls_mul(_mls_x414, _mls_x415);
      _mls_retval = _mls_x416;
    }
  } else {
    if (_mlsValue::isValueOf<_mls_Mul>(_mls_x405)) {
      auto _mls_x407 = _mlsValue::cast<_mls_Mul>(_mls_x405)->_mls_e1;
      auto _mls_x408 = _mlsValue::cast<_mls_Mul>(_mls_x405)->_mls_e2;
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x408)) {
        auto _mls_x411 = _mls_mul_case0(_mls_x408, _mls_x403);
        auto _mls_x412 = _mls_mul(_mls_x407, _mls_x411);
        _mls_retval = _mls_x412;
      } else {
        auto _mls_x409 = _mls_mul_default(_mls_x403, _mls_x408);
        auto _mls_x410 = _mls_mul(_mls_x407, _mls_x409);
        _mls_retval = _mls_x410;
      }
    } else {
      auto _mls_x406 = _mlsValue::create<_mls_Mul>(_mls_x405, _mls_x403);
      _mls_retval = _mls_x406;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default_case1(_mlsValue _mls_x420, _mlsValue _mls_x422) {
  _mlsValue _mls_retval;
  auto _mls_x419 = _mlsValue::cast<_mls_Mul>(_mls_x420)->_mls_e1;
  auto _mls_x421 = _mlsValue::cast<_mls_Mul>(_mls_x420)->_mls_e2;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x419)) {
    auto _mls_x434 = _mlsValue::cast<_mls_Val>(_mls_x419)->_mls_n;
    auto _mls_x435 = _mlsValue::create<_mls_Val>(_mls_x434);
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x422)) {
      auto _mls_x442 = _mls_mul_case01(_mls_x422, _mls_x421);
      auto _mls_x443 = _mls_mul(_mls_x435, _mls_x442);
      _mls_retval = _mls_x443;
    } else {
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x421)) {
        auto _mls_x440 = _mls_mul_default_case01(_mls_x421, _mls_x422);
        auto _mls_x441 = _mls_mul(_mls_x435, _mls_x440);
        _mls_retval = _mls_x441;
      } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x421)) {
        auto _mls_x438 = _mls_mul_default_case11(_mls_x421, _mls_x422);
        auto _mls_x439 = _mls_mul(_mls_x435, _mls_x438);
        _mls_retval = _mls_x439;
      } else {
        auto _mls_x436 = _mls_mul_default_default1(_mls_x422, _mls_x421);
        auto _mls_x437 = _mls_mul(_mls_x435, _mls_x436);
        _mls_retval = _mls_x437;
      }
    }
  } else {
    if (_mlsValue::isValueOf<_mls_Mul>(_mls_x422)) {
      auto _mls_x424 = _mlsValue::cast<_mls_Mul>(_mls_x422)->_mls_e1;
      auto _mls_x425 = _mlsValue::cast<_mls_Mul>(_mls_x422)->_mls_e2;
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x425)) {
        auto _mls_x432 = _mls_mul_case01(_mls_x425, _mls_x420);
        auto _mls_x433 = _mls_mul(_mls_x424, _mls_x432);
        _mls_retval = _mls_x433;
      } else {
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x420)) {
          auto _mls_x430 = _mls_mul_default_case01(_mls_x420, _mls_x425);
          auto _mls_x431 = _mls_mul(_mls_x424, _mls_x430);
          _mls_retval = _mls_x431;
        } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x420)) {
          auto _mls_x428 = _mls_mul_default_case11(_mls_x420, _mls_x425);
          auto _mls_x429 = _mls_mul(_mls_x424, _mls_x428);
          _mls_retval = _mls_x429;
        } else {
          auto _mls_x426 = _mls_mul_default_default1(_mls_x425, _mls_x420);
          auto _mls_x427 = _mls_mul(_mls_x424, _mls_x426);
          _mls_retval = _mls_x427;
        }
      }
    } else {
      auto _mls_x423 = _mlsValue::create<_mls_Mul>(_mls_x422, _mls_x420);
      _mls_retval = _mls_x423;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default_default1(_mlsValue _mls_x444, _mlsValue _mls_x446) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Mul>(_mls_x444)) {
    auto _mls_x447 = _mlsValue::cast<_mls_Mul>(_mls_x444)->_mls_e1;
    auto _mls_x448 = _mlsValue::cast<_mls_Mul>(_mls_x444)->_mls_e2;
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x448)) {
      auto _mls_x451 = _mls_mul_case0(_mls_x448, _mls_x446);
      auto _mls_x452 = _mls_mul(_mls_x447, _mls_x451);
      _mls_retval = _mls_x452;
    } else {
      auto _mls_x449 = _mls_mul_default(_mls_x446, _mls_x448);
      auto _mls_x450 = _mls_mul(_mls_x447, _mls_x449);
      _mls_retval = _mls_x450;
    }
  } else {
    auto _mls_x445 = _mlsValue::create<_mls_Mul>(_mls_x444, _mls_x446);
    _mls_retval = _mls_x445;
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default_default(_mlsValue _mls_x453, _mlsValue _mls_x455) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Mul>(_mls_x453)) {
    auto _mls_x456 = _mlsValue::cast<_mls_Mul>(_mls_x453)->_mls_e1;
    auto _mls_x457 = _mlsValue::cast<_mls_Mul>(_mls_x453)->_mls_e2;
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x457)) {
      auto _mls_x464 = _mls_mul_case01(_mls_x457, _mls_x455);
      auto _mls_x465 = _mls_mul(_mls_x456, _mls_x464);
      _mls_retval = _mls_x465;
    } else {
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x455)) {
        auto _mls_x462 = _mls_mul_default_case01(_mls_x455, _mls_x457);
        auto _mls_x463 = _mls_mul(_mls_x456, _mls_x462);
        _mls_retval = _mls_x463;
      } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x455)) {
        auto _mls_x460 = _mls_mul_default_case11(_mls_x455, _mls_x457);
        auto _mls_x461 = _mls_mul(_mls_x456, _mls_x460);
        _mls_retval = _mls_x461;
      } else {
        auto _mls_x458 = _mls_mul_default_default1(_mls_x457, _mls_x455);
        auto _mls_x459 = _mls_mul(_mls_x456, _mls_x458);
        _mls_retval = _mls_x459;
      }
    }
  } else {
    auto _mls_x454 = _mlsValue::create<_mls_Mul>(_mls_x453, _mls_x455);
    _mls_retval = _mls_x454;
  }
  return _mls_retval;
}
_mlsValue _mls_nestAux(_mlsValue _mls_x469, _mlsValue _mls_x467, _mlsValue _mls_x466, _mlsValue _mls_x468) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_x466, 0)) {
    _mls_retval = _mls_x468;
  } else {
    _mls_retval = _mls_nestAux_default(_mls_x467, _mls_x468, _mls_x466, _mls_x469);
  }
  return _mls_retval;
}
_mlsValue _mls_nestAux_caller_post(_mlsValue _mls_x470, _mlsValue _mls_x471, _mlsValue _mls_x472, _mlsValue _mls_x473) {
  _mlsValue _mls_retval;
  auto [_mls_x474, _mls_x475, _mls_x476, _mls_x477] = _mls_nestAux_caller_post_pre(_mls_x470, _mls_x471, _mls_x472, _mls_x473);
  auto _mls_x478 = _mls_nestAux(_mls_x474, _mls_x475, _mls_x476, _mls_x477);
  _mls_retval = _mls_x478;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_nestAux_caller_post_pre(_mlsValue _mls_x480, _mlsValue _mls_x481, _mlsValue _mls_x482, _mlsValue _mls_x483) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x479 = (_mls_x480 - _mlsValue::fromIntLit(1));
  _mls_retval = std::make_tuple(_mls_x481, _mls_x482, _mls_x479, _mls_x483);
  return _mls_retval;
}
_mlsValue _mls_nestAux_default(_mlsValue _mls_x484, _mlsValue _mls_x485, _mlsValue _mls_x488, _mlsValue _mls_x489) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_LamDeriv>(_mls_x484)) {
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x485)) {
      auto _mls_x501 = _mls_d_case0();
      auto [_mls_x502, _mls_x503, _mls_x504, _mls_x505] = _mls_nestAux_caller_post_pre(_mls_x488, _mls_x489, _mls_x484, _mls_x501);
      auto _mls_x506 = _mls_nestAux(_mls_x502, _mls_x503, _mls_x504, _mls_x505);
      _mls_retval = _mls_x506;
    } else if (_mlsValue::isValueOf<_mls_Var>(_mls_x485)) {
      auto _mls_x499 = _mlsValue::cast<_mls_Var>(_mls_x485)->_mls_x;
      auto _mls_x500 = _mls_d_case1_sr_post(_mlsValue::create<_mls_Str>("x"), _mls_x499);
      _mls_retval = _mls_nestAux_caller_post(_mls_x488, _mls_x489, _mls_x484, _mls_x500);
    } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x485)) {
      auto _mls_x496 = _mlsValue::cast<_mls_Add>(_mls_x485)->_mls_e1;
      auto _mls_x497 = _mlsValue::cast<_mls_Add>(_mls_x485)->_mls_e2;
      auto _mls_x498 = _mls_d_case2_sr_post(_mlsValue::create<_mls_Str>("x"), _mls_x496, _mls_x497);
      _mls_retval = _mls_nestAux_caller_post(_mls_x488, _mls_x489, _mls_x484, _mls_x498);
    } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x485)) {
      auto _mls_x493 = _mlsValue::cast<_mls_Mul>(_mls_x485)->_mls_e1;
      auto _mls_x494 = _mlsValue::cast<_mls_Mul>(_mls_x485)->_mls_e2;
      auto _mls_x495 = _mls_d_case3_sr_post(_mlsValue::create<_mls_Str>("x"), _mls_x494, _mls_x493);
      _mls_retval = _mls_nestAux_caller_post(_mls_x488, _mls_x489, _mls_x484, _mls_x495);
    } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_x485)) {
      auto _mls_x490 = _mlsValue::cast<_mls_Pow>(_mls_x485)->_mls_e1;
      auto _mls_x491 = _mlsValue::cast<_mls_Pow>(_mls_x485)->_mls_e2;
      auto _mls_x492 = _mls_d_case4_sr_post(_mls_x490, _mls_x491, _mlsValue::create<_mls_Str>("x"));
      _mls_retval = _mls_nestAux_caller_post(_mls_x488, _mls_x489, _mls_x484, _mls_x492);
    } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_x485)) {
      auto _mls_x486 = _mlsValue::cast<_mls_Ln>(_mls_x485)->_mls_e;
      auto _mls_x487 = _mls_d_case5_sr_post(_mlsValue::create<_mls_Str>("x"), _mls_x486);
      _mls_retval = _mls_nestAux_caller_post(_mls_x488, _mls_x489, _mls_x484, _mls_x487);
    } else {
      throw std::runtime_error("match error" LINE_STRING);
    }
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_pow(_mlsValue _mls_x507, _mlsValue _mls_x508) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x507)) {
    _mls_retval = _mls_pow_case0(_mls_x507, _mls_x508);
  } else {
    _mls_retval = _mls_pow_default(_mls_x508, _mls_x507);
  }
  return _mls_retval;
}
_mlsValue _mls_pow_case0(_mlsValue _mls_x510, _mlsValue _mls_x511) {
  _mlsValue _mls_retval;
  auto _mls_x509 = _mlsValue::cast<_mls_Val>(_mls_x510)->_mls_n;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x511)) {
    auto _mls_x514 = _mlsValue::cast<_mls_Val>(_mls_x511)->_mls_n;
    auto _mls_x515 = _mls_pown(_mls_x509, _mls_x514);
    auto _mls_x516 = _mlsValue::create<_mls_Val>(_mls_x515);
    _mls_retval = _mls_x516;
  } else {
    if (_mlsValue::isIntLit(_mls_x509, 0)) {
      auto _mls_x513 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
      _mls_retval = _mls_x513;
    } else {
      auto _mls_x512 = _mlsValue::create<_mls_Pow>(_mls_x510, _mls_x511);
      _mls_retval = _mls_x512;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_pow_default(_mlsValue _mls_x517, _mlsValue _mls_x518) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x517)) {
    _mls_retval = _mls_pow_default_case0(_mls_x517, _mls_x518);
  } else {
    _mls_retval = _mls_pow_default_default(_mls_x518, _mls_x517);
  }
  return _mls_retval;
}
_mlsValue _mls_pow_default_case0(_mlsValue _mls_x520, _mlsValue _mls_x522) {
  _mlsValue _mls_retval;
  auto _mls_x519 = _mlsValue::cast<_mls_Val>(_mls_x520)->_mls_n;
  if (_mlsValue::isIntLit(_mls_x519, 0)) {
    auto _mls_x523 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(1));
    _mls_retval = _mls_x523;
  } else if (_mlsValue::isIntLit(_mls_x519, 1)) {
    _mls_retval = _mls_x522;
  } else {
    auto _mls_x521 = _mlsValue::create<_mls_Pow>(_mls_x522, _mls_x520);
    _mls_retval = _mls_x521;
  }
  return _mls_retval;
}
_mlsValue _mls_pow_default_default(_mlsValue _mls_x525, _mlsValue _mls_x526) {
  _mlsValue _mls_retval;
  auto _mls_x524 = _mlsValue::create<_mls_Pow>(_mls_x525, _mls_x526);
  _mls_retval = _mls_x524;
  return _mls_retval;
}
_mlsValue _mls_pown(_mlsValue _mls_x147, _mlsValue _mls_n3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_n3, 0)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else if (_mlsValue::isIntLit(_mls_n3, 1)) {
    _mls_retval = _mls_x147;
  } else {
    auto _mls_x146 = (_mls_n3 / _mlsValue::fromIntLit(2));
    auto _mls_x148 = _mls_pown(_mls_x147, _mls_x146);
    auto _mls_x149 = (_mls_x148 * _mls_x148);
    auto _mls_x150 = (_mls_n3 % _mlsValue::fromIntLit(2));
    auto _mls_x151 = (_mls_x150 == _mlsValue::fromIntLit(0));
    if (_mlsValue::isIntLit(_mls_x151, 1)) {
      _mls_retval = _mls_j(_mls_x149, _mlsValue::fromIntLit(1));
    } else {
      _mls_retval = _mls_j(_mls_x149, _mls_x147);
    }
  }
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
