#include "mlsprelude.h"
struct _mls_LamF1;
struct _mls_LamF2;
struct _mls_List;
struct _mls_Cons;
struct _mls_Nil;
struct _mls_Tuple2;
struct _mls_Tuple3;
_mlsValue _mls_apply(_mlsValue, _mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_enumFromTo(_mlsValue, _mlsValue);
_mlsValue _mls_enumFromTo_case0(_mlsValue, _mlsValue);
_mlsValue _mls_enumFromTo_default();
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_enumFromTo_pre(_mlsValue, _mlsValue);
_mlsValue _mls_g_case0(_mlsValue, _mlsValue);
_mlsValue _mls_g_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_g_case0_sr_post_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_gcdE(_mlsValue, _mlsValue);
_mlsValue _mls_lscomp1(_mlsValue, _mlsValue);
_mlsValue _mls_lscomp1_case0();
_mlsValue _mls_lscomp2(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_map(_mlsValue, _mlsValue);
_mlsValue _mls_map_case0(_mlsValue, _mlsValue);
_mlsValue _mls_map_case1();
_mlsValue _mls_max_(_mlsValue);
_mlsValue _mls_max__case0_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_quotRem(_mlsValue, _mlsValue);
_mlsValue _mls_test(_mlsValue);
_mlsValue _mls_test_caller_post_caller_post(_mlsValue);
_mlsValue _mls_test_caller_post_caller_post_post(_mlsValue);
std::tuple<_mlsValue, _mlsValue> _mls_test_caller_post_caller_post_pre(_mlsValue);
_mlsValue _mls_test_caller_post_case0();
_mlsValue _mls_test_caller_post_case1(_mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_test_caller_post_pre(_mlsValue, _mlsValue);
struct _mls_LamF1: public _mlsObject {
  
  constexpr static inline const char *typeName = "LamF1";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_LamF1; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_LamF2: public _mlsObject {
  
  constexpr static inline const char *typeName = "LamF2";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_LamF2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_List: public _mlsObject {
  
  constexpr static inline const char *typeName = "List";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_List; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Cons: public _mls_List {
  _mlsValue _mls_head;
  _mlsValue _mls_tail;
  constexpr static inline const char *typeName = "Cons";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_head.print(); std::printf(", "); this->_mls_tail.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_head); _mlsValue::destroy(this->_mls_tail);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_head.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_head.asObject()) && this->_mls_tail.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_tail.asObject()); }
  static _mlsValue create(_mlsValue _mls_head, _mlsValue _mls_tail) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Cons; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_head = _mls_head; _mlsVal->_mls_tail = _mls_tail;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Nil: public _mls_List {
  
  constexpr static inline const char *typeName = "Nil";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Nil; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Tuple2: public _mlsObject {
  _mlsValue _mls_field0;
  _mlsValue _mls_field1;
  constexpr static inline const char *typeName = "Tuple2";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_field0.print(); std::printf(", "); this->_mls_field1.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_field0); _mlsValue::destroy(this->_mls_field1);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_field0.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field0.asObject()) && this->_mls_field1.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field1.asObject()); }
  static _mlsValue create(_mlsValue _mls_field0, _mlsValue _mls_field1) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Tuple2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_field0 = _mls_field0; _mlsVal->_mls_field1 = _mls_field1;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Tuple3: public _mlsObject {
  _mlsValue _mls_field0;
  _mlsValue _mls_field1;
  _mlsValue _mls_field2;
  constexpr static inline const char *typeName = "Tuple3";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_field0.print(); std::printf(", "); this->_mls_field1.print(); std::printf(", "); this->_mls_field2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_field0); _mlsValue::destroy(this->_mls_field1); _mlsValue::destroy(this->_mls_field2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_field0.asObject()->operator==(*other.cast<_mls_Tuple3>()->_mls_field0.asObject()) && this->_mls_field1.asObject()->operator==(*other.cast<_mls_Tuple3>()->_mls_field1.asObject()) && this->_mls_field2.asObject()->operator==(*other.cast<_mls_Tuple3>()->_mls_field2.asObject()); }
  static _mlsValue create(_mlsValue _mls_field0, _mlsValue _mls_field1, _mlsValue _mls_field2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Tuple3; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_field0 = _mls_field0; _mlsVal->_mls_field1 = _mls_field1; _mlsVal->_mls_field2 = _mls_field2;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_apply(_mlsValue _mls_f, _mlsValue _mls_xs) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_LamF1>(_mls_f)) {
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_xs)) {
      auto _mls_x7 = _mlsValue::cast<_mls_Tuple2>(_mls_xs)->_mls_field0;
      auto _mls_x8 = _mlsValue::cast<_mls_Tuple2>(_mls_xs)->_mls_field1;
      auto _mls_x9 = _mls_gcdE(_mls_x7, _mls_x8);
      auto _mls_x10 = _mlsValue::create<_mls_Tuple3>(_mls_x7, _mls_x8, _mls_x9);
      _mls_retval = _mls_x10;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else if (_mlsValue::isValueOf<_mls_LamF2>(_mls_f)) {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_xs)) {
      auto _mls_x = _mlsValue::cast<_mls_Tuple3>(_mls_xs)->_mls_field2;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x)) {
        auto _mls_x1 = _mlsValue::cast<_mls_Tuple3>(_mls_x)->_mls_field0;
        auto _mls_x2 = _mlsValue::cast<_mls_Tuple3>(_mls_x)->_mls_field1;
        auto _mls_x3 = _mlsValue::cast<_mls_Tuple3>(_mls_x)->_mls_field2;
        auto _mls_x4 = (_mls_x1 + _mls_x2);
        auto _mls_x5 = (_mls_x4 + _mls_x3);
        auto _mls_x79 = _mls_builtin_abs(_mls_x5);
        _mls_retval = _mls_x79;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x80 = _mls_test(_mlsValue::fromIntLit(1000));
  _mls_retval = _mls_x80;
  return _mls_retval;
}
_mlsValue _mls_enumFromTo(_mlsValue _mls_x81, _mlsValue _mls_x82) {
  _mlsValue _mls_retval;
  auto [_mls_x83, _mls_x84, _mls_x85] = _mls_enumFromTo_pre(_mls_x81, _mls_x82);
  if (_mlsValue::isIntLit(_mls_x83, 1)) {
    _mls_retval = _mls_enumFromTo_case0(_mls_x84, _mls_x85);
  } else {
    _mls_retval = _mls_enumFromTo_default();
  }
  return _mls_retval;
}
_mlsValue _mls_enumFromTo_case0(_mlsValue _mls_x87, _mlsValue _mls_x88) {
  _mlsValue _mls_retval;
  auto _mls_x86 = (_mls_x87 + _mlsValue::fromIntLit(1));
  auto _mls_x89 = _mls_enumFromTo(_mls_x86, _mls_x88);
  auto _mls_x90 = _mlsValue::create<_mls_Cons>(_mls_x87, _mls_x89);
  _mls_retval = _mls_x90;
  return _mls_retval;
}
_mlsValue _mls_enumFromTo_default() {
  _mlsValue _mls_retval;
  auto _mls_x91 = _mlsValue::create<_mls_Nil>();
  _mls_retval = _mls_x91;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_enumFromTo_pre(_mlsValue _mls_x93, _mlsValue _mls_x94) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x92 = (_mls_x93 <= _mls_x94);
  _mls_retval = std::make_tuple(_mls_x92, _mls_x93, _mls_x94);
  return _mls_retval;
}
_mlsValue _mls_g_case0(_mlsValue _mls_x96, _mlsValue _mls_x99) {
  _mlsValue _mls_retval;
  auto _mls_x95 = _mlsValue::cast<_mls_Tuple3>(_mls_x96)->_mls_field0;
  auto _mls_x97 = _mlsValue::cast<_mls_Tuple3>(_mls_x96)->_mls_field1;
  auto _mls_x98 = _mlsValue::cast<_mls_Tuple3>(_mls_x96)->_mls_field2;
  _mls_retval = _mls_g_case0_sr_post(_mls_x99, _mls_x98, _mls_x95, _mls_x97);
  return _mls_retval;
}
_mlsValue _mls_g_case0_sr_post(_mlsValue _mls_x100, _mlsValue _mls_x106, _mlsValue _mls_x105, _mlsValue _mls_x104) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x100)) {
    auto _mls_x101 = _mlsValue::cast<_mls_Tuple3>(_mls_x100)->_mls_field0;
    auto _mls_x102 = _mlsValue::cast<_mls_Tuple3>(_mls_x100)->_mls_field1;
    auto _mls_x103 = _mlsValue::cast<_mls_Tuple3>(_mls_x100)->_mls_field2;
    _mls_retval = _mls_g_case0_sr_post_case0_sr_post(_mls_x101, _mls_x103, _mls_x104, _mls_x105, _mls_x102, _mls_x106);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_g_case0_sr_post_case0_sr_post(_mlsValue _mls_x114, _mlsValue _mls_x108, _mlsValue _mls_x120, _mlsValue _mls_x116, _mlsValue _mls_x118, _mlsValue _mls_x109) {
  _mlsValue _mls_retval;
  auto _mls_x107 = (_mls_x108 == _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x107, 1)) {
    auto _mls_x124 = _mlsValue::create<_mls_Tuple3>(_mls_x109, _mls_x116, _mls_x120);
    _mls_retval = _mls_x124;
  } else {
    auto _mls_x110 = _mls_quotRem(_mls_x109, _mls_x108);
    auto _mls_x111 = _mlsValue::cast<_mls_Tuple2>(_mls_x110)->_mls_field0;
    auto _mls_x112 = _mlsValue::cast<_mls_Tuple2>(_mls_x110)->_mls_field1;
    auto _mls_x113 = (_mls_x111 * _mls_x114);
    auto _mls_x115 = (_mls_x116 - _mls_x113);
    auto _mls_x117 = (_mls_x111 * _mls_x118);
    auto _mls_x119 = (_mls_x120 - _mls_x117);
    auto _mls_x121 = _mlsValue::create<_mls_Tuple3>(_mls_x114, _mls_x118, _mls_x108);
    auto _mls_x122 = _mlsValue::create<_mls_Tuple3>(_mls_x115, _mls_x119, _mls_x112);
    auto _mls_x123 = _mls_g_case0(_mls_x121, _mls_x122);
    _mls_retval = _mls_x123;
  }
  return _mls_retval;
}
_mlsValue _mls_gcdE(_mlsValue _mls_x36, _mlsValue _mls_y) {
  _mlsValue _mls_retval;
  auto _mls_x35 = (_mls_x36 == _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x35, 1)) {
    auto _mls_x40 = _mlsValue::create<_mls_Tuple3>(_mls_y, _mlsValue::fromIntLit(0), _mlsValue::fromIntLit(1));
    _mls_retval = _mls_x40;
  } else {
    auto _mls_x125 = _mls_g_case0_sr_post_case0_sr_post(_mlsValue::fromIntLit(0), _mls_y, _mlsValue::fromIntLit(0), _mlsValue::fromIntLit(1), _mlsValue::fromIntLit(1), _mls_x36);
    _mls_retval = _mls_x125;
  }
  return _mls_retval;
}
_mlsValue _mls_lscomp1(_mlsValue _mls_x126, _mlsValue _mls_x129) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x126)) {
    _mls_retval = _mls_lscomp1_case0();
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x126)) {
    auto _mls_x127 = _mlsValue::cast<_mls_Cons>(_mls_x126)->_mls_head;
    auto _mls_x128 = _mlsValue::cast<_mls_Cons>(_mls_x126)->_mls_tail;
    auto _mls_x130 = _mls_lscomp2(_mls_x127, _mls_x128, _mls_x129, _mls_x129);
    _mls_retval = _mls_x130;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_lscomp1_case0() {
  _mlsValue _mls_retval;
  auto _mls_x131 = _mlsValue::create<_mls_Nil>();
  _mls_retval = _mls_x131;
  return _mls_retval;
}
_mlsValue _mls_lscomp2(_mlsValue _mls_h1, _mlsValue _mls_t1, _mlsValue _mls_p2, _mlsValue _mls_initMs) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_p2)) {
    auto _mls_x50 = _mls_lscomp1(_mls_t1, _mls_initMs);
    _mls_retval = _mls_x50;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_p2)) {
    auto _mls_x45 = _mlsValue::cast<_mls_Cons>(_mls_p2)->_mls_head;
    auto _mls_x46 = _mlsValue::cast<_mls_Cons>(_mls_p2)->_mls_tail;
    auto _mls_x47 = _mls_lscomp2(_mls_h1, _mls_t1, _mls_x46, _mls_initMs);
    auto _mls_x48 = _mlsValue::create<_mls_Tuple2>(_mls_h1, _mls_x45);
    auto _mls_x49 = _mlsValue::create<_mls_Cons>(_mls_x48, _mls_x47);
    _mls_retval = _mls_x49;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_map(_mlsValue _mls_x133, _mlsValue _mls_x132) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x132)) {
    _mls_retval = _mls_map_case0(_mls_x132, _mls_x133);
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x132)) {
    _mls_retval = _mls_map_case1();
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_map_case0(_mlsValue _mls_x135, _mlsValue _mls_x137) {
  _mlsValue _mls_retval;
  auto _mls_x134 = _mlsValue::cast<_mls_Cons>(_mls_x135)->_mls_head;
  auto _mls_x136 = _mlsValue::cast<_mls_Cons>(_mls_x135)->_mls_tail;
  auto _mls_x138 = _mls_apply(_mls_x137, _mls_x134);
  auto _mls_x139 = _mls_map(_mls_x137, _mls_x136);
  auto _mls_x140 = _mlsValue::create<_mls_Cons>(_mls_x138, _mls_x139);
  _mls_retval = _mls_x140;
  return _mls_retval;
}
_mlsValue _mls_map_case1() {
  _mlsValue _mls_retval;
  auto _mls_x141 = _mlsValue::create<_mls_Nil>();
  _mls_retval = _mls_x141;
  return _mls_retval;
}
_mlsValue _mls_max_(_mlsValue _mls_x142) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x142)) {
    auto _mls_x143 = _mlsValue::cast<_mls_Cons>(_mls_x142)->_mls_head;
    auto _mls_x144 = _mlsValue::cast<_mls_Cons>(_mls_x142)->_mls_tail;
    _mls_retval = _mls_max__case0_sr_post(_mls_x144, _mls_x143);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_max__case0_sr_post(_mlsValue _mls_x145, _mlsValue _mls_x149) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x145)) {
    _mls_retval = _mls_x149;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x145)) {
    auto _mls_x146 = _mlsValue::cast<_mls_Cons>(_mls_x145)->_mls_head;
    auto _mls_x147 = _mlsValue::cast<_mls_Cons>(_mls_x145)->_mls_tail;
    auto _mls_x148 = (_mls_x149 < _mls_x146);
    if (_mlsValue::isIntLit(_mls_x148, 1)) {
      auto _mls_x152 = _mlsValue::create<_mls_Cons>(_mls_x146, _mls_x147);
      auto _mls_x153 = _mls_max_(_mls_x152);
      _mls_retval = _mls_x153;
    } else {
      auto _mls_x150 = _mlsValue::create<_mls_Cons>(_mls_x149, _mls_x147);
      auto _mls_x151 = _mls_max_(_mls_x150);
      _mls_retval = _mls_x151;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_quotRem(_mlsValue _mls_a1, _mlsValue _mls_b1) {
  _mlsValue _mls_retval;
  auto _mls_x154 = _mls_builtin_trunc_div(_mls_a1, _mls_b1);
  auto _mls_x155 = _mls_builtin_trunc_mod(_mls_a1, _mls_b1);
  auto _mls_x68 = _mlsValue::create<_mls_Tuple2>(_mls_x154, _mls_x155);
  _mls_retval = _mls_x68;
  return _mls_retval;
}
_mlsValue _mls_test(_mlsValue _mls_d) {
  _mlsValue _mls_retval;
  auto _mls_x69 = (_mlsValue::fromIntLit(5000) + _mls_d);
  auto [_mls_x156, _mls_x157, _mls_x158] = _mls_enumFromTo_pre(_mlsValue::fromIntLit(5000), _mls_x69);
  if (_mlsValue::isIntLit(_mls_x156, 1)) {
    auto _mls_x166 = _mls_enumFromTo_case0(_mls_x157, _mls_x158);
    auto [_mls_x167, _mls_x168, _mls_x169, _mls_x170] = _mls_test_caller_post_pre(_mls_d, _mls_x166);
    if (_mlsValue::isIntLit(_mls_x167, 1)) {
      auto _mls_x172 = _mls_enumFromTo_case0(_mls_x168, _mls_x169);
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x170)) {
        _mls_retval = _mls_test_caller_post_case0();
      } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x170)) {
        _mls_retval = _mls_test_caller_post_case1(_mls_x170, _mls_x172);
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      auto _mls_x171 = _mls_enumFromTo_default();
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x170)) {
        _mls_retval = _mls_test_caller_post_case0();
      } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x170)) {
        _mls_retval = _mls_test_caller_post_case1(_mls_x170, _mls_x171);
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    }
  } else {
    auto _mls_x159 = _mls_enumFromTo_default();
    auto [_mls_x160, _mls_x161, _mls_x162, _mls_x163] = _mls_test_caller_post_pre(_mls_d, _mls_x159);
    if (_mlsValue::isIntLit(_mls_x160, 1)) {
      auto _mls_x165 = _mls_enumFromTo_case0(_mls_x161, _mls_x162);
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x163)) {
        _mls_retval = _mls_test_caller_post_case0();
      } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x163)) {
        _mls_retval = _mls_test_caller_post_case1(_mls_x163, _mls_x165);
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      auto _mls_x164 = _mls_enumFromTo_default();
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x163)) {
        _mls_retval = _mls_test_caller_post_case0();
      } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x163)) {
        _mls_retval = _mls_test_caller_post_case1(_mls_x163, _mls_x164);
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_test_caller_post_caller_post(_mlsValue _mls_x173) {
  _mlsValue _mls_retval;
  auto [_mls_x174, _mls_x175] = _mls_test_caller_post_caller_post_pre(_mls_x173);
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x175)) {
    auto _mls_x177 = _mls_map_case0(_mls_x175, _mls_x174);
    _mls_retval = _mls_test_caller_post_caller_post_post(_mls_x177);
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x175)) {
    auto _mls_x176 = _mls_map_case1();
    _mls_retval = _mls_test_caller_post_caller_post_post(_mls_x176);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_test_caller_post_caller_post_post(_mlsValue _mls_x179) {
  _mlsValue _mls_retval;
  auto _mls_x178 = _mlsValue::create<_mls_LamF2>();
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x179)) {
    auto _mls_x182 = _mls_map_case0(_mls_x179, _mls_x178);
    auto _mls_x183 = _mls_max_(_mls_x182);
    _mls_retval = _mls_x183;
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x179)) {
    auto _mls_x180 = _mls_map_case1();
    auto _mls_x181 = _mls_max_(_mls_x180);
    _mls_retval = _mls_x181;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue> _mls_test_caller_post_caller_post_pre(_mlsValue _mls_x185) {
  std::tuple<_mlsValue, _mlsValue> _mls_retval;
  auto _mls_x184 = _mlsValue::create<_mls_LamF1>();
  _mls_retval = std::make_tuple(_mls_x184, _mls_x185);
  return _mls_retval;
}
_mlsValue _mls_test_caller_post_case0() {
  _mlsValue _mls_retval;
  auto _mls_x186 = _mls_lscomp1_case0();
  auto [_mls_x187, _mls_x188] = _mls_test_caller_post_caller_post_pre(_mls_x186);
  auto _mls_x189 = _mls_map(_mls_x187, _mls_x188);
  _mls_retval = _mls_test_caller_post_caller_post_post(_mls_x189);
  return _mls_retval;
}
_mlsValue _mls_test_caller_post_case1(_mlsValue _mls_x191, _mlsValue _mls_x193) {
  _mlsValue _mls_retval;
  auto _mls_x190 = _mlsValue::cast<_mls_Cons>(_mls_x191)->_mls_head;
  auto _mls_x192 = _mlsValue::cast<_mls_Cons>(_mls_x191)->_mls_tail;
  auto _mls_x194 = _mls_lscomp2(_mls_x190, _mls_x192, _mls_x193, _mls_x193);
  _mls_retval = _mls_test_caller_post_caller_post(_mls_x194);
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_test_caller_post_pre(_mlsValue _mls_x196, _mlsValue _mls_x200) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x195 = (_mlsValue::fromIntLit(10000) + _mls_x196);
  auto [_mls_x197, _mls_x198, _mls_x199] = _mls_enumFromTo_pre(_mlsValue::fromIntLit(10000), _mls_x195);
  _mls_retval = std::make_tuple(_mls_x197, _mls_x198, _mls_x199, _mls_x200);
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
