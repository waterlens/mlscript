#include "mlsprelude.h"
struct _mls_Expr;
struct _mls_Var;
struct _mls_Val;
struct _mls_Ln;
struct _mls_Pow;
struct _mls_Lambda_deriv;
struct _mls_Add;
struct _mls_Mul;
_mlsValue _mls_d_case2_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_pow_default(_mlsValue, _mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_d_case0();
_mlsValue _mls_d_case1_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_mul_case01(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_case01(_mlsValue, _mlsValue);
_mlsValue _mls_nestAux(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case4_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case4_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_mul_case0(_mlsValue, _mlsValue);
_mlsValue _mls_d_case1(_mlsValue, _mlsValue);
_mlsValue _mls_d_case3_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case4_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case3(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default(_mlsValue, _mlsValue);
_mlsValue _mls_pow_default_case0(_mlsValue, _mlsValue);
_mlsValue _mls_add(_mlsValue, _mlsValue);
_mlsValue _mls_deriv(_mlsValue, _mlsValue);
_mlsValue _mls_pow_default_default(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_case11(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_case1(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_default1(_mlsValue, _mlsValue);
_mlsValue _mls_d(_mlsValue, _mlsValue);
_mlsValue _mls_add_case01(_mlsValue, _mlsValue);
_mlsValue _mls_pow_case0(_mlsValue, _mlsValue);
_mlsValue _mls_add_case0(_mlsValue, _mlsValue);
_mlsValue _mls_pown(_mlsValue, _mlsValue);
_mlsValue _mls_d_case4(_mlsValue, _mlsValue);
_mlsValue _mls_j(_mlsValue, _mlsValue);
_mlsValue _mls_main(_mlsValue);
_mlsValue _mls_add_default_case1(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_case0(_mlsValue, _mlsValue);
_mlsValue _mls_mul(_mlsValue, _mlsValue);
_mlsValue _mls_count(_mlsValue);
_mlsValue _mls_d_case2(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_default(_mlsValue, _mlsValue);
_mlsValue _mls_add_default(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_default(_mlsValue, _mlsValue);
_mlsValue _mls_ln(_mlsValue);
_mlsValue _mls_main_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_case0(_mlsValue, _mlsValue);
_mlsValue _mls_d_case5(_mlsValue, _mlsValue);
_mlsValue _mls_pow(_mlsValue, _mlsValue);
_mlsValue _mls_d_case5_sr_post(_mlsValue, _mlsValue);
struct _mls_Expr: public _mlsObject {
  
  constexpr static inline const char *typeName = "Expr";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Expr; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Var: public _mls_Expr {
  _mlsValue _mls_x;
  constexpr static inline const char *typeName = "Var";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_x.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_x);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_x.asObject()->operator==(*other.cast<_mls_Var>()->_mls_x.asObject()); }
  static _mlsValue create(_mlsValue _mls_x) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Var; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_x = _mls_x;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Val: public _mls_Expr {
  _mlsValue _mls_n;
  constexpr static inline const char *typeName = "Val";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_n.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_n);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_n.asObject()->operator==(*other.cast<_mls_Val>()->_mls_n.asObject()); }
  static _mlsValue create(_mlsValue _mls_n) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Val; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_n = _mls_n;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Ln: public _mls_Expr {
  _mlsValue _mls_e;
  constexpr static inline const char *typeName = "Ln";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e.asObject()->operator==(*other.cast<_mls_Ln>()->_mls_e.asObject()); }
  static _mlsValue create(_mlsValue _mls_e) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Ln; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e = _mls_e;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Pow: public _mls_Expr {
  _mlsValue _mls_e1;
  _mlsValue _mls_e2;
  constexpr static inline const char *typeName = "Pow";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e1.print(); std::printf(", "); this->_mls_e2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e1); _mlsValue::destroy(this->_mls_e2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e1.asObject()->operator==(*other.cast<_mls_Pow>()->_mls_e1.asObject()) && this->_mls_e2.asObject()->operator==(*other.cast<_mls_Pow>()->_mls_e2.asObject()); }
  static _mlsValue create(_mlsValue _mls_e1, _mlsValue _mls_e2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Pow; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e1 = _mls_e1; _mlsVal->_mls_e2 = _mls_e2;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Lambda_deriv: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_deriv";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_deriv; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Add: public _mls_Expr {
  _mlsValue _mls_e1;
  _mlsValue _mls_e2;
  constexpr static inline const char *typeName = "Add";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e1.print(); std::printf(", "); this->_mls_e2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e1); _mlsValue::destroy(this->_mls_e2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e1.asObject()->operator==(*other.cast<_mls_Add>()->_mls_e1.asObject()) && this->_mls_e2.asObject()->operator==(*other.cast<_mls_Add>()->_mls_e2.asObject()); }
  static _mlsValue create(_mlsValue _mls_e1, _mlsValue _mls_e2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Add; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e1 = _mls_e1; _mlsVal->_mls_e2 = _mls_e2;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Mul: public _mls_Expr {
  _mlsValue _mls_e1;
  _mlsValue _mls_e2;
  constexpr static inline const char *typeName = "Mul";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e1.print(); std::printf(", "); this->_mls_e2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e1); _mlsValue::destroy(this->_mls_e2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e1.asObject()->operator==(*other.cast<_mls_Mul>()->_mls_e1.asObject()) && this->_mls_e2.asObject()->operator==(*other.cast<_mls_Mul>()->_mls_e2.asObject()); }
  static _mlsValue create(_mlsValue _mls_e1, _mlsValue _mls_e2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Mul; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e1 = _mls_e1; _mlsVal->_mls_e2 = _mls_e2;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_add_case0(_mlsValue _mls_x165, _mlsValue _mls_x166) {
  _mlsValue _mls_retval;
  auto _mls_x164 = _mlsValue::cast<_mls_Val>(_mls_x165)->_mls_n;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x166)) {
    auto _mls_x175 = _mlsValue::cast<_mls_Val>(_mls_x166)->_mls_n;
    auto _mls_x176 = (_mls_x164 + _mls_x175);
    auto _mls_x177 = _mlsValue::create<_mls_Val>(_mls_x176);
    _mls_retval = _mls_x177;
  } else {
    if (_mlsValue::isIntLit(_mls_x164, 0)) {
      _mls_retval = _mls_x166;
    } else {
      if (_mlsValue::isValueOf<_mls_Add>(_mls_x166)) {
        auto _mls_x168 = _mlsValue::cast<_mls_Add>(_mls_x166)->_mls_e1;
        auto _mls_x169 = _mlsValue::cast<_mls_Add>(_mls_x166)->_mls_e2;
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x168)) {
          auto _mls_x171 = _mlsValue::cast<_mls_Val>(_mls_x168)->_mls_n;
          auto _mls_x172 = (_mls_x164 + _mls_x171);
          auto _mls_x173 = _mlsValue::create<_mls_Val>(_mls_x172);
          auto _mls_x174 = _mls_add_case01(_mls_x173, _mls_x169);
          _mls_retval = _mls_x174;
        } else {
          auto _mls_x170 = _mlsValue::create<_mls_Add>(_mls_x165, _mls_x166);
          _mls_retval = _mls_x170;
        }
      } else {
        auto _mls_x167 = _mlsValue::create<_mls_Add>(_mls_x165, _mls_x166);
        _mls_retval = _mls_x167;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_d_case4(_mlsValue _mls_x188, _mlsValue _mls_x190) {
  _mlsValue _mls_retval;
  auto _mls_x187 = _mlsValue::cast<_mls_Pow>(_mls_x188)->_mls_e1;
  auto _mls_x189 = _mlsValue::cast<_mls_Pow>(_mls_x188)->_mls_e2;
  _mls_retval = _mls_d_case4_sr_post(_mls_x187, _mls_x189, _mls_x190);
  return _mls_retval;
}
_mlsValue _mls_pow_default_default(_mlsValue _mls_x414, _mlsValue _mls_x415) {
  _mlsValue _mls_retval;
  auto _mls_x413 = _mlsValue::create<_mls_Pow>(_mls_x414, _mls_x415);
  _mls_retval = _mls_x413;
  return _mls_retval;
}
_mlsValue _mls_d_case2_sr_post(_mlsValue _mls_x356, _mlsValue _mls_x357, _mlsValue _mls_x359) {
  _mlsValue _mls_retval;
  auto _mls_x358 = _mls_d(_mls_x356, _mls_x357);
  auto _mls_x360 = _mls_d(_mls_x356, _mls_x359);
  auto _mls_x361 = _mls_add(_mls_x358, _mls_x360);
  _mls_retval = _mls_x361;
  return _mls_retval;
}
_mlsValue _mls_d_case2(_mlsValue _mls_x184, _mlsValue _mls_x186) {
  _mlsValue _mls_retval;
  auto _mls_x183 = _mlsValue::cast<_mls_Add>(_mls_x184)->_mls_e1;
  auto _mls_x185 = _mlsValue::cast<_mls_Add>(_mls_x184)->_mls_e2;
  _mls_retval = _mls_d_case2_sr_post(_mls_x186, _mls_x183, _mls_x185);
  return _mls_retval;
}
_mlsValue _mls_mul_default_case1(_mlsValue _mls_x192, _mlsValue _mls_x194) {
  _mlsValue _mls_retval;
  auto _mls_x191 = _mlsValue::cast<_mls_Mul>(_mls_x192)->_mls_e1;
  auto _mls_x193 = _mlsValue::cast<_mls_Mul>(_mls_x192)->_mls_e2;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x191)) {
    auto _mls_x202 = _mlsValue::cast<_mls_Val>(_mls_x191)->_mls_n;
    auto _mls_x203 = _mlsValue::create<_mls_Val>(_mls_x202);
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x194)) {
      auto _mls_x206 = _mls_mul_case0(_mls_x194, _mls_x193);
      auto _mls_x207 = _mls_mul(_mls_x203, _mls_x206);
      _mls_retval = _mls_x207;
    } else {
      auto _mls_x204 = _mls_mul_default(_mls_x193, _mls_x194);
      auto _mls_x205 = _mls_mul(_mls_x203, _mls_x204);
      _mls_retval = _mls_x205;
    }
  } else {
    if (_mlsValue::isValueOf<_mls_Mul>(_mls_x194)) {
      auto _mls_x196 = _mlsValue::cast<_mls_Mul>(_mls_x194)->_mls_e1;
      auto _mls_x197 = _mlsValue::cast<_mls_Mul>(_mls_x194)->_mls_e2;
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x197)) {
        auto _mls_x200 = _mls_mul_case0(_mls_x197, _mls_x192);
        auto _mls_x201 = _mls_mul(_mls_x196, _mls_x200);
        _mls_retval = _mls_x201;
      } else {
        auto _mls_x198 = _mls_mul_default(_mls_x192, _mls_x197);
        auto _mls_x199 = _mls_mul(_mls_x196, _mls_x198);
        _mls_retval = _mls_x199;
      }
    } else {
      auto _mls_x195 = _mlsValue::create<_mls_Mul>(_mls_x194, _mls_x192);
      _mls_retval = _mls_x195;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_d_case4_caller_post(_mlsValue _mls_x235, _mlsValue _mls_x239, _mlsValue _mls_x242, _mlsValue _mls_x234, _mlsValue _mls_x241) {
  _mlsValue _mls_retval;
  auto _mls_x236 = _mls_mul(_mls_x234, _mls_x235);
  auto _mls_x237 = (-_mlsValue::fromIntLit(1));
  auto _mls_x238 = _mlsValue::create<_mls_Val>(_mls_x237);
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x239)) {
    auto _mls_x243 = _mls_pow_case0(_mls_x239, _mls_x238);
    _mls_retval = _mls_d_case4_caller_post_caller_post(_mls_x241, _mls_x242, _mls_x243, _mls_x234, _mls_x239, _mls_x236);
  } else {
    auto _mls_x240 = _mls_pow_default(_mls_x238, _mls_x239);
    _mls_retval = _mls_d_case4_caller_post_caller_post(_mls_x241, _mls_x242, _mls_x240, _mls_x234, _mls_x239, _mls_x236);
  }
  return _mls_retval;
}
_mlsValue _mls_add_default(_mlsValue _mls_x362, _mlsValue _mls_x363) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x362)) {
    _mls_retval = _mls_add_default_case01(_mls_x362, _mls_x363);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x362)) {
    _mls_retval = _mls_add_default_case11(_mls_x362, _mls_x363);
  } else {
    _mls_retval = _mls_add_default_default1(_mls_x363, _mls_x362);
  }
  return _mls_retval;
}
_mlsValue _mls_pow(_mlsValue _mls_x340, _mlsValue _mls_x341) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x340)) {
    _mls_retval = _mls_pow_case0(_mls_x340, _mls_x341);
  } else {
    _mls_retval = _mls_pow_default(_mls_x341, _mls_x340);
  }
  return _mls_retval;
}
_mlsValue _mls_d_case1(_mlsValue _mls_x310, _mlsValue _mls_x311) {
  _mlsValue _mls_retval;
  auto _mls_x309 = _mlsValue::cast<_mls_Var>(_mls_x310)->_mls_x;
  _mls_retval = _mls_d_case1_sr_post(_mls_x311, _mls_x309);
  return _mls_retval;
}
_mlsValue _mls_d_case4_sr_post(_mlsValue _mls_x244, _mlsValue _mls_x245, _mlsValue _mls_x247) {
  _mlsValue _mls_retval;
  auto _mls_x246 = _mls_pow(_mls_x244, _mls_x245);
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x244)) {
    auto _mls_x253 = _mls_d_case0();
    _mls_retval = _mls_d_case4_caller_post(_mls_x253, _mls_x244, _mls_x246, _mls_x245, _mls_x247);
  } else if (_mlsValue::isValueOf<_mls_Var>(_mls_x244)) {
    auto _mls_x252 = _mls_d_case1(_mls_x244, _mls_x247);
    _mls_retval = _mls_d_case4_caller_post(_mls_x252, _mls_x244, _mls_x246, _mls_x245, _mls_x247);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x244)) {
    auto _mls_x251 = _mls_d_case2(_mls_x244, _mls_x247);
    _mls_retval = _mls_d_case4_caller_post(_mls_x251, _mls_x244, _mls_x246, _mls_x245, _mls_x247);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x244)) {
    auto _mls_x250 = _mls_d_case3(_mls_x244, _mls_x247);
    _mls_retval = _mls_d_case4_caller_post(_mls_x250, _mls_x244, _mls_x246, _mls_x245, _mls_x247);
  } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_x244)) {
    auto _mls_x249 = _mls_d_case4(_mls_x244, _mls_x247);
    _mls_retval = _mls_d_case4_caller_post(_mls_x249, _mls_x244, _mls_x246, _mls_x245, _mls_x247);
  } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_x244)) {
    auto _mls_x248 = _mls_d_case5(_mls_x244, _mls_x247);
    _mls_retval = _mls_d_case4_caller_post(_mls_x248, _mls_x244, _mls_x246, _mls_x245, _mls_x247);
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_add_default_case0(_mlsValue _mls_x456, _mlsValue _mls_x458) {
  _mlsValue _mls_retval;
  auto _mls_x455 = _mlsValue::cast<_mls_Val>(_mls_x456)->_mls_n;
  if (_mlsValue::isIntLit(_mls_x455, 0)) {
    _mls_retval = _mls_x458;
  } else {
    auto _mls_x457 = _mlsValue::create<_mls_Val>(_mls_x455);
    auto _mls_x459 = _mls_add_case0(_mls_x457, _mls_x458);
    _mls_retval = _mls_x459;
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default_case0(_mlsValue _mls_x351, _mlsValue _mls_x353) {
  _mlsValue _mls_retval;
  auto _mls_x350 = _mlsValue::cast<_mls_Val>(_mls_x351)->_mls_n;
  if (_mlsValue::isIntLit(_mls_x350, 0)) {
    auto _mls_x355 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
    _mls_retval = _mls_x355;
  } else if (_mlsValue::isIntLit(_mls_x350, 1)) {
    _mls_retval = _mls_x353;
  } else {
    auto _mls_x352 = _mlsValue::create<_mls_Val>(_mls_x350);
    auto _mls_x354 = _mls_mul_case0(_mls_x352, _mls_x353);
    _mls_retval = _mls_x354;
  }
  return _mls_retval;
}
_mlsValue _mls_count(_mlsValue _mls_e4) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_e4)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else if (_mlsValue::isValueOf<_mls_Var>(_mls_e4)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_e4)) {
    auto _mls_x51 = _mlsValue::cast<_mls_Add>(_mls_e4)->_mls_e1;
    auto _mls_x52 = _mlsValue::cast<_mls_Add>(_mls_e4)->_mls_e2;
    auto _mls_x53 = _mls_count(_mls_x51);
    auto _mls_x54 = _mls_count(_mls_x52);
    auto _mls_x55 = (_mls_x53 + _mls_x54);
    _mls_retval = _mls_x55;
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_e4)) {
    auto _mls_x46 = _mlsValue::cast<_mls_Mul>(_mls_e4)->_mls_e1;
    auto _mls_x47 = _mlsValue::cast<_mls_Mul>(_mls_e4)->_mls_e2;
    auto _mls_x48 = _mls_count(_mls_x46);
    auto _mls_x49 = _mls_count(_mls_x47);
    auto _mls_x50 = (_mls_x48 + _mls_x49);
    _mls_retval = _mls_x50;
  } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_e4)) {
    auto _mls_x41 = _mlsValue::cast<_mls_Pow>(_mls_e4)->_mls_e1;
    auto _mls_x42 = _mlsValue::cast<_mls_Pow>(_mls_e4)->_mls_e2;
    auto _mls_x43 = _mls_count(_mls_x41);
    auto _mls_x44 = _mls_count(_mls_x42);
    auto _mls_x45 = (_mls_x43 + _mls_x44);
    _mls_retval = _mls_x45;
  } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_e4)) {
    auto _mls_x39 = _mlsValue::cast<_mls_Ln>(_mls_e4)->_mls_e;
    auto _mls_x40 = _mls_count(_mls_x39);
    _mls_retval = _mls_x40;
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_pow_default_case0(_mlsValue _mls_x315, _mlsValue _mls_x317) {
  _mlsValue _mls_retval;
  auto _mls_x314 = _mlsValue::cast<_mls_Val>(_mls_x315)->_mls_n;
  if (_mlsValue::isIntLit(_mls_x314, 0)) {
    auto _mls_x318 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(1));
    _mls_retval = _mls_x318;
  } else if (_mlsValue::isIntLit(_mls_x314, 1)) {
    _mls_retval = _mls_x317;
  } else {
    auto _mls_x316 = _mlsValue::create<_mls_Pow>(_mls_x317, _mls_x315);
    _mls_retval = _mls_x316;
  }
  return _mls_retval;
}
_mlsValue _mls_add_default_default1(_mlsValue _mls_x296, _mlsValue _mls_x298) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_x296)) {
    auto _mls_x299 = _mlsValue::cast<_mls_Add>(_mls_x296)->_mls_e1;
    auto _mls_x300 = _mlsValue::cast<_mls_Add>(_mls_x296)->_mls_e2;
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x300)) {
      auto _mls_x307 = _mls_add_case01(_mls_x300, _mls_x298);
      auto _mls_x308 = _mls_add(_mls_x299, _mls_x307);
      _mls_retval = _mls_x308;
    } else {
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x298)) {
        auto _mls_x305 = _mls_add_default_case0(_mls_x298, _mls_x300);
        auto _mls_x306 = _mls_add(_mls_x299, _mls_x305);
        _mls_retval = _mls_x306;
      } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x298)) {
        auto _mls_x303 = _mls_add_default_case1(_mls_x298, _mls_x300);
        auto _mls_x304 = _mls_add(_mls_x299, _mls_x303);
        _mls_retval = _mls_x304;
      } else {
        auto _mls_x301 = _mls_add_default_default(_mls_x300, _mls_x298);
        auto _mls_x302 = _mls_add(_mls_x299, _mls_x301);
        _mls_retval = _mls_x302;
      }
    }
  } else {
    auto _mls_x297 = _mlsValue::create<_mls_Add>(_mls_x296, _mls_x298);
    _mls_retval = _mls_x297;
  }
  return _mls_retval;
}
_mlsValue _mls_add_default_default(_mlsValue _mls_x, _mlsValue _mls_x155) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_x)) {
    auto _mls_x156 = _mlsValue::cast<_mls_Add>(_mls_x)->_mls_e1;
    auto _mls_x157 = _mlsValue::cast<_mls_Add>(_mls_x)->_mls_e2;
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x157)) {
      auto _mls_x160 = _mls_add_case0(_mls_x157, _mls_x155);
      auto _mls_x161 = _mls_add(_mls_x156, _mls_x160);
      _mls_retval = _mls_x161;
    } else {
      auto _mls_x158 = _mls_add_default(_mls_x155, _mls_x157);
      auto _mls_x159 = _mls_add(_mls_x156, _mls_x158);
      _mls_retval = _mls_x159;
    }
  } else {
    auto _mls_x154 = _mlsValue::create<_mls_Add>(_mls_x, _mls_x155);
    _mls_retval = _mls_x154;
  }
  return _mls_retval;
}
_mlsValue _mls_add_default_case01(_mlsValue _mls_x390, _mlsValue _mls_x392) {
  _mlsValue _mls_retval;
  auto _mls_x389 = _mlsValue::cast<_mls_Val>(_mls_x390)->_mls_n;
  if (_mlsValue::isIntLit(_mls_x389, 0)) {
    _mls_retval = _mls_x392;
  } else {
    auto _mls_x391 = _mlsValue::create<_mls_Val>(_mls_x389);
    auto _mls_x393 = _mls_add_case01(_mls_x391, _mls_x392);
    _mls_retval = _mls_x393;
  }
  return _mls_retval;
}
_mlsValue _mls_pown(_mlsValue _mls_x148, _mlsValue _mls_n3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_n3, 0)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else if (_mlsValue::isIntLit(_mls_n3, 1)) {
    _mls_retval = _mls_x148;
  } else {
    auto _mls_x147 = (_mls_n3 / _mlsValue::fromIntLit(2));
    auto _mls_x149 = _mls_pown(_mls_x148, _mls_x147);
    auto _mls_x150 = (_mls_x149 * _mls_x149);
    auto _mls_x151 = (_mls_n3 % _mlsValue::fromIntLit(2));
    auto _mls_x152 = (_mls_x151 == _mlsValue::fromIntLit(0));
    if (_mlsValue::isIntLit(_mls_x152, 1)) {
      _mls_retval = _mls_j(_mls_x150, _mlsValue::fromIntLit(1));
    } else {
      _mls_retval = _mls_j(_mls_x150, _mls_x148);
    }
  }
  return _mls_retval;
}
_mlsValue _mls_d_case3(_mlsValue _mls_x410, _mlsValue _mls_x412) {
  _mlsValue _mls_retval;
  auto _mls_x409 = _mlsValue::cast<_mls_Mul>(_mls_x410)->_mls_e1;
  auto _mls_x411 = _mlsValue::cast<_mls_Mul>(_mls_x410)->_mls_e2;
  _mls_retval = _mls_d_case3_sr_post(_mls_x412, _mls_x411, _mls_x409);
  return _mls_retval;
}
_mlsValue _mls_d_case3_sr_post(_mlsValue _mls_x288, _mlsValue _mls_x289, _mlsValue _mls_x291) {
  _mlsValue _mls_retval;
  auto _mls_x290 = _mls_d(_mls_x288, _mls_x289);
  auto _mls_x292 = _mls_mul(_mls_x291, _mls_x290);
  auto _mls_x293 = _mls_d(_mls_x288, _mls_x291);
  auto _mls_x294 = _mls_mul(_mls_x289, _mls_x293);
  auto _mls_x295 = _mls_add(_mls_x292, _mls_x294);
  _mls_retval = _mls_x295;
  return _mls_retval;
}
_mlsValue _mls_mul_default(_mlsValue _mls_x419, _mlsValue _mls_x420) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x419)) {
    auto _mls_x451 = _mlsValue::cast<_mls_Val>(_mls_x419)->_mls_n;
    if (_mlsValue::isIntLit(_mls_x451, 0)) {
      auto _mls_x454 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
      _mls_retval = _mls_x454;
    } else if (_mlsValue::isIntLit(_mls_x451, 1)) {
      _mls_retval = _mls_x420;
    } else {
      auto _mls_x452 = _mlsValue::create<_mls_Val>(_mls_x451);
      auto _mls_x453 = _mls_mul_case01(_mls_x452, _mls_x420);
      _mls_retval = _mls_x453;
    }
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x419)) {
    auto _mls_x432 = _mlsValue::cast<_mls_Mul>(_mls_x419)->_mls_e1;
    auto _mls_x433 = _mlsValue::cast<_mls_Mul>(_mls_x419)->_mls_e2;
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x432)) {
      auto _mls_x441 = _mlsValue::cast<_mls_Val>(_mls_x432)->_mls_n;
      auto _mls_x442 = _mlsValue::create<_mls_Val>(_mls_x441);
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x420)) {
        auto _mls_x449 = _mls_mul_case01(_mls_x420, _mls_x433);
        auto _mls_x450 = _mls_mul(_mls_x442, _mls_x449);
        _mls_retval = _mls_x450;
      } else {
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x433)) {
          auto _mls_x447 = _mls_mul_default_case0(_mls_x433, _mls_x420);
          auto _mls_x448 = _mls_mul(_mls_x442, _mls_x447);
          _mls_retval = _mls_x448;
        } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x433)) {
          auto _mls_x445 = _mls_mul_default_case1(_mls_x433, _mls_x420);
          auto _mls_x446 = _mls_mul(_mls_x442, _mls_x445);
          _mls_retval = _mls_x446;
        } else {
          auto _mls_x443 = _mls_mul_default_default(_mls_x420, _mls_x433);
          auto _mls_x444 = _mls_mul(_mls_x442, _mls_x443);
          _mls_retval = _mls_x444;
        }
      }
    } else {
      if (_mlsValue::isValueOf<_mls_Mul>(_mls_x420)) {
        auto _mls_x435 = _mlsValue::cast<_mls_Mul>(_mls_x420)->_mls_e1;
        auto _mls_x436 = _mlsValue::cast<_mls_Mul>(_mls_x420)->_mls_e2;
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x436)) {
          auto _mls_x439 = _mls_mul_case01(_mls_x436, _mls_x419);
          auto _mls_x440 = _mls_mul(_mls_x435, _mls_x439);
          _mls_retval = _mls_x440;
        } else {
          auto _mls_x437 = _mls_mul_default_case1(_mls_x419, _mls_x436);
          auto _mls_x438 = _mls_mul(_mls_x435, _mls_x437);
          _mls_retval = _mls_x438;
        }
      } else {
        auto _mls_x434 = _mlsValue::create<_mls_Mul>(_mls_x420, _mls_x419);
        _mls_retval = _mls_x434;
      }
    }
  } else {
    if (_mlsValue::isValueOf<_mls_Mul>(_mls_x420)) {
      auto _mls_x422 = _mlsValue::cast<_mls_Mul>(_mls_x420)->_mls_e1;
      auto _mls_x423 = _mlsValue::cast<_mls_Mul>(_mls_x420)->_mls_e2;
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x423)) {
        auto _mls_x430 = _mls_mul_case01(_mls_x423, _mls_x419);
        auto _mls_x431 = _mls_mul(_mls_x422, _mls_x430);
        _mls_retval = _mls_x431;
      } else {
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x419)) {
          auto _mls_x428 = _mls_mul_default_case0(_mls_x419, _mls_x423);
          auto _mls_x429 = _mls_mul(_mls_x422, _mls_x428);
          _mls_retval = _mls_x429;
        } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x419)) {
          auto _mls_x426 = _mls_mul_default_case1(_mls_x419, _mls_x423);
          auto _mls_x427 = _mls_mul(_mls_x422, _mls_x426);
          _mls_retval = _mls_x427;
        } else {
          auto _mls_x424 = _mls_mul_default_default(_mls_x423, _mls_x419);
          auto _mls_x425 = _mls_mul(_mls_x422, _mls_x424);
          _mls_retval = _mls_x425;
        }
      }
    } else {
      auto _mls_x421 = _mlsValue::create<_mls_Mul>(_mls_x420, _mls_x419);
      _mls_retval = _mls_x421;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_add_default_case11(_mlsValue _mls_x320, _mlsValue _mls_x322) {
  _mlsValue _mls_retval;
  auto _mls_x319 = _mlsValue::cast<_mls_Add>(_mls_x320)->_mls_e1;
  auto _mls_x321 = _mlsValue::cast<_mls_Add>(_mls_x320)->_mls_e2;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x319)) {
    auto _mls_x330 = _mlsValue::cast<_mls_Val>(_mls_x319)->_mls_n;
    auto _mls_x331 = _mlsValue::create<_mls_Val>(_mls_x330);
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x322)) {
      auto _mls_x338 = _mls_add_case01(_mls_x322, _mls_x321);
      auto _mls_x339 = _mls_add(_mls_x331, _mls_x338);
      _mls_retval = _mls_x339;
    } else {
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x321)) {
        auto _mls_x336 = _mls_add_default_case0(_mls_x321, _mls_x322);
        auto _mls_x337 = _mls_add(_mls_x331, _mls_x336);
        _mls_retval = _mls_x337;
      } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x321)) {
        auto _mls_x334 = _mls_add_default_case1(_mls_x321, _mls_x322);
        auto _mls_x335 = _mls_add(_mls_x331, _mls_x334);
        _mls_retval = _mls_x335;
      } else {
        auto _mls_x332 = _mls_add_default_default(_mls_x322, _mls_x321);
        auto _mls_x333 = _mls_add(_mls_x331, _mls_x332);
        _mls_retval = _mls_x333;
      }
    }
  } else {
    if (_mlsValue::isValueOf<_mls_Add>(_mls_x322)) {
      auto _mls_x324 = _mlsValue::cast<_mls_Add>(_mls_x322)->_mls_e1;
      auto _mls_x325 = _mlsValue::cast<_mls_Add>(_mls_x322)->_mls_e2;
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x325)) {
        auto _mls_x328 = _mls_add_case01(_mls_x325, _mls_x320);
        auto _mls_x329 = _mls_add(_mls_x324, _mls_x328);
        _mls_retval = _mls_x329;
      } else {
        auto _mls_x326 = _mls_add_default_case1(_mls_x320, _mls_x325);
        auto _mls_x327 = _mls_add(_mls_x324, _mls_x326);
        _mls_retval = _mls_x327;
      }
    } else {
      auto _mls_x323 = _mlsValue::create<_mls_Add>(_mls_x322, _mls_x320);
      _mls_retval = _mls_x323;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_pow_case0(_mlsValue _mls_x343, _mlsValue _mls_x344) {
  _mlsValue _mls_retval;
  auto _mls_x342 = _mlsValue::cast<_mls_Val>(_mls_x343)->_mls_n;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x344)) {
    auto _mls_x347 = _mlsValue::cast<_mls_Val>(_mls_x344)->_mls_n;
    auto _mls_x348 = _mls_pown(_mls_x342, _mls_x347);
    auto _mls_x349 = _mlsValue::create<_mls_Val>(_mls_x348);
    _mls_retval = _mls_x349;
  } else {
    if (_mlsValue::isIntLit(_mls_x342, 0)) {
      auto _mls_x346 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
      _mls_retval = _mls_x346;
    } else {
      auto _mls_x345 = _mlsValue::create<_mls_Pow>(_mls_x343, _mls_x344);
      _mls_retval = _mls_x345;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_main_caller_post(_mlsValue _mls_x179, _mlsValue _mls_x180) {
  _mlsValue _mls_retval;
  auto _mls_x178 = _mlsValue::create<_mls_Lambda_deriv>();
  auto _mls_x181 = _mls_nestAux(_mls_x179, _mls_x178, _mls_x179, _mls_x180);
  auto _mls_x182 = _mls_count(_mls_x181);
  _mls_retval = _mls_x182;
  return _mls_retval;
}
_mlsValue _mls_add(_mlsValue _mls_x312, _mlsValue _mls_x313) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x312)) {
    _mls_retval = _mls_add_case0(_mls_x312, _mls_x313);
  } else {
    _mls_retval = _mls_add_default(_mls_x313, _mls_x312);
  }
  return _mls_retval;
}
_mlsValue _mls_d_case0() {
  _mlsValue _mls_retval;
  auto _mls_x254 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
  _mls_retval = _mls_x254;
  return _mls_retval;
}
_mlsValue _mls_mul(_mlsValue _mls_x255, _mlsValue _mls_x256) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x255)) {
    _mls_retval = _mls_mul_case01(_mls_x255, _mls_x256);
  } else {
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x256)) {
      _mls_retval = _mls_mul_default_case0(_mls_x256, _mls_x255);
    } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x256)) {
      _mls_retval = _mls_mul_default_case1(_mls_x256, _mls_x255);
    } else {
      _mls_retval = _mls_mul_default_default(_mls_x255, _mls_x256);
    }
  }
  return _mls_retval;
}
_mlsValue _mls_d_case5(_mlsValue _mls_x417, _mlsValue _mls_x418) {
  _mlsValue _mls_retval;
  auto _mls_x416 = _mlsValue::cast<_mls_Ln>(_mls_x417)->_mls_e;
  _mls_retval = _mls_d_case5_sr_post(_mls_x418, _mls_x416);
  return _mls_retval;
}
_mlsValue _mls_nestAux(_mlsValue _mls_s, _mlsValue _mls_f, _mlsValue _mls_n1, _mlsValue _mls_e3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_n1, 0)) {
    _mls_retval = _mls_e3;
  } else {
    auto _mls_x35 = (_mls_s - _mls_n1);
    auto _mls_x36 = _mlsMethodCall<_mls_Callable>(_mls_f)->_mls_apply2(_mls_x35, _mls_e3);
    auto _mls_x37 = (_mls_n1 - _mlsValue::fromIntLit(1));
    auto _mls_x38 = _mls_nestAux(_mls_s, _mls_f, _mls_x37, _mls_x36);
    _mls_retval = _mls_x38;
  }
  return _mls_retval;
}
_mlsValue _mls_d_case4_caller_post_caller_post(_mlsValue _mls_x213, _mlsValue _mls_x218, _mlsValue _mls_x209, _mlsValue _mls_x214, _mlsValue _mls_x211, _mlsValue _mls_x208) {
  _mlsValue _mls_retval;
  auto _mls_x210 = _mls_mul(_mls_x208, _mls_x209);
  auto _mls_x212 = _mls_ln(_mls_x211);
  auto _mls_x215 = _mls_d(_mls_x213, _mls_x214);
  auto _mls_x216 = _mls_mul(_mls_x212, _mls_x215);
  auto _mls_x217 = _mls_add(_mls_x210, _mls_x216);
  auto _mls_x219 = _mls_mul(_mls_x218, _mls_x217);
  _mls_retval = _mls_x219;
  return _mls_retval;
}
_mlsValue _mls_ln(_mlsValue _mls_e6) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_e6)) {
    auto _mls_x108 = _mlsValue::cast<_mls_Val>(_mls_e6)->_mls_n;
    if (_mlsValue::isIntLit(_mls_x108, 1)) {
      auto _mls_x110 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
      _mls_retval = _mls_x110;
    } else {
      auto _mls_x109 = _mlsValue::create<_mls_Ln>(_mls_e6);
      _mls_retval = _mls_x109;
    }
  } else {
    auto _mls_x107 = _mlsValue::create<_mls_Ln>(_mls_e6);
    _mls_retval = _mls_x107;
  }
  return _mls_retval;
}
_mlsValue _mls_add_case01(_mlsValue _mls_x275, _mlsValue _mls_x276) {
  _mlsValue _mls_retval;
  auto _mls_x274 = _mlsValue::cast<_mls_Val>(_mls_x275)->_mls_n;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x276)) {
    auto _mls_x285 = _mlsValue::cast<_mls_Val>(_mls_x276)->_mls_n;
    auto _mls_x286 = (_mls_x274 + _mls_x285);
    auto _mls_x287 = _mlsValue::create<_mls_Val>(_mls_x286);
    _mls_retval = _mls_x287;
  } else {
    if (_mlsValue::isIntLit(_mls_x274, 0)) {
      _mls_retval = _mls_x276;
    } else {
      if (_mlsValue::isValueOf<_mls_Add>(_mls_x276)) {
        auto _mls_x278 = _mlsValue::cast<_mls_Add>(_mls_x276)->_mls_e1;
        auto _mls_x279 = _mlsValue::cast<_mls_Add>(_mls_x276)->_mls_e2;
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x278)) {
          auto _mls_x281 = _mlsValue::cast<_mls_Val>(_mls_x278)->_mls_n;
          auto _mls_x282 = (_mls_x274 + _mls_x281);
          auto _mls_x283 = _mlsValue::create<_mls_Val>(_mls_x282);
          auto _mls_x284 = _mls_add_case0(_mls_x283, _mls_x279);
          _mls_retval = _mls_x284;
        } else {
          auto _mls_x280 = _mlsValue::create<_mls_Add>(_mls_x275, _mls_x276);
          _mls_retval = _mls_x280;
        }
      } else {
        auto _mls_x277 = _mlsValue::create<_mls_Add>(_mls_x275, _mls_x276);
        _mls_retval = _mls_x277;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_d(_mlsValue _mls_x366, _mlsValue _mls_x364) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x364)) {
    _mls_retval = _mls_d_case0();
  } else if (_mlsValue::isValueOf<_mls_Var>(_mls_x364)) {
    auto _mls_x373 = _mlsValue::cast<_mls_Var>(_mls_x364)->_mls_x;
    _mls_retval = _mls_d_case1_sr_post(_mls_x366, _mls_x373);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x364)) {
    auto _mls_x371 = _mlsValue::cast<_mls_Add>(_mls_x364)->_mls_e1;
    auto _mls_x372 = _mlsValue::cast<_mls_Add>(_mls_x364)->_mls_e2;
    _mls_retval = _mls_d_case2_sr_post(_mls_x366, _mls_x371, _mls_x372);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x364)) {
    auto _mls_x369 = _mlsValue::cast<_mls_Mul>(_mls_x364)->_mls_e1;
    auto _mls_x370 = _mlsValue::cast<_mls_Mul>(_mls_x364)->_mls_e2;
    _mls_retval = _mls_d_case3_sr_post(_mls_x366, _mls_x370, _mls_x369);
  } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_x364)) {
    auto _mls_x367 = _mlsValue::cast<_mls_Pow>(_mls_x364)->_mls_e1;
    auto _mls_x368 = _mlsValue::cast<_mls_Pow>(_mls_x364)->_mls_e2;
    _mls_retval = _mls_d_case4_sr_post(_mls_x367, _mls_x368, _mls_x366);
  } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_x364)) {
    auto _mls_x365 = _mlsValue::cast<_mls_Ln>(_mls_x364)->_mls_e;
    _mls_retval = _mls_d_case5_sr_post(_mls_x366, _mls_x365);
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x57 = _mls_main(_mlsValue::fromIntLit(10));
  _mls_retval = _mls_x57;
  return _mls_retval;
}
_mlsValue _mls_main(_mlsValue _mls_n2) {
  _mlsValue _mls_retval;
  auto _mls_x111 = _mlsValue::create<_mls_Var>(_mlsValue::create<_mls_Str>("x"));
  auto _mls_x469 = _mls_pow_default_default(_mls_x111, _mls_x111);
  _mls_retval = _mls_main_caller_post(_mls_n2, _mls_x469);
  return _mls_retval;
}
_mlsValue _mls_mul_case01(_mlsValue _mls_x395, _mlsValue _mls_x396) {
  _mlsValue _mls_retval;
  auto _mls_x394 = _mlsValue::cast<_mls_Val>(_mls_x395)->_mls_n;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x396)) {
    auto _mls_x406 = _mlsValue::cast<_mls_Val>(_mls_x396)->_mls_n;
    auto _mls_x407 = (_mls_x394 * _mls_x406);
    auto _mls_x408 = _mlsValue::create<_mls_Val>(_mls_x407);
    _mls_retval = _mls_x408;
  } else {
    if (_mlsValue::isIntLit(_mls_x394, 0)) {
      auto _mls_x405 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
      _mls_retval = _mls_x405;
    } else if (_mlsValue::isIntLit(_mls_x394, 1)) {
      _mls_retval = _mls_x396;
    } else {
      if (_mlsValue::isValueOf<_mls_Mul>(_mls_x396)) {
        auto _mls_x398 = _mlsValue::cast<_mls_Mul>(_mls_x396)->_mls_e1;
        auto _mls_x399 = _mlsValue::cast<_mls_Mul>(_mls_x396)->_mls_e2;
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x398)) {
          auto _mls_x401 = _mlsValue::cast<_mls_Val>(_mls_x398)->_mls_n;
          auto _mls_x402 = (_mls_x394 * _mls_x401);
          auto _mls_x403 = _mlsValue::create<_mls_Val>(_mls_x402);
          auto _mls_x404 = _mls_mul_case0(_mls_x403, _mls_x399);
          _mls_retval = _mls_x404;
        } else {
          auto _mls_x400 = _mlsValue::create<_mls_Mul>(_mls_x395, _mls_x396);
          _mls_retval = _mls_x400;
        }
      } else {
        auto _mls_x397 = _mlsValue::create<_mls_Mul>(_mls_x395, _mls_x396);
        _mls_retval = _mls_x397;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_j(_mlsValue _mls_tmp, _mlsValue _mls_tmp1) {
  _mlsValue _mls_retval;
  auto _mls_x58 = (_mls_tmp * _mls_tmp1);
  _mls_retval = _mls_x58;
  return _mls_retval;
}
_mlsValue _mls_mul_case0(_mlsValue _mls_x375, _mlsValue _mls_x376) {
  _mlsValue _mls_retval;
  auto _mls_x374 = _mlsValue::cast<_mls_Val>(_mls_x375)->_mls_n;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x376)) {
    auto _mls_x386 = _mlsValue::cast<_mls_Val>(_mls_x376)->_mls_n;
    auto _mls_x387 = (_mls_x374 * _mls_x386);
    auto _mls_x388 = _mlsValue::create<_mls_Val>(_mls_x387);
    _mls_retval = _mls_x388;
  } else {
    if (_mlsValue::isIntLit(_mls_x374, 0)) {
      auto _mls_x385 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
      _mls_retval = _mls_x385;
    } else if (_mlsValue::isIntLit(_mls_x374, 1)) {
      _mls_retval = _mls_x376;
    } else {
      if (_mlsValue::isValueOf<_mls_Mul>(_mls_x376)) {
        auto _mls_x378 = _mlsValue::cast<_mls_Mul>(_mls_x376)->_mls_e1;
        auto _mls_x379 = _mlsValue::cast<_mls_Mul>(_mls_x376)->_mls_e2;
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x378)) {
          auto _mls_x381 = _mlsValue::cast<_mls_Val>(_mls_x378)->_mls_n;
          auto _mls_x382 = (_mls_x374 * _mls_x381);
          auto _mls_x383 = _mlsValue::create<_mls_Val>(_mls_x382);
          auto _mls_x384 = _mls_mul_case01(_mls_x383, _mls_x379);
          _mls_retval = _mls_x384;
        } else {
          auto _mls_x380 = _mlsValue::create<_mls_Mul>(_mls_x375, _mls_x376);
          _mls_retval = _mls_x380;
        }
      } else {
        auto _mls_x377 = _mlsValue::create<_mls_Mul>(_mls_x375, _mls_x376);
        _mls_retval = _mls_x377;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_d_case1_sr_post(_mlsValue _mls_x221, _mlsValue _mls_x222) {
  _mlsValue _mls_retval;
  auto _mls_x220 = (_mls_x221 == _mls_x222);
  if (_mlsValue::isIntLit(_mls_x220, 1)) {
    auto _mls_x224 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(1));
    _mls_retval = _mls_x224;
  } else {
    auto _mls_x223 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
    _mls_retval = _mls_x223;
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default_default(_mlsValue _mls_x225, _mlsValue _mls_x227) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Mul>(_mls_x225)) {
    auto _mls_x228 = _mlsValue::cast<_mls_Mul>(_mls_x225)->_mls_e1;
    auto _mls_x229 = _mlsValue::cast<_mls_Mul>(_mls_x225)->_mls_e2;
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x229)) {
      auto _mls_x232 = _mls_mul_case0(_mls_x229, _mls_x227);
      auto _mls_x233 = _mls_mul(_mls_x228, _mls_x232);
      _mls_retval = _mls_x233;
    } else {
      auto _mls_x230 = _mls_mul_default(_mls_x227, _mls_x229);
      auto _mls_x231 = _mls_mul(_mls_x228, _mls_x230);
      _mls_retval = _mls_x231;
    }
  } else {
    auto _mls_x226 = _mlsValue::create<_mls_Mul>(_mls_x225, _mls_x227);
    _mls_retval = _mls_x226;
  }
  return _mls_retval;
}
_mlsValue _mls_deriv(_mlsValue _mls_i, _mlsValue _mls_f1) {
  _mlsValue _mls_retval;
  auto _mls_x56 = _mls_d(_mlsValue::create<_mls_Str>("x"), _mls_f1);
  _mls_retval = _mls_x56;
  return _mls_retval;
}
_mlsValue _mls_add_default_case1(_mlsValue _mls_x258, _mlsValue _mls_x260) {
  _mlsValue _mls_retval;
  auto _mls_x257 = _mlsValue::cast<_mls_Add>(_mls_x258)->_mls_e1;
  auto _mls_x259 = _mlsValue::cast<_mls_Add>(_mls_x258)->_mls_e2;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x257)) {
    auto _mls_x268 = _mlsValue::cast<_mls_Val>(_mls_x257)->_mls_n;
    auto _mls_x269 = _mlsValue::create<_mls_Val>(_mls_x268);
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x260)) {
      auto _mls_x272 = _mls_add_case0(_mls_x260, _mls_x259);
      auto _mls_x273 = _mls_add(_mls_x269, _mls_x272);
      _mls_retval = _mls_x273;
    } else {
      auto _mls_x270 = _mls_add_default(_mls_x259, _mls_x260);
      auto _mls_x271 = _mls_add(_mls_x269, _mls_x270);
      _mls_retval = _mls_x271;
    }
  } else {
    if (_mlsValue::isValueOf<_mls_Add>(_mls_x260)) {
      auto _mls_x262 = _mlsValue::cast<_mls_Add>(_mls_x260)->_mls_e1;
      auto _mls_x263 = _mlsValue::cast<_mls_Add>(_mls_x260)->_mls_e2;
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x263)) {
        auto _mls_x266 = _mls_add_case0(_mls_x263, _mls_x258);
        auto _mls_x267 = _mls_add(_mls_x262, _mls_x266);
        _mls_retval = _mls_x267;
      } else {
        auto _mls_x264 = _mls_add_default(_mls_x258, _mls_x263);
        auto _mls_x265 = _mls_add(_mls_x262, _mls_x264);
        _mls_retval = _mls_x265;
      }
    } else {
      auto _mls_x261 = _mlsValue::create<_mls_Add>(_mls_x260, _mls_x258);
      _mls_retval = _mls_x261;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_d_case5_sr_post(_mlsValue _mls_x460, _mlsValue _mls_x461) {
  _mlsValue _mls_retval;
  auto _mls_x462 = _mls_d(_mls_x460, _mls_x461);
  auto _mls_x463 = (-_mlsValue::fromIntLit(1));
  auto _mls_x464 = _mlsValue::create<_mls_Val>(_mls_x463);
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x461)) {
    auto _mls_x467 = _mls_pow_case0(_mls_x461, _mls_x464);
    auto _mls_x468 = _mls_mul(_mls_x462, _mls_x467);
    _mls_retval = _mls_x468;
  } else {
    auto _mls_x465 = _mls_pow_default(_mls_x464, _mls_x461);
    auto _mls_x466 = _mls_mul(_mls_x462, _mls_x465);
    _mls_retval = _mls_x466;
  }
  return _mls_retval;
}
_mlsValue _mls_pow_default(_mlsValue _mls_x162, _mlsValue _mls_x163) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x162)) {
    _mls_retval = _mls_pow_default_case0(_mls_x162, _mls_x163);
  } else {
    _mls_retval = _mls_pow_default_default(_mls_x163, _mls_x162);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_deriv::_mls_apply2(_mlsValue _mls_arg, _mlsValue _mls_arg1) {
  _mlsValue _mls_retval;
  auto _mls_x1 = _mls_deriv(_mls_arg, _mls_arg1);
  _mls_retval = _mls_x1;
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
