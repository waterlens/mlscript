#include "mlsprelude.h"
struct _mls_Tree;
struct _mls_LamF;
struct _mls_Color;
struct _mls_Leaf;
struct _mls_Node;
struct _mls_Black;
struct _mls_Red;
_mlsValue _mls_apply_f(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_balance1(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_balance2(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_fold(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_fold_case1_sr_post_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_ins(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_ins_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_ins_caller_post1(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_ins_caller_post_case0(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_ins_caller_post_case01(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_ins_caller_post_default1(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_ins_caller_post_default(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_ins_case0(_mlsValue, _mlsValue);
_mlsValue _mls_ins_case1(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_insert_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_insert_caller_post_case0(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_isRed_case0_pre(_mlsValue);
_mlsValue _mls_isRed_case0_sr_post(_mlsValue);
_mlsValue _mls_main();
_mlsValue _mls_mkMap(_mlsValue);
_mlsValue _mls_mkMapAux(_mlsValue, _mlsValue);
_mlsValue _mls_mkMapAux_default(_mlsValue, _mlsValue);
_mlsValue _mls_mkMapAux_default_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_mkMapAux_pre(_mlsValue, _mlsValue);
_mlsValue _mls_setBlack(_mlsValue);
struct _mls_Tree: public _mlsObject {
  
  constexpr static inline const char *typeName = "Tree";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Tree; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_LamF: public _mlsObject {
  
  constexpr static inline const char *typeName = "LamF";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_LamF; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Color: public _mlsObject {
  
  constexpr static inline const char *typeName = "Color";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Color; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Leaf: public _mls_Tree {
  
  constexpr static inline const char *typeName = "Leaf";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Leaf; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Node: public _mls_Tree {
  _mlsValue _mls_color;
  _mlsValue _mls_left;
  _mlsValue _mls_key;
  _mlsValue _mls_value;
  _mlsValue _mls_right;
  constexpr static inline const char *typeName = "Node";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_color.print(); std::printf(", "); this->_mls_left.print(); std::printf(", "); this->_mls_key.print(); std::printf(", "); this->_mls_value.print(); std::printf(", "); this->_mls_right.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_color); _mlsValue::destroy(this->_mls_left); _mlsValue::destroy(this->_mls_key); _mlsValue::destroy(this->_mls_value); _mlsValue::destroy(this->_mls_right);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_color.asObject()->operator==(*other.cast<_mls_Node>()->_mls_color.asObject()) && this->_mls_left.asObject()->operator==(*other.cast<_mls_Node>()->_mls_left.asObject()) && this->_mls_key.asObject()->operator==(*other.cast<_mls_Node>()->_mls_key.asObject()) && this->_mls_value.asObject()->operator==(*other.cast<_mls_Node>()->_mls_value.asObject()) && this->_mls_right.asObject()->operator==(*other.cast<_mls_Node>()->_mls_right.asObject()); }
  static _mlsValue create(_mlsValue _mls_color, _mlsValue _mls_left, _mlsValue _mls_key, _mlsValue _mls_value, _mlsValue _mls_right) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Node; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_color = _mls_color; _mlsVal->_mls_left = _mls_left; _mlsVal->_mls_key = _mls_key; _mlsVal->_mls_value = _mls_value; _mlsVal->_mls_right = _mls_right;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Black: public _mls_Color {
  
  constexpr static inline const char *typeName = "Black";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Black; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Red: public _mls_Color {
  
  constexpr static inline const char *typeName = "Red";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Red; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_apply_f(_mlsValue _mls_f, _mlsValue _mls_a, _mlsValue _mls_b, _mlsValue _mls_c) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_LamF>(_mls_f)) {
    if (_mlsValue::isIntLit(_mls_b, 1)) {
      auto _mls_x = (_mls_c + _mlsValue::fromIntLit(1));
      _mls_retval = _mls_x;
    } else {
      _mls_retval = _mls_c;
    }
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_balance1(_mlsValue _mls_k, _mlsValue _mls_v, _mlsValue _mls_t1, _mlsValue _mls_t2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Node>(_mls_t2)) {
    auto _mls_x2 = _mlsValue::cast<_mls_Node>(_mls_t2)->_mls_left;
    auto _mls_x3 = _mlsValue::cast<_mls_Node>(_mls_t2)->_mls_key;
    auto _mls_x4 = _mlsValue::cast<_mls_Node>(_mls_t2)->_mls_value;
    auto _mls_x5 = _mlsValue::cast<_mls_Node>(_mls_t2)->_mls_right;
    if (_mlsValue::isValueOf<_mls_Node>(_mls_x2)) {
      auto _mls_x25 = _mlsValue::cast<_mls_Node>(_mls_x2)->_mls_color;
      auto _mls_x26 = _mlsValue::cast<_mls_Node>(_mls_x2)->_mls_left;
      auto _mls_x27 = _mlsValue::cast<_mls_Node>(_mls_x2)->_mls_key;
      auto _mls_x28 = _mlsValue::cast<_mls_Node>(_mls_x2)->_mls_value;
      auto _mls_x29 = _mlsValue::cast<_mls_Node>(_mls_x2)->_mls_right;
      if (_mlsValue::isValueOf<_mls_Red>(_mls_x25)) {
        auto _mls_x49 = _mlsValue::create<_mls_Black>();
        auto _mls_x50 = _mlsValue::create<_mls_Node>(_mls_x49, _mls_x26, _mls_x27, _mls_x28, _mls_x29);
        auto _mls_x51 = _mlsValue::create<_mls_Black>();
        auto _mls_x52 = _mlsValue::create<_mls_Node>(_mls_x51, _mls_x5, _mls_k, _mls_v, _mls_t1);
        auto _mls_x53 = _mlsValue::create<_mls_Red>();
        auto _mls_x54 = _mlsValue::create<_mls_Node>(_mls_x53, _mls_x50, _mls_x3, _mls_x4, _mls_x52);
        _mls_retval = _mls_x54;
      } else {
        if (_mlsValue::isValueOf<_mls_Node>(_mls_x5)) {
          auto _mls_x34 = _mlsValue::cast<_mls_Node>(_mls_x5)->_mls_color;
          auto _mls_x35 = _mlsValue::cast<_mls_Node>(_mls_x5)->_mls_left;
          auto _mls_x36 = _mlsValue::cast<_mls_Node>(_mls_x5)->_mls_key;
          auto _mls_x37 = _mlsValue::cast<_mls_Node>(_mls_x5)->_mls_value;
          auto _mls_x38 = _mlsValue::cast<_mls_Node>(_mls_x5)->_mls_right;
          if (_mlsValue::isValueOf<_mls_Red>(_mls_x34)) {
            auto _mls_x43 = _mlsValue::create<_mls_Black>();
            auto _mls_x44 = _mlsValue::create<_mls_Node>(_mls_x43, _mls_x2, _mls_x3, _mls_x4, _mls_x35);
            auto _mls_x45 = _mlsValue::create<_mls_Black>();
            auto _mls_x46 = _mlsValue::create<_mls_Node>(_mls_x45, _mls_x38, _mls_k, _mls_v, _mls_t1);
            auto _mls_x47 = _mlsValue::create<_mls_Red>();
            auto _mls_x48 = _mlsValue::create<_mls_Node>(_mls_x47, _mls_x44, _mls_x36, _mls_x37, _mls_x46);
            _mls_retval = _mls_x48;
          } else {
            auto _mls_x39 = _mlsValue::create<_mls_Red>();
            auto _mls_x40 = _mlsValue::create<_mls_Node>(_mls_x39, _mls_x2, _mls_x3, _mls_x4, _mls_x5);
            auto _mls_x41 = _mlsValue::create<_mls_Black>();
            auto _mls_x42 = _mlsValue::create<_mls_Node>(_mls_x41, _mls_x40, _mls_k, _mls_v, _mls_t1);
            _mls_retval = _mls_x42;
          }
        } else {
          auto _mls_x30 = _mlsValue::create<_mls_Red>();
          auto _mls_x31 = _mlsValue::create<_mls_Node>(_mls_x30, _mls_x2, _mls_x3, _mls_x4, _mls_x5);
          auto _mls_x32 = _mlsValue::create<_mls_Black>();
          auto _mls_x33 = _mlsValue::create<_mls_Node>(_mls_x32, _mls_x31, _mls_k, _mls_v, _mls_t1);
          _mls_retval = _mls_x33;
        }
      }
    } else {
      if (_mlsValue::isValueOf<_mls_Node>(_mls_x5)) {
        auto _mls_x10 = _mlsValue::cast<_mls_Node>(_mls_x5)->_mls_color;
        auto _mls_x11 = _mlsValue::cast<_mls_Node>(_mls_x5)->_mls_left;
        auto _mls_x12 = _mlsValue::cast<_mls_Node>(_mls_x5)->_mls_key;
        auto _mls_x13 = _mlsValue::cast<_mls_Node>(_mls_x5)->_mls_value;
        auto _mls_x14 = _mlsValue::cast<_mls_Node>(_mls_x5)->_mls_right;
        if (_mlsValue::isValueOf<_mls_Red>(_mls_x10)) {
          auto _mls_x19 = _mlsValue::create<_mls_Black>();
          auto _mls_x20 = _mlsValue::create<_mls_Node>(_mls_x19, _mls_x2, _mls_x3, _mls_x4, _mls_x11);
          auto _mls_x21 = _mlsValue::create<_mls_Black>();
          auto _mls_x22 = _mlsValue::create<_mls_Node>(_mls_x21, _mls_x14, _mls_k, _mls_v, _mls_t1);
          auto _mls_x23 = _mlsValue::create<_mls_Red>();
          auto _mls_x24 = _mlsValue::create<_mls_Node>(_mls_x23, _mls_x20, _mls_x12, _mls_x13, _mls_x22);
          _mls_retval = _mls_x24;
        } else {
          auto _mls_x15 = _mlsValue::create<_mls_Red>();
          auto _mls_x16 = _mlsValue::create<_mls_Node>(_mls_x15, _mls_x2, _mls_x3, _mls_x4, _mls_x5);
          auto _mls_x17 = _mlsValue::create<_mls_Black>();
          auto _mls_x18 = _mlsValue::create<_mls_Node>(_mls_x17, _mls_x16, _mls_k, _mls_v, _mls_t1);
          _mls_retval = _mls_x18;
        }
      } else {
        auto _mls_x6 = _mlsValue::create<_mls_Red>();
        auto _mls_x7 = _mlsValue::create<_mls_Node>(_mls_x6, _mls_x2, _mls_x3, _mls_x4, _mls_x5);
        auto _mls_x8 = _mlsValue::create<_mls_Black>();
        auto _mls_x9 = _mlsValue::create<_mls_Node>(_mls_x8, _mls_x7, _mls_k, _mls_v, _mls_t1);
        _mls_retval = _mls_x9;
      }
    }
  } else {
    auto _mls_x1 = _mlsValue::create<_mls_Leaf>();
    _mls_retval = _mls_x1;
  }
  return _mls_retval;
}
_mlsValue _mls_balance2(_mlsValue _mls_t11, _mlsValue _mls_k1, _mlsValue _mls_v1, _mlsValue _mls_t21) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Node>(_mls_t21)) {
    auto _mls_x56 = _mlsValue::cast<_mls_Node>(_mls_t21)->_mls_left;
    auto _mls_x57 = _mlsValue::cast<_mls_Node>(_mls_t21)->_mls_key;
    auto _mls_x58 = _mlsValue::cast<_mls_Node>(_mls_t21)->_mls_value;
    auto _mls_x59 = _mlsValue::cast<_mls_Node>(_mls_t21)->_mls_right;
    if (_mlsValue::isValueOf<_mls_Node>(_mls_x56)) {
      auto _mls_x79 = _mlsValue::cast<_mls_Node>(_mls_x56)->_mls_color;
      auto _mls_x80 = _mlsValue::cast<_mls_Node>(_mls_x56)->_mls_left;
      auto _mls_x81 = _mlsValue::cast<_mls_Node>(_mls_x56)->_mls_key;
      auto _mls_x82 = _mlsValue::cast<_mls_Node>(_mls_x56)->_mls_value;
      auto _mls_x83 = _mlsValue::cast<_mls_Node>(_mls_x56)->_mls_right;
      if (_mlsValue::isValueOf<_mls_Red>(_mls_x79)) {
        auto _mls_x103 = _mlsValue::create<_mls_Black>();
        auto _mls_x104 = _mlsValue::create<_mls_Node>(_mls_x103, _mls_t11, _mls_k1, _mls_v1, _mls_x80);
        auto _mls_x105 = _mlsValue::create<_mls_Black>();
        auto _mls_x106 = _mlsValue::create<_mls_Node>(_mls_x105, _mls_x83, _mls_x57, _mls_x58, _mls_x59);
        auto _mls_x107 = _mlsValue::create<_mls_Red>();
        auto _mls_x108 = _mlsValue::create<_mls_Node>(_mls_x107, _mls_x104, _mls_x81, _mls_x82, _mls_x106);
        _mls_retval = _mls_x108;
      } else {
        if (_mlsValue::isValueOf<_mls_Node>(_mls_x59)) {
          auto _mls_x88 = _mlsValue::cast<_mls_Node>(_mls_x59)->_mls_color;
          auto _mls_x89 = _mlsValue::cast<_mls_Node>(_mls_x59)->_mls_left;
          auto _mls_x90 = _mlsValue::cast<_mls_Node>(_mls_x59)->_mls_key;
          auto _mls_x91 = _mlsValue::cast<_mls_Node>(_mls_x59)->_mls_value;
          auto _mls_x92 = _mlsValue::cast<_mls_Node>(_mls_x59)->_mls_right;
          if (_mlsValue::isValueOf<_mls_Red>(_mls_x88)) {
            auto _mls_x97 = _mlsValue::create<_mls_Black>();
            auto _mls_x98 = _mlsValue::create<_mls_Node>(_mls_x97, _mls_t11, _mls_k1, _mls_v1, _mls_x56);
            auto _mls_x99 = _mlsValue::create<_mls_Black>();
            auto _mls_x100 = _mlsValue::create<_mls_Node>(_mls_x99, _mls_x89, _mls_x90, _mls_x91, _mls_x92);
            auto _mls_x101 = _mlsValue::create<_mls_Red>();
            auto _mls_x102 = _mlsValue::create<_mls_Node>(_mls_x101, _mls_x98, _mls_x57, _mls_x58, _mls_x100);
            _mls_retval = _mls_x102;
          } else {
            auto _mls_x93 = _mlsValue::create<_mls_Red>();
            auto _mls_x94 = _mlsValue::create<_mls_Node>(_mls_x93, _mls_x56, _mls_x57, _mls_x58, _mls_x59);
            auto _mls_x95 = _mlsValue::create<_mls_Black>();
            auto _mls_x96 = _mlsValue::create<_mls_Node>(_mls_x95, _mls_t11, _mls_k1, _mls_v1, _mls_x94);
            _mls_retval = _mls_x96;
          }
        } else {
          auto _mls_x84 = _mlsValue::create<_mls_Red>();
          auto _mls_x85 = _mlsValue::create<_mls_Node>(_mls_x84, _mls_x56, _mls_x57, _mls_x58, _mls_x59);
          auto _mls_x86 = _mlsValue::create<_mls_Black>();
          auto _mls_x87 = _mlsValue::create<_mls_Node>(_mls_x86, _mls_t11, _mls_k1, _mls_v1, _mls_x85);
          _mls_retval = _mls_x87;
        }
      }
    } else {
      if (_mlsValue::isValueOf<_mls_Node>(_mls_x59)) {
        auto _mls_x64 = _mlsValue::cast<_mls_Node>(_mls_x59)->_mls_color;
        auto _mls_x65 = _mlsValue::cast<_mls_Node>(_mls_x59)->_mls_left;
        auto _mls_x66 = _mlsValue::cast<_mls_Node>(_mls_x59)->_mls_key;
        auto _mls_x67 = _mlsValue::cast<_mls_Node>(_mls_x59)->_mls_value;
        auto _mls_x68 = _mlsValue::cast<_mls_Node>(_mls_x59)->_mls_right;
        if (_mlsValue::isValueOf<_mls_Red>(_mls_x64)) {
          auto _mls_x73 = _mlsValue::create<_mls_Black>();
          auto _mls_x74 = _mlsValue::create<_mls_Node>(_mls_x73, _mls_t11, _mls_k1, _mls_v1, _mls_x56);
          auto _mls_x75 = _mlsValue::create<_mls_Black>();
          auto _mls_x76 = _mlsValue::create<_mls_Node>(_mls_x75, _mls_x65, _mls_x66, _mls_x67, _mls_x68);
          auto _mls_x77 = _mlsValue::create<_mls_Red>();
          auto _mls_x78 = _mlsValue::create<_mls_Node>(_mls_x77, _mls_x74, _mls_x57, _mls_x58, _mls_x76);
          _mls_retval = _mls_x78;
        } else {
          auto _mls_x69 = _mlsValue::create<_mls_Red>();
          auto _mls_x70 = _mlsValue::create<_mls_Node>(_mls_x69, _mls_x56, _mls_x57, _mls_x58, _mls_x59);
          auto _mls_x71 = _mlsValue::create<_mls_Black>();
          auto _mls_x72 = _mlsValue::create<_mls_Node>(_mls_x71, _mls_t11, _mls_k1, _mls_v1, _mls_x70);
          _mls_retval = _mls_x72;
        }
      } else {
        auto _mls_x60 = _mlsValue::create<_mls_Red>();
        auto _mls_x61 = _mlsValue::create<_mls_Node>(_mls_x60, _mls_x56, _mls_x57, _mls_x58, _mls_x59);
        auto _mls_x62 = _mlsValue::create<_mls_Black>();
        auto _mls_x63 = _mlsValue::create<_mls_Node>(_mls_x62, _mls_t11, _mls_k1, _mls_v1, _mls_x61);
        _mls_retval = _mls_x63;
      }
    }
  } else {
    auto _mls_x55 = _mlsValue::create<_mls_Leaf>();
    _mls_retval = _mls_x55;
  }
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x109 = _mls_main();
  _mls_retval = _mls_x109;
  return _mls_retval;
}
_mlsValue _mls_fold(_mlsValue _mls_x179, _mlsValue _mls_x174, _mlsValue _mls_x180) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Leaf>(_mls_x174)) {
    _mls_retval = _mls_x180;
  } else if (_mlsValue::isValueOf<_mls_Node>(_mls_x174)) {
    auto _mls_x175 = _mlsValue::cast<_mls_Node>(_mls_x174)->_mls_left;
    auto _mls_x176 = _mlsValue::cast<_mls_Node>(_mls_x174)->_mls_key;
    auto _mls_x177 = _mlsValue::cast<_mls_Node>(_mls_x174)->_mls_value;
    auto _mls_x178 = _mlsValue::cast<_mls_Node>(_mls_x174)->_mls_right;
    auto _mls_x181 = _mls_fold(_mls_x179, _mls_x175, _mls_x180);
    _mls_retval = _mls_fold_case1_sr_post_post(_mls_x181, _mls_x178, _mls_x177, _mls_x179, _mls_x176);
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_fold_case1_sr_post_post(_mlsValue _mls_x185, _mlsValue _mls_x187, _mlsValue _mls_x184, _mlsValue _mls_x182, _mlsValue _mls_x183) {
  _mlsValue _mls_retval;
  auto _mls_x186 = _mls_apply_f(_mls_x182, _mls_x183, _mls_x184, _mls_x185);
  auto _mls_x188 = _mls_fold(_mls_x182, _mls_x187, _mls_x186);
  _mls_retval = _mls_x188;
  return _mls_retval;
}
_mlsValue _mls_ins(_mlsValue _mls_x190, _mlsValue _mls_x191, _mlsValue _mls_x189) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Leaf>(_mls_x189)) {
    _mls_retval = _mls_ins_case0(_mls_x190, _mls_x191);
  } else if (_mlsValue::isValueOf<_mls_Node>(_mls_x189)) {
    _mls_retval = _mls_ins_case1(_mls_x189, _mls_x190, _mls_x191);
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_ins_caller_post(_mlsValue _mls_x196, _mlsValue _mls_x197, _mlsValue _mls_x198, _mlsValue _mls_x194, _mlsValue _mls_x193, _mlsValue _mls_x192, _mlsValue _mls_x195) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_x192, 1)) {
    _mls_retval = _mls_ins_caller_post_case0(_mls_x193, _mls_x194, _mls_x195, _mls_x196, _mls_x197, _mls_x198);
  } else {
    _mls_retval = _mls_ins_caller_post_default(_mls_x193, _mls_x194, _mls_x195, _mls_x196, _mls_x197, _mls_x198);
  }
  return _mls_retval;
}
_mlsValue _mls_ins_caller_post1(_mlsValue _mls_x203, _mlsValue _mls_x200, _mlsValue _mls_x199, _mlsValue _mls_x204, _mlsValue _mls_x205, _mlsValue _mls_x201, _mlsValue _mls_x202) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_x199, 1)) {
    _mls_retval = _mls_ins_caller_post_case01(_mls_x200, _mls_x201, _mls_x202, _mls_x203, _mls_x204, _mls_x205);
  } else {
    _mls_retval = _mls_ins_caller_post_default1(_mls_x200, _mls_x201, _mls_x202, _mls_x203, _mls_x204, _mls_x205);
  }
  return _mls_retval;
}
_mlsValue _mls_ins_caller_post_case0(_mlsValue _mls_x208, _mlsValue _mls_x212, _mlsValue _mls_x207, _mlsValue _mls_x211, _mlsValue _mls_x206, _mlsValue _mls_x210) {
  _mlsValue _mls_retval;
  auto _mls_x209 = _mls_ins(_mls_x206, _mls_x207, _mls_x208);
  auto _mls_x213 = _mls_balance1(_mls_x210, _mls_x211, _mls_x209, _mls_x212);
  _mls_retval = _mls_x213;
  return _mls_retval;
}
_mlsValue _mls_ins_caller_post_case01(_mlsValue _mls_x215, _mlsValue _mls_x218, _mlsValue _mls_x214, _mlsValue _mls_x220, _mlsValue _mls_x219, _mlsValue _mls_x216) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Leaf>(_mls_x214)) {
    auto _mls_x222 = _mls_ins_case0(_mls_x215, _mls_x216);
    auto _mls_x223 = _mls_balance2(_mls_x218, _mls_x219, _mls_x220, _mls_x222);
    _mls_retval = _mls_x223;
  } else if (_mlsValue::isValueOf<_mls_Node>(_mls_x214)) {
    auto _mls_x217 = _mls_ins_case1(_mls_x214, _mls_x215, _mls_x216);
    auto _mls_x221 = _mls_balance2(_mls_x218, _mls_x219, _mls_x220, _mls_x217);
    _mls_retval = _mls_x221;
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_ins_caller_post_default1(_mlsValue _mls_x224, _mlsValue _mls_x230, _mlsValue _mls_x226, _mlsValue _mls_x232, _mlsValue _mls_x231, _mlsValue _mls_x225) {
  _mlsValue _mls_retval;
  auto _mls_x227 = _mls_ins(_mls_x224, _mls_x225, _mls_x226);
  auto _mls_x228 = _mlsValue::create<_mls_Black>();
  auto _mls_x229 = _mlsValue::create<_mls_Node>(_mls_x228, _mls_x230, _mls_x231, _mls_x232, _mls_x227);
  _mls_retval = _mls_x229;
  return _mls_retval;
}
_mlsValue _mls_ins_caller_post_default(_mlsValue _mls_x241, _mlsValue _mls_x235, _mlsValue _mls_x234, _mlsValue _mls_x240, _mlsValue _mls_x233, _mlsValue _mls_x239) {
  _mlsValue _mls_retval;
  auto _mls_x236 = _mls_ins(_mls_x233, _mls_x234, _mls_x235);
  auto _mls_x237 = _mlsValue::create<_mls_Black>();
  auto _mls_x238 = _mlsValue::create<_mls_Node>(_mls_x237, _mls_x236, _mls_x239, _mls_x240, _mls_x241);
  _mls_retval = _mls_x238;
  return _mls_retval;
}
_mlsValue _mls_ins_case0(_mlsValue _mls_x246, _mlsValue _mls_x247) {
  _mlsValue _mls_retval;
  auto _mls_x242 = _mlsValue::create<_mls_Red>();
  auto _mls_x243 = _mlsValue::create<_mls_Leaf>();
  auto _mls_x244 = _mlsValue::create<_mls_Leaf>();
  auto _mls_x245 = _mlsValue::create<_mls_Node>(_mls_x242, _mls_x243, _mls_x246, _mls_x247, _mls_x244);
  _mls_retval = _mls_x245;
  return _mls_retval;
}
_mlsValue _mls_ins_case1(_mlsValue _mls_x249, _mlsValue _mls_x255, _mlsValue _mls_x257) {
  _mlsValue _mls_retval;
  auto _mls_x248 = _mlsValue::cast<_mls_Node>(_mls_x249)->_mls_color;
  auto _mls_x250 = _mlsValue::cast<_mls_Node>(_mls_x249)->_mls_left;
  auto _mls_x251 = _mlsValue::cast<_mls_Node>(_mls_x249)->_mls_key;
  auto _mls_x252 = _mlsValue::cast<_mls_Node>(_mls_x249)->_mls_value;
  auto _mls_x253 = _mlsValue::cast<_mls_Node>(_mls_x249)->_mls_right;
  if (_mlsValue::isValueOf<_mls_Red>(_mls_x248)) {
    auto _mls_x262 = (_mls_x255 < _mls_x251);
    if (_mlsValue::isIntLit(_mls_x262, 1)) {
      auto _mls_x269 = _mls_ins(_mls_x255, _mls_x257, _mls_x250);
      auto _mls_x270 = _mlsValue::create<_mls_Red>();
      auto _mls_x271 = _mlsValue::create<_mls_Node>(_mls_x270, _mls_x269, _mls_x251, _mls_x252, _mls_x253);
      _mls_retval = _mls_x271;
    } else {
      auto _mls_x263 = (_mls_x255 == _mls_x251);
      if (_mlsValue::isIntLit(_mls_x263, 1)) {
        auto _mls_x267 = _mlsValue::create<_mls_Red>();
        auto _mls_x268 = _mlsValue::create<_mls_Node>(_mls_x267, _mls_x250, _mls_x255, _mls_x257, _mls_x253);
        _mls_retval = _mls_x268;
      } else {
        auto _mls_x264 = _mls_ins(_mls_x255, _mls_x257, _mls_x253);
        auto _mls_x265 = _mlsValue::create<_mls_Red>();
        auto _mls_x266 = _mlsValue::create<_mls_Node>(_mls_x265, _mls_x250, _mls_x251, _mls_x252, _mls_x264);
        _mls_retval = _mls_x266;
      }
    }
  } else if (_mlsValue::isValueOf<_mls_Black>(_mls_x248)) {
    auto _mls_x254 = (_mls_x255 < _mls_x251);
    if (_mlsValue::isIntLit(_mls_x254, 1)) {
      if (_mlsValue::isValueOf<_mls_Node>(_mls_x250)) {
        auto _mls_x261 = _mls_isRed_case0_sr_post(_mls_x250);
        _mls_retval = _mls_ins_caller_post(_mls_x252, _mls_x255, _mls_x251, _mls_x250, _mls_x253, _mls_x261, _mls_x257);
      } else {
        _mls_retval = _mls_ins_caller_post_default(_mls_x253, _mls_x250, _mls_x257, _mls_x252, _mls_x255, _mls_x251);
      }
    } else {
      auto _mls_x256 = (_mls_x255 == _mls_x251);
      if (_mlsValue::isIntLit(_mls_x256, 1)) {
        auto _mls_x259 = _mlsValue::create<_mls_Black>();
        auto _mls_x260 = _mlsValue::create<_mls_Node>(_mls_x259, _mls_x250, _mls_x255, _mls_x257, _mls_x253);
        _mls_retval = _mls_x260;
      } else {
        if (_mlsValue::isValueOf<_mls_Node>(_mls_x253)) {
          auto _mls_x258 = _mls_isRed_case0_sr_post(_mls_x253);
          _mls_retval = _mls_ins_caller_post1(_mls_x252, _mls_x255, _mls_x258, _mls_x251, _mls_x257, _mls_x250, _mls_x253);
        } else {
          _mls_retval = _mls_ins_caller_post_default1(_mls_x255, _mls_x250, _mls_x253, _mls_x252, _mls_x251, _mls_x257);
        }
      }
    }
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_insert_caller_post(_mlsValue _mls_x272, _mlsValue _mls_x273, _mlsValue _mls_x274, _mlsValue _mls_x275) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_x272, 1)) {
    _mls_retval = _mls_insert_caller_post_case0(_mls_x273, _mls_x274, _mls_x275);
  } else {
    auto _mls_x276 = _mls_ins(_mls_x273, _mls_x274, _mls_x275);
    _mls_retval = _mls_x276;
  }
  return _mls_retval;
}
_mlsValue _mls_insert_caller_post_case0(_mlsValue _mls_x278, _mlsValue _mls_x279, _mlsValue _mls_x277) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Leaf>(_mls_x277)) {
    auto _mls_x282 = _mls_ins_case0(_mls_x278, _mls_x279);
    auto _mls_x283 = _mls_setBlack(_mls_x282);
    _mls_retval = _mls_x283;
  } else if (_mlsValue::isValueOf<_mls_Node>(_mls_x277)) {
    auto _mls_x280 = _mls_ins_case1(_mls_x277, _mls_x278, _mls_x279);
    auto _mls_x281 = _mls_setBlack(_mls_x280);
    _mls_retval = _mls_x281;
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_isRed_case0_pre(_mlsValue _mls_x285) {
  _mlsValue _mls_retval;
  auto _mls_x284 = _mlsValue::cast<_mls_Node>(_mls_x285)->_mls_color;
  _mls_retval = _mls_x284;
  return _mls_retval;
}
_mlsValue _mls_isRed_case0_sr_post(_mlsValue _mls_x286) {
  _mlsValue _mls_retval;
  auto _mls_x287 = _mls_isRed_case0_pre(_mls_x286);
  if (_mlsValue::isValueOf<_mls_Red>(_mls_x287)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else {
    _mls_retval = _mlsValue::fromIntLit(0);
  }
  return _mls_retval;
}
_mlsValue _mls_main() {
  _mlsValue _mls_retval;
  auto _mls_x157 = _mls_mkMap(_mlsValue::fromIntLit(6000));
  auto _mls_x158 = _mlsValue::create<_mls_LamF>();
  if (_mlsValue::isValueOf<_mls_Leaf>(_mls_x157)) {
    _mls_retval = _mlsValue::fromIntLit(0);
  } else if (_mlsValue::isValueOf<_mls_Node>(_mls_x157)) {
    auto _mls_x288 = _mlsValue::cast<_mls_Node>(_mls_x157)->_mls_left;
    auto _mls_x289 = _mlsValue::cast<_mls_Node>(_mls_x157)->_mls_key;
    auto _mls_x290 = _mlsValue::cast<_mls_Node>(_mls_x157)->_mls_value;
    auto _mls_x291 = _mlsValue::cast<_mls_Node>(_mls_x157)->_mls_right;
    auto _mls_x292 = _mls_fold(_mls_x158, _mls_x288, _mlsValue::fromIntLit(0));
    auto _mls_x293 = _mls_fold_case1_sr_post_post(_mls_x292, _mls_x291, _mls_x290, _mls_x158, _mls_x289);
    _mls_retval = _mls_x293;
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_mkMap(_mlsValue _mls_n) {
  _mlsValue _mls_retval;
  auto _mls_x160 = _mlsValue::create<_mls_Leaf>();
  auto [_mls_x294, _mls_x295, _mls_x296] = _mls_mkMapAux_pre(_mls_n, _mls_x160);
  if (_mlsValue::isIntLit(_mls_x294, 1)) {
    _mls_retval = _mls_x295;
  } else {
    auto _mls_x297 = _mls_mkMapAux_default(_mls_x296, _mls_x295);
    _mls_retval = _mls_x297;
  }
  return _mls_retval;
}
_mlsValue _mls_mkMapAux(_mlsValue _mls_x298, _mlsValue _mls_x299) {
  _mlsValue _mls_retval;
  auto [_mls_x300, _mls_x301, _mls_x302] = _mls_mkMapAux_pre(_mls_x298, _mls_x299);
  if (_mlsValue::isIntLit(_mls_x300, 1)) {
    _mls_retval = _mls_x301;
  } else {
    _mls_retval = _mls_mkMapAux_default(_mls_x302, _mls_x301);
  }
  return _mls_retval;
}
_mlsValue _mls_mkMapAux_default(_mlsValue _mls_x304, _mlsValue _mls_x307) {
  _mlsValue _mls_retval;
  auto _mls_x303 = (_mls_x304 - _mlsValue::fromIntLit(1));
  auto _mls_x305 = (_mls_x304 % _mlsValue::fromIntLit(10));
  auto _mls_x306 = (_mls_x305 == _mlsValue::fromIntLit(0));
  if (_mlsValue::isValueOf<_mls_Node>(_mls_x307)) {
    auto _mls_x312 = _mlsValue::cast<_mls_Node>(_mls_x307)->_mls_color;
    _mls_retval = _mls_mkMapAux_default_caller_post(_mls_x312, _mls_x304, _mls_x303, _mls_x307, _mls_x306);
  } else {
    if (_mlsValue::isValueOf<_mls_Leaf>(_mls_x307)) {
      auto _mls_x310 = _mls_ins_case0(_mls_x304, _mls_x306);
      auto _mls_x311 = _mls_mkMapAux(_mls_x303, _mls_x310);
      _mls_retval = _mls_x311;
    } else if (_mlsValue::isValueOf<_mls_Node>(_mls_x307)) {
      auto _mls_x308 = _mls_ins_case1(_mls_x307, _mls_x304, _mls_x306);
      auto _mls_x309 = _mls_mkMapAux(_mls_x303, _mls_x308);
      _mls_retval = _mls_x309;
    } else {
      throw std::runtime_error("match error" LINE_STRING);
    }
  }
  return _mls_retval;
}
_mlsValue _mls_mkMapAux_default_caller_post(_mlsValue _mls_x313, _mlsValue _mls_x314, _mlsValue _mls_x318, _mlsValue _mls_x316, _mlsValue _mls_x315) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Red>(_mls_x313)) {
    auto _mls_x320 = _mls_insert_caller_post(_mlsValue::fromIntLit(1), _mls_x314, _mls_x315, _mls_x316);
    auto _mls_x321 = _mls_mkMapAux(_mls_x318, _mls_x320);
    _mls_retval = _mls_x321;
  } else {
    auto _mls_x317 = _mls_insert_caller_post(_mlsValue::fromIntLit(0), _mls_x314, _mls_x315, _mls_x316);
    auto _mls_x319 = _mls_mkMapAux(_mls_x318, _mls_x317);
    _mls_retval = _mls_x319;
  }
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_mkMapAux_pre(_mlsValue _mls_x323, _mlsValue _mls_x324) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x322 = (_mls_x323 == _mlsValue::fromIntLit(0));
  _mls_retval = std::make_tuple(_mls_x322, _mls_x324, _mls_x323);
  return _mls_retval;
}
_mlsValue _mls_setBlack(_mlsValue _mls_t7) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Node>(_mls_t7)) {
    auto _mls_x168 = _mlsValue::cast<_mls_Node>(_mls_t7)->_mls_left;
    auto _mls_x169 = _mlsValue::cast<_mls_Node>(_mls_t7)->_mls_key;
    auto _mls_x170 = _mlsValue::cast<_mls_Node>(_mls_t7)->_mls_value;
    auto _mls_x171 = _mlsValue::cast<_mls_Node>(_mls_t7)->_mls_right;
    auto _mls_x172 = _mlsValue::create<_mls_Black>();
    auto _mls_x173 = _mlsValue::create<_mls_Node>(_mls_x172, _mls_x168, _mls_x169, _mls_x170, _mls_x171);
    _mls_retval = _mls_x173;
  } else {
    _mls_retval = _mls_t7;
  }
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
