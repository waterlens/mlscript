#include "mlsprelude.h"
struct _mls_Expr;
struct _mls_Var;
struct _mls_Val;
struct _mls_Ln;
struct _mls_Pow;
struct _mls_Lambda_deriv;
struct _mls_Add;
struct _mls_Mul;
_mlsValue _mls_entry();
_mlsValue _mls_d(_mlsValue, _mlsValue);
_mlsValue _mls_nestAux(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_pown(_mlsValue, _mlsValue);
_mlsValue _mls_ln(_mlsValue);
_mlsValue _mls_pow(_mlsValue, _mlsValue);
_mlsValue _mls_add(_mlsValue, _mlsValue);
_mlsValue _mls_deriv(_mlsValue, _mlsValue);
_mlsValue _mls_j(_mlsValue, _mlsValue);
_mlsValue _mls_main(_mlsValue);
_mlsValue _mls_mul(_mlsValue, _mlsValue);
_mlsValue _mls_count(_mlsValue);
struct _mls_Expr: public _mlsObject {
  
  constexpr static inline const char *typeName = "Expr";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Expr; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Var: public _mls_Expr {
  _mlsValue _mls_x;
  constexpr static inline const char *typeName = "Var";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_x.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_x);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_x.asObject()->operator==(*other.cast<_mls_Var>()->_mls_x.asObject()); }
  static _mlsValue create(_mlsValue _mls_x) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Var; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_x = _mls_x;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Val: public _mls_Expr {
  _mlsValue _mls_n;
  constexpr static inline const char *typeName = "Val";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_n.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_n);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_n.asObject()->operator==(*other.cast<_mls_Val>()->_mls_n.asObject()); }
  static _mlsValue create(_mlsValue _mls_n) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Val; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_n = _mls_n;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Ln: public _mls_Expr {
  _mlsValue _mls_e;
  constexpr static inline const char *typeName = "Ln";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e.asObject()->operator==(*other.cast<_mls_Ln>()->_mls_e.asObject()); }
  static _mlsValue create(_mlsValue _mls_e) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Ln; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e = _mls_e;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Pow: public _mls_Expr {
  _mlsValue _mls_e1;
  _mlsValue _mls_e2;
  constexpr static inline const char *typeName = "Pow";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e1.print(); std::printf(", "); this->_mls_e2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e1); _mlsValue::destroy(this->_mls_e2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e1.asObject()->operator==(*other.cast<_mls_Pow>()->_mls_e1.asObject()) && this->_mls_e2.asObject()->operator==(*other.cast<_mls_Pow>()->_mls_e2.asObject()); }
  static _mlsValue create(_mlsValue _mls_e1, _mlsValue _mls_e2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Pow; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e1 = _mls_e1; _mlsVal->_mls_e2 = _mls_e2;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Lambda_deriv: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_deriv";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_deriv; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Add: public _mls_Expr {
  _mlsValue _mls_e1;
  _mlsValue _mls_e2;
  constexpr static inline const char *typeName = "Add";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e1.print(); std::printf(", "); this->_mls_e2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e1); _mlsValue::destroy(this->_mls_e2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e1.asObject()->operator==(*other.cast<_mls_Add>()->_mls_e1.asObject()) && this->_mls_e2.asObject()->operator==(*other.cast<_mls_Add>()->_mls_e2.asObject()); }
  static _mlsValue create(_mlsValue _mls_e1, _mlsValue _mls_e2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Add; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e1 = _mls_e1; _mlsVal->_mls_e2 = _mls_e2;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Mul: public _mls_Expr {
  _mlsValue _mls_e1;
  _mlsValue _mls_e2;
  constexpr static inline const char *typeName = "Mul";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e1.print(); std::printf(", "); this->_mls_e2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e1); _mlsValue::destroy(this->_mls_e2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e1.asObject()->operator==(*other.cast<_mls_Mul>()->_mls_e1.asObject()) && this->_mls_e2.asObject()->operator==(*other.cast<_mls_Mul>()->_mls_e2.asObject()); }
  static _mlsValue create(_mlsValue _mls_e1, _mlsValue _mls_e2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Mul; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e1 = _mls_e1; _mlsVal->_mls_e2 = _mls_e2;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_pown(_mlsValue _mls_x148, _mlsValue _mls_n3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_n3, 0)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else if (_mlsValue::isIntLit(_mls_n3, 1)) {
    _mls_retval = _mls_x148;
  } else {
    auto _mls_x147 = (_mls_n3 / _mlsValue::fromIntLit(2));
    auto _mls_x149 = _mls_pown(_mls_x148, _mls_x147);
    auto _mls_x150 = (_mls_x149 * _mls_x149);
    auto _mls_x151 = (_mls_n3 % _mlsValue::fromIntLit(2));
    auto _mls_x152 = (_mls_x151 == _mlsValue::fromIntLit(0));
    if (_mlsValue::isIntLit(_mls_x152, 1)) {
      _mls_retval = _mls_j(_mls_x150, _mlsValue::fromIntLit(1));
    } else {
      _mls_retval = _mls_j(_mls_x150, _mls_x148);
    }
  }
  return _mls_retval;
}
_mlsValue _mls_add(_mlsValue _mls_e15, _mlsValue _mls_e25) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_e15)) {
    auto _mls_x135 = _mlsValue::cast<_mls_Val>(_mls_e15)->_mls_n;
    if (_mlsValue::isValueOf<_mls_Val>(_mls_e25)) {
      auto _mls_x144 = _mlsValue::cast<_mls_Val>(_mls_e25)->_mls_n;
      auto _mls_x145 = (_mls_x135 + _mls_x144);
      auto _mls_x146 = _mlsValue::create<_mls_Val>(_mls_x145);
      _mls_retval = _mls_x146;
    } else {
      if (_mlsValue::isIntLit(_mls_x135, 0)) {
        _mls_retval = _mls_e25;
      } else {
        if (_mlsValue::isValueOf<_mls_Add>(_mls_e25)) {
          auto _mls_x137 = _mlsValue::cast<_mls_Add>(_mls_e25)->_mls_e1;
          auto _mls_x138 = _mlsValue::cast<_mls_Add>(_mls_e25)->_mls_e2;
          if (_mlsValue::isValueOf<_mls_Val>(_mls_x137)) {
            auto _mls_x140 = _mlsValue::cast<_mls_Val>(_mls_x137)->_mls_n;
            auto _mls_x141 = (_mls_x135 + _mls_x140);
            auto _mls_x142 = _mlsValue::create<_mls_Val>(_mls_x141);
            auto _mls_x143 = _mls_add(_mls_x142, _mls_x138);
            _mls_retval = _mls_x143;
          } else {
            auto _mls_x139 = _mlsValue::create<_mls_Add>(_mls_e15, _mls_e25);
            _mls_retval = _mls_x139;
          }
        } else {
          auto _mls_x136 = _mlsValue::create<_mls_Add>(_mls_e15, _mls_e25);
          _mls_retval = _mls_x136;
        }
      }
    }
  } else {
    if (_mlsValue::isValueOf<_mls_Val>(_mls_e25)) {
      auto _mls_x132 = _mlsValue::cast<_mls_Val>(_mls_e25)->_mls_n;
      if (_mlsValue::isIntLit(_mls_x132, 0)) {
        _mls_retval = _mls_e15;
      } else {
        auto _mls_x133 = _mlsValue::create<_mls_Val>(_mls_x132);
        auto _mls_x134 = _mls_add(_mls_x133, _mls_e15);
        _mls_retval = _mls_x134;
      }
    } else if (_mlsValue::isValueOf<_mls_Add>(_mls_e25)) {
      auto _mls_x121 = _mlsValue::cast<_mls_Add>(_mls_e25)->_mls_e1;
      auto _mls_x122 = _mlsValue::cast<_mls_Add>(_mls_e25)->_mls_e2;
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x121)) {
        auto _mls_x128 = _mlsValue::cast<_mls_Val>(_mls_x121)->_mls_n;
        auto _mls_x129 = _mlsValue::create<_mls_Val>(_mls_x128);
        auto _mls_x130 = _mls_add(_mls_e15, _mls_x122);
        auto _mls_x131 = _mls_add(_mls_x129, _mls_x130);
        _mls_retval = _mls_x131;
      } else {
        if (_mlsValue::isValueOf<_mls_Add>(_mls_e15)) {
          auto _mls_x124 = _mlsValue::cast<_mls_Add>(_mls_e15)->_mls_e1;
          auto _mls_x125 = _mlsValue::cast<_mls_Add>(_mls_e15)->_mls_e2;
          auto _mls_x126 = _mls_add(_mls_x125, _mls_e25);
          auto _mls_x127 = _mls_add(_mls_x124, _mls_x126);
          _mls_retval = _mls_x127;
        } else {
          auto _mls_x123 = _mlsValue::create<_mls_Add>(_mls_e15, _mls_e25);
          _mls_retval = _mls_x123;
        }
      }
    } else {
      if (_mlsValue::isValueOf<_mls_Add>(_mls_e15)) {
        auto _mls_x117 = _mlsValue::cast<_mls_Add>(_mls_e15)->_mls_e1;
        auto _mls_x118 = _mlsValue::cast<_mls_Add>(_mls_e15)->_mls_e2;
        auto _mls_x119 = _mls_add(_mls_x118, _mls_e25);
        auto _mls_x120 = _mls_add(_mls_x117, _mls_x119);
        _mls_retval = _mls_x120;
      } else {
        auto _mls_x116 = _mlsValue::create<_mls_Add>(_mls_e15, _mls_e25);
        _mls_retval = _mls_x116;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_ln(_mlsValue _mls_e6) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_e6)) {
    auto _mls_x108 = _mlsValue::cast<_mls_Val>(_mls_e6)->_mls_n;
    if (_mlsValue::isIntLit(_mls_x108, 1)) {
      auto _mls_x110 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
      _mls_retval = _mls_x110;
    } else {
      auto _mls_x109 = _mlsValue::create<_mls_Ln>(_mls_e6);
      _mls_retval = _mls_x109;
    }
  } else {
    auto _mls_x107 = _mlsValue::create<_mls_Ln>(_mls_e6);
    _mls_retval = _mls_x107;
  }
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x57 = _mls_main(_mlsValue::fromIntLit(10));
  _mls_retval = _mls_x57;
  return _mls_retval;
}
_mlsValue _mls_j(_mlsValue _mls_tmp, _mlsValue _mls_tmp1) {
  _mlsValue _mls_retval;
  auto _mls_x58 = (_mls_tmp * _mls_tmp1);
  _mls_retval = _mls_x58;
  return _mls_retval;
}
_mlsValue _mls_main(_mlsValue _mls_n2) {
  _mlsValue _mls_retval;
  auto _mls_x111 = _mlsValue::create<_mls_Var>(_mlsValue::create<_mls_Str>("x"));
  auto _mls_x112 = _mls_pow(_mls_x111, _mls_x111);
  auto _mls_x113 = _mlsValue::create<_mls_Lambda_deriv>();
  auto _mls_x114 = _mls_nestAux(_mls_n2, _mls_x113, _mls_n2, _mls_x112);
  auto _mls_x115 = _mls_count(_mls_x114);
  _mls_retval = _mls_x115;
  return _mls_retval;
}
_mlsValue _mls_deriv(_mlsValue _mls_i, _mlsValue _mls_f1) {
  _mlsValue _mls_retval;
  auto _mls_x56 = _mls_d(_mlsValue::create<_mls_Str>("x"), _mls_f1);
  _mls_retval = _mls_x56;
  return _mls_retval;
}
_mlsValue _mls_pow(_mlsValue _mls_e14, _mlsValue _mls_e24) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_e14)) {
    auto _mls_x63 = _mlsValue::cast<_mls_Val>(_mls_e14)->_mls_n;
    if (_mlsValue::isValueOf<_mls_Val>(_mls_e24)) {
      auto _mls_x66 = _mlsValue::cast<_mls_Val>(_mls_e24)->_mls_n;
      auto _mls_x67 = _mls_pown(_mls_x63, _mls_x66);
      auto _mls_x68 = _mlsValue::create<_mls_Val>(_mls_x67);
      _mls_retval = _mls_x68;
    } else {
      if (_mlsValue::isIntLit(_mls_x63, 0)) {
        auto _mls_x65 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
        _mls_retval = _mls_x65;
      } else {
        auto _mls_x64 = _mlsValue::create<_mls_Pow>(_mls_e14, _mls_e24);
        _mls_retval = _mls_x64;
      }
    }
  } else {
    if (_mlsValue::isValueOf<_mls_Val>(_mls_e24)) {
      auto _mls_x60 = _mlsValue::cast<_mls_Val>(_mls_e24)->_mls_n;
      if (_mlsValue::isIntLit(_mls_x60, 0)) {
        auto _mls_x62 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(1));
        _mls_retval = _mls_x62;
      } else if (_mlsValue::isIntLit(_mls_x60, 1)) {
        _mls_retval = _mls_e14;
      } else {
        auto _mls_x61 = _mlsValue::create<_mls_Pow>(_mls_e14, _mls_e24);
        _mls_retval = _mls_x61;
      }
    } else {
      auto _mls_x59 = _mlsValue::create<_mls_Pow>(_mls_e14, _mls_e24);
      _mls_retval = _mls_x59;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_count(_mlsValue _mls_e4) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_e4)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else if (_mlsValue::isValueOf<_mls_Var>(_mls_e4)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_e4)) {
    auto _mls_x51 = _mlsValue::cast<_mls_Add>(_mls_e4)->_mls_e1;
    auto _mls_x52 = _mlsValue::cast<_mls_Add>(_mls_e4)->_mls_e2;
    auto _mls_x53 = _mls_count(_mls_x51);
    auto _mls_x54 = _mls_count(_mls_x52);
    auto _mls_x55 = (_mls_x53 + _mls_x54);
    _mls_retval = _mls_x55;
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_e4)) {
    auto _mls_x46 = _mlsValue::cast<_mls_Mul>(_mls_e4)->_mls_e1;
    auto _mls_x47 = _mlsValue::cast<_mls_Mul>(_mls_e4)->_mls_e2;
    auto _mls_x48 = _mls_count(_mls_x46);
    auto _mls_x49 = _mls_count(_mls_x47);
    auto _mls_x50 = (_mls_x48 + _mls_x49);
    _mls_retval = _mls_x50;
  } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_e4)) {
    auto _mls_x41 = _mlsValue::cast<_mls_Pow>(_mls_e4)->_mls_e1;
    auto _mls_x42 = _mlsValue::cast<_mls_Pow>(_mls_e4)->_mls_e2;
    auto _mls_x43 = _mls_count(_mls_x41);
    auto _mls_x44 = _mls_count(_mls_x42);
    auto _mls_x45 = (_mls_x43 + _mls_x44);
    _mls_retval = _mls_x45;
  } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_e4)) {
    auto _mls_x39 = _mlsValue::cast<_mls_Ln>(_mls_e4)->_mls_e;
    auto _mls_x40 = _mls_count(_mls_x39);
    _mls_retval = _mls_x40;
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_mul(_mlsValue _mls_e13, _mlsValue _mls_e23) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_e13)) {
    auto _mls_x22 = _mlsValue::cast<_mls_Val>(_mls_e13)->_mls_n;
    if (_mlsValue::isValueOf<_mls_Val>(_mls_e23)) {
      auto _mls_x32 = _mlsValue::cast<_mls_Val>(_mls_e23)->_mls_n;
      auto _mls_x33 = (_mls_x22 * _mls_x32);
      auto _mls_x34 = _mlsValue::create<_mls_Val>(_mls_x33);
      _mls_retval = _mls_x34;
    } else {
      if (_mlsValue::isIntLit(_mls_x22, 0)) {
        auto _mls_x31 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
        _mls_retval = _mls_x31;
      } else if (_mlsValue::isIntLit(_mls_x22, 1)) {
        _mls_retval = _mls_e23;
      } else {
        if (_mlsValue::isValueOf<_mls_Mul>(_mls_e23)) {
          auto _mls_x24 = _mlsValue::cast<_mls_Mul>(_mls_e23)->_mls_e1;
          auto _mls_x25 = _mlsValue::cast<_mls_Mul>(_mls_e23)->_mls_e2;
          if (_mlsValue::isValueOf<_mls_Val>(_mls_x24)) {
            auto _mls_x27 = _mlsValue::cast<_mls_Val>(_mls_x24)->_mls_n;
            auto _mls_x28 = (_mls_x22 * _mls_x27);
            auto _mls_x29 = _mlsValue::create<_mls_Val>(_mls_x28);
            auto _mls_x30 = _mls_mul(_mls_x29, _mls_x25);
            _mls_retval = _mls_x30;
          } else {
            auto _mls_x26 = _mlsValue::create<_mls_Mul>(_mls_e13, _mls_e23);
            _mls_retval = _mls_x26;
          }
        } else {
          auto _mls_x23 = _mlsValue::create<_mls_Mul>(_mls_e13, _mls_e23);
          _mls_retval = _mls_x23;
        }
      }
    }
  } else {
    if (_mlsValue::isValueOf<_mls_Val>(_mls_e23)) {
      auto _mls_x18 = _mlsValue::cast<_mls_Val>(_mls_e23)->_mls_n;
      if (_mlsValue::isIntLit(_mls_x18, 0)) {
        auto _mls_x21 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
        _mls_retval = _mls_x21;
      } else if (_mlsValue::isIntLit(_mls_x18, 1)) {
        _mls_retval = _mls_e13;
      } else {
        auto _mls_x19 = _mlsValue::create<_mls_Val>(_mls_x18);
        auto _mls_x20 = _mls_mul(_mls_x19, _mls_e13);
        _mls_retval = _mls_x20;
      }
    } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_e23)) {
      auto _mls_x7 = _mlsValue::cast<_mls_Mul>(_mls_e23)->_mls_e1;
      auto _mls_x8 = _mlsValue::cast<_mls_Mul>(_mls_e23)->_mls_e2;
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x7)) {
        auto _mls_x14 = _mlsValue::cast<_mls_Val>(_mls_x7)->_mls_n;
        auto _mls_x15 = _mlsValue::create<_mls_Val>(_mls_x14);
        auto _mls_x16 = _mls_mul(_mls_e13, _mls_x8);
        auto _mls_x17 = _mls_mul(_mls_x15, _mls_x16);
        _mls_retval = _mls_x17;
      } else {
        if (_mlsValue::isValueOf<_mls_Mul>(_mls_e13)) {
          auto _mls_x10 = _mlsValue::cast<_mls_Mul>(_mls_e13)->_mls_e1;
          auto _mls_x11 = _mlsValue::cast<_mls_Mul>(_mls_e13)->_mls_e2;
          auto _mls_x12 = _mls_mul(_mls_x11, _mls_e23);
          auto _mls_x13 = _mls_mul(_mls_x10, _mls_x12);
          _mls_retval = _mls_x13;
        } else {
          auto _mls_x9 = _mlsValue::create<_mls_Mul>(_mls_e13, _mls_e23);
          _mls_retval = _mls_x9;
        }
      }
    } else {
      if (_mlsValue::isValueOf<_mls_Mul>(_mls_e13)) {
        auto _mls_x3 = _mlsValue::cast<_mls_Mul>(_mls_e13)->_mls_e1;
        auto _mls_x4 = _mlsValue::cast<_mls_Mul>(_mls_e13)->_mls_e2;
        auto _mls_x5 = _mls_mul(_mls_x4, _mls_e23);
        auto _mls_x6 = _mls_mul(_mls_x3, _mls_x5);
        _mls_retval = _mls_x6;
      } else {
        auto _mls_x2 = _mlsValue::create<_mls_Mul>(_mls_e13, _mls_e23);
        _mls_retval = _mls_x2;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_nestAux(_mlsValue _mls_s, _mlsValue _mls_f, _mlsValue _mls_n1, _mlsValue _mls_e3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_n1, 0)) {
    _mls_retval = _mls_e3;
  } else {
    auto _mls_x35 = (_mls_s - _mls_n1);
    auto _mls_x36 = _mlsMethodCall<_mls_Callable>(_mls_f)->_mls_apply2(_mls_x35, _mls_e3);
    auto _mls_x37 = (_mls_n1 - _mlsValue::fromIntLit(1));
    auto _mls_x38 = _mls_nestAux(_mls_s, _mls_f, _mls_x37, _mls_x36);
    _mls_retval = _mls_x38;
  }
  return _mls_retval;
}
_mlsValue _mls_d(_mlsValue _mls_x70, _mlsValue _mls_e5) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_e5)) {
    auto _mls_x106 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
    _mls_retval = _mls_x106;
  } else if (_mlsValue::isValueOf<_mls_Var>(_mls_e5)) {
    auto _mls_x102 = _mlsValue::cast<_mls_Var>(_mls_e5)->_mls_x;
    auto _mls_x103 = (_mls_x70 == _mls_x102);
    if (_mlsValue::isIntLit(_mls_x103, 1)) {
      auto _mls_x105 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(1));
      _mls_retval = _mls_x105;
    } else {
      auto _mls_x104 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
      _mls_retval = _mls_x104;
    }
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_e5)) {
    auto _mls_x97 = _mlsValue::cast<_mls_Add>(_mls_e5)->_mls_e1;
    auto _mls_x98 = _mlsValue::cast<_mls_Add>(_mls_e5)->_mls_e2;
    auto _mls_x99 = _mls_d(_mls_x70, _mls_x97);
    auto _mls_x100 = _mls_d(_mls_x70, _mls_x98);
    auto _mls_x101 = _mls_add(_mls_x99, _mls_x100);
    _mls_retval = _mls_x101;
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_e5)) {
    auto _mls_x90 = _mlsValue::cast<_mls_Mul>(_mls_e5)->_mls_e1;
    auto _mls_x91 = _mlsValue::cast<_mls_Mul>(_mls_e5)->_mls_e2;
    auto _mls_x92 = _mls_d(_mls_x70, _mls_x91);
    auto _mls_x93 = _mls_mul(_mls_x90, _mls_x92);
    auto _mls_x94 = _mls_d(_mls_x70, _mls_x90);
    auto _mls_x95 = _mls_mul(_mls_x91, _mls_x94);
    auto _mls_x96 = _mls_add(_mls_x93, _mls_x95);
    _mls_retval = _mls_x96;
  } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_e5)) {
    auto _mls_x76 = _mlsValue::cast<_mls_Pow>(_mls_e5)->_mls_e1;
    auto _mls_x77 = _mlsValue::cast<_mls_Pow>(_mls_e5)->_mls_e2;
    auto _mls_x78 = _mls_pow(_mls_x76, _mls_x77);
    auto _mls_x79 = _mls_d(_mls_x70, _mls_x76);
    auto _mls_x80 = _mls_mul(_mls_x77, _mls_x79);
    auto _mls_x81 = (-_mlsValue::fromIntLit(1));
    auto _mls_x82 = _mlsValue::create<_mls_Val>(_mls_x81);
    auto _mls_x83 = _mls_pow(_mls_x76, _mls_x82);
    auto _mls_x84 = _mls_mul(_mls_x80, _mls_x83);
    auto _mls_x85 = _mls_ln(_mls_x76);
    auto _mls_x86 = _mls_d(_mls_x70, _mls_x77);
    auto _mls_x87 = _mls_mul(_mls_x85, _mls_x86);
    auto _mls_x88 = _mls_add(_mls_x84, _mls_x87);
    auto _mls_x89 = _mls_mul(_mls_x78, _mls_x88);
    _mls_retval = _mls_x89;
  } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_e5)) {
    auto _mls_x69 = _mlsValue::cast<_mls_Ln>(_mls_e5)->_mls_e;
    auto _mls_x71 = _mls_d(_mls_x70, _mls_x69);
    auto _mls_x72 = (-_mlsValue::fromIntLit(1));
    auto _mls_x73 = _mlsValue::create<_mls_Val>(_mls_x72);
    auto _mls_x74 = _mls_pow(_mls_x69, _mls_x73);
    auto _mls_x75 = _mls_mul(_mls_x71, _mls_x74);
    _mls_retval = _mls_x75;
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_deriv::_mls_apply2(_mlsValue _mls_arg, _mlsValue _mls_arg1) {
  _mlsValue _mls_retval;
  auto _mls_x1 = _mls_deriv(_mls_arg, _mls_arg1);
  _mls_retval = _mls_x1;
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
