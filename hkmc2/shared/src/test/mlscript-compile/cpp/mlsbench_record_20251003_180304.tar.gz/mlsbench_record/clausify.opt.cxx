#include "mlsprelude.h"
struct _mls_Formula;
struct _mls_Con;
struct _mls_Dis;
struct _mls_Eqv;
struct _mls_Imp;
struct _mls_Lambda_clauses;
struct _mls_Lambda_disp;
struct _mls_Lambda_l;
struct _mls_Lambda_lambda;
struct _mls_Lambda_lscomp;
struct _mls_Lambda_red;
struct _mls_Lambda_uniclHelper;
struct _mls_List;
struct _mls_Cons;
struct _mls_Nil;
struct _mls_Not;
struct _mls_StackFrame;
struct _mls_Ast;
struct _mls_Lex;
struct _mls_Sym;
struct _mls_Tuple2;
_mlsValue _mls_append(_mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper(_mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper_case0_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper_case0_sr_post_case0(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper_case0_sr_post_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper_case0_sr_post_case0_sr_post_case0(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper_case0_sr_post_case0_sr_post_case1(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper_case0_sr_post_case0_sr_post_case2(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper_case0_sr_post_case1(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper_case0_sr_post_case1_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper_case0_sr_post_case1_sr_post_case0(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper_case0_sr_post_case2(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper_case0_sr_post_case2_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper_case0_sr_post_case2_sr_post_case0(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper_case1_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper_case1_sr_post_case0(_mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper_case1_sr_post_case0_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper_case2_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper_case2_sr_post_case0(_mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper_case2_sr_post_case0_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_clauseHelper_case2_sr_post_case0_sr_post_case0(_mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue> _mls_clause_pre(_mlsValue);
_mlsValue _mls_clauses(_mlsValue);
_mlsValue _mls_clauses_caller_post_caller_post(_mlsValue);
_mlsValue _mls_clauses_caller_post_caller_post_caller_post_post(_mlsValue);
_mlsValue _mls_concat(_mlsValue);
_mlsValue _mls_concat_case0();
_mlsValue _mls_concat_case1(_mlsValue);
_mlsValue _mls_concat_case11(_mlsValue);
_mlsValue _mls_concat_case1_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_conjunct(_mlsValue);
_mlsValue _mls_disin(_mlsValue);
_mlsValue _mls_disin_case0(_mlsValue);
_mlsValue _mls_disin_case0_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_disin_case0_caller_post_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_disin_case0_caller_post_caller_post1(_mlsValue, _mlsValue);
_mlsValue _mls_disin_case0_caller_post_caller_post2(_mlsValue, _mlsValue);
_mlsValue _mls_disin_case0_caller_post_caller_post_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_disin_case0_caller_post_case01(_mlsValue, _mlsValue);
_mlsValue _mls_disin_case0_caller_post_case0(_mlsValue, _mlsValue);
_mlsValue _mls_disin_case0_caller_post_case11(_mlsValue, _mlsValue);
_mlsValue _mls_disin_case0_caller_post_case1(_mlsValue, _mlsValue);
_mlsValue _mls_disin_case0_caller_post_default(_mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_disin_case0_caller_post_default_pre(_mlsValue, _mlsValue);
_mlsValue _mls_disin_case0_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_disin_case0_sr_post_case0(_mlsValue, _mlsValue);
_mlsValue _mls_disin_case0_sr_post_default(_mlsValue, _mlsValue);
_mlsValue _mls_disin_case1(_mlsValue);
_mlsValue _mls_disin_case1_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_disp(_mlsValue);
_mlsValue _mls_disp_caller_post_post(_mlsValue, _mlsValue);
_mlsValue _mls_disp_caller_post_post_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_disp_caller_post_post_caller_post_caller_post_post(_mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_disp_caller_post_post_pre(_mlsValue, _mlsValue);
_mlsValue _mls_elim(_mlsValue);
_mlsValue _mls_elim_case0_sr_post(_mlsValue);
_mlsValue _mls_elim_case1_sr_post(_mlsValue);
_mlsValue _mls_elim_case2_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_elim_case3_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_elim_case4_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_elim_case5_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_elim_case5_sr_post_caller_post_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_foldr(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_inList(_mlsValue, _mlsValue);
_mlsValue _mls_insert(_mlsValue, _mlsValue);
_mlsValue _mls_interleave(_mlsValue, _mlsValue);
_mlsValue _mls_interleave_case0(_mlsValue, _mlsValue);
_mlsValue _mls_interleave_case0_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_interleave_case0_sr_post1(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_interleave_case0_sr_post_post(_mlsValue, _mlsValue);
_mlsValue _mls_interleave_case1();
_mlsValue _mls_listLen(_mlsValue);
_mlsValue _mls_list_to_str(_mlsValue);
_mlsValue _mls_list_to_str_case1_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_map(_mlsValue, _mlsValue);
_mlsValue _mls_map_case0_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_map_case1();
_mlsValue _mls_negin(_mlsValue);
_mlsValue _mls_negin_case0(_mlsValue);
_mlsValue _mls_negin_case0_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_negin_case0_caller_post1(_mlsValue, _mlsValue);
_mlsValue _mls_negin_case0_caller_post_caller_post1(_mlsValue, _mlsValue);
_mlsValue _mls_negin_case0_caller_post_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_negin_case1_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_negin_case2_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_opri(_mlsValue);
_mlsValue _mls_parse(_mlsValue);
_mlsValue _mls_parseHelper(_mlsValue, _mlsValue);
_mlsValue _mls_parseHelper_case1(_mlsValue, _mlsValue);
_mlsValue _mls_parseHelper_case11(_mlsValue, _mlsValue);
_mlsValue _mls_parseHelper_case1_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_parseHelper_case1_sr_post_case1(_mlsValue, _mlsValue);
_mlsValue _mls_parseHelper_case1_sr_post_case2(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_parseHelper_case1_sr_post_case2_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_parseHelper_case1_sr_post_case2_case0_sr_post_case0(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_parseHelper_case1_sr_post_case2_case0_sr_post_default(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_parseHelper_case1_sr_post_case2_default(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_parseHelper_case1_sr_post_case2_default_case0(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_parseHelper_case1_sr_post_case2_default_default(_mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_parseHelper_case1_sr_post_case2_default_pre(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_parseHelper_case1_sr_post_default(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_parseHelper_case1_sr_post_default_case0(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_parseHelper_case1_sr_post_default_default(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_parseHelper_case1_sr_post_default_default_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_parseHelper_case1_sr_post_default_pre(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_parse_caller_post(_mlsValue);
_mlsValue _mls_red(_mlsValue);
_mlsValue _mls_red_case0(_mlsValue);
_mlsValue _mls_redstar(_mlsValue);
_mlsValue _mls_replicate(_mlsValue, _mlsValue);
_mlsValue _mls_replicate_case0();
_mlsValue _mls_replicate_default(_mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_replicate_pre(_mlsValue, _mlsValue);
_mlsValue _mls_split(_mlsValue);
_mlsValue _mls_splitHelper(_mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue> _mls_split_pre(_mlsValue);
_mlsValue _mls_spri(_mlsValue);
_mlsValue _mls_spri_case0(_mlsValue);
_mlsValue _mls_str_to_list(_mlsValue);
_mlsValue _mls_tautclause_case0_sr_post_pre(_mlsValue, _mlsValue);
_mlsValue _mls_testClausify_nofib(_mlsValue);
_mlsValue _mls_testClausify_nofib_caller_post_post_case1(_mlsValue);
std::tuple<_mlsValue, _mlsValue> _mls_testClausify_nofib_caller_post_pre(_mlsValue);
_mlsValue _mls_unicl(_mlsValue);
_mlsValue _mls_uniclHelper(_mlsValue, _mlsValue);
_mlsValue _mls_uniclHelper_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_uniclHelper_caller_post_case0(_mlsValue, _mlsValue);
_mlsValue _mls_while_(_mlsValue, _mlsValue, _mlsValue);
struct _mls_Formula: public _mlsObject {
  
  constexpr static inline const char *typeName = "Formula";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Formula; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Con: public _mls_Formula {
  _mlsValue _mls_a;
  _mlsValue _mls_b;
  constexpr static inline const char *typeName = "Con";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_a.print(); std::printf(", "); this->_mls_b.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_a); _mlsValue::destroy(this->_mls_b);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_a.asObject()->operator==(*other.cast<_mls_Con>()->_mls_a.asObject()) && this->_mls_b.asObject()->operator==(*other.cast<_mls_Con>()->_mls_b.asObject()); }
  static _mlsValue create(_mlsValue _mls_a, _mlsValue _mls_b) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Con; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_a = _mls_a; _mlsVal->_mls_b = _mls_b;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Dis: public _mls_Formula {
  _mlsValue _mls_a;
  _mlsValue _mls_b;
  constexpr static inline const char *typeName = "Dis";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_a.print(); std::printf(", "); this->_mls_b.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_a); _mlsValue::destroy(this->_mls_b);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_a.asObject()->operator==(*other.cast<_mls_Dis>()->_mls_a.asObject()) && this->_mls_b.asObject()->operator==(*other.cast<_mls_Dis>()->_mls_b.asObject()); }
  static _mlsValue create(_mlsValue _mls_a, _mlsValue _mls_b) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Dis; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_a = _mls_a; _mlsVal->_mls_b = _mls_b;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Eqv: public _mls_Formula {
  _mlsValue _mls_a;
  _mlsValue _mls_b;
  constexpr static inline const char *typeName = "Eqv";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_a.print(); std::printf(", "); this->_mls_b.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_a); _mlsValue::destroy(this->_mls_b);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_a.asObject()->operator==(*other.cast<_mls_Eqv>()->_mls_a.asObject()) && this->_mls_b.asObject()->operator==(*other.cast<_mls_Eqv>()->_mls_b.asObject()); }
  static _mlsValue create(_mlsValue _mls_a, _mlsValue _mls_b) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Eqv; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_a = _mls_a; _mlsVal->_mls_b = _mls_b;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Imp: public _mls_Formula {
  _mlsValue _mls_a;
  _mlsValue _mls_b;
  constexpr static inline const char *typeName = "Imp";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_a.print(); std::printf(", "); this->_mls_b.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_a); _mlsValue::destroy(this->_mls_b);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_a.asObject()->operator==(*other.cast<_mls_Imp>()->_mls_a.asObject()) && this->_mls_b.asObject()->operator==(*other.cast<_mls_Imp>()->_mls_b.asObject()); }
  static _mlsValue create(_mlsValue _mls_a, _mlsValue _mls_b) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Imp; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_a = _mls_a; _mlsVal->_mls_b = _mls_b;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Lambda_clauses: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_clauses";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_clauses; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_disp: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_disp";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_disp; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_l: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_l";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_l; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_lambda: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lscomp: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_lscomp";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lscomp>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lscomp; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_red: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_red";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_red; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_uniclHelper: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_uniclHelper";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_uniclHelper; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_List: public _mlsObject {
  
  constexpr static inline const char *typeName = "List";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_List; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Cons: public _mls_List {
  _mlsValue _mls_head;
  _mlsValue _mls_tail;
  constexpr static inline const char *typeName = "Cons";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_head.print(); std::printf(", "); this->_mls_tail.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_head); _mlsValue::destroy(this->_mls_tail);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_head.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_head.asObject()) && this->_mls_tail.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_tail.asObject()); }
  static _mlsValue create(_mlsValue _mls_head, _mlsValue _mls_tail) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Cons; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_head = _mls_head; _mlsVal->_mls_tail = _mls_tail;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Nil: public _mls_List {
  
  constexpr static inline const char *typeName = "Nil";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Nil; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Not: public _mls_Formula {
  _mlsValue _mls_a;
  constexpr static inline const char *typeName = "Not";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_a.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_a);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_a.asObject()->operator==(*other.cast<_mls_Not>()->_mls_a.asObject()); }
  static _mlsValue create(_mlsValue _mls_a) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Not; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_a = _mls_a;  return _mlsValue(_mlsVal); }
  
};
struct _mls_StackFrame: public _mlsObject {
  
  constexpr static inline const char *typeName = "StackFrame";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_StackFrame; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Ast: public _mls_StackFrame {
  _mlsValue _mls_f;
  constexpr static inline const char *typeName = "Ast";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_f.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_f);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_f.asObject()->operator==(*other.cast<_mls_Ast>()->_mls_f.asObject()); }
  static _mlsValue create(_mlsValue _mls_f) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Ast; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_f = _mls_f;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Lex: public _mls_StackFrame {
  _mlsValue _mls_s;
  constexpr static inline const char *typeName = "Lex";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_s.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_s);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_s.asObject()->operator==(*other.cast<_mls_Lex>()->_mls_s.asObject()); }
  static _mlsValue create(_mlsValue _mls_s) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lex; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_s = _mls_s;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Sym: public _mls_Formula {
  _mlsValue _mls_a;
  constexpr static inline const char *typeName = "Sym";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_a.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_a);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_a.asObject()->operator==(*other.cast<_mls_Sym>()->_mls_a.asObject()); }
  static _mlsValue create(_mlsValue _mls_a) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Sym; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_a = _mls_a;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Tuple2: public _mlsObject {
  _mlsValue _mls_field0;
  _mlsValue _mls_field1;
  constexpr static inline const char *typeName = "Tuple2";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_field0.print(); std::printf(", "); this->_mls_field1.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_field0); _mlsValue::destroy(this->_mls_field1);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_field0.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field0.asObject()) && this->_mls_field1.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field1.asObject()); }
  static _mlsValue create(_mlsValue _mls_field0, _mlsValue _mls_field1) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Tuple2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_field0 = _mls_field0; _mlsVal->_mls_field1 = _mls_field1;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_append(_mlsValue _mls_xs, _mlsValue _mls_ys) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs)) {
    _mls_retval = _mls_ys;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs)) {
    auto _mls_x17 = _mlsValue::cast<_mls_Cons>(_mls_xs)->_mls_head;
    auto _mls_x18 = _mlsValue::cast<_mls_Cons>(_mls_xs)->_mls_tail;
    auto _mls_x19 = _mls_append(_mls_x18, _mls_ys);
    auto _mls_x20 = _mlsValue::create<_mls_Cons>(_mls_x17, _mls_x19);
    _mls_retval = _mls_x20;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_clauseHelper(_mlsValue _mls_x387, _mlsValue _mls_x389) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Dis>(_mls_x387)) {
    auto _mls_x391 = _mlsValue::cast<_mls_Dis>(_mls_x387)->_mls_a;
    auto _mls_x392 = _mlsValue::cast<_mls_Dis>(_mls_x387)->_mls_b;
    _mls_retval = _mls_clauseHelper_case0_sr_post(_mls_x392, _mls_x389, _mls_x391);
  } else if (_mlsValue::isValueOf<_mls_Sym>(_mls_x387)) {
    auto _mls_x390 = _mlsValue::cast<_mls_Sym>(_mls_x387)->_mls_a;
    _mls_retval = _mls_clauseHelper_case1_sr_post(_mls_x389, _mls_x390);
  } else if (_mlsValue::isValueOf<_mls_Not>(_mls_x387)) {
    auto _mls_x388 = _mlsValue::cast<_mls_Not>(_mls_x387)->_mls_a;
    _mls_retval = _mls_clauseHelper_case2_sr_post(_mls_x388, _mls_x389);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_clauseHelper_case0_sr_post(_mlsValue _mls_x393, _mlsValue _mls_x394, _mlsValue _mls_x395) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Dis>(_mls_x393)) {
    _mls_retval = _mls_clauseHelper_case0_sr_post_case0(_mls_x393, _mls_x394, _mls_x395);
  } else if (_mlsValue::isValueOf<_mls_Sym>(_mls_x393)) {
    _mls_retval = _mls_clauseHelper_case0_sr_post_case1(_mls_x393, _mls_x394, _mls_x395);
  } else if (_mlsValue::isValueOf<_mls_Not>(_mls_x393)) {
    _mls_retval = _mls_clauseHelper_case0_sr_post_case2(_mls_x393, _mls_x394, _mls_x395);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_clauseHelper_case0_sr_post_case0(_mlsValue _mls_x397, _mlsValue _mls_x399, _mlsValue _mls_x400) {
  _mlsValue _mls_retval;
  auto _mls_x396 = _mlsValue::cast<_mls_Dis>(_mls_x397)->_mls_a;
  auto _mls_x398 = _mlsValue::cast<_mls_Dis>(_mls_x397)->_mls_b;
  _mls_retval = _mls_clauseHelper_case0_sr_post_case0_sr_post(_mls_x398, _mls_x399, _mls_x396, _mls_x400);
  return _mls_retval;
}
_mlsValue _mls_clauseHelper_case0_sr_post_case0_sr_post(_mlsValue _mls_x401, _mlsValue _mls_x402, _mlsValue _mls_x403, _mlsValue _mls_x405) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Dis>(_mls_x401)) {
    auto _mls_x409 = _mls_clauseHelper_case0_sr_post_case0(_mls_x401, _mls_x402, _mls_x403);
    auto _mls_x410 = _mls_clauseHelper(_mls_x405, _mls_x409);
    _mls_retval = _mls_x410;
  } else if (_mlsValue::isValueOf<_mls_Sym>(_mls_x401)) {
    auto _mls_x407 = _mls_clauseHelper_case0_sr_post_case1(_mls_x401, _mls_x402, _mls_x403);
    auto _mls_x408 = _mls_clauseHelper(_mls_x405, _mls_x407);
    _mls_retval = _mls_x408;
  } else if (_mlsValue::isValueOf<_mls_Not>(_mls_x401)) {
    auto _mls_x404 = _mls_clauseHelper_case0_sr_post_case2(_mls_x401, _mls_x402, _mls_x403);
    auto _mls_x406 = _mls_clauseHelper(_mls_x405, _mls_x404);
    _mls_retval = _mls_x406;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_clauseHelper_case0_sr_post_case0_sr_post_case0(_mlsValue _mls_x411, _mlsValue _mls_x412, _mlsValue _mls_x413, _mlsValue _mls_x415) {
  _mlsValue _mls_retval;
  auto _mls_x414 = _mls_clauseHelper_case0_sr_post_case0(_mls_x411, _mls_x412, _mls_x413);
  auto _mls_x416 = _mls_clauseHelper(_mls_x415, _mls_x414);
  _mls_retval = _mls_x416;
  return _mls_retval;
}
_mlsValue _mls_clauseHelper_case0_sr_post_case0_sr_post_case1(_mlsValue _mls_x417, _mlsValue _mls_x418, _mlsValue _mls_x419, _mlsValue _mls_x421) {
  _mlsValue _mls_retval;
  auto _mls_x420 = _mls_clauseHelper_case0_sr_post_case1(_mls_x417, _mls_x418, _mls_x419);
  auto _mls_x422 = _mls_clauseHelper(_mls_x421, _mls_x420);
  _mls_retval = _mls_x422;
  return _mls_retval;
}
_mlsValue _mls_clauseHelper_case0_sr_post_case0_sr_post_case2(_mlsValue _mls_x423, _mlsValue _mls_x424, _mlsValue _mls_x425, _mlsValue _mls_x427) {
  _mlsValue _mls_retval;
  auto _mls_x426 = _mls_clauseHelper_case0_sr_post_case2(_mls_x423, _mls_x424, _mls_x425);
  auto _mls_x428 = _mls_clauseHelper(_mls_x427, _mls_x426);
  _mls_retval = _mls_x428;
  return _mls_retval;
}
_mlsValue _mls_clauseHelper_case0_sr_post_case1(_mlsValue _mls_x430, _mlsValue _mls_x431, _mlsValue _mls_x432) {
  _mlsValue _mls_retval;
  auto _mls_x429 = _mlsValue::cast<_mls_Sym>(_mls_x430)->_mls_a;
  _mls_retval = _mls_clauseHelper_case0_sr_post_case1_sr_post(_mls_x431, _mls_x429, _mls_x432);
  return _mls_retval;
}
_mlsValue _mls_clauseHelper_case0_sr_post_case1_sr_post(_mlsValue _mls_x433, _mlsValue _mls_x434, _mlsValue _mls_x436) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x433)) {
    auto _mls_x435 = _mls_clauseHelper_case1_sr_post_case0(_mls_x433, _mls_x434);
    auto _mls_x437 = _mls_clauseHelper(_mls_x436, _mls_x435);
    _mls_retval = _mls_x437;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_clauseHelper_case0_sr_post_case1_sr_post_case0(_mlsValue _mls_x438, _mlsValue _mls_x439, _mlsValue _mls_x441) {
  _mlsValue _mls_retval;
  auto _mls_x440 = _mls_clauseHelper_case1_sr_post_case0(_mls_x438, _mls_x439);
  auto _mls_x442 = _mls_clauseHelper(_mls_x441, _mls_x440);
  _mls_retval = _mls_x442;
  return _mls_retval;
}
_mlsValue _mls_clauseHelper_case0_sr_post_case2(_mlsValue _mls_x444, _mlsValue _mls_x445, _mlsValue _mls_x446) {
  _mlsValue _mls_retval;
  auto _mls_x443 = _mlsValue::cast<_mls_Not>(_mls_x444)->_mls_a;
  _mls_retval = _mls_clauseHelper_case0_sr_post_case2_sr_post(_mls_x443, _mls_x445, _mls_x446);
  return _mls_retval;
}
_mlsValue _mls_clauseHelper_case0_sr_post_case2_sr_post(_mlsValue _mls_x447, _mlsValue _mls_x448, _mlsValue _mls_x450) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Sym>(_mls_x447)) {
    auto _mls_x449 = _mls_clauseHelper_case2_sr_post_case0(_mls_x447, _mls_x448);
    auto _mls_x451 = _mls_clauseHelper(_mls_x450, _mls_x449);
    _mls_retval = _mls_x451;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_clauseHelper_case0_sr_post_case2_sr_post_case0(_mlsValue _mls_x452, _mlsValue _mls_x453, _mlsValue _mls_x455) {
  _mlsValue _mls_retval;
  auto _mls_x454 = _mls_clauseHelper_case2_sr_post_case0(_mls_x452, _mls_x453);
  auto _mls_x456 = _mls_clauseHelper(_mls_x455, _mls_x454);
  _mls_retval = _mls_x456;
  return _mls_retval;
}
_mlsValue _mls_clauseHelper_case1_sr_post(_mlsValue _mls_x457, _mlsValue _mls_x458) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x457)) {
    _mls_retval = _mls_clauseHelper_case1_sr_post_case0(_mls_x457, _mls_x458);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_clauseHelper_case1_sr_post_case0(_mlsValue _mls_x460, _mlsValue _mls_x462) {
  _mlsValue _mls_retval;
  auto _mls_x459 = _mlsValue::cast<_mls_Tuple2>(_mls_x460)->_mls_field0;
  auto _mls_x461 = _mlsValue::cast<_mls_Tuple2>(_mls_x460)->_mls_field1;
  _mls_retval = _mls_clauseHelper_case1_sr_post_case0_sr_post(_mls_x462, _mls_x459, _mls_x461);
  return _mls_retval;
}
_mlsValue _mls_clauseHelper_case1_sr_post_case0_sr_post(_mlsValue _mls_x463, _mlsValue _mls_x464, _mlsValue _mls_x467) {
  _mlsValue _mls_retval;
  auto _mls_x465 = _mls_insert(_mls_x463, _mls_x464);
  auto _mls_x466 = _mlsValue::create<_mls_Tuple2>(_mls_x465, _mls_x467);
  _mls_retval = _mls_x466;
  return _mls_retval;
}
_mlsValue _mls_clauseHelper_case2_sr_post(_mlsValue _mls_x468, _mlsValue _mls_x469) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Sym>(_mls_x468)) {
    _mls_retval = _mls_clauseHelper_case2_sr_post_case0(_mls_x468, _mls_x469);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_clauseHelper_case2_sr_post_case0(_mlsValue _mls_x471, _mlsValue _mls_x472) {
  _mlsValue _mls_retval;
  auto _mls_x470 = _mlsValue::cast<_mls_Sym>(_mls_x471)->_mls_a;
  _mls_retval = _mls_clauseHelper_case2_sr_post_case0_sr_post(_mls_x472, _mls_x470);
  return _mls_retval;
}
_mlsValue _mls_clauseHelper_case2_sr_post_case0_sr_post(_mlsValue _mls_x473, _mlsValue _mls_x474) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x473)) {
    _mls_retval = _mls_clauseHelper_case2_sr_post_case0_sr_post_case0(_mls_x473, _mls_x474);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_clauseHelper_case2_sr_post_case0_sr_post_case0(_mlsValue _mls_x476, _mlsValue _mls_x478) {
  _mlsValue _mls_retval;
  auto _mls_x475 = _mlsValue::cast<_mls_Tuple2>(_mls_x476)->_mls_field0;
  auto _mls_x477 = _mlsValue::cast<_mls_Tuple2>(_mls_x476)->_mls_field1;
  auto _mls_x479 = _mls_insert(_mls_x478, _mls_x477);
  auto _mls_x480 = _mlsValue::create<_mls_Tuple2>(_mls_x475, _mls_x479);
  _mls_retval = _mls_x480;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue> _mls_clause_pre(_mlsValue _mls_x484) {
  std::tuple<_mlsValue, _mlsValue> _mls_retval;
  auto _mls_x481 = _mlsValue::create<_mls_Nil>();
  auto _mls_x482 = _mlsValue::create<_mls_Nil>();
  auto _mls_x483 = _mlsValue::create<_mls_Tuple2>(_mls_x481, _mls_x482);
  _mls_retval = std::make_tuple(_mls_x484, _mls_x483);
  return _mls_retval;
}
_mlsValue _mls_clauses(_mlsValue _mls_t) {
  _mlsValue _mls_retval;
  auto _mls_x41 = _mls_parse(_mls_t);
  if (_mlsValue::isValueOf<_mls_Sym>(_mls_x41)) {
    auto _mls_x528 = _mlsValue::cast<_mls_Sym>(_mls_x41)->_mls_a;
    auto _mls_x529 = _mls_elim_case0_sr_post(_mls_x528);
    auto [_mls_x530, _mls_x531] = _mls_split_pre(_mls_x529);
    auto _mls_x532 = _mls_splitHelper(_mls_x530, _mls_x531);
    _mls_retval = _mls_clauses_caller_post_caller_post_caller_post_post(_mls_x532);
  } else if (_mlsValue::isValueOf<_mls_Not>(_mls_x41)) {
    auto _mls_x525 = _mlsValue::cast<_mls_Not>(_mls_x41)->_mls_a;
    auto _mls_x526 = _mls_elim_case1_sr_post(_mls_x525);
    auto _mls_x527 = _mls_negin_case0(_mls_x526);
    _mls_retval = _mls_clauses_caller_post_caller_post(_mls_x527);
  } else if (_mlsValue::isValueOf<_mls_Dis>(_mls_x41)) {
    auto _mls_x515 = _mlsValue::cast<_mls_Dis>(_mls_x41)->_mls_a;
    auto _mls_x516 = _mlsValue::cast<_mls_Dis>(_mls_x41)->_mls_b;
    auto _mls_x517 = _mls_elim_case2_sr_post(_mls_x515, _mls_x516);
    auto _mls_x518 = _mlsValue::cast<_mls_Dis>(_mls_x517)->_mls_a;
    auto _mls_x519 = _mlsValue::cast<_mls_Dis>(_mls_x517)->_mls_b;
    auto _mls_x520 = _mls_negin_case1_sr_post(_mls_x518, _mls_x519);
    auto _mls_x521 = _mlsValue::cast<_mls_Dis>(_mls_x520)->_mls_a;
    auto _mls_x522 = _mlsValue::cast<_mls_Dis>(_mls_x520)->_mls_b;
    auto _mls_x523 = _mls_disin_case0_sr_post(_mls_x522, _mls_x521);
    auto _mls_x524 = _mls_split(_mls_x523);
    _mls_retval = _mls_clauses_caller_post_caller_post_caller_post_post(_mls_x524);
  } else if (_mlsValue::isValueOf<_mls_Con>(_mls_x41)) {
    auto _mls_x505 = _mlsValue::cast<_mls_Con>(_mls_x41)->_mls_a;
    auto _mls_x506 = _mlsValue::cast<_mls_Con>(_mls_x41)->_mls_b;
    auto _mls_x507 = _mls_elim_case3_sr_post(_mls_x505, _mls_x506);
    auto _mls_x508 = _mlsValue::cast<_mls_Con>(_mls_x507)->_mls_a;
    auto _mls_x509 = _mlsValue::cast<_mls_Con>(_mls_x507)->_mls_b;
    auto _mls_x510 = _mls_negin_case2_sr_post(_mls_x508, _mls_x509);
    auto _mls_x511 = _mlsValue::cast<_mls_Con>(_mls_x510)->_mls_a;
    auto _mls_x512 = _mlsValue::cast<_mls_Con>(_mls_x510)->_mls_b;
    auto _mls_x513 = _mls_disin_case1_sr_post(_mls_x511, _mls_x512);
    auto _mls_x514 = _mls_split(_mls_x513);
    _mls_retval = _mls_clauses_caller_post_caller_post_caller_post_post(_mls_x514);
  } else if (_mlsValue::isValueOf<_mls_Imp>(_mls_x41)) {
    auto _mls_x495 = _mlsValue::cast<_mls_Imp>(_mls_x41)->_mls_a;
    auto _mls_x496 = _mlsValue::cast<_mls_Imp>(_mls_x41)->_mls_b;
    auto _mls_x497 = _mls_elim_case4_sr_post(_mls_x495, _mls_x496);
    auto _mls_x498 = _mlsValue::cast<_mls_Dis>(_mls_x497)->_mls_a;
    auto _mls_x499 = _mlsValue::cast<_mls_Dis>(_mls_x497)->_mls_b;
    auto _mls_x500 = _mls_negin_case1_sr_post(_mls_x498, _mls_x499);
    auto _mls_x501 = _mlsValue::cast<_mls_Dis>(_mls_x500)->_mls_a;
    auto _mls_x502 = _mlsValue::cast<_mls_Dis>(_mls_x500)->_mls_b;
    auto _mls_x503 = _mls_disin_case0_sr_post(_mls_x502, _mls_x501);
    auto _mls_x504 = _mls_split(_mls_x503);
    _mls_retval = _mls_clauses_caller_post_caller_post_caller_post_post(_mls_x504);
  } else if (_mlsValue::isValueOf<_mls_Eqv>(_mls_x41)) {
    auto _mls_x485 = _mlsValue::cast<_mls_Eqv>(_mls_x41)->_mls_a;
    auto _mls_x486 = _mlsValue::cast<_mls_Eqv>(_mls_x41)->_mls_b;
    auto _mls_x487 = _mls_elim_case5_sr_post(_mls_x485, _mls_x486);
    auto _mls_x488 = _mlsValue::cast<_mls_Con>(_mls_x487)->_mls_a;
    auto _mls_x489 = _mlsValue::cast<_mls_Con>(_mls_x487)->_mls_b;
    auto _mls_x490 = _mls_negin_case2_sr_post(_mls_x488, _mls_x489);
    auto _mls_x491 = _mlsValue::cast<_mls_Con>(_mls_x490)->_mls_a;
    auto _mls_x492 = _mlsValue::cast<_mls_Con>(_mls_x490)->_mls_b;
    auto _mls_x493 = _mls_disin_case1_sr_post(_mls_x491, _mls_x492);
    auto _mls_x494 = _mls_split(_mls_x493);
    _mls_retval = _mls_clauses_caller_post_caller_post_caller_post_post(_mls_x494);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_clauses_caller_post_caller_post(_mlsValue _mls_x533) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Dis>(_mls_x533)) {
    auto _mls_x541 = _mlsValue::cast<_mls_Dis>(_mls_x533)->_mls_a;
    auto _mls_x542 = _mlsValue::cast<_mls_Dis>(_mls_x533)->_mls_b;
    auto _mls_x543 = _mls_disin_case0_sr_post(_mls_x542, _mls_x541);
    auto _mls_x544 = _mls_split(_mls_x543);
    _mls_retval = _mls_clauses_caller_post_caller_post_caller_post_post(_mls_x544);
  } else if (_mlsValue::isValueOf<_mls_Con>(_mls_x533)) {
    auto _mls_x537 = _mlsValue::cast<_mls_Con>(_mls_x533)->_mls_a;
    auto _mls_x538 = _mlsValue::cast<_mls_Con>(_mls_x533)->_mls_b;
    auto _mls_x539 = _mls_disin_case1_sr_post(_mls_x537, _mls_x538);
    auto _mls_x540 = _mls_split(_mls_x539);
    _mls_retval = _mls_clauses_caller_post_caller_post_caller_post_post(_mls_x540);
  } else {
    auto [_mls_x534, _mls_x535] = _mls_split_pre(_mls_x533);
    auto _mls_x536 = _mls_splitHelper(_mls_x534, _mls_x535);
    _mls_retval = _mls_clauses_caller_post_caller_post_caller_post_post(_mls_x536);
  }
  return _mls_retval;
}
_mlsValue _mls_clauses_caller_post_caller_post_caller_post_post(_mlsValue _mls_x545) {
  _mlsValue _mls_retval;
  auto _mls_x546 = _mls_unicl(_mls_x545);
  auto _mls_x547 = _mlsValue::create<_mls_Lambda_disp>();
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x546)) {
    auto _mls_x550 = _mlsValue::cast<_mls_Cons>(_mls_x546)->_mls_head;
    auto _mls_x551 = _mlsValue::cast<_mls_Cons>(_mls_x546)->_mls_tail;
    auto _mls_x552 = _mls_map_case0_sr_post(_mls_x547, _mls_x550, _mls_x551);
    auto _mls_x553 = _mls_concat(_mls_x552);
    _mls_retval = _mls_x553;
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x546)) {
    auto _mls_x548 = _mls_map_case1();
    auto _mls_x549 = _mls_concat_case0();
    _mls_retval = _mls_x549;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_concat(_mlsValue _mls_x554) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x554)) {
    _mls_retval = _mls_concat_case0();
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x554)) {
    _mls_retval = _mls_concat_case1(_mls_x554);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_concat_case0() {
  _mlsValue _mls_retval;
  auto _mls_x555 = _mlsValue::create<_mls_Nil>();
  _mls_retval = _mls_x555;
  return _mls_retval;
}
_mlsValue _mls_concat_case1(_mlsValue _mls_x557) {
  _mlsValue _mls_retval;
  auto _mls_x556 = _mlsValue::cast<_mls_Cons>(_mls_x557)->_mls_head;
  auto _mls_x558 = _mlsValue::cast<_mls_Cons>(_mls_x557)->_mls_tail;
  _mls_retval = _mls_concat_case1_sr_post(_mls_x558, _mls_x556);
  return _mls_retval;
}
_mlsValue _mls_concat_case11(_mlsValue _mls_x560) {
  _mlsValue _mls_retval;
  auto _mls_x559 = _mlsValue::cast<_mls_Cons>(_mls_x560)->_mls_head;
  auto _mls_x561 = _mlsValue::cast<_mls_Cons>(_mls_x560)->_mls_tail;
  _mls_retval = _mls_concat_case1_sr_post(_mls_x561, _mls_x559);
  return _mls_retval;
}
_mlsValue _mls_concat_case1_sr_post(_mlsValue _mls_x562, _mlsValue _mls_x564) {
  _mlsValue _mls_retval;
  auto _mls_x563 = _mls_concat(_mls_x562);
  auto _mls_x565 = _mls_append(_mls_x564, _mls_x563);
  _mls_retval = _mls_x565;
  return _mls_retval;
}
_mlsValue _mls_conjunct(_mlsValue _mls_p2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Con>(_mls_p2)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else {
    _mls_retval = _mlsValue::fromIntLit(0);
  }
  return _mls_retval;
}
_mlsValue _mls_disin(_mlsValue _mls_x566) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Dis>(_mls_x566)) {
    _mls_retval = _mls_disin_case0(_mls_x566);
  } else if (_mlsValue::isValueOf<_mls_Con>(_mls_x566)) {
    _mls_retval = _mls_disin_case1(_mls_x566);
  } else {
    _mls_retval = _mls_x566;
  }
  return _mls_retval;
}
_mlsValue _mls_disin_case0(_mlsValue _mls_x568) {
  _mlsValue _mls_retval;
  auto _mls_x567 = _mlsValue::cast<_mls_Dis>(_mls_x568)->_mls_a;
  auto _mls_x569 = _mlsValue::cast<_mls_Dis>(_mls_x568)->_mls_b;
  _mls_retval = _mls_disin_case0_sr_post(_mls_x569, _mls_x567);
  return _mls_retval;
}
_mlsValue _mls_disin_case0_caller_post(_mlsValue _mls_x570, _mlsValue _mls_x571) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Dis>(_mls_x570)) {
    _mls_retval = _mls_disin_case0_caller_post_case0(_mls_x570, _mls_x571);
  } else if (_mlsValue::isValueOf<_mls_Con>(_mls_x570)) {
    _mls_retval = _mls_disin_case0_caller_post_case1(_mls_x570, _mls_x571);
  } else {
    _mls_retval = _mls_disin_case0_caller_post_default(_mls_x571, _mls_x570);
  }
  return _mls_retval;
}
_mlsValue _mls_disin_case0_caller_post_caller_post(_mlsValue _mls_x572, _mlsValue _mls_x574) {
  _mlsValue _mls_retval;
  auto _mls_x573 = _mls_conjunct(_mls_x572);
  auto _mls_x575 = _mls_conjunct(_mls_x574);
  _mls_retval = _mls_disin_case0_caller_post_caller_post_post(_mls_x573, _mls_x575, _mls_x572, _mls_x574);
  return _mls_retval;
}
_mlsValue _mls_disin_case0_caller_post_caller_post1(_mlsValue _mls_x577, _mlsValue _mls_x578) {
  _mlsValue _mls_retval;
  auto _mls_x576 = _mlsValue::create<_mls_Con>(_mls_x577, _mls_x578);
  _mls_retval = _mls_x576;
  return _mls_retval;
}
_mlsValue _mls_disin_case0_caller_post_caller_post2(_mlsValue _mls_x580, _mlsValue _mls_x581) {
  _mlsValue _mls_retval;
  auto _mls_x579 = _mlsValue::create<_mls_Con>(_mls_x580, _mls_x581);
  _mls_retval = _mls_x579;
  return _mls_retval;
}
_mlsValue _mls_disin_case0_caller_post_caller_post_post(_mlsValue _mls_x583, _mlsValue _mls_x584, _mlsValue _mls_x586, _mlsValue _mls_x587) {
  _mlsValue _mls_retval;
  auto _mls_x582 = (_mls_x583 || _mls_x584);
  if (_mlsValue::isIntLit(_mls_x582, 1)) {
    auto _mls_x588 = _mlsValue::create<_mls_Dis>(_mls_x586, _mls_x587);
    auto _mls_x589 = _mls_disin_case0(_mls_x588);
    _mls_retval = _mls_x589;
  } else {
    auto _mls_x585 = _mlsValue::create<_mls_Dis>(_mls_x586, _mls_x587);
    _mls_retval = _mls_x585;
  }
  return _mls_retval;
}
_mlsValue _mls_disin_case0_caller_post_case01(_mlsValue _mls_x591, _mlsValue _mls_x594) {
  _mlsValue _mls_retval;
  auto _mls_x590 = _mlsValue::cast<_mls_Dis>(_mls_x591)->_mls_a;
  auto _mls_x592 = _mlsValue::cast<_mls_Dis>(_mls_x591)->_mls_b;
  auto _mls_x593 = _mls_disin_case0_sr_post(_mls_x592, _mls_x590);
  _mls_retval = _mls_disin_case0_caller_post_caller_post(_mls_x594, _mls_x593);
  return _mls_retval;
}
_mlsValue _mls_disin_case0_caller_post_case0(_mlsValue _mls_x596, _mlsValue _mls_x599) {
  _mlsValue _mls_retval;
  auto _mls_x595 = _mlsValue::cast<_mls_Dis>(_mls_x596)->_mls_a;
  auto _mls_x597 = _mlsValue::cast<_mls_Dis>(_mls_x596)->_mls_b;
  auto _mls_x598 = _mls_disin_case0_sr_post(_mls_x597, _mls_x595);
  _mls_retval = _mls_disin_case0_caller_post_caller_post(_mls_x599, _mls_x598);
  return _mls_retval;
}
_mlsValue _mls_disin_case0_caller_post_case11(_mlsValue _mls_x601, _mlsValue _mls_x604) {
  _mlsValue _mls_retval;
  auto _mls_x600 = _mlsValue::cast<_mls_Con>(_mls_x601)->_mls_a;
  auto _mls_x602 = _mlsValue::cast<_mls_Con>(_mls_x601)->_mls_b;
  auto _mls_x603 = _mls_disin_case1_sr_post(_mls_x600, _mls_x602);
  _mls_retval = _mls_disin_case0_caller_post_caller_post(_mls_x604, _mls_x603);
  return _mls_retval;
}
_mlsValue _mls_disin_case0_caller_post_case1(_mlsValue _mls_x606, _mlsValue _mls_x609) {
  _mlsValue _mls_retval;
  auto _mls_x605 = _mlsValue::cast<_mls_Con>(_mls_x606)->_mls_a;
  auto _mls_x607 = _mlsValue::cast<_mls_Con>(_mls_x606)->_mls_b;
  auto _mls_x608 = _mls_disin_case1_sr_post(_mls_x605, _mls_x607);
  _mls_retval = _mls_disin_case0_caller_post_caller_post(_mls_x609, _mls_x608);
  return _mls_retval;
}
_mlsValue _mls_disin_case0_caller_post_default(_mlsValue _mls_x610, _mlsValue _mls_x612) {
  _mlsValue _mls_retval;
  auto _mls_x611 = _mls_conjunct(_mls_x610);
  auto _mls_x613 = _mls_conjunct(_mls_x612);
  _mls_retval = _mls_disin_case0_caller_post_caller_post_post(_mls_x611, _mls_x613, _mls_x610, _mls_x612);
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_disin_case0_caller_post_default_pre(_mlsValue _mls_x614, _mlsValue _mls_x616) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x615 = _mls_conjunct(_mls_x614);
  auto _mls_x617 = _mls_conjunct(_mls_x616);
  _mls_retval = std::make_tuple(_mls_x615, _mls_x617, _mls_x614, _mls_x616);
  return _mls_retval;
}
_mlsValue _mls_disin_case0_sr_post(_mlsValue _mls_x618, _mlsValue _mls_x619) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Con>(_mls_x618)) {
    auto _mls_x643 = _mlsValue::cast<_mls_Con>(_mls_x618)->_mls_a;
    auto _mls_x644 = _mlsValue::cast<_mls_Con>(_mls_x618)->_mls_b;
    if (_mlsValue::isValueOf<_mls_Con>(_mls_x643)) {
      auto _mls_x647 = _mls_disin_case0_sr_post_case0(_mls_x643, _mls_x619);
      auto _mls_x648 = _mls_disin_case0_sr_post(_mls_x644, _mls_x619);
      _mls_retval = _mls_disin_case0_caller_post_caller_post1(_mls_x647, _mls_x648);
    } else {
      auto _mls_x645 = _mls_disin_case0_sr_post_default(_mls_x619, _mls_x643);
      auto _mls_x646 = _mls_disin_case0_sr_post(_mls_x644, _mls_x619);
      _mls_retval = _mls_disin_case0_caller_post_caller_post1(_mls_x645, _mls_x646);
    }
  } else {
    if (_mlsValue::isValueOf<_mls_Con>(_mls_x619)) {
      auto _mls_x637 = _mlsValue::cast<_mls_Con>(_mls_x619)->_mls_a;
      auto _mls_x638 = _mlsValue::cast<_mls_Con>(_mls_x619)->_mls_b;
      if (_mlsValue::isValueOf<_mls_Con>(_mls_x618)) {
        auto _mls_x641 = _mls_disin_case0_sr_post_case0(_mls_x618, _mls_x637);
        auto _mls_x642 = _mls_disin_case0_sr_post(_mls_x618, _mls_x638);
        _mls_retval = _mls_disin_case0_caller_post_caller_post2(_mls_x641, _mls_x642);
      } else {
        auto _mls_x639 = _mls_disin_case0_sr_post_default(_mls_x637, _mls_x618);
        auto _mls_x640 = _mls_disin_case0_sr_post(_mls_x618, _mls_x638);
        _mls_retval = _mls_disin_case0_caller_post_caller_post2(_mls_x639, _mls_x640);
      }
    } else {
      if (_mlsValue::isValueOf<_mls_Dis>(_mls_x619)) {
        auto _mls_x633 = _mlsValue::cast<_mls_Dis>(_mls_x619)->_mls_a;
        auto _mls_x634 = _mlsValue::cast<_mls_Dis>(_mls_x619)->_mls_b;
        if (_mlsValue::isValueOf<_mls_Con>(_mls_x634)) {
          auto _mls_x636 = _mls_disin_case0_sr_post_case0(_mls_x634, _mls_x633);
          _mls_retval = _mls_disin_case0_caller_post(_mls_x618, _mls_x636);
        } else {
          auto _mls_x635 = _mls_disin_case0_sr_post_default(_mls_x633, _mls_x634);
          _mls_retval = _mls_disin_case0_caller_post(_mls_x618, _mls_x635);
        }
      } else if (_mlsValue::isValueOf<_mls_Con>(_mls_x619)) {
        auto _mls_x630 = _mlsValue::cast<_mls_Con>(_mls_x619)->_mls_a;
        auto _mls_x631 = _mlsValue::cast<_mls_Con>(_mls_x619)->_mls_b;
        auto _mls_x632 = _mls_disin_case1_sr_post(_mls_x630, _mls_x631);
        if (_mlsValue::isValueOf<_mls_Dis>(_mls_x618)) {
          _mls_retval = _mls_disin_case0_caller_post_case0(_mls_x618, _mls_x632);
        } else if (_mlsValue::isValueOf<_mls_Con>(_mls_x618)) {
          _mls_retval = _mls_disin_case0_caller_post_case1(_mls_x618, _mls_x632);
        } else {
          _mls_retval = _mls_disin_case0_caller_post_default(_mls_x632, _mls_x618);
        }
      } else {
        if (_mlsValue::isValueOf<_mls_Dis>(_mls_x618)) {
          auto _mls_x627 = _mlsValue::cast<_mls_Dis>(_mls_x618)->_mls_a;
          auto _mls_x628 = _mlsValue::cast<_mls_Dis>(_mls_x618)->_mls_b;
          auto _mls_x629 = _mls_disin_case0_sr_post(_mls_x628, _mls_x627);
          _mls_retval = _mls_disin_case0_caller_post_caller_post(_mls_x619, _mls_x629);
        } else if (_mlsValue::isValueOf<_mls_Con>(_mls_x618)) {
          auto _mls_x624 = _mlsValue::cast<_mls_Con>(_mls_x618)->_mls_a;
          auto _mls_x625 = _mlsValue::cast<_mls_Con>(_mls_x618)->_mls_b;
          auto _mls_x626 = _mls_disin_case1_sr_post(_mls_x624, _mls_x625);
          _mls_retval = _mls_disin_case0_caller_post_caller_post(_mls_x619, _mls_x626);
        } else {
          auto [_mls_x620, _mls_x621, _mls_x622, _mls_x623] = _mls_disin_case0_caller_post_default_pre(_mls_x619, _mls_x618);
          _mls_retval = _mls_disin_case0_caller_post_caller_post_post(_mls_x620, _mls_x621, _mls_x622, _mls_x623);
        }
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_disin_case0_sr_post_case0(_mlsValue _mls_x650, _mlsValue _mls_x652) {
  _mlsValue _mls_retval;
  auto _mls_x649 = _mlsValue::cast<_mls_Con>(_mls_x650)->_mls_a;
  auto _mls_x651 = _mlsValue::cast<_mls_Con>(_mls_x650)->_mls_b;
  auto _mls_x653 = _mls_disin_case0_sr_post(_mls_x649, _mls_x652);
  auto _mls_x654 = _mls_disin_case0_sr_post(_mls_x651, _mls_x652);
  _mls_retval = _mls_disin_case0_caller_post_caller_post1(_mls_x653, _mls_x654);
  return _mls_retval;
}
_mlsValue _mls_disin_case0_sr_post_default(_mlsValue _mls_x655, _mlsValue _mls_x656) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Con>(_mls_x655)) {
    auto _mls_x667 = _mlsValue::cast<_mls_Con>(_mls_x655)->_mls_a;
    auto _mls_x668 = _mlsValue::cast<_mls_Con>(_mls_x655)->_mls_b;
    auto _mls_x669 = _mls_disin_case0_sr_post(_mls_x656, _mls_x667);
    auto _mls_x670 = _mls_disin_case0_sr_post(_mls_x656, _mls_x668);
    _mls_retval = _mls_disin_case0_caller_post_caller_post2(_mls_x669, _mls_x670);
  } else {
    if (_mlsValue::isValueOf<_mls_Dis>(_mls_x655)) {
      auto _mls_x664 = _mlsValue::cast<_mls_Dis>(_mls_x655)->_mls_a;
      auto _mls_x665 = _mlsValue::cast<_mls_Dis>(_mls_x655)->_mls_b;
      auto _mls_x666 = _mls_disin_case0_sr_post(_mls_x665, _mls_x664);
      _mls_retval = _mls_disin_case0_caller_post(_mls_x656, _mls_x666);
    } else if (_mlsValue::isValueOf<_mls_Con>(_mls_x655)) {
      auto _mls_x661 = _mlsValue::cast<_mls_Con>(_mls_x655)->_mls_a;
      auto _mls_x662 = _mlsValue::cast<_mls_Con>(_mls_x655)->_mls_b;
      auto _mls_x663 = _mls_disin_case1_sr_post(_mls_x661, _mls_x662);
      _mls_retval = _mls_disin_case0_caller_post(_mls_x656, _mls_x663);
    } else {
      if (_mlsValue::isValueOf<_mls_Dis>(_mls_x656)) {
        _mls_retval = _mls_disin_case0_caller_post_case01(_mls_x656, _mls_x655);
      } else if (_mlsValue::isValueOf<_mls_Con>(_mls_x656)) {
        _mls_retval = _mls_disin_case0_caller_post_case11(_mls_x656, _mls_x655);
      } else {
        auto [_mls_x657, _mls_x658, _mls_x659, _mls_x660] = _mls_disin_case0_caller_post_default_pre(_mls_x655, _mls_x656);
        _mls_retval = _mls_disin_case0_caller_post_caller_post_post(_mls_x657, _mls_x658, _mls_x659, _mls_x660);
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_disin_case1(_mlsValue _mls_x672) {
  _mlsValue _mls_retval;
  auto _mls_x671 = _mlsValue::cast<_mls_Con>(_mls_x672)->_mls_a;
  auto _mls_x673 = _mlsValue::cast<_mls_Con>(_mls_x672)->_mls_b;
  _mls_retval = _mls_disin_case1_sr_post(_mls_x671, _mls_x673);
  return _mls_retval;
}
_mlsValue _mls_disin_case1_sr_post(_mlsValue _mls_x674, _mlsValue _mls_x676) {
  _mlsValue _mls_retval;
  auto _mls_x675 = _mls_disin(_mls_x674);
  auto _mls_x677 = _mls_disin(_mls_x676);
  auto _mls_x678 = _mlsValue::create<_mls_Con>(_mls_x675, _mls_x677);
  _mls_retval = _mls_x678;
  return _mls_retval;
}
_mlsValue _mls_disp(_mlsValue _mls_l_r) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_l_r)) {
    auto _mls_x84 = _mlsValue::cast<_mls_Tuple2>(_mls_l_r)->_mls_field0;
    auto _mls_x85 = _mlsValue::cast<_mls_Tuple2>(_mls_l_r)->_mls_field1;
    auto _mls_x86 = _mls_listLen(_mls_x84);
    auto [_mls_x679, _mls_x680, _mls_x681] = _mls_replicate_pre(_mls_x86, _mlsValue::create<_mls_Str>(" "));
    if (_mlsValue::isIntLit(_mls_x679, 1)) {
      auto _mls_x702 = _mls_replicate_case0();
      if (_mlsValue::isValueOf<_mls_Cons>(_mls_x84)) {
        auto _mls_x718 = _mlsValue::cast<_mls_Cons>(_mls_x84)->_mls_head;
        auto _mls_x719 = _mls_interleave_case1();
        auto _mls_x720 = _mls_interleave_case0_sr_post_post(_mls_x718, _mls_x719);
        _mls_retval = _mls_disp_caller_post_post(_mls_x85, _mls_x720);
      } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x84)) {
        auto _mls_x703 = _mls_interleave_case1();
        auto [_mls_x704, _mls_x705, _mls_x706, _mls_x707, _mls_x708, _mls_x709] = _mls_disp_caller_post_post_pre(_mls_x85, _mls_x703);
        if (_mlsValue::isIntLit(_mls_x707, 1)) {
          auto _mls_x714 = _mls_replicate_case0();
          auto _mls_x715 = _mls_interleave_case1();
          auto _mls_x716 = _mls_str_to_list(_mlsValue::create<_mls_Str>("\n"));
          auto _mls_x717 = _mls_append(_mls_x715, _mls_x716);
          _mls_retval = _mls_disp_caller_post_post_caller_post_caller_post_post(_mls_x706, _mls_x717, _mls_x708);
        } else {
          auto _mls_x710 = _mls_replicate_default(_mls_x705, _mls_x704);
          auto _mls_x711 = _mlsValue::cast<_mls_Cons>(_mls_x710)->_mls_head;
          auto _mls_x712 = _mlsValue::cast<_mls_Cons>(_mls_x710)->_mls_tail;
          auto _mls_x713 = _mls_interleave_case0_sr_post(_mls_x709, _mls_x712, _mls_x711);
          _mls_retval = _mls_disp_caller_post_post_caller_post_caller_post(_mls_x713, _mls_x706, _mls_x708);
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      auto _mls_x682 = _mls_replicate_default(_mls_x680, _mls_x681);
      if (_mlsValue::isValueOf<_mls_Cons>(_mls_x84)) {
        auto _mls_x698 = _mlsValue::cast<_mls_Cons>(_mls_x84)->_mls_head;
        auto _mls_x699 = _mlsValue::cast<_mls_Cons>(_mls_x84)->_mls_tail;
        auto _mls_x700 = _mls_interleave_case0(_mls_x682, _mls_x699);
        auto _mls_x701 = _mls_interleave_case0_sr_post_post(_mls_x698, _mls_x700);
        _mls_retval = _mls_disp_caller_post_post(_mls_x85, _mls_x701);
      } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x84)) {
        auto _mls_x683 = _mls_interleave_case1();
        auto [_mls_x684, _mls_x685, _mls_x686, _mls_x687, _mls_x688, _mls_x689] = _mls_disp_caller_post_post_pre(_mls_x85, _mls_x683);
        if (_mlsValue::isIntLit(_mls_x687, 1)) {
          auto _mls_x694 = _mls_replicate_case0();
          auto _mls_x695 = _mls_interleave_case1();
          auto _mls_x696 = _mls_str_to_list(_mlsValue::create<_mls_Str>("\n"));
          auto _mls_x697 = _mls_append(_mls_x695, _mls_x696);
          _mls_retval = _mls_disp_caller_post_post_caller_post_caller_post_post(_mls_x686, _mls_x697, _mls_x688);
        } else {
          auto _mls_x690 = _mls_replicate_default(_mls_x685, _mls_x684);
          auto _mls_x691 = _mlsValue::cast<_mls_Cons>(_mls_x690)->_mls_head;
          auto _mls_x692 = _mlsValue::cast<_mls_Cons>(_mls_x690)->_mls_tail;
          auto _mls_x693 = _mls_interleave_case0_sr_post(_mls_x689, _mls_x692, _mls_x691);
          _mls_retval = _mls_disp_caller_post_post_caller_post_caller_post(_mls_x693, _mls_x686, _mls_x688);
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_disp_caller_post_post(_mlsValue _mls_x721, _mlsValue _mls_x722) {
  _mlsValue _mls_retval;
  auto [_mls_x723, _mls_x724, _mls_x725, _mls_x726, _mls_x727, _mls_x728] = _mls_disp_caller_post_post_pre(_mls_x721, _mls_x722);
  if (_mlsValue::isIntLit(_mls_x726, 1)) {
    auto _mls_x733 = _mls_replicate_case0();
    auto _mls_x734 = _mls_interleave_case1();
    auto _mls_x735 = _mls_str_to_list(_mlsValue::create<_mls_Str>("\n"));
    auto _mls_x736 = _mls_append(_mls_x734, _mls_x735);
    _mls_retval = _mls_disp_caller_post_post_caller_post_caller_post_post(_mls_x725, _mls_x736, _mls_x727);
  } else {
    auto _mls_x729 = _mls_replicate_default(_mls_x724, _mls_x723);
    auto _mls_x730 = _mlsValue::cast<_mls_Cons>(_mls_x729)->_mls_head;
    auto _mls_x731 = _mlsValue::cast<_mls_Cons>(_mls_x729)->_mls_tail;
    auto _mls_x732 = _mls_interleave_case0_sr_post1(_mls_x728, _mls_x731, _mls_x730);
    _mls_retval = _mls_disp_caller_post_post_caller_post_caller_post(_mls_x732, _mls_x725, _mls_x727);
  }
  return _mls_retval;
}
_mlsValue _mls_disp_caller_post_post_caller_post_caller_post(_mlsValue _mls_x738, _mlsValue _mls_x740, _mlsValue _mls_x741) {
  _mlsValue _mls_retval;
  auto _mls_x737 = _mls_str_to_list(_mlsValue::create<_mls_Str>("\n"));
  auto _mls_x739 = _mls_append(_mls_x738, _mls_x737);
  _mls_retval = _mls_disp_caller_post_post_caller_post_caller_post_post(_mls_x740, _mls_x739, _mls_x741);
  return _mls_retval;
}
_mlsValue _mls_disp_caller_post_post_caller_post_caller_post_post(_mlsValue _mls_x742, _mlsValue _mls_x743, _mlsValue _mls_x745) {
  _mlsValue _mls_retval;
  auto _mls_x744 = _mls_append(_mls_x742, _mls_x743);
  auto _mls_x746 = _mls_append(_mls_x745, _mls_x744);
  _mls_retval = _mls_x746;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_disp_caller_post_post_pre(_mlsValue _mls_x748, _mlsValue _mls_x753) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x747 = _mls_str_to_list(_mlsValue::create<_mls_Str>("<="));
  auto _mls_x749 = _mls_listLen(_mls_x748);
  auto [_mls_x750, _mls_x751, _mls_x752] = _mls_replicate_pre(_mls_x749, _mlsValue::create<_mls_Str>(" "));
  _mls_retval = std::make_tuple(_mls_x752, _mls_x751, _mls_x747, _mls_x750, _mls_x753, _mls_x748);
  return _mls_retval;
}
_mlsValue _mls_elim(_mlsValue _mls_x754) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Sym>(_mls_x754)) {
    auto _mls_x766 = _mlsValue::cast<_mls_Sym>(_mls_x754)->_mls_a;
    _mls_retval = _mls_elim_case0_sr_post(_mls_x766);
  } else if (_mlsValue::isValueOf<_mls_Not>(_mls_x754)) {
    auto _mls_x765 = _mlsValue::cast<_mls_Not>(_mls_x754)->_mls_a;
    _mls_retval = _mls_elim_case1_sr_post(_mls_x765);
  } else if (_mlsValue::isValueOf<_mls_Dis>(_mls_x754)) {
    auto _mls_x763 = _mlsValue::cast<_mls_Dis>(_mls_x754)->_mls_a;
    auto _mls_x764 = _mlsValue::cast<_mls_Dis>(_mls_x754)->_mls_b;
    _mls_retval = _mls_elim_case2_sr_post(_mls_x763, _mls_x764);
  } else if (_mlsValue::isValueOf<_mls_Con>(_mls_x754)) {
    auto _mls_x761 = _mlsValue::cast<_mls_Con>(_mls_x754)->_mls_a;
    auto _mls_x762 = _mlsValue::cast<_mls_Con>(_mls_x754)->_mls_b;
    _mls_retval = _mls_elim_case3_sr_post(_mls_x761, _mls_x762);
  } else if (_mlsValue::isValueOf<_mls_Imp>(_mls_x754)) {
    auto _mls_x759 = _mlsValue::cast<_mls_Imp>(_mls_x754)->_mls_a;
    auto _mls_x760 = _mlsValue::cast<_mls_Imp>(_mls_x754)->_mls_b;
    _mls_retval = _mls_elim_case4_sr_post(_mls_x759, _mls_x760);
  } else if (_mlsValue::isValueOf<_mls_Eqv>(_mls_x754)) {
    auto _mls_x755 = _mlsValue::cast<_mls_Eqv>(_mls_x754)->_mls_a;
    auto _mls_x756 = _mlsValue::cast<_mls_Eqv>(_mls_x754)->_mls_b;
    auto _mls_x757 = _mls_elim_case4_sr_post(_mls_x755, _mls_x756);
    auto _mls_x758 = _mls_elim_case4_sr_post(_mls_x756, _mls_x755);
    _mls_retval = _mls_elim_case5_sr_post_caller_post_caller_post(_mls_x757, _mls_x758);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_elim_case0_sr_post(_mlsValue _mls_x768) {
  _mlsValue _mls_retval;
  auto _mls_x767 = _mlsValue::create<_mls_Sym>(_mls_x768);
  _mls_retval = _mls_x767;
  return _mls_retval;
}
_mlsValue _mls_elim_case1_sr_post(_mlsValue _mls_x769) {
  _mlsValue _mls_retval;
  auto _mls_x770 = _mls_elim(_mls_x769);
  auto _mls_x771 = _mlsValue::create<_mls_Not>(_mls_x770);
  _mls_retval = _mls_x771;
  return _mls_retval;
}
_mlsValue _mls_elim_case2_sr_post(_mlsValue _mls_x772, _mlsValue _mls_x774) {
  _mlsValue _mls_retval;
  auto _mls_x773 = _mls_elim(_mls_x772);
  auto _mls_x775 = _mls_elim(_mls_x774);
  auto _mls_x776 = _mlsValue::create<_mls_Dis>(_mls_x773, _mls_x775);
  _mls_retval = _mls_x776;
  return _mls_retval;
}
_mlsValue _mls_elim_case3_sr_post(_mlsValue _mls_x777, _mlsValue _mls_x779) {
  _mlsValue _mls_retval;
  auto _mls_x778 = _mls_elim(_mls_x777);
  auto _mls_x780 = _mls_elim(_mls_x779);
  auto _mls_x781 = _mlsValue::create<_mls_Con>(_mls_x778, _mls_x780);
  _mls_retval = _mls_x781;
  return _mls_retval;
}
_mlsValue _mls_elim_case4_sr_post(_mlsValue _mls_x782, _mlsValue _mls_x785) {
  _mlsValue _mls_retval;
  auto _mls_x783 = _mls_elim(_mls_x782);
  auto _mls_x784 = _mlsValue::create<_mls_Not>(_mls_x783);
  auto _mls_x786 = _mls_elim(_mls_x785);
  auto _mls_x787 = _mlsValue::create<_mls_Dis>(_mls_x784, _mls_x786);
  _mls_retval = _mls_x787;
  return _mls_retval;
}
_mlsValue _mls_elim_case5_sr_post(_mlsValue _mls_x788, _mlsValue _mls_x789) {
  _mlsValue _mls_retval;
  auto _mls_x790 = _mls_elim_case4_sr_post(_mls_x788, _mls_x789);
  auto _mls_x791 = _mls_elim_case4_sr_post(_mls_x789, _mls_x788);
  _mls_retval = _mls_elim_case5_sr_post_caller_post_caller_post(_mls_x790, _mls_x791);
  return _mls_retval;
}
_mlsValue _mls_elim_case5_sr_post_caller_post_caller_post(_mlsValue _mls_x793, _mlsValue _mls_x794) {
  _mlsValue _mls_retval;
  auto _mls_x792 = _mlsValue::create<_mls_Con>(_mls_x793, _mls_x794);
  _mls_retval = _mls_x792;
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x125 = _mls_testClausify_nofib(_mlsValue::fromIntLit(200));
  _mls_retval = _mls_x125;
  return _mls_retval;
}
_mlsValue _mls_foldr(_mlsValue _mls_f1, _mlsValue _mls_z, _mlsValue _mls_xs1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs1)) {
    _mls_retval = _mls_z;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs1)) {
    auto _mls_x126 = _mlsValue::cast<_mls_Cons>(_mls_xs1)->_mls_head;
    auto _mls_x127 = _mlsValue::cast<_mls_Cons>(_mls_xs1)->_mls_tail;
    auto _mls_x128 = _mls_foldr(_mls_f1, _mls_z, _mls_x127);
    auto _mls_x129 = _mlsMethodCall<_mls_Callable>(_mls_f1)->_mls_apply2(_mls_x126, _mls_x128);
    _mls_retval = _mls_x129;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_inList(_mlsValue _mls_x133, _mlsValue _mls_ls3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls3)) {
    auto _mls_x130 = _mlsValue::cast<_mls_Cons>(_mls_ls3)->_mls_head;
    auto _mls_x131 = _mlsValue::cast<_mls_Cons>(_mls_ls3)->_mls_tail;
    auto _mls_x132 = (_mls_x133 == _mls_x130);
    if (_mlsValue::isIntLit(_mls_x132, 1)) {
      _mls_retval = _mlsValue::fromIntLit(1);
    } else {
      auto _mls_x134 = _mls_inList(_mls_x133, _mls_x131);
      _mls_retval = _mls_x134;
    }
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls3)) {
    _mls_retval = _mlsValue::fromIntLit(0);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_insert(_mlsValue _mls_x138, _mlsValue _mls_ys1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ys1)) {
    auto _mls_x145 = _mlsValue::create<_mls_Nil>();
    auto _mls_x146 = _mlsValue::create<_mls_Cons>(_mls_x138, _mls_x145);
    _mls_retval = _mls_x146;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ys1)) {
    auto _mls_x135 = _mlsValue::cast<_mls_Cons>(_mls_ys1)->_mls_head;
    auto _mls_x136 = _mlsValue::cast<_mls_Cons>(_mls_ys1)->_mls_tail;
    auto _mls_x795 = _mls_builtin_str_lt(_mls_x138, _mls_x135);
    if (_mlsValue::isIntLit(_mls_x795, 1)) {
      auto _mls_x143 = _mlsValue::create<_mls_Cons>(_mls_x135, _mls_x136);
      auto _mls_x144 = _mlsValue::create<_mls_Cons>(_mls_x138, _mls_x143);
      _mls_retval = _mls_x144;
    } else {
      auto _mls_x796 = _mls_builtin_str_gt(_mls_x138, _mls_x135);
      if (_mlsValue::isIntLit(_mls_x796, 1)) {
        auto _mls_x141 = _mls_insert(_mls_x138, _mls_x136);
        auto _mls_x142 = _mlsValue::create<_mls_Cons>(_mls_x135, _mls_x141);
        _mls_retval = _mls_x142;
      } else {
        auto _mls_x140 = _mlsValue::create<_mls_Cons>(_mls_x135, _mls_x136);
        _mls_retval = _mls_x140;
      }
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_interleave(_mlsValue _mls_x797, _mlsValue _mls_x798) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x797)) {
    _mls_retval = _mls_interleave_case0(_mls_x797, _mls_x798);
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x797)) {
    _mls_retval = _mls_interleave_case1();
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_interleave_case0(_mlsValue _mls_x800, _mlsValue _mls_x802) {
  _mlsValue _mls_retval;
  auto _mls_x799 = _mlsValue::cast<_mls_Cons>(_mls_x800)->_mls_head;
  auto _mls_x801 = _mlsValue::cast<_mls_Cons>(_mls_x800)->_mls_tail;
  auto _mls_x803 = _mls_interleave(_mls_x802, _mls_x801);
  _mls_retval = _mls_interleave_case0_sr_post_post(_mls_x799, _mls_x803);
  return _mls_retval;
}
_mlsValue _mls_interleave_case0_sr_post(_mlsValue _mls_x804, _mlsValue _mls_x805, _mlsValue _mls_x807) {
  _mlsValue _mls_retval;
  auto _mls_x806 = _mls_interleave(_mls_x804, _mls_x805);
  _mls_retval = _mls_interleave_case0_sr_post_post(_mls_x807, _mls_x806);
  return _mls_retval;
}
_mlsValue _mls_interleave_case0_sr_post1(_mlsValue _mls_x808, _mlsValue _mls_x809, _mlsValue _mls_x811) {
  _mlsValue _mls_retval;
  auto _mls_x810 = _mls_interleave(_mls_x808, _mls_x809);
  _mls_retval = _mls_interleave_case0_sr_post_post(_mls_x811, _mls_x810);
  return _mls_retval;
}
_mlsValue _mls_interleave_case0_sr_post_post(_mlsValue _mls_x813, _mlsValue _mls_x814) {
  _mlsValue _mls_retval;
  auto _mls_x812 = _mlsValue::create<_mls_Cons>(_mls_x813, _mls_x814);
  _mls_retval = _mls_x812;
  return _mls_retval;
}
_mlsValue _mls_interleave_case1() {
  _mlsValue _mls_retval;
  auto _mls_x815 = _mlsValue::create<_mls_Nil>();
  _mls_retval = _mls_x815;
  return _mls_retval;
}
_mlsValue _mls_listLen(_mlsValue _mls_ls4) {
  _mlsValue _mls_retval;
  auto _mls_x152 = _mlsValue::create<_mls_Lambda_l>();
  auto _mls_x153 = _mlsMethodCall<_mls_Callable>(_mls_x152)->_mls_apply2(_mls_ls4, _mlsValue::fromIntLit(0));
  _mls_retval = _mls_x153;
  return _mls_retval;
}
_mlsValue _mls_list_to_str(_mlsValue _mls_x816) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x816)) {
    _mls_retval = _mlsValue::create<_mls_Str>("");
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x816)) {
    auto _mls_x817 = _mlsValue::cast<_mls_Cons>(_mls_x816)->_mls_head;
    auto _mls_x818 = _mlsValue::cast<_mls_Cons>(_mls_x816)->_mls_tail;
    _mls_retval = _mls_list_to_str_case1_sr_post(_mls_x818, _mls_x817);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_list_to_str_case1_sr_post(_mlsValue _mls_x819, _mlsValue _mls_x822) {
  _mlsValue _mls_retval;
  auto _mls_x820 = _mls_list_to_str(_mls_x819);
  auto _mls_x821 = _mls_builtin_str_concat(_mls_x822, _mls_x820);
  _mls_retval = _mls_x821;
  return _mls_retval;
}
_mlsValue _mls_map(_mlsValue _mls_x826, _mlsValue _mls_x823) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x823)) {
    auto _mls_x824 = _mlsValue::cast<_mls_Cons>(_mls_x823)->_mls_head;
    auto _mls_x825 = _mlsValue::cast<_mls_Cons>(_mls_x823)->_mls_tail;
    _mls_retval = _mls_map_case0_sr_post(_mls_x826, _mls_x824, _mls_x825);
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x823)) {
    _mls_retval = _mls_map_case1();
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_map_case0_sr_post(_mlsValue _mls_x827, _mlsValue _mls_x828, _mlsValue _mls_x830) {
  _mlsValue _mls_retval;
  auto _mls_x829 = _mlsMethodCall<_mls_Callable>(_mls_x827)->_mls_apply1(_mls_x828);
  auto _mls_x831 = _mls_map(_mls_x827, _mls_x830);
  auto _mls_x832 = _mlsValue::create<_mls_Cons>(_mls_x829, _mls_x831);
  _mls_retval = _mls_x832;
  return _mls_retval;
}
_mlsValue _mls_map_case1() {
  _mlsValue _mls_retval;
  auto _mls_x833 = _mlsValue::create<_mls_Nil>();
  _mls_retval = _mls_x833;
  return _mls_retval;
}
_mlsValue _mls_negin(_mlsValue _mls_x834) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Not>(_mls_x834)) {
    _mls_retval = _mls_negin_case0(_mls_x834);
  } else if (_mlsValue::isValueOf<_mls_Dis>(_mls_x834)) {
    auto _mls_x837 = _mlsValue::cast<_mls_Dis>(_mls_x834)->_mls_a;
    auto _mls_x838 = _mlsValue::cast<_mls_Dis>(_mls_x834)->_mls_b;
    _mls_retval = _mls_negin_case1_sr_post(_mls_x837, _mls_x838);
  } else if (_mlsValue::isValueOf<_mls_Con>(_mls_x834)) {
    auto _mls_x835 = _mlsValue::cast<_mls_Con>(_mls_x834)->_mls_a;
    auto _mls_x836 = _mlsValue::cast<_mls_Con>(_mls_x834)->_mls_b;
    _mls_retval = _mls_negin_case2_sr_post(_mls_x835, _mls_x836);
  } else {
    _mls_retval = _mls_x834;
  }
  return _mls_retval;
}
_mlsValue _mls_negin_case0(_mlsValue _mls_x840) {
  _mlsValue _mls_retval;
  auto _mls_x839 = _mlsValue::cast<_mls_Not>(_mls_x840)->_mls_a;
  if (_mlsValue::isValueOf<_mls_Not>(_mls_x839)) {
    auto _mls_x849 = _mlsValue::cast<_mls_Not>(_mls_x839)->_mls_a;
    auto _mls_x850 = _mls_negin(_mls_x849);
    _mls_retval = _mls_x850;
  } else if (_mlsValue::isValueOf<_mls_Con>(_mls_x839)) {
    auto _mls_x845 = _mlsValue::cast<_mls_Con>(_mls_x839)->_mls_a;
    auto _mls_x846 = _mlsValue::cast<_mls_Con>(_mls_x839)->_mls_b;
    auto _mls_x847 = _mlsValue::create<_mls_Not>(_mls_x845);
    auto _mls_x848 = _mls_negin_case0(_mls_x847);
    _mls_retval = _mls_negin_case0_caller_post1(_mls_x846, _mls_x848);
  } else if (_mlsValue::isValueOf<_mls_Dis>(_mls_x839)) {
    auto _mls_x841 = _mlsValue::cast<_mls_Dis>(_mls_x839)->_mls_a;
    auto _mls_x842 = _mlsValue::cast<_mls_Dis>(_mls_x839)->_mls_b;
    auto _mls_x843 = _mlsValue::create<_mls_Not>(_mls_x841);
    auto _mls_x844 = _mls_negin_case0(_mls_x843);
    _mls_retval = _mls_negin_case0_caller_post(_mls_x842, _mls_x844);
  } else {
    _mls_retval = _mls_x840;
  }
  return _mls_retval;
}
_mlsValue _mls_negin_case0_caller_post(_mlsValue _mls_x852, _mlsValue _mls_x854) {
  _mlsValue _mls_retval;
  auto _mls_x851 = _mlsValue::create<_mls_Not>(_mls_x852);
  auto _mls_x853 = _mls_negin_case0(_mls_x851);
  _mls_retval = _mls_negin_case0_caller_post_caller_post(_mls_x854, _mls_x853);
  return _mls_retval;
}
_mlsValue _mls_negin_case0_caller_post1(_mlsValue _mls_x856, _mlsValue _mls_x858) {
  _mlsValue _mls_retval;
  auto _mls_x855 = _mlsValue::create<_mls_Not>(_mls_x856);
  auto _mls_x857 = _mls_negin_case0(_mls_x855);
  _mls_retval = _mls_negin_case0_caller_post_caller_post1(_mls_x858, _mls_x857);
  return _mls_retval;
}
_mlsValue _mls_negin_case0_caller_post_caller_post1(_mlsValue _mls_x860, _mlsValue _mls_x861) {
  _mlsValue _mls_retval;
  auto _mls_x859 = _mlsValue::create<_mls_Dis>(_mls_x860, _mls_x861);
  _mls_retval = _mls_x859;
  return _mls_retval;
}
_mlsValue _mls_negin_case0_caller_post_caller_post(_mlsValue _mls_x863, _mlsValue _mls_x864) {
  _mlsValue _mls_retval;
  auto _mls_x862 = _mlsValue::create<_mls_Con>(_mls_x863, _mls_x864);
  _mls_retval = _mls_x862;
  return _mls_retval;
}
_mlsValue _mls_negin_case1_sr_post(_mlsValue _mls_x865, _mlsValue _mls_x867) {
  _mlsValue _mls_retval;
  auto _mls_x866 = _mls_negin(_mls_x865);
  auto _mls_x868 = _mls_negin(_mls_x867);
  auto _mls_x869 = _mlsValue::create<_mls_Dis>(_mls_x866, _mls_x868);
  _mls_retval = _mls_x869;
  return _mls_retval;
}
_mlsValue _mls_negin_case2_sr_post(_mlsValue _mls_x870, _mlsValue _mls_x872) {
  _mlsValue _mls_retval;
  auto _mls_x871 = _mls_negin(_mls_x870);
  auto _mls_x873 = _mls_negin(_mls_x872);
  auto _mls_x874 = _mlsValue::create<_mls_Con>(_mls_x871, _mls_x873);
  _mls_retval = _mls_x874;
  return _mls_retval;
}
_mlsValue _mls_opri(_mlsValue _mls_c) {
  _mlsValue _mls_retval;
  auto _mls_x197 = (_mls_c == _mlsValue::create<_mls_Str>("("));
  if (_mlsValue::isIntLit(_mls_x197, 1)) {
    _mls_retval = _mlsValue::fromIntLit(0);
  } else {
    auto _mls_x198 = (_mls_c == _mlsValue::create<_mls_Str>("="));
    if (_mlsValue::isIntLit(_mls_x198, 1)) {
      _mls_retval = _mlsValue::fromIntLit(1);
    } else {
      auto _mls_x199 = (_mls_c == _mlsValue::create<_mls_Str>(">"));
      if (_mlsValue::isIntLit(_mls_x199, 1)) {
        _mls_retval = _mlsValue::fromIntLit(2);
      } else {
        auto _mls_x200 = (_mls_c == _mlsValue::create<_mls_Str>("|"));
        if (_mlsValue::isIntLit(_mls_x200, 1)) {
          _mls_retval = _mlsValue::fromIntLit(3);
        } else {
          auto _mls_x201 = (_mls_c == _mlsValue::create<_mls_Str>("&"));
          if (_mlsValue::isIntLit(_mls_x201, 1)) {
            _mls_retval = _mlsValue::fromIntLit(4);
          } else {
            auto _mls_x202 = (_mls_c == _mlsValue::create<_mls_Str>("~"));
            if (_mlsValue::isIntLit(_mls_x202, 1)) {
              _mls_retval = _mlsValue::fromIntLit(5);
            } else {
              _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
            }
          }
        }
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_parse(_mlsValue _mls_t1) {
  _mlsValue _mls_retval;
  auto _mls_x203 = _mlsValue::create<_mls_Nil>();
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_t1)) {
    auto _mls_x902 = _mls_redstar(_mls_x203);
    _mls_retval = _mls_parse_caller_post(_mls_x902);
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_t1)) {
    auto _mls_x875 = _mlsValue::cast<_mls_Cons>(_mls_t1)->_mls_head;
    auto _mls_x876 = _mlsValue::cast<_mls_Cons>(_mls_t1)->_mls_tail;
    if (_mls_Str::isStrLit(_mls_x875, " ")) {
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x876)) {
        auto _mls_x901 = _mls_redstar(_mls_x203);
        _mls_retval = _mls_parse_caller_post(_mls_x901);
      } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x876)) {
        auto _mls_x895 = _mlsValue::cast<_mls_Cons>(_mls_x876)->_mls_head;
        auto _mls_x896 = _mlsValue::cast<_mls_Cons>(_mls_x876)->_mls_tail;
        if (_mls_Str::isStrLit(_mls_x895, " ")) {
          auto _mls_x900 = _mls_parseHelper(_mls_x896, _mls_x203);
          _mls_retval = _mls_parse_caller_post(_mls_x900);
        } else if (_mls_Str::isStrLit(_mls_x895, "(")) {
          auto _mls_x899 = _mls_parseHelper_case1_sr_post_case1(_mls_x203, _mls_x896);
          _mls_retval = _mls_parse_caller_post(_mls_x899);
        } else if (_mls_Str::isStrLit(_mls_x895, ")")) {
          auto _mls_x898 = _mls_parseHelper_case1_sr_post_case2(_mls_x203, _mls_x896, _mls_x895);
          _mls_retval = _mls_parse_caller_post(_mls_x898);
        } else {
          auto _mls_x897 = _mls_parseHelper_case1_sr_post_default(_mls_x895, _mls_x203, _mls_x896);
          _mls_retval = _mls_parse_caller_post(_mls_x897);
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else if (_mls_Str::isStrLit(_mls_x875, "(")) {
      auto _mls_x894 = _mls_parseHelper_case1_sr_post_case1(_mls_x203, _mls_x876);
      _mls_retval = _mls_parse_caller_post(_mls_x894);
    } else if (_mls_Str::isStrLit(_mls_x875, ")")) {
      auto _mls_x883 = _mls_redstar(_mls_x203);
      if (_mlsValue::isValueOf<_mls_Cons>(_mls_x883)) {
        auto _mls_x890 = _mlsValue::cast<_mls_Cons>(_mls_x883)->_mls_head;
        auto _mls_x891 = _mlsValue::cast<_mls_Cons>(_mls_x883)->_mls_tail;
        if (_mlsValue::isValueOf<_mls_Cons>(_mls_x891)) {
          auto _mls_x893 = _mls_parseHelper_case1_sr_post_case2_case0_sr_post_case0(_mls_x876, _mls_x890, _mls_x875, _mls_x891, _mls_x203);
          _mls_retval = _mls_parse_caller_post(_mls_x893);
        } else {
          auto _mls_x892 = _mls_parseHelper_case1_sr_post_case2_case0_sr_post_default(_mls_x875, _mls_x203, _mls_x876);
          _mls_retval = _mls_parse_caller_post(_mls_x892);
        }
      } else {
        auto [_mls_x884, _mls_x885, _mls_x886, _mls_x887] = _mls_parseHelper_case1_sr_post_case2_default_pre(_mls_x875, _mls_x203, _mls_x876);
        if (_mlsValue::isIntLit(_mls_x884, 1)) {
          auto _mls_x889 = _mls_parseHelper_case1_sr_post_case2_default_case0(_mls_x885, _mls_x886, _mls_x887);
          _mls_retval = _mls_parse_caller_post(_mls_x889);
        } else {
          auto _mls_x888 = _mls_parseHelper_case1_sr_post_case2_default_default(_mls_x886, _mls_x885, _mls_x887);
          _mls_retval = _mls_parse_caller_post(_mls_x888);
        }
      }
    } else {
      auto [_mls_x877, _mls_x878, _mls_x879, _mls_x880] = _mls_parseHelper_case1_sr_post_default_pre(_mls_x875, _mls_x203, _mls_x876);
      if (_mlsValue::isIntLit(_mls_x877, 1)) {
        auto _mls_x882 = _mls_parseHelper_case1_sr_post_default_case0(_mls_x878, _mls_x879, _mls_x880);
        _mls_retval = _mls_parse_caller_post(_mls_x882);
      } else {
        auto _mls_x881 = _mls_parseHelper_case1_sr_post_default_default(_mls_x879, _mls_x878, _mls_x880);
        _mls_retval = _mls_parse_caller_post(_mls_x881);
      }
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_parseHelper(_mlsValue _mls_x903, _mlsValue _mls_x904) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x903)) {
    auto _mls_x905 = _mls_redstar(_mls_x904);
    _mls_retval = _mls_x905;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x903)) {
    _mls_retval = _mls_parseHelper_case1(_mls_x903, _mls_x904);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_parseHelper_case1(_mlsValue _mls_x907, _mlsValue _mls_x909) {
  _mlsValue _mls_retval;
  auto _mls_x906 = _mlsValue::cast<_mls_Cons>(_mls_x907)->_mls_head;
  auto _mls_x908 = _mlsValue::cast<_mls_Cons>(_mls_x907)->_mls_tail;
  _mls_retval = _mls_parseHelper_case1_sr_post(_mls_x906, _mls_x908, _mls_x909);
  return _mls_retval;
}
_mlsValue _mls_parseHelper_case11(_mlsValue _mls_x911, _mlsValue _mls_x913) {
  _mlsValue _mls_retval;
  auto _mls_x910 = _mlsValue::cast<_mls_Cons>(_mls_x911)->_mls_head;
  auto _mls_x912 = _mlsValue::cast<_mls_Cons>(_mls_x911)->_mls_tail;
  _mls_retval = _mls_parseHelper_case1_sr_post(_mls_x910, _mls_x912, _mls_x913);
  return _mls_retval;
}
_mlsValue _mls_parseHelper_case1_sr_post(_mlsValue _mls_x914, _mlsValue _mls_x916, _mlsValue _mls_x915) {
  _mlsValue _mls_retval;
  if (_mls_Str::isStrLit(_mls_x914, " ")) {
    auto _mls_x917 = _mls_parseHelper(_mls_x916, _mls_x915);
    _mls_retval = _mls_x917;
  } else if (_mls_Str::isStrLit(_mls_x914, "(")) {
    _mls_retval = _mls_parseHelper_case1_sr_post_case1(_mls_x915, _mls_x916);
  } else if (_mls_Str::isStrLit(_mls_x914, ")")) {
    _mls_retval = _mls_parseHelper_case1_sr_post_case2(_mls_x915, _mls_x916, _mls_x914);
  } else {
    _mls_retval = _mls_parseHelper_case1_sr_post_default(_mls_x914, _mls_x915, _mls_x916);
  }
  return _mls_retval;
}
_mlsValue _mls_parseHelper_case1_sr_post_case1(_mlsValue _mls_x920, _mlsValue _mls_x921) {
  _mlsValue _mls_retval;
  auto _mls_x918 = _mlsValue::create<_mls_Lex>(_mlsValue::create<_mls_Str>("("));
  auto _mls_x919 = _mlsValue::create<_mls_Cons>(_mls_x918, _mls_x920);
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x921)) {
    auto _mls_x928 = _mls_redstar(_mls_x919);
    _mls_retval = _mls_x928;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x921)) {
    auto _mls_x922 = _mlsValue::cast<_mls_Cons>(_mls_x921)->_mls_head;
    auto _mls_x923 = _mlsValue::cast<_mls_Cons>(_mls_x921)->_mls_tail;
    if (_mls_Str::isStrLit(_mls_x922, " ")) {
      auto _mls_x927 = _mls_parseHelper(_mls_x923, _mls_x919);
      _mls_retval = _mls_x927;
    } else if (_mls_Str::isStrLit(_mls_x922, "(")) {
      auto _mls_x926 = _mls_parseHelper_case1_sr_post_case1(_mls_x919, _mls_x923);
      _mls_retval = _mls_x926;
    } else if (_mls_Str::isStrLit(_mls_x922, ")")) {
      auto _mls_x925 = _mls_parseHelper_case1_sr_post_case2(_mls_x919, _mls_x923, _mls_x922);
      _mls_retval = _mls_x925;
    } else {
      auto _mls_x924 = _mls_parseHelper_case1_sr_post_default(_mls_x922, _mls_x919, _mls_x923);
      _mls_retval = _mls_x924;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_parseHelper_case1_sr_post_case2(_mlsValue _mls_x929, _mlsValue _mls_x932, _mlsValue _mls_x931) {
  _mlsValue _mls_retval;
  auto _mls_x930 = _mls_redstar(_mls_x929);
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x930)) {
    auto _mls_x933 = _mlsValue::cast<_mls_Cons>(_mls_x930)->_mls_head;
    auto _mls_x934 = _mlsValue::cast<_mls_Cons>(_mls_x930)->_mls_tail;
    _mls_retval = _mls_parseHelper_case1_sr_post_case2_case0_sr_post(_mls_x933, _mls_x931, _mls_x929, _mls_x934, _mls_x932);
  } else {
    _mls_retval = _mls_parseHelper_case1_sr_post_case2_default(_mls_x931, _mls_x929, _mls_x932);
  }
  return _mls_retval;
}
_mlsValue _mls_parseHelper_case1_sr_post_case2_case0_sr_post(_mlsValue _mls_x939, _mlsValue _mls_x936, _mlsValue _mls_x937, _mlsValue _mls_x935, _mlsValue _mls_x938) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x935)) {
    _mls_retval = _mls_parseHelper_case1_sr_post_case2_case0_sr_post_case0(_mls_x938, _mls_x939, _mls_x936, _mls_x935, _mls_x937);
  } else {
    _mls_retval = _mls_parseHelper_case1_sr_post_case2_case0_sr_post_default(_mls_x936, _mls_x937, _mls_x938);
  }
  return _mls_retval;
}
_mlsValue _mls_parseHelper_case1_sr_post_case2_case0_sr_post_case0(_mlsValue _mls_x953, _mlsValue _mls_x980, _mlsValue _mls_x944, _mlsValue _mls_x941, _mlsValue _mls_x947) {
  _mlsValue _mls_retval;
  auto _mls_x940 = _mlsValue::cast<_mls_Cons>(_mls_x941)->_mls_head;
  auto _mls_x942 = _mlsValue::cast<_mls_Cons>(_mls_x941)->_mls_tail;
  if (_mlsValue::isValueOf<_mls_Lex>(_mls_x940)) {
    auto _mls_x962 = _mlsValue::cast<_mls_Lex>(_mls_x940)->_mls_s;
    if (_mls_Str::isStrLit(_mls_x962, "(")) {
      auto _mls_x979 = _mlsValue::create<_mls_Cons>(_mls_x980, _mls_x942);
      auto _mls_x981 = _mls_parseHelper(_mls_x953, _mls_x979);
      _mls_retval = _mls_x981;
    } else {
      auto _mls_x963 = _mls_builtin_str_leq(_mlsValue::create<_mls_Str>("a"), _mls_x944);
      auto _mls_x964 = _mls_builtin_str_leq(_mls_x944, _mlsValue::create<_mls_Str>("z"));
      auto _mls_x965 = (_mls_x963 && _mls_x964);
      if (_mlsValue::isIntLit(_mls_x965, 1)) {
        auto _mls_x975 = _mlsValue::create<_mls_Sym>(_mls_x944);
        auto _mls_x976 = _mlsValue::create<_mls_Ast>(_mls_x975);
        auto _mls_x977 = _mlsValue::create<_mls_Cons>(_mls_x976, _mls_x947);
        auto _mls_x978 = _mls_parseHelper(_mls_x953, _mls_x977);
        _mls_retval = _mls_x978;
      } else {
        auto _mls_x966 = _mls_spri(_mls_x947);
        auto _mls_x967 = _mls_opri(_mls_x944);
        auto _mls_x968 = (_mls_x966 > _mls_x967);
        if (_mlsValue::isIntLit(_mls_x968, 1)) {
          auto _mls_x972 = _mlsValue::create<_mls_Cons>(_mls_x944, _mls_x953);
          auto _mls_x973 = _mls_red(_mls_x947);
          auto _mls_x974 = _mls_parseHelper(_mls_x972, _mls_x973);
          _mls_retval = _mls_x974;
        } else {
          auto _mls_x969 = _mlsValue::create<_mls_Lex>(_mls_x944);
          auto _mls_x970 = _mlsValue::create<_mls_Cons>(_mls_x969, _mls_x947);
          auto _mls_x971 = _mls_parseHelper(_mls_x953, _mls_x970);
          _mls_retval = _mls_x971;
        }
      }
    }
  } else {
    auto _mls_x943 = _mls_builtin_str_leq(_mlsValue::create<_mls_Str>("a"), _mls_x944);
    auto _mls_x945 = _mls_builtin_str_leq(_mls_x944, _mlsValue::create<_mls_Str>("z"));
    auto _mls_x946 = (_mls_x943 && _mls_x945);
    if (_mlsValue::isIntLit(_mls_x946, 1)) {
      auto _mls_x958 = _mlsValue::create<_mls_Sym>(_mls_x944);
      auto _mls_x959 = _mlsValue::create<_mls_Ast>(_mls_x958);
      auto _mls_x960 = _mlsValue::create<_mls_Cons>(_mls_x959, _mls_x947);
      auto _mls_x961 = _mls_parseHelper(_mls_x953, _mls_x960);
      _mls_retval = _mls_x961;
    } else {
      auto _mls_x948 = _mls_spri(_mls_x947);
      auto _mls_x949 = _mls_opri(_mls_x944);
      auto _mls_x950 = (_mls_x948 > _mls_x949);
      if (_mlsValue::isIntLit(_mls_x950, 1)) {
        auto _mls_x955 = _mlsValue::create<_mls_Cons>(_mls_x944, _mls_x953);
        auto _mls_x956 = _mls_red(_mls_x947);
        auto _mls_x957 = _mls_parseHelper(_mls_x955, _mls_x956);
        _mls_retval = _mls_x957;
      } else {
        auto _mls_x951 = _mlsValue::create<_mls_Lex>(_mls_x944);
        auto _mls_x952 = _mlsValue::create<_mls_Cons>(_mls_x951, _mls_x947);
        auto _mls_x954 = _mls_parseHelper(_mls_x953, _mls_x952);
        _mls_retval = _mls_x954;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_parseHelper_case1_sr_post_case2_case0_sr_post_default(_mlsValue _mls_x983, _mlsValue _mls_x986, _mlsValue _mls_x992) {
  _mlsValue _mls_retval;
  auto _mls_x982 = _mls_builtin_str_leq(_mlsValue::create<_mls_Str>("a"), _mls_x983);
  auto _mls_x984 = _mls_builtin_str_leq(_mls_x983, _mlsValue::create<_mls_Str>("z"));
  auto _mls_x985 = (_mls_x982 && _mls_x984);
  if (_mlsValue::isIntLit(_mls_x985, 1)) {
    auto _mls_x997 = _mlsValue::create<_mls_Sym>(_mls_x983);
    auto _mls_x998 = _mlsValue::create<_mls_Ast>(_mls_x997);
    auto _mls_x999 = _mlsValue::create<_mls_Cons>(_mls_x998, _mls_x986);
    auto _mls_x1000 = _mls_parseHelper(_mls_x992, _mls_x999);
    _mls_retval = _mls_x1000;
  } else {
    auto _mls_x987 = _mls_spri(_mls_x986);
    auto _mls_x988 = _mls_opri(_mls_x983);
    auto _mls_x989 = (_mls_x987 > _mls_x988);
    if (_mlsValue::isIntLit(_mls_x989, 1)) {
      auto _mls_x994 = _mlsValue::create<_mls_Cons>(_mls_x983, _mls_x992);
      auto _mls_x995 = _mls_red(_mls_x986);
      auto _mls_x996 = _mls_parseHelper(_mls_x994, _mls_x995);
      _mls_retval = _mls_x996;
    } else {
      auto _mls_x990 = _mlsValue::create<_mls_Lex>(_mls_x983);
      auto _mls_x991 = _mlsValue::create<_mls_Cons>(_mls_x990, _mls_x986);
      auto _mls_x993 = _mls_parseHelper(_mls_x992, _mls_x991);
      _mls_retval = _mls_x993;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_parseHelper_case1_sr_post_case2_default(_mlsValue _mls_x1001, _mlsValue _mls_x1002, _mlsValue _mls_x1003) {
  _mlsValue _mls_retval;
  auto [_mls_x1004, _mls_x1005, _mls_x1006, _mls_x1007] = _mls_parseHelper_case1_sr_post_case2_default_pre(_mls_x1001, _mls_x1002, _mls_x1003);
  if (_mlsValue::isIntLit(_mls_x1004, 1)) {
    _mls_retval = _mls_parseHelper_case1_sr_post_case2_default_case0(_mls_x1005, _mls_x1006, _mls_x1007);
  } else {
    _mls_retval = _mls_parseHelper_case1_sr_post_case2_default_default(_mls_x1006, _mls_x1005, _mls_x1007);
  }
  return _mls_retval;
}
_mlsValue _mls_parseHelper_case1_sr_post_case2_default_case0(_mlsValue _mls_x1009, _mlsValue _mls_x1012, _mlsValue _mls_x1013) {
  _mlsValue _mls_retval;
  auto _mls_x1008 = _mlsValue::create<_mls_Sym>(_mls_x1009);
  auto _mls_x1010 = _mlsValue::create<_mls_Ast>(_mls_x1008);
  auto _mls_x1011 = _mlsValue::create<_mls_Cons>(_mls_x1010, _mls_x1012);
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1013)) {
    auto _mls_x1015 = _mls_redstar(_mls_x1011);
    _mls_retval = _mls_x1015;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1013)) {
    auto _mls_x1014 = _mls_parseHelper_case1(_mls_x1013, _mls_x1011);
    _mls_retval = _mls_x1014;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_parseHelper_case1_sr_post_case2_default_default(_mlsValue _mls_x1016, _mlsValue _mls_x1018, _mlsValue _mls_x1023) {
  _mlsValue _mls_retval;
  auto _mls_x1017 = _mls_spri(_mls_x1016);
  auto _mls_x1019 = _mls_opri(_mls_x1018);
  auto _mls_x1020 = (_mls_x1017 > _mls_x1019);
  if (_mlsValue::isIntLit(_mls_x1020, 1)) {
    auto _mls_x1026 = _mlsValue::create<_mls_Cons>(_mls_x1018, _mls_x1023);
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1016)) {
      auto _mls_x1027 = _mls_red_case0(_mls_x1016);
      auto _mls_x1028 = _mls_parseHelper(_mls_x1026, _mls_x1027);
      _mls_retval = _mls_x1028;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    auto _mls_x1021 = _mlsValue::create<_mls_Lex>(_mls_x1018);
    auto _mls_x1022 = _mlsValue::create<_mls_Cons>(_mls_x1021, _mls_x1016);
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1023)) {
      auto _mls_x1025 = _mls_redstar(_mls_x1022);
      _mls_retval = _mls_x1025;
    } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1023)) {
      auto _mls_x1024 = _mls_parseHelper_case1(_mls_x1023, _mls_x1022);
      _mls_retval = _mls_x1024;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  }
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_parseHelper_case1_sr_post_case2_default_pre(_mlsValue _mls_x1030, _mlsValue _mls_x1033, _mlsValue _mls_x1034) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x1029 = _mls_builtin_str_leq(_mlsValue::create<_mls_Str>("a"), _mls_x1030);
  auto _mls_x1031 = _mls_builtin_str_leq(_mls_x1030, _mlsValue::create<_mls_Str>("z"));
  auto _mls_x1032 = (_mls_x1029 && _mls_x1031);
  _mls_retval = std::make_tuple(_mls_x1032, _mls_x1030, _mls_x1033, _mls_x1034);
  return _mls_retval;
}
_mlsValue _mls_parseHelper_case1_sr_post_default(_mlsValue _mls_x1035, _mlsValue _mls_x1036, _mlsValue _mls_x1037) {
  _mlsValue _mls_retval;
  auto [_mls_x1038, _mls_x1039, _mls_x1040, _mls_x1041] = _mls_parseHelper_case1_sr_post_default_pre(_mls_x1035, _mls_x1036, _mls_x1037);
  if (_mlsValue::isIntLit(_mls_x1038, 1)) {
    _mls_retval = _mls_parseHelper_case1_sr_post_default_case0(_mls_x1039, _mls_x1040, _mls_x1041);
  } else {
    _mls_retval = _mls_parseHelper_case1_sr_post_default_default(_mls_x1040, _mls_x1039, _mls_x1041);
  }
  return _mls_retval;
}
_mlsValue _mls_parseHelper_case1_sr_post_default_case0(_mlsValue _mls_x1043, _mlsValue _mls_x1046, _mlsValue _mls_x1047) {
  _mlsValue _mls_retval;
  auto _mls_x1042 = _mlsValue::create<_mls_Sym>(_mls_x1043);
  auto _mls_x1044 = _mlsValue::create<_mls_Ast>(_mls_x1042);
  auto _mls_x1045 = _mlsValue::create<_mls_Cons>(_mls_x1044, _mls_x1046);
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1047)) {
    auto _mls_x1051 = _mls_redstar(_mls_x1045);
    _mls_retval = _mls_x1051;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1047)) {
    auto _mls_x1048 = _mlsValue::cast<_mls_Cons>(_mls_x1047)->_mls_head;
    auto _mls_x1049 = _mlsValue::cast<_mls_Cons>(_mls_x1047)->_mls_tail;
    auto _mls_x1050 = _mls_parseHelper_case1_sr_post(_mls_x1048, _mls_x1049, _mls_x1045);
    _mls_retval = _mls_x1050;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_parseHelper_case1_sr_post_default_default(_mlsValue _mls_x1052, _mlsValue _mls_x1053, _mlsValue _mls_x1054) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1052)) {
    auto _mls_x1055 = _mls_spri_case0(_mls_x1052);
    _mls_retval = _mls_parseHelper_case1_sr_post_default_default_caller_post(_mls_x1053, _mls_x1055, _mls_x1054, _mls_x1052);
  } else {
    _mls_retval = _mls_parseHelper_case1_sr_post_default_default_caller_post(_mls_x1053, _mlsValue::fromIntLit(0), _mls_x1054, _mls_x1052);
  }
  return _mls_retval;
}
_mlsValue _mls_parseHelper_case1_sr_post_default_default_caller_post(_mlsValue _mls_x1056, _mlsValue _mls_x1059, _mlsValue _mls_x1063, _mlsValue _mls_x1062) {
  _mlsValue _mls_retval;
  auto _mls_x1057 = _mls_opri(_mls_x1056);
  auto _mls_x1058 = (_mls_x1059 > _mls_x1057);
  if (_mlsValue::isIntLit(_mls_x1058, 1)) {
    auto _mls_x1066 = _mlsValue::create<_mls_Cons>(_mls_x1056, _mls_x1063);
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1062)) {
      auto _mls_x1067 = _mls_red_case0(_mls_x1062);
      auto _mls_x1068 = _mls_parseHelper(_mls_x1066, _mls_x1067);
      _mls_retval = _mls_x1068;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    auto _mls_x1060 = _mlsValue::create<_mls_Lex>(_mls_x1056);
    auto _mls_x1061 = _mlsValue::create<_mls_Cons>(_mls_x1060, _mls_x1062);
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1063)) {
      auto _mls_x1065 = _mls_redstar(_mls_x1061);
      _mls_retval = _mls_x1065;
    } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1063)) {
      auto _mls_x1064 = _mls_parseHelper_case11(_mls_x1063, _mls_x1061);
      _mls_retval = _mls_x1064;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  }
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_parseHelper_case1_sr_post_default_pre(_mlsValue _mls_x1070, _mlsValue _mls_x1073, _mlsValue _mls_x1074) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x1069 = _mls_builtin_str_leq(_mlsValue::create<_mls_Str>("a"), _mls_x1070);
  auto _mls_x1071 = _mls_builtin_str_leq(_mls_x1070, _mlsValue::create<_mls_Str>("z"));
  auto _mls_x1072 = (_mls_x1069 && _mls_x1071);
  _mls_retval = std::make_tuple(_mls_x1072, _mls_x1070, _mls_x1073, _mls_x1074);
  return _mls_retval;
}
_mlsValue _mls_parse_caller_post(_mlsValue _mls_x1075) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1075)) {
    auto _mls_x1076 = _mlsValue::cast<_mls_Cons>(_mls_x1075)->_mls_head;
    auto _mls_x1077 = _mlsValue::cast<_mls_Cons>(_mls_x1075)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Ast>(_mls_x1076)) {
      auto _mls_x1078 = _mlsValue::cast<_mls_Ast>(_mls_x1076)->_mls_f;
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1077)) {
        _mls_retval = _mls_x1078;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_red(_mlsValue _mls_x1079) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1079)) {
    _mls_retval = _mls_red_case0(_mls_x1079);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_red_case0(_mlsValue _mls_x1081) {
  _mlsValue _mls_retval;
  auto _mls_x1080 = _mlsValue::cast<_mls_Cons>(_mls_x1081)->_mls_head;
  auto _mls_x1082 = _mlsValue::cast<_mls_Cons>(_mls_x1081)->_mls_tail;
  if (_mlsValue::isValueOf<_mls_Ast>(_mls_x1080)) {
    auto _mls_x1083 = _mlsValue::cast<_mls_Ast>(_mls_x1080)->_mls_f;
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1082)) {
      auto _mls_x1084 = _mlsValue::cast<_mls_Cons>(_mls_x1082)->_mls_head;
      auto _mls_x1085 = _mlsValue::cast<_mls_Cons>(_mls_x1082)->_mls_tail;
      if (_mlsValue::isValueOf<_mls_Lex>(_mls_x1084)) {
        auto _mls_x1086 = _mlsValue::cast<_mls_Lex>(_mls_x1084)->_mls_s;
        if (_mls_Str::isStrLit(_mls_x1086, "=")) {
          if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1085)) {
            auto _mls_x1108 = _mlsValue::cast<_mls_Cons>(_mls_x1085)->_mls_head;
            auto _mls_x1109 = _mlsValue::cast<_mls_Cons>(_mls_x1085)->_mls_tail;
            if (_mlsValue::isValueOf<_mls_Ast>(_mls_x1108)) {
              auto _mls_x1110 = _mlsValue::cast<_mls_Ast>(_mls_x1108)->_mls_f;
              auto _mls_x1111 = _mlsValue::create<_mls_Eqv>(_mls_x1110, _mls_x1083);
              auto _mls_x1112 = _mlsValue::create<_mls_Ast>(_mls_x1111);
              auto _mls_x1113 = _mlsValue::create<_mls_Cons>(_mls_x1112, _mls_x1109);
              _mls_retval = _mls_x1113;
            } else {
              _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
            }
          } else {
            _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
          }
        } else if (_mls_Str::isStrLit(_mls_x1086, ">")) {
          if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1085)) {
            auto _mls_x1102 = _mlsValue::cast<_mls_Cons>(_mls_x1085)->_mls_head;
            auto _mls_x1103 = _mlsValue::cast<_mls_Cons>(_mls_x1085)->_mls_tail;
            if (_mlsValue::isValueOf<_mls_Ast>(_mls_x1102)) {
              auto _mls_x1104 = _mlsValue::cast<_mls_Ast>(_mls_x1102)->_mls_f;
              auto _mls_x1105 = _mlsValue::create<_mls_Imp>(_mls_x1104, _mls_x1083);
              auto _mls_x1106 = _mlsValue::create<_mls_Ast>(_mls_x1105);
              auto _mls_x1107 = _mlsValue::create<_mls_Cons>(_mls_x1106, _mls_x1103);
              _mls_retval = _mls_x1107;
            } else {
              _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
            }
          } else {
            _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
          }
        } else if (_mls_Str::isStrLit(_mls_x1086, "|")) {
          if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1085)) {
            auto _mls_x1096 = _mlsValue::cast<_mls_Cons>(_mls_x1085)->_mls_head;
            auto _mls_x1097 = _mlsValue::cast<_mls_Cons>(_mls_x1085)->_mls_tail;
            if (_mlsValue::isValueOf<_mls_Ast>(_mls_x1096)) {
              auto _mls_x1098 = _mlsValue::cast<_mls_Ast>(_mls_x1096)->_mls_f;
              auto _mls_x1099 = _mlsValue::create<_mls_Dis>(_mls_x1098, _mls_x1083);
              auto _mls_x1100 = _mlsValue::create<_mls_Ast>(_mls_x1099);
              auto _mls_x1101 = _mlsValue::create<_mls_Cons>(_mls_x1100, _mls_x1097);
              _mls_retval = _mls_x1101;
            } else {
              _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
            }
          } else {
            _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
          }
        } else if (_mls_Str::isStrLit(_mls_x1086, "&")) {
          if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1085)) {
            auto _mls_x1090 = _mlsValue::cast<_mls_Cons>(_mls_x1085)->_mls_head;
            auto _mls_x1091 = _mlsValue::cast<_mls_Cons>(_mls_x1085)->_mls_tail;
            if (_mlsValue::isValueOf<_mls_Ast>(_mls_x1090)) {
              auto _mls_x1092 = _mlsValue::cast<_mls_Ast>(_mls_x1090)->_mls_f;
              auto _mls_x1093 = _mlsValue::create<_mls_Con>(_mls_x1092, _mls_x1083);
              auto _mls_x1094 = _mlsValue::create<_mls_Ast>(_mls_x1093);
              auto _mls_x1095 = _mlsValue::create<_mls_Cons>(_mls_x1094, _mls_x1091);
              _mls_retval = _mls_x1095;
            } else {
              _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
            }
          } else {
            _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
          }
        } else if (_mls_Str::isStrLit(_mls_x1086, "~")) {
          auto _mls_x1087 = _mlsValue::create<_mls_Not>(_mls_x1083);
          auto _mls_x1088 = _mlsValue::create<_mls_Ast>(_mls_x1087);
          auto _mls_x1089 = _mlsValue::create<_mls_Cons>(_mls_x1088, _mls_x1085);
          _mls_retval = _mls_x1089;
        } else {
          _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_redstar(_mlsValue _mls_s4) {
  _mlsValue _mls_retval;
  auto _mls_x336 = _mlsValue::create<_mls_Lambda_lambda>();
  auto _mls_x337 = _mlsValue::create<_mls_Lambda_red>();
  auto _mls_x338 = _mls_while_(_mls_x336, _mls_x337, _mls_s4);
  _mls_retval = _mls_x338;
  return _mls_retval;
}
_mlsValue _mls_replicate(_mlsValue _mls_x1114, _mlsValue _mls_x1115) {
  _mlsValue _mls_retval;
  auto [_mls_x1116, _mls_x1117, _mls_x1118] = _mls_replicate_pre(_mls_x1114, _mls_x1115);
  if (_mlsValue::isIntLit(_mls_x1116, 1)) {
    _mls_retval = _mls_replicate_case0();
  } else {
    _mls_retval = _mls_replicate_default(_mls_x1117, _mls_x1118);
  }
  return _mls_retval;
}
_mlsValue _mls_replicate_case0() {
  _mlsValue _mls_retval;
  auto _mls_x1119 = _mlsValue::create<_mls_Nil>();
  _mls_retval = _mls_x1119;
  return _mls_retval;
}
_mlsValue _mls_replicate_default(_mlsValue _mls_x1121, _mlsValue _mls_x1122) {
  _mlsValue _mls_retval;
  auto _mls_x1120 = (_mls_x1121 - _mlsValue::fromIntLit(1));
  auto _mls_x1123 = _mls_replicate(_mls_x1120, _mls_x1122);
  auto _mls_x1124 = _mlsValue::create<_mls_Cons>(_mls_x1122, _mls_x1123);
  _mls_retval = _mls_x1124;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_replicate_pre(_mlsValue _mls_x1126, _mlsValue _mls_x1127) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x1125 = (_mls_x1126 == _mlsValue::fromIntLit(0));
  _mls_retval = std::make_tuple(_mls_x1125, _mls_x1126, _mls_x1127);
  return _mls_retval;
}
_mlsValue _mls_split(_mlsValue _mls_x1128) {
  _mlsValue _mls_retval;
  auto [_mls_x1129, _mls_x1130] = _mls_split_pre(_mls_x1128);
  auto _mls_x1131 = _mls_splitHelper(_mls_x1129, _mls_x1130);
  _mls_retval = _mls_x1131;
  return _mls_retval;
}
_mlsValue _mls_splitHelper(_mlsValue _mls_p7, _mlsValue _mls_a7) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Con>(_mls_p7)) {
    auto _mls_x348 = _mlsValue::cast<_mls_Con>(_mls_p7)->_mls_a;
    auto _mls_x349 = _mlsValue::cast<_mls_Con>(_mls_p7)->_mls_b;
    auto _mls_x350 = _mls_splitHelper(_mls_x349, _mls_a7);
    auto _mls_x351 = _mls_splitHelper(_mls_x348, _mls_x350);
    _mls_retval = _mls_x351;
  } else {
    auto _mls_x347 = _mlsValue::create<_mls_Cons>(_mls_p7, _mls_a7);
    _mls_retval = _mls_x347;
  }
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue> _mls_split_pre(_mlsValue _mls_x1133) {
  std::tuple<_mlsValue, _mlsValue> _mls_retval;
  auto _mls_x1132 = _mlsValue::create<_mls_Nil>();
  _mls_retval = std::make_tuple(_mls_x1133, _mls_x1132);
  return _mls_retval;
}
_mlsValue _mls_spri(_mlsValue _mls_x1134) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1134)) {
    _mls_retval = _mls_spri_case0(_mls_x1134);
  } else {
    _mls_retval = _mlsValue::fromIntLit(0);
  }
  return _mls_retval;
}
_mlsValue _mls_spri_case0(_mlsValue _mls_x1136) {
  _mlsValue _mls_retval;
  auto _mls_x1135 = _mlsValue::cast<_mls_Cons>(_mls_x1136)->_mls_head;
  auto _mls_x1137 = _mlsValue::cast<_mls_Cons>(_mls_x1136)->_mls_tail;
  if (_mlsValue::isValueOf<_mls_Ast>(_mls_x1135)) {
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1137)) {
      auto _mls_x1138 = _mlsValue::cast<_mls_Cons>(_mls_x1137)->_mls_head;
      if (_mlsValue::isValueOf<_mls_Lex>(_mls_x1138)) {
        auto _mls_x1139 = _mlsValue::cast<_mls_Lex>(_mls_x1138)->_mls_s;
        auto _mls_x1140 = _mls_opri(_mls_x1139);
        _mls_retval = _mls_x1140;
      } else {
        _mls_retval = _mlsValue::fromIntLit(0);
      }
    } else {
      _mls_retval = _mlsValue::fromIntLit(0);
    }
  } else {
    _mls_retval = _mlsValue::fromIntLit(0);
  }
  return _mls_retval;
}
_mlsValue _mls_str_to_list(_mlsValue _mls_x358) {
  _mlsValue _mls_retval;
  auto _mls_x1141 = _mls_builtin_str_head(_mls_x358);
  if (_mlsValue::isValueOf<_mls_Unit>(_mls_x1141)) {
    auto _mls_x363 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x363;
  } else {
    auto _mls_x1142 = _mls_builtin_str_head(_mls_x358);
    auto _mls_x1143 = _mls_builtin_str_tail(_mls_x358);
    auto _mls_x361 = _mls_str_to_list(_mls_x1143);
    auto _mls_x362 = _mlsValue::create<_mls_Cons>(_mls_x1142, _mls_x361);
    _mls_retval = _mls_x362;
  }
  return _mls_retval;
}
_mlsValue _mls_tautclause_case0_sr_post_pre(_mlsValue _mls_x1145, _mlsValue _mls_x1146) {
  _mlsValue _mls_retval;
  auto _mls_x1144 = _mlsValue::create<_mls_Lambda_lscomp>(_mls_x1145);
  auto _mls_x1147 = _mlsMethodCall<_mls_Callable>(_mls_x1144)->_mls_apply1(_mls_x1146);
  _mls_retval = _mls_x1147;
  return _mls_retval;
}
_mlsValue _mls_testClausify_nofib(_mlsValue _mls_n1) {
  _mlsValue _mls_retval;
  auto _mls_x370 = _mls_str_to_list(_mlsValue::create<_mls_Str>("(a = a = a) = (a = a = a) = (a = a = a)"));
  auto [_mls_x1148, _mls_x1149, _mls_x1150] = _mls_replicate_pre(_mls_n1, _mls_x370);
  if (_mlsValue::isIntLit(_mls_x1148, 1)) {
    auto _mls_x1159 = _mls_replicate_case0();
    auto [_mls_x1160, _mls_x1161] = _mls_testClausify_nofib_caller_post_pre(_mls_x1159);
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1161)) {
      auto _mls_x1164 = _mlsValue::cast<_mls_Cons>(_mls_x1161)->_mls_head;
      auto _mls_x1165 = _mlsValue::cast<_mls_Cons>(_mls_x1161)->_mls_tail;
      auto _mls_x1166 = _mls_map_case0_sr_post(_mls_x1160, _mls_x1164, _mls_x1165);
      _mls_retval = _mls_testClausify_nofib_caller_post_post_case1(_mls_x1166);
    } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1161)) {
      auto _mls_x1162 = _mls_map_case1();
      auto _mls_x1163 = _mls_concat_case0();
      _mls_retval = _mlsValue::create<_mls_Str>("");
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    auto _mls_x1151 = _mls_replicate_default(_mls_x1149, _mls_x1150);
    auto [_mls_x1152, _mls_x1153] = _mls_testClausify_nofib_caller_post_pre(_mls_x1151);
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1153)) {
      auto _mls_x1156 = _mlsValue::cast<_mls_Cons>(_mls_x1153)->_mls_head;
      auto _mls_x1157 = _mlsValue::cast<_mls_Cons>(_mls_x1153)->_mls_tail;
      auto _mls_x1158 = _mls_map_case0_sr_post(_mls_x1152, _mls_x1156, _mls_x1157);
      _mls_retval = _mls_testClausify_nofib_caller_post_post_case1(_mls_x1158);
    } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1153)) {
      auto _mls_x1154 = _mls_map_case1();
      auto _mls_x1155 = _mls_concat_case0();
      _mls_retval = _mlsValue::create<_mls_Str>("");
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  }
  return _mls_retval;
}
_mlsValue _mls_testClausify_nofib_caller_post_post_case1(_mlsValue _mls_x1167) {
  _mlsValue _mls_retval;
  auto _mls_x1168 = _mls_concat_case11(_mls_x1167);
  auto _mls_x1169 = _mls_list_to_str(_mls_x1168);
  _mls_retval = _mls_x1169;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue> _mls_testClausify_nofib_caller_post_pre(_mlsValue _mls_x1171) {
  std::tuple<_mlsValue, _mlsValue> _mls_retval;
  auto _mls_x1170 = _mlsValue::create<_mls_Lambda_clauses>();
  _mls_retval = std::make_tuple(_mls_x1170, _mls_x1171);
  return _mls_retval;
}
_mlsValue _mls_unicl(_mlsValue _mls_a8) {
  _mlsValue _mls_retval;
  auto _mls_x376 = _mlsValue::create<_mls_Lambda_uniclHelper>();
  auto _mls_x377 = _mlsValue::create<_mls_Nil>();
  auto _mls_x378 = _mls_foldr(_mls_x376, _mls_x377, _mls_a8);
  _mls_retval = _mls_x378;
  return _mls_retval;
}
_mlsValue _mls_uniclHelper(_mlsValue _mls_p8, _mlsValue _mls_x381) {
  _mlsValue _mls_retval;
  auto [_mls_x1172, _mls_x1173] = _mls_clause_pre(_mls_p8);
  if (_mlsValue::isValueOf<_mls_Dis>(_mls_x1172)) {
    auto _mls_x1181 = _mlsValue::cast<_mls_Dis>(_mls_x1172)->_mls_a;
    auto _mls_x1182 = _mlsValue::cast<_mls_Dis>(_mls_x1172)->_mls_b;
    if (_mlsValue::isValueOf<_mls_Dis>(_mls_x1182)) {
      auto _mls_x1187 = _mlsValue::cast<_mls_Dis>(_mls_x1182)->_mls_a;
      auto _mls_x1188 = _mlsValue::cast<_mls_Dis>(_mls_x1182)->_mls_b;
      if (_mlsValue::isValueOf<_mls_Dis>(_mls_x1188)) {
        auto _mls_x1191 = _mls_clauseHelper_case0_sr_post_case0_sr_post_case0(_mls_x1188, _mls_x1173, _mls_x1187, _mls_x1181);
        _mls_retval = _mls_uniclHelper_caller_post(_mls_x1191, _mls_x381);
      } else if (_mlsValue::isValueOf<_mls_Sym>(_mls_x1188)) {
        auto _mls_x1190 = _mls_clauseHelper_case0_sr_post_case0_sr_post_case1(_mls_x1188, _mls_x1173, _mls_x1187, _mls_x1181);
        _mls_retval = _mls_uniclHelper_caller_post(_mls_x1190, _mls_x381);
      } else if (_mlsValue::isValueOf<_mls_Not>(_mls_x1188)) {
        auto _mls_x1189 = _mls_clauseHelper_case0_sr_post_case0_sr_post_case2(_mls_x1188, _mls_x1173, _mls_x1187, _mls_x1181);
        _mls_retval = _mls_uniclHelper_caller_post(_mls_x1189, _mls_x381);
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else if (_mlsValue::isValueOf<_mls_Sym>(_mls_x1182)) {
      auto _mls_x1185 = _mlsValue::cast<_mls_Sym>(_mls_x1182)->_mls_a;
      auto _mls_x1186 = _mls_clauseHelper_case0_sr_post_case1_sr_post_case0(_mls_x1173, _mls_x1185, _mls_x1181);
      _mls_retval = _mls_uniclHelper_caller_post(_mls_x1186, _mls_x381);
    } else if (_mlsValue::isValueOf<_mls_Not>(_mls_x1182)) {
      auto _mls_x1183 = _mlsValue::cast<_mls_Not>(_mls_x1182)->_mls_a;
      if (_mlsValue::isValueOf<_mls_Sym>(_mls_x1183)) {
        auto _mls_x1184 = _mls_clauseHelper_case0_sr_post_case2_sr_post_case0(_mls_x1183, _mls_x1173, _mls_x1181);
        _mls_retval = _mls_uniclHelper_caller_post(_mls_x1184, _mls_x381);
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else if (_mlsValue::isValueOf<_mls_Sym>(_mls_x1172)) {
    auto _mls_x1177 = _mlsValue::cast<_mls_Sym>(_mls_x1172)->_mls_a;
    auto _mls_x1178 = _mlsValue::cast<_mls_Tuple2>(_mls_x1173)->_mls_field0;
    auto _mls_x1179 = _mlsValue::cast<_mls_Tuple2>(_mls_x1173)->_mls_field1;
    auto _mls_x1180 = _mls_clauseHelper_case1_sr_post_case0_sr_post(_mls_x1177, _mls_x1178, _mls_x1179);
    _mls_retval = _mls_uniclHelper_caller_post_case0(_mls_x1180, _mls_x381);
  } else if (_mlsValue::isValueOf<_mls_Not>(_mls_x1172)) {
    auto _mls_x1174 = _mlsValue::cast<_mls_Not>(_mls_x1172)->_mls_a;
    if (_mlsValue::isValueOf<_mls_Sym>(_mls_x1174)) {
      auto _mls_x1175 = _mlsValue::cast<_mls_Sym>(_mls_x1174)->_mls_a;
      auto _mls_x1176 = _mls_clauseHelper_case2_sr_post_case0_sr_post_case0(_mls_x1173, _mls_x1175);
      _mls_retval = _mls_uniclHelper_caller_post(_mls_x1176, _mls_x381);
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_uniclHelper_caller_post(_mlsValue _mls_x1192, _mlsValue _mls_x1193) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x1192)) {
    _mls_retval = _mls_uniclHelper_caller_post_case0(_mls_x1192, _mls_x1193);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_uniclHelper_caller_post_case0(_mlsValue _mls_x1195, _mlsValue _mls_x1198) {
  _mlsValue _mls_retval;
  auto _mls_x1194 = _mlsValue::cast<_mls_Tuple2>(_mls_x1195)->_mls_field0;
  auto _mls_x1196 = _mlsValue::cast<_mls_Tuple2>(_mls_x1195)->_mls_field1;
  auto _mls_x1197 = _mls_tautclause_case0_sr_post_pre(_mls_x1196, _mls_x1194);
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1197)) {
    auto _mls_x1199 = _mls_insert(_mls_x1195, _mls_x1198);
    _mls_retval = _mls_x1199;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1197)) {
    _mls_retval = _mls_x1198;
  } else {
    _mls_retval = _mls_x1198;
  }
  return _mls_retval;
}
_mlsValue _mls_while_(_mlsValue _mls_p9, _mlsValue _mls_f3, _mlsValue _mls_x383) {
  _mlsValue _mls_retval;
  auto _mls_x384 = _mlsMethodCall<_mls_Callable>(_mls_p9)->_mls_apply1(_mls_x383);
  if (_mlsValue::isIntLit(_mls_x384, 1)) {
    auto _mls_x385 = _mlsMethodCall<_mls_Callable>(_mls_f3)->_mls_apply1(_mls_x383);
    auto _mls_x386 = _mls_while_(_mls_p9, _mls_f3, _mls_x385);
    _mls_retval = _mls_x386;
  } else {
    _mls_retval = _mls_x383;
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_clauses::_mls_apply1(_mlsValue _mls_arg) {
  _mlsValue _mls_retval;
  auto _mls_x = _mls_clauses(_mls_arg);
  _mls_retval = _mls_x;
  return _mls_retval;
}
_mlsValue _mls_Lambda_disp::_mls_apply1(_mlsValue _mls_arg1) {
  _mlsValue _mls_retval;
  auto _mls_x1 = _mls_disp(_mls_arg1);
  _mls_retval = _mls_x1;
  return _mls_retval;
}
_mlsValue _mls_Lambda_l::_mls_apply2(_mlsValue _mls_ls, _mlsValue _mls_a4) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls)) {
    _mls_retval = _mls_a4;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls)) {
    auto _mls_x2 = _mlsValue::cast<_mls_Cons>(_mls_ls)->_mls_head;
    auto _mls_x3 = _mlsValue::cast<_mls_Cons>(_mls_ls)->_mls_tail;
    auto _mls_x4 = (_mls_a4 + _mlsValue::fromIntLit(1));
    auto _mls_x5 = this->_mls_apply2(_mls_x3, _mls_x4);
    _mls_retval = _mls_x5;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda::_mls_apply1(_mlsValue _mls_s) {
  _mlsValue _mls_retval;
  auto _mls_x6 = _mls_spri(_mls_s);
  auto _mls_x7 = (_mls_x6 != _mlsValue::fromIntLit(0));
  _mls_retval = _mls_x7;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lscomp::_mls_apply1(_mlsValue _mls_ls1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls1)) {
    auto _mls_x14 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x14;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls1)) {
    auto _mls_x8 = _mlsValue::cast<_mls_Cons>(_mls_ls1)->_mls_head;
    auto _mls_x9 = _mlsValue::cast<_mls_Cons>(_mls_ls1)->_mls_tail;
    auto _mls_x10 = _mls_inList(_mls_x8, _mls_lam_arg0);
    if (_mlsValue::isIntLit(_mls_x10, 1)) {
      auto _mls_x12 = this->_mls_apply1(_mls_x9);
      auto _mls_x13 = _mlsValue::create<_mls_Cons>(_mls_x8, _mls_x12);
      _mls_retval = _mls_x13;
    } else {
      auto _mls_x11 = this->_mls_apply1(_mls_x9);
      _mls_retval = _mls_x11;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_red::_mls_apply1(_mlsValue _mls_arg2) {
  _mlsValue _mls_retval;
  auto _mls_x15 = _mls_red(_mls_arg2);
  _mls_retval = _mls_x15;
  return _mls_retval;
}
_mlsValue _mls_Lambda_uniclHelper::_mls_apply2(_mlsValue _mls_arg3, _mlsValue _mls_arg4) {
  _mlsValue _mls_retval;
  auto _mls_x16 = _mls_uniclHelper(_mls_arg3, _mls_arg4);
  _mls_retval = _mls_x16;
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
