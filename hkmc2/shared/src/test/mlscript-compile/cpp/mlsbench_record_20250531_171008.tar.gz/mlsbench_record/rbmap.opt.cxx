#include "mlsprelude.h"
struct _mls_Tree;
struct _mls_LamF;
struct _mls_Color;
struct _mls_Leaf;
struct _mls_Node;
struct _mls_Black;
struct _mls_Red;
_mlsValue _mls_mkMapAux(_mlsValue, _mlsValue);
_mlsValue _mls_insert_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_fold_case1_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_ins_case1(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_ins_case0(_mlsValue, _mlsValue);
_mlsValue _mls_mkMapAux_default(_mlsValue, _mlsValue);
_mlsValue _mls_insert(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_apply_f(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_mkMapAux_pre(_mlsValue, _mlsValue);
_mlsValue _mls_ins(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_ins_caller_post1(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_balance2(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_ins_caller_post_default1(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_ins_caller_post_default(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_main();
_mlsValue _mls_ins_caller_post_case0(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_mkMap(_mlsValue);
_mlsValue _mls_isRed_case0_sr_post(_mlsValue);
_mlsValue _mls_insert_caller_post_case0(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_balance1(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_ins_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_fold(_mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_fold_case1_sr_post_pre(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_setBlack(_mlsValue);
_mlsValue _mls_ins_caller_post_case01(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
struct _mls_Tree: public _mlsObject {
  
  constexpr static inline const char *typeName = "Tree";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Tree; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_LamF: public _mlsObject {
  
  constexpr static inline const char *typeName = "LamF";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_LamF; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Color: public _mlsObject {
  
  constexpr static inline const char *typeName = "Color";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Color; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Leaf: public _mls_Tree {
  
  constexpr static inline const char *typeName = "Leaf";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Leaf; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Node: public _mls_Tree {
  _mlsValue _mls_color;
  _mlsValue _mls_left;
  _mlsValue _mls_key;
  _mlsValue _mls_value;
  _mlsValue _mls_right;
  constexpr static inline const char *typeName = "Node";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_color.print(); std::printf(", "); this->_mls_left.print(); std::printf(", "); this->_mls_key.print(); std::printf(", "); this->_mls_value.print(); std::printf(", "); this->_mls_right.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_color); _mlsValue::destroy(this->_mls_left); _mlsValue::destroy(this->_mls_key); _mlsValue::destroy(this->_mls_value); _mlsValue::destroy(this->_mls_right);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_color.asObject()->operator==(*other.cast<_mls_Node>()->_mls_color.asObject()) && this->_mls_left.asObject()->operator==(*other.cast<_mls_Node>()->_mls_left.asObject()) && this->_mls_key.asObject()->operator==(*other.cast<_mls_Node>()->_mls_key.asObject()) && this->_mls_value.asObject()->operator==(*other.cast<_mls_Node>()->_mls_value.asObject()) && this->_mls_right.asObject()->operator==(*other.cast<_mls_Node>()->_mls_right.asObject()); }
  static _mlsValue create(_mlsValue _mls_color, _mlsValue _mls_left, _mlsValue _mls_key, _mlsValue _mls_value, _mlsValue _mls_right) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Node; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_color = _mls_color; _mlsVal->_mls_left = _mls_left; _mlsVal->_mls_key = _mls_key; _mlsVal->_mls_value = _mls_value; _mlsVal->_mls_right = _mls_right;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Black: public _mls_Color {
  
  constexpr static inline const char *typeName = "Black";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Black; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Red: public _mls_Color {
  
  constexpr static inline const char *typeName = "Red";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Red; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_ins_caller_post_default(_mlsValue _mls_x295, _mlsValue _mls_x290, _mlsValue _mls_x296, _mlsValue _mls_x289, _mlsValue _mls_x294, _mlsValue _mls_x288) {
  _mlsValue _mls_retval;
  auto _mls_x291 = _mls_ins(_mls_x288, _mls_x289, _mls_x290);
  auto _mls_x292 = _mlsValue::create<_mls_Black>();
  auto _mls_x293 = _mlsValue::create<_mls_Node>(_mls_x292, _mls_x294, _mls_x295, _mls_x296, _mls_x291);
  _mls_retval = _mls_x293;
  return _mls_retval;
}
_mlsValue _mls_ins_caller_post1(_mlsValue _mls_x248, _mlsValue _mls_x250, _mlsValue _mls_x247, _mlsValue _mls_x249, _mlsValue _mls_x246, _mlsValue _mls_x245, _mlsValue _mls_x251) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_x245, 1)) {
    _mls_retval = _mls_ins_caller_post_case01(_mls_x246, _mls_x247, _mls_x248, _mls_x249, _mls_x250, _mls_x251);
  } else {
    _mls_retval = _mls_ins_caller_post_default1(_mls_x246, _mls_x247, _mls_x248, _mls_x249, _mls_x250, _mls_x251);
  }
  return _mls_retval;
}
_mlsValue _mls_insert_caller_post(_mlsValue _mls_x252, _mlsValue _mls_x253, _mlsValue _mls_x254, _mlsValue _mls_x255) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_x252, 1)) {
    _mls_retval = _mls_insert_caller_post_case0(_mls_x253, _mls_x254, _mls_x255);
  } else {
    auto _mls_x256 = _mls_ins(_mls_x253, _mls_x254, _mls_x255);
    _mls_retval = _mls_x256;
  }
  return _mls_retval;
}
_mlsValue _mls_insert_caller_post_case0(_mlsValue _mls_x314, _mlsValue _mls_x315, _mlsValue _mls_x313) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Leaf>(_mls_x313)) {
    auto _mls_x318 = _mls_ins_case0(_mls_x314, _mls_x315);
    auto _mls_x319 = _mls_setBlack(_mls_x318);
    _mls_retval = _mls_x319;
  } else if (_mlsValue::isValueOf<_mls_Node>(_mls_x313)) {
    auto _mls_x316 = _mls_ins_case1(_mls_x313, _mls_x314, _mls_x315);
    auto _mls_x317 = _mls_setBlack(_mls_x316);
    _mls_retval = _mls_x317;
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_ins_caller_post(_mlsValue _mls_x229, _mlsValue _mls_x227, _mlsValue _mls_x230, _mlsValue _mls_x228, _mlsValue _mls_x231, _mlsValue _mls_x232, _mlsValue _mls_x233) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_x227, 1)) {
    _mls_retval = _mls_ins_caller_post_case0(_mls_x228, _mls_x229, _mls_x230, _mls_x231, _mls_x232, _mls_x233);
  } else {
    _mls_retval = _mls_ins_caller_post_default(_mls_x228, _mls_x229, _mls_x230, _mls_x231, _mls_x232, _mls_x233);
  }
  return _mls_retval;
}
_mlsValue _mls_mkMap(_mlsValue _mls_n1) {
  _mlsValue _mls_retval;
  auto _mls_x155 = _mlsValue::create<_mls_Leaf>();
  auto [_mls_x309, _mls_x310, _mls_x311] = _mls_mkMapAux_pre(_mls_n1, _mls_x155);
  if (_mlsValue::isIntLit(_mls_x309, 1)) {
    _mls_retval = _mls_x310;
  } else {
    auto _mls_x312 = _mls_mkMapAux_default(_mls_x311, _mls_x310);
    _mls_retval = _mls_x312;
  }
  return _mls_retval;
}
_mlsValue _mls_fold_case1_sr_post(_mlsValue _mls_x278, _mlsValue _mls_x279, _mlsValue _mls_x280, _mlsValue _mls_x281, _mlsValue _mls_x282, _mlsValue _mls_x283) {
  _mlsValue _mls_retval;
  auto [_mls_x284, _mls_x285, _mls_x286] = _mls_fold_case1_sr_post_pre(_mls_x278, _mls_x279, _mls_x280, _mls_x281, _mls_x282, _mls_x283);
  auto _mls_x287 = _mls_fold(_mls_x284, _mls_x285, _mls_x286);
  _mls_retval = _mls_x287;
  return _mls_retval;
}
_mlsValue _mls_setBlack(_mlsValue _mls_t6) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Node>(_mls_t6)) {
    auto _mls_x160 = _mlsValue::cast<_mls_Node>(_mls_t6)->_mls_left;
    auto _mls_x161 = _mlsValue::cast<_mls_Node>(_mls_t6)->_mls_key;
    auto _mls_x162 = _mlsValue::cast<_mls_Node>(_mls_t6)->_mls_value;
    auto _mls_x163 = _mlsValue::cast<_mls_Node>(_mls_t6)->_mls_right;
    auto _mls_x164 = _mlsValue::create<_mls_Black>();
    auto _mls_x165 = _mlsValue::create<_mls_Node>(_mls_x164, _mls_x160, _mls_x161, _mls_x162, _mls_x163);
    _mls_retval = _mls_x165;
  } else {
    _mls_retval = _mls_t6;
  }
  return _mls_retval;
}
_mlsValue _mls_ins_caller_post_default1(_mlsValue _mls_x218, _mlsValue _mls_x224, _mlsValue _mls_x226, _mlsValue _mls_x220, _mlsValue _mls_x225, _mlsValue _mls_x219) {
  _mlsValue _mls_retval;
  auto _mls_x221 = _mls_ins(_mls_x218, _mls_x219, _mls_x220);
  auto _mls_x222 = _mlsValue::create<_mls_Black>();
  auto _mls_x223 = _mlsValue::create<_mls_Node>(_mls_x222, _mls_x221, _mls_x224, _mls_x225, _mls_x226);
  _mls_retval = _mls_x223;
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x108 = _mls_main();
  _mls_retval = _mls_x108;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_fold_case1_sr_post_pre(_mlsValue _mls_x211, _mlsValue _mls_x217, _mlsValue _mls_x210, _mlsValue _mls_x215, _mlsValue _mls_x214, _mlsValue _mls_x212) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x213 = _mls_fold(_mls_x210, _mls_x211, _mls_x212);
  auto _mls_x216 = _mls_apply_f(_mls_x210, _mls_x214, _mls_x215, _mls_x213);
  _mls_retval = std::make_tuple(_mls_x210, _mls_x217, _mls_x216);
  return _mls_retval;
}
_mlsValue _mls_ins_case0(_mlsValue _mls_x269, _mlsValue _mls_x270) {
  _mlsValue _mls_retval;
  auto _mls_x265 = _mlsValue::create<_mls_Red>();
  auto _mls_x266 = _mlsValue::create<_mls_Leaf>();
  auto _mls_x267 = _mlsValue::create<_mls_Leaf>();
  auto _mls_x268 = _mlsValue::create<_mls_Node>(_mls_x265, _mls_x266, _mls_x269, _mls_x270, _mls_x267);
  _mls_retval = _mls_x268;
  return _mls_retval;
}
_mlsValue _mls_ins_caller_post_case01(_mlsValue _mls_x297, _mlsValue _mls_x301, _mlsValue _mls_x299, _mlsValue _mls_x303, _mlsValue _mls_x302, _mlsValue _mls_x298) {
  _mlsValue _mls_retval;
  auto _mls_x300 = _mls_ins(_mls_x297, _mls_x298, _mls_x299);
  auto _mls_x304 = _mls_balance1(_mls_x301, _mls_x302, _mls_x300, _mls_x303);
  _mls_retval = _mls_x304;
  return _mls_retval;
}
_mlsValue _mls_balance1(_mlsValue _mls_k, _mlsValue _mls_v, _mlsValue _mls_t1, _mlsValue _mls_t2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Node>(_mls_t2)) {
    auto _mls_x1 = _mlsValue::cast<_mls_Node>(_mls_t2)->_mls_left;
    auto _mls_x2 = _mlsValue::cast<_mls_Node>(_mls_t2)->_mls_key;
    auto _mls_x3 = _mlsValue::cast<_mls_Node>(_mls_t2)->_mls_value;
    auto _mls_x4 = _mlsValue::cast<_mls_Node>(_mls_t2)->_mls_right;
    if (_mlsValue::isValueOf<_mls_Node>(_mls_x1)) {
      auto _mls_x24 = _mlsValue::cast<_mls_Node>(_mls_x1)->_mls_color;
      auto _mls_x25 = _mlsValue::cast<_mls_Node>(_mls_x1)->_mls_left;
      auto _mls_x26 = _mlsValue::cast<_mls_Node>(_mls_x1)->_mls_key;
      auto _mls_x27 = _mlsValue::cast<_mls_Node>(_mls_x1)->_mls_value;
      auto _mls_x28 = _mlsValue::cast<_mls_Node>(_mls_x1)->_mls_right;
      if (_mlsValue::isValueOf<_mls_Red>(_mls_x24)) {
        auto _mls_x48 = _mlsValue::create<_mls_Black>();
        auto _mls_x49 = _mlsValue::create<_mls_Node>(_mls_x48, _mls_x25, _mls_x26, _mls_x27, _mls_x28);
        auto _mls_x50 = _mlsValue::create<_mls_Black>();
        auto _mls_x51 = _mlsValue::create<_mls_Node>(_mls_x50, _mls_x4, _mls_k, _mls_v, _mls_t1);
        auto _mls_x52 = _mlsValue::create<_mls_Red>();
        auto _mls_x53 = _mlsValue::create<_mls_Node>(_mls_x52, _mls_x49, _mls_x2, _mls_x3, _mls_x51);
        _mls_retval = _mls_x53;
      } else {
        if (_mlsValue::isValueOf<_mls_Node>(_mls_x4)) {
          auto _mls_x33 = _mlsValue::cast<_mls_Node>(_mls_x4)->_mls_color;
          auto _mls_x34 = _mlsValue::cast<_mls_Node>(_mls_x4)->_mls_left;
          auto _mls_x35 = _mlsValue::cast<_mls_Node>(_mls_x4)->_mls_key;
          auto _mls_x36 = _mlsValue::cast<_mls_Node>(_mls_x4)->_mls_value;
          auto _mls_x37 = _mlsValue::cast<_mls_Node>(_mls_x4)->_mls_right;
          if (_mlsValue::isValueOf<_mls_Red>(_mls_x33)) {
            auto _mls_x42 = _mlsValue::create<_mls_Black>();
            auto _mls_x43 = _mlsValue::create<_mls_Node>(_mls_x42, _mls_x1, _mls_x2, _mls_x3, _mls_x34);
            auto _mls_x44 = _mlsValue::create<_mls_Black>();
            auto _mls_x45 = _mlsValue::create<_mls_Node>(_mls_x44, _mls_x37, _mls_k, _mls_v, _mls_t1);
            auto _mls_x46 = _mlsValue::create<_mls_Red>();
            auto _mls_x47 = _mlsValue::create<_mls_Node>(_mls_x46, _mls_x43, _mls_x35, _mls_x36, _mls_x45);
            _mls_retval = _mls_x47;
          } else {
            auto _mls_x38 = _mlsValue::create<_mls_Red>();
            auto _mls_x39 = _mlsValue::create<_mls_Node>(_mls_x38, _mls_x1, _mls_x2, _mls_x3, _mls_x4);
            auto _mls_x40 = _mlsValue::create<_mls_Black>();
            auto _mls_x41 = _mlsValue::create<_mls_Node>(_mls_x40, _mls_x39, _mls_k, _mls_v, _mls_t1);
            _mls_retval = _mls_x41;
          }
        } else {
          auto _mls_x29 = _mlsValue::create<_mls_Red>();
          auto _mls_x30 = _mlsValue::create<_mls_Node>(_mls_x29, _mls_x1, _mls_x2, _mls_x3, _mls_x4);
          auto _mls_x31 = _mlsValue::create<_mls_Black>();
          auto _mls_x32 = _mlsValue::create<_mls_Node>(_mls_x31, _mls_x30, _mls_k, _mls_v, _mls_t1);
          _mls_retval = _mls_x32;
        }
      }
    } else {
      if (_mlsValue::isValueOf<_mls_Node>(_mls_x4)) {
        auto _mls_x9 = _mlsValue::cast<_mls_Node>(_mls_x4)->_mls_color;
        auto _mls_x10 = _mlsValue::cast<_mls_Node>(_mls_x4)->_mls_left;
        auto _mls_x11 = _mlsValue::cast<_mls_Node>(_mls_x4)->_mls_key;
        auto _mls_x12 = _mlsValue::cast<_mls_Node>(_mls_x4)->_mls_value;
        auto _mls_x13 = _mlsValue::cast<_mls_Node>(_mls_x4)->_mls_right;
        if (_mlsValue::isValueOf<_mls_Red>(_mls_x9)) {
          auto _mls_x18 = _mlsValue::create<_mls_Black>();
          auto _mls_x19 = _mlsValue::create<_mls_Node>(_mls_x18, _mls_x1, _mls_x2, _mls_x3, _mls_x10);
          auto _mls_x20 = _mlsValue::create<_mls_Black>();
          auto _mls_x21 = _mlsValue::create<_mls_Node>(_mls_x20, _mls_x13, _mls_k, _mls_v, _mls_t1);
          auto _mls_x22 = _mlsValue::create<_mls_Red>();
          auto _mls_x23 = _mlsValue::create<_mls_Node>(_mls_x22, _mls_x19, _mls_x11, _mls_x12, _mls_x21);
          _mls_retval = _mls_x23;
        } else {
          auto _mls_x14 = _mlsValue::create<_mls_Red>();
          auto _mls_x15 = _mlsValue::create<_mls_Node>(_mls_x14, _mls_x1, _mls_x2, _mls_x3, _mls_x4);
          auto _mls_x16 = _mlsValue::create<_mls_Black>();
          auto _mls_x17 = _mlsValue::create<_mls_Node>(_mls_x16, _mls_x15, _mls_k, _mls_v, _mls_t1);
          _mls_retval = _mls_x17;
        }
      } else {
        auto _mls_x5 = _mlsValue::create<_mls_Red>();
        auto _mls_x6 = _mlsValue::create<_mls_Node>(_mls_x5, _mls_x1, _mls_x2, _mls_x3, _mls_x4);
        auto _mls_x7 = _mlsValue::create<_mls_Black>();
        auto _mls_x8 = _mlsValue::create<_mls_Node>(_mls_x7, _mls_x6, _mls_k, _mls_v, _mls_t1);
        _mls_retval = _mls_x8;
      }
    }
  } else {
    auto _mls_x = _mlsValue::create<_mls_Leaf>();
    _mls_retval = _mls_x;
  }
  return _mls_retval;
}
_mlsValue _mls_mkMapAux_default(_mlsValue _mls_x321, _mlsValue _mls_x324) {
  _mlsValue _mls_retval;
  auto _mls_x320 = (_mls_x321 - _mlsValue::fromIntLit(1));
  auto _mls_x322 = (_mls_x321 % _mlsValue::fromIntLit(10));
  auto _mls_x323 = (_mls_x322 == _mlsValue::fromIntLit(0));
  auto _mls_x325 = _mls_insert(_mls_x321, _mls_x323, _mls_x324);
  auto _mls_x326 = _mls_mkMapAux(_mls_x320, _mls_x325);
  _mls_retval = _mls_x326;
  return _mls_retval;
}
_mlsValue _mls_insert(_mlsValue _mls_k2, _mlsValue _mls_v2, _mlsValue _mls_t4) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Node>(_mls_t4)) {
    auto _mls_x308 = _mlsValue::cast<_mls_Node>(_mls_t4)->_mls_color;
    if (_mlsValue::isValueOf<_mls_Red>(_mls_x308)) {
      _mls_retval = _mls_insert_caller_post(_mlsValue::fromIntLit(1), _mls_k2, _mls_v2, _mls_t4);
    } else {
      _mls_retval = _mls_insert_caller_post(_mlsValue::fromIntLit(0), _mls_k2, _mls_v2, _mls_t4);
    }
  } else {
    if (_mlsValue::isValueOf<_mls_Leaf>(_mls_t4)) {
      auto _mls_x307 = _mls_ins_case0(_mls_k2, _mls_v2);
      _mls_retval = _mls_x307;
    } else if (_mlsValue::isValueOf<_mls_Node>(_mls_t4)) {
      auto _mls_x306 = _mls_ins_case1(_mls_t4, _mls_k2, _mls_v2);
      _mls_retval = _mls_x306;
    } else {
      throw std::runtime_error("match error" LINE_STRING);
    }
  }
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_mkMapAux_pre(_mlsValue _mls_x240, _mlsValue _mls_x241) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x239 = (_mls_x240 == _mlsValue::fromIntLit(0));
  _mls_retval = std::make_tuple(_mls_x239, _mls_x241, _mls_x240);
  return _mls_retval;
}
_mlsValue _mls_main() {
  _mlsValue _mls_retval;
  auto _mls_x157 = _mls_mkMap(_mlsValue::fromIntLit(6000));
  auto _mls_x158 = _mlsValue::create<_mls_LamF>();
  if (_mlsValue::isValueOf<_mls_Leaf>(_mls_x157)) {
    _mls_retval = _mlsValue::fromIntLit(0);
  } else if (_mlsValue::isValueOf<_mls_Node>(_mls_x157)) {
    auto _mls_x257 = _mlsValue::cast<_mls_Node>(_mls_x157)->_mls_left;
    auto _mls_x258 = _mlsValue::cast<_mls_Node>(_mls_x157)->_mls_key;
    auto _mls_x259 = _mlsValue::cast<_mls_Node>(_mls_x157)->_mls_value;
    auto _mls_x260 = _mlsValue::cast<_mls_Node>(_mls_x157)->_mls_right;
    auto [_mls_x261, _mls_x262, _mls_x263] = _mls_fold_case1_sr_post_pre(_mls_x257, _mls_x260, _mls_x158, _mls_x259, _mls_x258, _mlsValue::fromIntLit(0));
    auto _mls_x264 = _mls_fold(_mls_x261, _mls_x262, _mls_x263);
    _mls_retval = _mls_x264;
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_isRed_case0_sr_post(_mlsValue _mls_x305) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Red>(_mls_x305)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else {
    _mls_retval = _mlsValue::fromIntLit(0);
  }
  return _mls_retval;
}
_mlsValue _mls_balance2(_mlsValue _mls_t11, _mlsValue _mls_k1, _mlsValue _mls_v1, _mlsValue _mls_t21) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Node>(_mls_t21)) {
    auto _mls_x55 = _mlsValue::cast<_mls_Node>(_mls_t21)->_mls_left;
    auto _mls_x56 = _mlsValue::cast<_mls_Node>(_mls_t21)->_mls_key;
    auto _mls_x57 = _mlsValue::cast<_mls_Node>(_mls_t21)->_mls_value;
    auto _mls_x58 = _mlsValue::cast<_mls_Node>(_mls_t21)->_mls_right;
    if (_mlsValue::isValueOf<_mls_Node>(_mls_x55)) {
      auto _mls_x78 = _mlsValue::cast<_mls_Node>(_mls_x55)->_mls_color;
      auto _mls_x79 = _mlsValue::cast<_mls_Node>(_mls_x55)->_mls_left;
      auto _mls_x80 = _mlsValue::cast<_mls_Node>(_mls_x55)->_mls_key;
      auto _mls_x81 = _mlsValue::cast<_mls_Node>(_mls_x55)->_mls_value;
      auto _mls_x82 = _mlsValue::cast<_mls_Node>(_mls_x55)->_mls_right;
      if (_mlsValue::isValueOf<_mls_Red>(_mls_x78)) {
        auto _mls_x102 = _mlsValue::create<_mls_Black>();
        auto _mls_x103 = _mlsValue::create<_mls_Node>(_mls_x102, _mls_t11, _mls_k1, _mls_v1, _mls_x79);
        auto _mls_x104 = _mlsValue::create<_mls_Black>();
        auto _mls_x105 = _mlsValue::create<_mls_Node>(_mls_x104, _mls_x82, _mls_x56, _mls_x57, _mls_x58);
        auto _mls_x106 = _mlsValue::create<_mls_Red>();
        auto _mls_x107 = _mlsValue::create<_mls_Node>(_mls_x106, _mls_x103, _mls_x80, _mls_x81, _mls_x105);
        _mls_retval = _mls_x107;
      } else {
        if (_mlsValue::isValueOf<_mls_Node>(_mls_x58)) {
          auto _mls_x87 = _mlsValue::cast<_mls_Node>(_mls_x58)->_mls_color;
          auto _mls_x88 = _mlsValue::cast<_mls_Node>(_mls_x58)->_mls_left;
          auto _mls_x89 = _mlsValue::cast<_mls_Node>(_mls_x58)->_mls_key;
          auto _mls_x90 = _mlsValue::cast<_mls_Node>(_mls_x58)->_mls_value;
          auto _mls_x91 = _mlsValue::cast<_mls_Node>(_mls_x58)->_mls_right;
          if (_mlsValue::isValueOf<_mls_Red>(_mls_x87)) {
            auto _mls_x96 = _mlsValue::create<_mls_Black>();
            auto _mls_x97 = _mlsValue::create<_mls_Node>(_mls_x96, _mls_t11, _mls_k1, _mls_v1, _mls_x55);
            auto _mls_x98 = _mlsValue::create<_mls_Black>();
            auto _mls_x99 = _mlsValue::create<_mls_Node>(_mls_x98, _mls_x88, _mls_x89, _mls_x90, _mls_x91);
            auto _mls_x100 = _mlsValue::create<_mls_Red>();
            auto _mls_x101 = _mlsValue::create<_mls_Node>(_mls_x100, _mls_x97, _mls_x56, _mls_x57, _mls_x99);
            _mls_retval = _mls_x101;
          } else {
            auto _mls_x92 = _mlsValue::create<_mls_Red>();
            auto _mls_x93 = _mlsValue::create<_mls_Node>(_mls_x92, _mls_x55, _mls_x56, _mls_x57, _mls_x58);
            auto _mls_x94 = _mlsValue::create<_mls_Black>();
            auto _mls_x95 = _mlsValue::create<_mls_Node>(_mls_x94, _mls_t11, _mls_k1, _mls_v1, _mls_x93);
            _mls_retval = _mls_x95;
          }
        } else {
          auto _mls_x83 = _mlsValue::create<_mls_Red>();
          auto _mls_x84 = _mlsValue::create<_mls_Node>(_mls_x83, _mls_x55, _mls_x56, _mls_x57, _mls_x58);
          auto _mls_x85 = _mlsValue::create<_mls_Black>();
          auto _mls_x86 = _mlsValue::create<_mls_Node>(_mls_x85, _mls_t11, _mls_k1, _mls_v1, _mls_x84);
          _mls_retval = _mls_x86;
        }
      }
    } else {
      if (_mlsValue::isValueOf<_mls_Node>(_mls_x58)) {
        auto _mls_x63 = _mlsValue::cast<_mls_Node>(_mls_x58)->_mls_color;
        auto _mls_x64 = _mlsValue::cast<_mls_Node>(_mls_x58)->_mls_left;
        auto _mls_x65 = _mlsValue::cast<_mls_Node>(_mls_x58)->_mls_key;
        auto _mls_x66 = _mlsValue::cast<_mls_Node>(_mls_x58)->_mls_value;
        auto _mls_x67 = _mlsValue::cast<_mls_Node>(_mls_x58)->_mls_right;
        if (_mlsValue::isValueOf<_mls_Red>(_mls_x63)) {
          auto _mls_x72 = _mlsValue::create<_mls_Black>();
          auto _mls_x73 = _mlsValue::create<_mls_Node>(_mls_x72, _mls_t11, _mls_k1, _mls_v1, _mls_x55);
          auto _mls_x74 = _mlsValue::create<_mls_Black>();
          auto _mls_x75 = _mlsValue::create<_mls_Node>(_mls_x74, _mls_x64, _mls_x65, _mls_x66, _mls_x67);
          auto _mls_x76 = _mlsValue::create<_mls_Red>();
          auto _mls_x77 = _mlsValue::create<_mls_Node>(_mls_x76, _mls_x73, _mls_x56, _mls_x57, _mls_x75);
          _mls_retval = _mls_x77;
        } else {
          auto _mls_x68 = _mlsValue::create<_mls_Red>();
          auto _mls_x69 = _mlsValue::create<_mls_Node>(_mls_x68, _mls_x55, _mls_x56, _mls_x57, _mls_x58);
          auto _mls_x70 = _mlsValue::create<_mls_Black>();
          auto _mls_x71 = _mlsValue::create<_mls_Node>(_mls_x70, _mls_t11, _mls_k1, _mls_v1, _mls_x69);
          _mls_retval = _mls_x71;
        }
      } else {
        auto _mls_x59 = _mlsValue::create<_mls_Red>();
        auto _mls_x60 = _mlsValue::create<_mls_Node>(_mls_x59, _mls_x55, _mls_x56, _mls_x57, _mls_x58);
        auto _mls_x61 = _mlsValue::create<_mls_Black>();
        auto _mls_x62 = _mlsValue::create<_mls_Node>(_mls_x61, _mls_t11, _mls_k1, _mls_v1, _mls_x60);
        _mls_retval = _mls_x62;
      }
    }
  } else {
    auto _mls_x54 = _mlsValue::create<_mls_Leaf>();
    _mls_retval = _mls_x54;
  }
  return _mls_retval;
}
_mlsValue _mls_ins_case1(_mlsValue _mls_x175, _mlsValue _mls_x181, _mlsValue _mls_x183) {
  _mlsValue _mls_retval;
  auto _mls_x174 = _mlsValue::cast<_mls_Node>(_mls_x175)->_mls_color;
  auto _mls_x176 = _mlsValue::cast<_mls_Node>(_mls_x175)->_mls_left;
  auto _mls_x177 = _mlsValue::cast<_mls_Node>(_mls_x175)->_mls_key;
  auto _mls_x178 = _mlsValue::cast<_mls_Node>(_mls_x175)->_mls_value;
  auto _mls_x179 = _mlsValue::cast<_mls_Node>(_mls_x175)->_mls_right;
  if (_mlsValue::isValueOf<_mls_Red>(_mls_x174)) {
    auto _mls_x190 = (_mls_x181 < _mls_x177);
    if (_mlsValue::isIntLit(_mls_x190, 1)) {
      auto _mls_x197 = _mls_ins(_mls_x181, _mls_x183, _mls_x176);
      auto _mls_x198 = _mlsValue::create<_mls_Red>();
      auto _mls_x199 = _mlsValue::create<_mls_Node>(_mls_x198, _mls_x197, _mls_x177, _mls_x178, _mls_x179);
      _mls_retval = _mls_x199;
    } else {
      auto _mls_x191 = (_mls_x181 == _mls_x177);
      if (_mlsValue::isIntLit(_mls_x191, 1)) {
        auto _mls_x195 = _mlsValue::create<_mls_Red>();
        auto _mls_x196 = _mlsValue::create<_mls_Node>(_mls_x195, _mls_x176, _mls_x181, _mls_x183, _mls_x179);
        _mls_retval = _mls_x196;
      } else {
        auto _mls_x192 = _mls_ins(_mls_x181, _mls_x183, _mls_x179);
        auto _mls_x193 = _mlsValue::create<_mls_Red>();
        auto _mls_x194 = _mlsValue::create<_mls_Node>(_mls_x193, _mls_x176, _mls_x177, _mls_x178, _mls_x192);
        _mls_retval = _mls_x194;
      }
    }
  } else if (_mlsValue::isValueOf<_mls_Black>(_mls_x174)) {
    auto _mls_x180 = (_mls_x181 < _mls_x177);
    if (_mlsValue::isIntLit(_mls_x180, 1)) {
      if (_mlsValue::isValueOf<_mls_Node>(_mls_x176)) {
        auto _mls_x188 = _mlsValue::cast<_mls_Node>(_mls_x176)->_mls_color;
        auto _mls_x189 = _mls_isRed_case0_sr_post(_mls_x188);
        _mls_retval = _mls_ins_caller_post1(_mls_x179, _mls_x178, _mls_x177, _mls_x176, _mls_x181, _mls_x189, _mls_x183);
      } else {
        _mls_retval = _mls_ins_caller_post_default1(_mls_x181, _mls_x177, _mls_x179, _mls_x176, _mls_x178, _mls_x183);
      }
    } else {
      auto _mls_x182 = (_mls_x181 == _mls_x177);
      if (_mlsValue::isIntLit(_mls_x182, 1)) {
        auto _mls_x186 = _mlsValue::create<_mls_Black>();
        auto _mls_x187 = _mlsValue::create<_mls_Node>(_mls_x186, _mls_x176, _mls_x181, _mls_x183, _mls_x179);
        _mls_retval = _mls_x187;
      } else {
        if (_mlsValue::isValueOf<_mls_Node>(_mls_x179)) {
          auto _mls_x184 = _mlsValue::cast<_mls_Node>(_mls_x179)->_mls_color;
          auto _mls_x185 = _mls_isRed_case0_sr_post(_mls_x184);
          _mls_retval = _mls_ins_caller_post(_mls_x179, _mls_x185, _mls_x178, _mls_x177, _mls_x183, _mls_x176, _mls_x181);
        } else {
          _mls_retval = _mls_ins_caller_post_default(_mls_x177, _mls_x179, _mls_x178, _mls_x183, _mls_x176, _mls_x181);
        }
      }
    }
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_ins(_mlsValue _mls_x243, _mlsValue _mls_x244, _mlsValue _mls_x242) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Leaf>(_mls_x242)) {
    _mls_retval = _mls_ins_case0(_mls_x243, _mls_x244);
  } else if (_mlsValue::isValueOf<_mls_Node>(_mls_x242)) {
    _mls_retval = _mls_ins_case1(_mls_x242, _mls_x243, _mls_x244);
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_ins_caller_post_case0(_mlsValue _mls_x205, _mlsValue _mls_x200, _mlsValue _mls_x206, _mlsValue _mls_x202, _mlsValue _mls_x204, _mlsValue _mls_x201) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Leaf>(_mls_x200)) {
    auto _mls_x208 = _mls_ins_case0(_mls_x201, _mls_x202);
    auto _mls_x209 = _mls_balance2(_mls_x204, _mls_x205, _mls_x206, _mls_x208);
    _mls_retval = _mls_x209;
  } else if (_mlsValue::isValueOf<_mls_Node>(_mls_x200)) {
    auto _mls_x203 = _mls_ins_case1(_mls_x200, _mls_x201, _mls_x202);
    auto _mls_x207 = _mls_balance2(_mls_x204, _mls_x205, _mls_x206, _mls_x203);
    _mls_retval = _mls_x207;
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_apply_f(_mlsValue _mls_f1, _mlsValue _mls_a, _mlsValue _mls_b1, _mlsValue _mls_c) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_LamF>(_mls_f1)) {
    if (_mlsValue::isIntLit(_mls_b1, 1)) {
      auto _mls_x173 = (_mls_c + _mlsValue::fromIntLit(1));
      _mls_retval = _mls_x173;
    } else {
      _mls_retval = _mls_c;
    }
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_fold(_mlsValue _mls_x276, _mlsValue _mls_x271, _mlsValue _mls_x277) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Leaf>(_mls_x271)) {
    _mls_retval = _mls_x277;
  } else if (_mlsValue::isValueOf<_mls_Node>(_mls_x271)) {
    auto _mls_x272 = _mlsValue::cast<_mls_Node>(_mls_x271)->_mls_left;
    auto _mls_x273 = _mlsValue::cast<_mls_Node>(_mls_x271)->_mls_key;
    auto _mls_x274 = _mlsValue::cast<_mls_Node>(_mls_x271)->_mls_value;
    auto _mls_x275 = _mlsValue::cast<_mls_Node>(_mls_x271)->_mls_right;
    _mls_retval = _mls_fold_case1_sr_post(_mls_x272, _mls_x275, _mls_x276, _mls_x274, _mls_x273, _mls_x277);
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_mkMapAux(_mlsValue _mls_x234, _mlsValue _mls_x235) {
  _mlsValue _mls_retval;
  auto [_mls_x236, _mls_x237, _mls_x238] = _mls_mkMapAux_pre(_mls_x234, _mls_x235);
  if (_mlsValue::isIntLit(_mls_x236, 1)) {
    _mls_retval = _mls_x237;
  } else {
    _mls_retval = _mls_mkMapAux_default(_mls_x238, _mls_x237);
  }
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
