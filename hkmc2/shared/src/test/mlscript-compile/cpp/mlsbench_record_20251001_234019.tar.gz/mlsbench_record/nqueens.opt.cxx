#include "mlsprelude.h"
struct _mls_List;
struct _mls_Cons;
struct _mls_Nil;
_mlsValue _mls_append_safe(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_append_safe_caller_post_case0(_mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_append_safe_caller_post_case0_pre(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_extend(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_find_solution_case0();
_mlsValue _mls_find_solution_default(_mlsValue, _mlsValue);
_mlsValue _mls_find_solution_default_caller_post(_mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_find_solution_default_caller_post_pre(_mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_find_solution_pre(_mlsValue, _mlsValue);
_mlsValue _mls_length(_mlsValue);
_mlsValue _mls_length_case0_sr_post(_mlsValue);
_mlsValue _mls_queens(_mlsValue);
_mlsValue _mls_safe(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_safe_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_safe_case0_sr_post_default(_mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_safe_case0_sr_post_pre(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
struct _mls_List: public _mlsObject {
  
  constexpr static inline const char *typeName = "List";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_List; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Cons: public _mls_List {
  _mlsValue _mls_head;
  _mlsValue _mls_tail;
  constexpr static inline const char *typeName = "Cons";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_head.print(); std::printf(", "); this->_mls_tail.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_head); _mlsValue::destroy(this->_mls_tail);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_head.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_head.asObject()) && this->_mls_tail.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_tail.asObject()); }
  static _mlsValue create(_mlsValue _mls_head, _mlsValue _mls_tail) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Cons; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_head = _mls_head; _mlsVal->_mls_tail = _mls_tail;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Nil: public _mls_List {
  
  constexpr static inline const char *typeName = "Nil";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Nil; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_append_safe(_mlsValue _mls_queen, _mlsValue _mls_xs, _mlsValue _mls_xss) {
  _mlsValue _mls_retval;
  auto _mls_x = (_mls_queen <= _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x, 1)) {
    _mls_retval = _mls_xss;
  } else {
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs)) {
      auto _mls_x40 = _mlsValue::cast<_mls_Cons>(_mls_xs)->_mls_head;
      auto _mls_x41 = _mlsValue::cast<_mls_Cons>(_mls_xs)->_mls_tail;
      auto [_mls_x42, _mls_x43, _mls_x44, _mls_x45] = _mls_safe_case0_sr_post_pre(_mls_queen, _mls_x40, _mlsValue::fromIntLit(1), _mls_x41);
      if (_mlsValue::isIntLit(_mls_x42, 1)) {
        _mls_retval = _mls_append_safe_caller_post_case0(_mls_queen, _mls_xs, _mls_xss);
      } else {
        auto _mls_x46 = _mls_safe_case0_sr_post_default(_mls_x43, _mls_x44, _mls_x45);
        if (_mlsValue::isIntLit(_mls_x46, 1)) {
          _mls_retval = _mls_append_safe_caller_post_case0(_mls_queen, _mls_xs, _mls_xss);
        } else {
          auto _mls_x47 = _mls_append_safe(_mls_queen, _mls_xs, _mls_xss);
          _mls_retval = _mls_x47;
        }
      }
    } else {
      auto [_mls_x36, _mls_x37, _mls_x38] = _mls_append_safe_caller_post_case0_pre(_mls_queen, _mls_xs, _mls_xss);
      auto _mls_x39 = _mls_append_safe(_mls_x36, _mls_x37, _mls_x38);
      _mls_retval = _mls_x39;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_append_safe_caller_post_case0(_mlsValue _mls_x48, _mlsValue _mls_x49, _mlsValue _mls_x50) {
  _mlsValue _mls_retval;
  auto [_mls_x51, _mls_x52, _mls_x53] = _mls_append_safe_caller_post_case0_pre(_mls_x48, _mls_x49, _mls_x50);
  auto _mls_x54 = _mls_append_safe(_mls_x51, _mls_x52, _mls_x53);
  _mls_retval = _mls_x54;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_append_safe_caller_post_case0_pre(_mlsValue _mls_x56, _mlsValue _mls_x58, _mlsValue _mls_x60) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x55 = (_mls_x56 - _mlsValue::fromIntLit(1));
  auto _mls_x57 = _mlsValue::create<_mls_Cons>(_mls_x56, _mls_x58);
  auto _mls_x59 = _mlsValue::create<_mls_Cons>(_mls_x57, _mls_x60);
  _mls_retval = std::make_tuple(_mls_x55, _mls_x58, _mls_x59);
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x7 = _mls_queens(_mlsValue::fromIntLit(8));
  _mls_retval = _mls_x7;
  return _mls_retval;
}
_mlsValue _mls_extend(_mlsValue _mls_queen1, _mlsValue _mls_acc, _mlsValue _mls_xss1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_xss1)) {
    auto _mls_x8 = _mlsValue::cast<_mls_Cons>(_mls_xss1)->_mls_head;
    auto _mls_x9 = _mlsValue::cast<_mls_Cons>(_mls_xss1)->_mls_tail;
    auto _mls_x10 = _mls_append_safe(_mls_queen1, _mls_x8, _mls_acc);
    auto _mls_x11 = _mls_extend(_mls_queen1, _mls_x10, _mls_x9);
    _mls_retval = _mls_x11;
  } else {
    _mls_retval = _mls_acc;
  }
  return _mls_retval;
}
_mlsValue _mls_find_solution_case0() {
  _mlsValue _mls_retval;
  auto _mls_x61 = _mlsValue::create<_mls_Nil>();
  auto _mls_x62 = _mlsValue::create<_mls_Nil>();
  auto _mls_x63 = _mlsValue::create<_mls_Cons>(_mls_x61, _mls_x62);
  _mls_retval = _mls_x63;
  return _mls_retval;
}
_mlsValue _mls_find_solution_default(_mlsValue _mls_x65, _mlsValue _mls_x66) {
  _mlsValue _mls_retval;
  auto _mls_x64 = (_mls_x65 - _mlsValue::fromIntLit(1));
  auto [_mls_x67, _mls_x68, _mls_x69] = _mls_find_solution_pre(_mls_x66, _mls_x64);
  if (_mlsValue::isIntLit(_mls_x67, 1)) {
    auto _mls_x71 = _mls_find_solution_case0();
    auto [_mls_x72, _mls_x73, _mls_x74] = _mls_find_solution_default_caller_post_pre(_mls_x66, _mls_x71);
    auto _mls_x75 = _mls_extend(_mls_x72, _mls_x73, _mls_x74);
    _mls_retval = _mls_x75;
  } else {
    auto _mls_x70 = _mls_find_solution_default(_mls_x68, _mls_x69);
    _mls_retval = _mls_find_solution_default_caller_post(_mls_x66, _mls_x70);
  }
  return _mls_retval;
}
_mlsValue _mls_find_solution_default_caller_post(_mlsValue _mls_x76, _mlsValue _mls_x77) {
  _mlsValue _mls_retval;
  auto [_mls_x78, _mls_x79, _mls_x80] = _mls_find_solution_default_caller_post_pre(_mls_x76, _mls_x77);
  auto _mls_x81 = _mls_extend(_mls_x78, _mls_x79, _mls_x80);
  _mls_retval = _mls_x81;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_find_solution_default_caller_post_pre(_mlsValue _mls_x83, _mlsValue _mls_x84) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x82 = _mlsValue::create<_mls_Nil>();
  _mls_retval = std::make_tuple(_mls_x83, _mls_x82, _mls_x84);
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_find_solution_pre(_mlsValue _mls_x87, _mlsValue _mls_x86) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x85 = (_mls_x86 == _mlsValue::fromIntLit(0));
  _mls_retval = std::make_tuple(_mls_x85, _mls_x86, _mls_x87);
  return _mls_retval;
}
_mlsValue _mls_length(_mlsValue _mls_x88) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x88)) {
    auto _mls_x89 = _mlsValue::cast<_mls_Cons>(_mls_x88)->_mls_tail;
    _mls_retval = _mls_length_case0_sr_post(_mls_x89);
  } else {
    _mls_retval = _mlsValue::fromIntLit(0);
  }
  return _mls_retval;
}
_mlsValue _mls_length_case0_sr_post(_mlsValue _mls_x90) {
  _mlsValue _mls_retval;
  auto _mls_x91 = _mls_length(_mls_x90);
  auto _mls_x92 = (_mlsValue::fromIntLit(1) + _mls_x91);
  _mls_retval = _mls_x92;
  return _mls_retval;
}
_mlsValue _mls_queens(_mlsValue _mls_n1) {
  _mlsValue _mls_retval;
  auto [_mls_x93, _mls_x94, _mls_x95] = _mls_find_solution_pre(_mls_n1, _mls_n1);
  if (_mlsValue::isIntLit(_mls_x93, 1)) {
    auto _mls_x98 = _mls_find_solution_case0();
    auto _mls_x99 = _mlsValue::cast<_mls_Cons>(_mls_x98)->_mls_tail;
    auto _mls_x100 = _mls_length_case0_sr_post(_mls_x99);
    _mls_retval = _mls_x100;
  } else {
    auto _mls_x96 = _mls_find_solution_default(_mls_x94, _mls_x95);
    auto _mls_x97 = _mls_length(_mls_x96);
    _mls_retval = _mls_x97;
  }
  return _mls_retval;
}
_mlsValue _mls_safe(_mlsValue _mls_x104, _mlsValue _mls_x105, _mlsValue _mls_x101) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x101)) {
    auto _mls_x102 = _mlsValue::cast<_mls_Cons>(_mls_x101)->_mls_head;
    auto _mls_x103 = _mlsValue::cast<_mls_Cons>(_mls_x101)->_mls_tail;
    _mls_retval = _mls_safe_case0_sr_post(_mls_x104, _mls_x102, _mls_x105, _mls_x103);
  } else {
    _mls_retval = _mlsValue::fromIntLit(1);
  }
  return _mls_retval;
}
_mlsValue _mls_safe_case0_sr_post(_mlsValue _mls_x106, _mlsValue _mls_x107, _mlsValue _mls_x108, _mlsValue _mls_x109) {
  _mlsValue _mls_retval;
  auto [_mls_x110, _mls_x111, _mls_x112, _mls_x113] = _mls_safe_case0_sr_post_pre(_mls_x106, _mls_x107, _mls_x108, _mls_x109);
  if (_mlsValue::isIntLit(_mls_x110, 1)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else {
    _mls_retval = _mls_safe_case0_sr_post_default(_mls_x111, _mls_x112, _mls_x113);
  }
  return _mls_retval;
}
_mlsValue _mls_safe_case0_sr_post_default(_mlsValue _mls_x115, _mlsValue _mls_x116, _mlsValue _mls_x117) {
  _mlsValue _mls_retval;
  auto _mls_x114 = (_mls_x115 + _mlsValue::fromIntLit(1));
  auto _mls_x118 = _mls_safe(_mls_x116, _mls_x114, _mls_x117);
  _mls_retval = _mls_x118;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_safe_case0_sr_post_pre(_mlsValue _mls_x120, _mlsValue _mls_x121, _mlsValue _mls_x123, _mlsValue _mls_x129) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x119 = (_mls_x120 != _mls_x121);
  auto _mls_x122 = (_mls_x121 + _mls_x123);
  auto _mls_x124 = (_mls_x120 != _mls_x122);
  auto _mls_x125 = (_mls_x119 && _mls_x124);
  auto _mls_x126 = (_mls_x121 - _mls_x123);
  auto _mls_x127 = (_mls_x120 != _mls_x126);
  auto _mls_x128 = (_mls_x125 && _mls_x127);
  _mls_retval = std::make_tuple(_mls_x128, _mls_x123, _mls_x120, _mls_x129);
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
