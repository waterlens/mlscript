#include "mlsprelude.h"
struct _mls_Expr;
struct _mls_Add;
struct _mls_LamDeriv;
struct _mls_Ln;
struct _mls_Mul;
struct _mls_Pow;
struct _mls_Val;
struct _mls_Var;
_mlsValue _mls_add(_mlsValue, _mlsValue);
_mlsValue _mls_add_case01(_mlsValue, _mlsValue);
_mlsValue _mls_add_case0(_mlsValue, _mlsValue);
_mlsValue _mls_add_default(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_case0(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_case0_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_case1(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_case1_case0(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_add_default_case1_default(_mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_add_default_case1_pre(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_default(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_default_case0(_mlsValue, _mlsValue);
_mlsValue _mls_add_default_default_default(_mlsValue, _mlsValue);
_mlsValue _mls_count(_mlsValue);
_mlsValue _mls_d(_mlsValue, _mlsValue);
_mlsValue _mls_d_case0();
_mlsValue _mls_d_case11(_mlsValue, _mlsValue);
_mlsValue _mls_d_case1(_mlsValue, _mlsValue);
_mlsValue _mls_d_case1_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_d_case21(_mlsValue, _mlsValue);
_mlsValue _mls_d_case2(_mlsValue, _mlsValue);
_mlsValue _mls_d_case2_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case31(_mlsValue, _mlsValue);
_mlsValue _mls_d_case3(_mlsValue, _mlsValue);
_mlsValue _mls_d_case3_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case3_sr_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case4(_mlsValue, _mlsValue);
_mlsValue _mls_d_case41(_mlsValue, _mlsValue);
_mlsValue _mls_d_case4_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case4_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case4_caller_post_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case4_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case4_sr_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_d_case51(_mlsValue, _mlsValue);
_mlsValue _mls_d_case5(_mlsValue, _mlsValue);
_mlsValue _mls_d_case5_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_d_case5_sr_post_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_j(_mlsValue, _mlsValue);
_mlsValue _mls_ln_case0(_mlsValue);
_mlsValue _mls_ln_default(_mlsValue);
_mlsValue _mls_main(_mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_main_caller_post_pre(_mlsValue, _mlsValue);
_mlsValue _mls_mul(_mlsValue, _mlsValue);
_mlsValue _mls_mul_case0(_mlsValue, _mlsValue);
_mlsValue _mls_mul_case01(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_case0(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_case0_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_case1(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_case1_case0(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_mul_default_case1_default(_mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_mul_default_case1_pre(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_default(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_default_case0(_mlsValue, _mlsValue);
_mlsValue _mls_mul_default_default_default(_mlsValue, _mlsValue);
_mlsValue _mls_nestAux(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_nestAux_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_nestAux_caller_post_pre(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_nestAux_default(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_pow_case0(_mlsValue, _mlsValue);
_mlsValue _mls_pow_default(_mlsValue, _mlsValue);
_mlsValue _mls_pow_default_case0(_mlsValue, _mlsValue);
_mlsValue _mls_pow_default_default(_mlsValue, _mlsValue);
_mlsValue _mls_pown(_mlsValue, _mlsValue);
struct _mls_Expr: public _mlsObject {
  
  constexpr static inline const char *typeName = "Expr";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Expr; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Add: public _mls_Expr {
  _mlsValue _mls_e1;
  _mlsValue _mls_e2;
  constexpr static inline const char *typeName = "Add";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e1.print(); std::printf(", "); this->_mls_e2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e1); _mlsValue::destroy(this->_mls_e2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e1.asObject()->operator==(*other.cast<_mls_Add>()->_mls_e1.asObject()) && this->_mls_e2.asObject()->operator==(*other.cast<_mls_Add>()->_mls_e2.asObject()); }
  static _mlsValue create(_mlsValue _mls_e1, _mlsValue _mls_e2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Add; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e1 = _mls_e1; _mlsVal->_mls_e2 = _mls_e2;  return _mlsValue(_mlsVal); }
  
};
struct _mls_LamDeriv: public _mlsObject {
  
  constexpr static inline const char *typeName = "LamDeriv";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_LamDeriv; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Ln: public _mls_Expr {
  _mlsValue _mls_e;
  constexpr static inline const char *typeName = "Ln";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e.asObject()->operator==(*other.cast<_mls_Ln>()->_mls_e.asObject()); }
  static _mlsValue create(_mlsValue _mls_e) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Ln; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e = _mls_e;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Mul: public _mls_Expr {
  _mlsValue _mls_e1;
  _mlsValue _mls_e2;
  constexpr static inline const char *typeName = "Mul";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e1.print(); std::printf(", "); this->_mls_e2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e1); _mlsValue::destroy(this->_mls_e2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e1.asObject()->operator==(*other.cast<_mls_Mul>()->_mls_e1.asObject()) && this->_mls_e2.asObject()->operator==(*other.cast<_mls_Mul>()->_mls_e2.asObject()); }
  static _mlsValue create(_mlsValue _mls_e1, _mlsValue _mls_e2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Mul; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e1 = _mls_e1; _mlsVal->_mls_e2 = _mls_e2;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Pow: public _mls_Expr {
  _mlsValue _mls_e1;
  _mlsValue _mls_e2;
  constexpr static inline const char *typeName = "Pow";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e1.print(); std::printf(", "); this->_mls_e2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e1); _mlsValue::destroy(this->_mls_e2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e1.asObject()->operator==(*other.cast<_mls_Pow>()->_mls_e1.asObject()) && this->_mls_e2.asObject()->operator==(*other.cast<_mls_Pow>()->_mls_e2.asObject()); }
  static _mlsValue create(_mlsValue _mls_e1, _mlsValue _mls_e2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Pow; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e1 = _mls_e1; _mlsVal->_mls_e2 = _mls_e2;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Val: public _mls_Expr {
  _mlsValue _mls_n;
  constexpr static inline const char *typeName = "Val";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_n.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_n);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_n.asObject()->operator==(*other.cast<_mls_Val>()->_mls_n.asObject()); }
  static _mlsValue create(_mlsValue _mls_n) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Val; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_n = _mls_n;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Var: public _mls_Expr {
  _mlsValue _mls_x;
  constexpr static inline const char *typeName = "Var";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_x.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_x);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_x.asObject()->operator==(*other.cast<_mls_Var>()->_mls_x.asObject()); }
  static _mlsValue create(_mlsValue _mls_x) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Var; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_x = _mls_x;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_add(_mlsValue _mls_x, _mlsValue _mls_x153) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x)) {
    _mls_retval = _mls_add_case0(_mls_x, _mls_x153);
  } else {
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x153)) {
      _mls_retval = _mls_add_default_case0(_mls_x153, _mls_x);
    } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x153)) {
      _mls_retval = _mls_add_default_case1(_mls_x153, _mls_x);
    } else {
      _mls_retval = _mls_add_default_default(_mls_x, _mls_x153);
    }
  }
  return _mls_retval;
}
_mlsValue _mls_add_case01(_mlsValue _mls_x155, _mlsValue _mls_x156) {
  _mlsValue _mls_retval;
  auto _mls_x154 = _mlsValue::cast<_mls_Val>(_mls_x155)->_mls_n;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x156)) {
    auto _mls_x165 = _mlsValue::cast<_mls_Val>(_mls_x156)->_mls_n;
    auto _mls_x166 = (_mls_x154 + _mls_x165);
    auto _mls_x167 = _mlsValue::create<_mls_Val>(_mls_x166);
    _mls_retval = _mls_x167;
  } else {
    if (_mlsValue::isIntLit(_mls_x154, 0)) {
      _mls_retval = _mls_x156;
    } else {
      if (_mlsValue::isValueOf<_mls_Add>(_mls_x156)) {
        auto _mls_x158 = _mlsValue::cast<_mls_Add>(_mls_x156)->_mls_e1;
        auto _mls_x159 = _mlsValue::cast<_mls_Add>(_mls_x156)->_mls_e2;
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x158)) {
          auto _mls_x161 = _mlsValue::cast<_mls_Val>(_mls_x158)->_mls_n;
          auto _mls_x162 = (_mls_x154 + _mls_x161);
          auto _mls_x163 = _mlsValue::create<_mls_Val>(_mls_x162);
          auto _mls_x164 = _mls_add_case0(_mls_x163, _mls_x159);
          _mls_retval = _mls_x164;
        } else {
          auto _mls_x160 = _mlsValue::create<_mls_Add>(_mls_x155, _mls_x156);
          _mls_retval = _mls_x160;
        }
      } else {
        auto _mls_x157 = _mlsValue::create<_mls_Add>(_mls_x155, _mls_x156);
        _mls_retval = _mls_x157;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_add_case0(_mlsValue _mls_x169, _mlsValue _mls_x170) {
  _mlsValue _mls_retval;
  auto _mls_x168 = _mlsValue::cast<_mls_Val>(_mls_x169)->_mls_n;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x170)) {
    auto _mls_x179 = _mlsValue::cast<_mls_Val>(_mls_x170)->_mls_n;
    auto _mls_x180 = (_mls_x168 + _mls_x179);
    auto _mls_x181 = _mlsValue::create<_mls_Val>(_mls_x180);
    _mls_retval = _mls_x181;
  } else {
    if (_mlsValue::isIntLit(_mls_x168, 0)) {
      _mls_retval = _mls_x170;
    } else {
      if (_mlsValue::isValueOf<_mls_Add>(_mls_x170)) {
        auto _mls_x172 = _mlsValue::cast<_mls_Add>(_mls_x170)->_mls_e1;
        auto _mls_x173 = _mlsValue::cast<_mls_Add>(_mls_x170)->_mls_e2;
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x172)) {
          auto _mls_x175 = _mlsValue::cast<_mls_Val>(_mls_x172)->_mls_n;
          auto _mls_x176 = (_mls_x168 + _mls_x175);
          auto _mls_x177 = _mlsValue::create<_mls_Val>(_mls_x176);
          auto _mls_x178 = _mls_add_case01(_mls_x177, _mls_x173);
          _mls_retval = _mls_x178;
        } else {
          auto _mls_x174 = _mlsValue::create<_mls_Add>(_mls_x169, _mls_x170);
          _mls_retval = _mls_x174;
        }
      } else {
        auto _mls_x171 = _mlsValue::create<_mls_Add>(_mls_x169, _mls_x170);
        _mls_retval = _mls_x171;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_add_default(_mlsValue _mls_x182, _mlsValue _mls_x183) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x182)) {
    _mls_retval = _mls_add_default_case0(_mls_x182, _mls_x183);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x182)) {
    _mls_retval = _mls_add_default_case1(_mls_x182, _mls_x183);
  } else {
    _mls_retval = _mls_add_default_default(_mls_x183, _mls_x182);
  }
  return _mls_retval;
}
_mlsValue _mls_add_default_case0(_mlsValue _mls_x185, _mlsValue _mls_x187) {
  _mlsValue _mls_retval;
  auto _mls_x184 = _mlsValue::cast<_mls_Val>(_mls_x185)->_mls_n;
  if (_mlsValue::isIntLit(_mls_x184, 0)) {
    _mls_retval = _mls_x187;
  } else {
    auto _mls_x186 = _mlsValue::create<_mls_Val>(_mls_x184);
    auto _mls_x188 = _mls_add_case01(_mls_x186, _mls_x187);
    _mls_retval = _mls_x188;
  }
  return _mls_retval;
}
_mlsValue _mls_add_default_case0_sr_post(_mlsValue _mls_x189, _mlsValue _mls_x191) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_x189, 0)) {
    _mls_retval = _mls_x191;
  } else {
    auto _mls_x190 = _mlsValue::create<_mls_Val>(_mls_x189);
    auto _mls_x192 = _mls_add_case0(_mls_x190, _mls_x191);
    _mls_retval = _mls_x192;
  }
  return _mls_retval;
}
_mlsValue _mls_add_default_case1(_mlsValue _mls_x194, _mlsValue _mls_x196) {
  _mlsValue _mls_retval;
  auto _mls_x193 = _mlsValue::cast<_mls_Add>(_mls_x194)->_mls_e1;
  auto _mls_x195 = _mlsValue::cast<_mls_Add>(_mls_x194)->_mls_e2;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x193)) {
    auto _mls_x210 = _mlsValue::cast<_mls_Val>(_mls_x193)->_mls_n;
    auto _mls_x211 = _mlsValue::create<_mls_Val>(_mls_x210);
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x196)) {
      auto _mls_x227 = _mls_add_case01(_mls_x196, _mls_x195);
      auto _mls_x228 = _mls_add(_mls_x211, _mls_x227);
      _mls_retval = _mls_x228;
    } else {
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x195)) {
        auto _mls_x224 = _mlsValue::cast<_mls_Val>(_mls_x195)->_mls_n;
        auto _mls_x225 = _mls_add_default_case0_sr_post(_mls_x224, _mls_x196);
        auto _mls_x226 = _mls_add(_mls_x211, _mls_x225);
        _mls_retval = _mls_x226;
      } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x195)) {
        auto [_mls_x216, _mls_x217, _mls_x218, _mls_x219] = _mls_add_default_case1_pre(_mls_x195, _mls_x196);
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x216)) {
          auto _mls_x222 = _mls_add_default_case1_case0(_mls_x216, _mls_x217, _mls_x218);
          auto _mls_x223 = _mls_add(_mls_x211, _mls_x222);
          _mls_retval = _mls_x223;
        } else {
          auto _mls_x220 = _mls_add_default_case1_default(_mls_x217, _mls_x219);
          auto _mls_x221 = _mls_add(_mls_x211, _mls_x220);
          _mls_retval = _mls_x221;
        }
      } else {
        if (_mlsValue::isValueOf<_mls_Add>(_mls_x196)) {
          auto _mls_x214 = _mls_add_default_default_case0(_mls_x196, _mls_x195);
          auto _mls_x215 = _mls_add(_mls_x211, _mls_x214);
          _mls_retval = _mls_x215;
        } else {
          auto _mls_x212 = _mls_add_default_default_default(_mls_x196, _mls_x195);
          auto _mls_x213 = _mls_add(_mls_x211, _mls_x212);
          _mls_retval = _mls_x213;
        }
      }
    }
  } else {
    if (_mlsValue::isValueOf<_mls_Add>(_mls_x196)) {
      auto _mls_x198 = _mlsValue::cast<_mls_Add>(_mls_x196)->_mls_e1;
      auto _mls_x199 = _mlsValue::cast<_mls_Add>(_mls_x196)->_mls_e2;
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x199)) {
        auto _mls_x208 = _mls_add_case01(_mls_x199, _mls_x194);
        auto _mls_x209 = _mls_add(_mls_x198, _mls_x208);
        _mls_retval = _mls_x209;
      } else {
        auto [_mls_x200, _mls_x201, _mls_x202, _mls_x203] = _mls_add_default_case1_pre(_mls_x194, _mls_x199);
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x200)) {
          auto _mls_x206 = _mls_add_default_case1_case0(_mls_x200, _mls_x201, _mls_x202);
          auto _mls_x207 = _mls_add(_mls_x198, _mls_x206);
          _mls_retval = _mls_x207;
        } else {
          auto _mls_x204 = _mls_add_default_case1_default(_mls_x201, _mls_x203);
          auto _mls_x205 = _mls_add(_mls_x198, _mls_x204);
          _mls_retval = _mls_x205;
        }
      }
    } else {
      auto _mls_x197 = _mlsValue::create<_mls_Add>(_mls_x196, _mls_x194);
      _mls_retval = _mls_x197;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_add_default_case1_case0(_mlsValue _mls_x230, _mlsValue _mls_x232, _mlsValue _mls_x233) {
  _mlsValue _mls_retval;
  auto _mls_x229 = _mlsValue::cast<_mls_Val>(_mls_x230)->_mls_n;
  auto _mls_x231 = _mlsValue::create<_mls_Val>(_mls_x229);
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x232)) {
    auto _mls_x240 = _mls_add_case0(_mls_x232, _mls_x233);
    auto _mls_x241 = _mls_add(_mls_x231, _mls_x240);
    _mls_retval = _mls_x241;
  } else {
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x233)) {
      auto _mls_x238 = _mls_add_default_case0(_mls_x233, _mls_x232);
      auto _mls_x239 = _mls_add(_mls_x231, _mls_x238);
      _mls_retval = _mls_x239;
    } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x233)) {
      auto _mls_x236 = _mls_add_default_case1(_mls_x233, _mls_x232);
      auto _mls_x237 = _mls_add(_mls_x231, _mls_x236);
      _mls_retval = _mls_x237;
    } else {
      auto _mls_x234 = _mls_add_default_default(_mls_x232, _mls_x233);
      auto _mls_x235 = _mls_add(_mls_x231, _mls_x234);
      _mls_retval = _mls_x235;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_add_default_case1_default(_mlsValue _mls_x242, _mlsValue _mls_x244) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_x242)) {
    auto _mls_x245 = _mlsValue::cast<_mls_Add>(_mls_x242)->_mls_e1;
    auto _mls_x246 = _mlsValue::cast<_mls_Add>(_mls_x242)->_mls_e2;
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x246)) {
      auto _mls_x253 = _mls_add_case0(_mls_x246, _mls_x244);
      auto _mls_x254 = _mls_add(_mls_x245, _mls_x253);
      _mls_retval = _mls_x254;
    } else {
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x244)) {
        auto _mls_x251 = _mls_add_default_case0(_mls_x244, _mls_x246);
        auto _mls_x252 = _mls_add(_mls_x245, _mls_x251);
        _mls_retval = _mls_x252;
      } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x244)) {
        auto _mls_x249 = _mls_add_default_case1(_mls_x244, _mls_x246);
        auto _mls_x250 = _mls_add(_mls_x245, _mls_x249);
        _mls_retval = _mls_x250;
      } else {
        auto _mls_x247 = _mls_add_default_default(_mls_x246, _mls_x244);
        auto _mls_x248 = _mls_add(_mls_x245, _mls_x247);
        _mls_retval = _mls_x248;
      }
    }
  } else {
    auto _mls_x243 = _mlsValue::create<_mls_Add>(_mls_x242, _mls_x244);
    _mls_retval = _mls_x243;
  }
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_add_default_case1_pre(_mlsValue _mls_x256, _mlsValue _mls_x258) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x255 = _mlsValue::cast<_mls_Add>(_mls_x256)->_mls_e1;
  auto _mls_x257 = _mlsValue::cast<_mls_Add>(_mls_x256)->_mls_e2;
  _mls_retval = std::make_tuple(_mls_x255, _mls_x258, _mls_x257, _mls_x256);
  return _mls_retval;
}
_mlsValue _mls_add_default_default(_mlsValue _mls_x259, _mlsValue _mls_x261) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_x259)) {
    auto _mls_x262 = _mlsValue::cast<_mls_Add>(_mls_x259)->_mls_e1;
    auto _mls_x263 = _mlsValue::cast<_mls_Add>(_mls_x259)->_mls_e2;
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x263)) {
      auto _mls_x279 = _mls_add_case01(_mls_x263, _mls_x261);
      auto _mls_x280 = _mls_add(_mls_x262, _mls_x279);
      _mls_retval = _mls_x280;
    } else {
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x261)) {
        auto _mls_x276 = _mlsValue::cast<_mls_Val>(_mls_x261)->_mls_n;
        auto _mls_x277 = _mls_add_default_case0_sr_post(_mls_x276, _mls_x263);
        auto _mls_x278 = _mls_add(_mls_x262, _mls_x277);
        _mls_retval = _mls_x278;
      } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x261)) {
        auto [_mls_x268, _mls_x269, _mls_x270, _mls_x271] = _mls_add_default_case1_pre(_mls_x261, _mls_x263);
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x268)) {
          auto _mls_x274 = _mls_add_default_case1_case0(_mls_x268, _mls_x269, _mls_x270);
          auto _mls_x275 = _mls_add(_mls_x262, _mls_x274);
          _mls_retval = _mls_x275;
        } else {
          auto _mls_x272 = _mls_add_default_case1_default(_mls_x269, _mls_x271);
          auto _mls_x273 = _mls_add(_mls_x262, _mls_x272);
          _mls_retval = _mls_x273;
        }
      } else {
        if (_mlsValue::isValueOf<_mls_Add>(_mls_x263)) {
          auto _mls_x266 = _mls_add_default_default_case0(_mls_x263, _mls_x261);
          auto _mls_x267 = _mls_add(_mls_x262, _mls_x266);
          _mls_retval = _mls_x267;
        } else {
          auto _mls_x264 = _mls_add_default_default_default(_mls_x263, _mls_x261);
          auto _mls_x265 = _mls_add(_mls_x262, _mls_x264);
          _mls_retval = _mls_x265;
        }
      }
    }
  } else {
    auto _mls_x260 = _mlsValue::create<_mls_Add>(_mls_x259, _mls_x261);
    _mls_retval = _mls_x260;
  }
  return _mls_retval;
}
_mlsValue _mls_add_default_default_case0(_mlsValue _mls_x282, _mlsValue _mls_x284) {
  _mlsValue _mls_retval;
  auto _mls_x281 = _mlsValue::cast<_mls_Add>(_mls_x282)->_mls_e1;
  auto _mls_x283 = _mlsValue::cast<_mls_Add>(_mls_x282)->_mls_e2;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x283)) {
    auto _mls_x287 = _mls_add_case0(_mls_x283, _mls_x284);
    auto _mls_x288 = _mls_add(_mls_x281, _mls_x287);
    _mls_retval = _mls_x288;
  } else {
    auto _mls_x285 = _mls_add_default(_mls_x284, _mls_x283);
    auto _mls_x286 = _mls_add(_mls_x281, _mls_x285);
    _mls_retval = _mls_x286;
  }
  return _mls_retval;
}
_mlsValue _mls_add_default_default_default(_mlsValue _mls_x290, _mlsValue _mls_x291) {
  _mlsValue _mls_retval;
  auto _mls_x289 = _mlsValue::create<_mls_Add>(_mls_x290, _mls_x291);
  _mls_retval = _mls_x289;
  return _mls_retval;
}
_mlsValue _mls_count(_mlsValue _mls_e3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_e3)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else if (_mlsValue::isValueOf<_mls_Var>(_mls_e3)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_e3)) {
    auto _mls_x45 = _mlsValue::cast<_mls_Add>(_mls_e3)->_mls_e1;
    auto _mls_x46 = _mlsValue::cast<_mls_Add>(_mls_e3)->_mls_e2;
    auto _mls_x47 = _mls_count(_mls_x45);
    auto _mls_x48 = _mls_count(_mls_x46);
    auto _mls_x49 = (_mls_x47 + _mls_x48);
    _mls_retval = _mls_x49;
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_e3)) {
    auto _mls_x40 = _mlsValue::cast<_mls_Mul>(_mls_e3)->_mls_e1;
    auto _mls_x41 = _mlsValue::cast<_mls_Mul>(_mls_e3)->_mls_e2;
    auto _mls_x42 = _mls_count(_mls_x40);
    auto _mls_x43 = _mls_count(_mls_x41);
    auto _mls_x44 = (_mls_x42 + _mls_x43);
    _mls_retval = _mls_x44;
  } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_e3)) {
    auto _mls_x35 = _mlsValue::cast<_mls_Pow>(_mls_e3)->_mls_e1;
    auto _mls_x36 = _mlsValue::cast<_mls_Pow>(_mls_e3)->_mls_e2;
    auto _mls_x37 = _mls_count(_mls_x35);
    auto _mls_x38 = _mls_count(_mls_x36);
    auto _mls_x39 = (_mls_x37 + _mls_x38);
    _mls_retval = _mls_x39;
  } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_e3)) {
    auto _mls_x33 = _mlsValue::cast<_mls_Ln>(_mls_e3)->_mls_e;
    auto _mls_x34 = _mls_count(_mls_x33);
    _mls_retval = _mls_x34;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_d(_mlsValue _mls_x293, _mlsValue _mls_x292) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x292)) {
    _mls_retval = _mls_d_case0();
  } else if (_mlsValue::isValueOf<_mls_Var>(_mls_x292)) {
    _mls_retval = _mls_d_case1(_mls_x292, _mls_x293);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x292)) {
    _mls_retval = _mls_d_case2(_mls_x292, _mls_x293);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x292)) {
    _mls_retval = _mls_d_case3(_mls_x292, _mls_x293);
  } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_x292)) {
    _mls_retval = _mls_d_case4(_mls_x292, _mls_x293);
  } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_x292)) {
    _mls_retval = _mls_d_case5(_mls_x292, _mls_x293);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_d_case0() {
  _mlsValue _mls_retval;
  auto _mls_x294 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
  _mls_retval = _mls_x294;
  return _mls_retval;
}
_mlsValue _mls_d_case11(_mlsValue _mls_x296, _mlsValue _mls_x297) {
  _mlsValue _mls_retval;
  auto _mls_x295 = _mlsValue::cast<_mls_Var>(_mls_x296)->_mls_x;
  _mls_retval = _mls_d_case1_sr_post(_mls_x297, _mls_x295);
  return _mls_retval;
}
_mlsValue _mls_d_case1(_mlsValue _mls_x299, _mlsValue _mls_x300) {
  _mlsValue _mls_retval;
  auto _mls_x298 = _mlsValue::cast<_mls_Var>(_mls_x299)->_mls_x;
  _mls_retval = _mls_d_case1_sr_post(_mls_x300, _mls_x298);
  return _mls_retval;
}
_mlsValue _mls_d_case1_sr_post(_mlsValue _mls_x302, _mlsValue _mls_x303) {
  _mlsValue _mls_retval;
  auto _mls_x301 = (_mls_x302 == _mls_x303);
  if (_mlsValue::isIntLit(_mls_x301, 1)) {
    auto _mls_x305 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(1));
    _mls_retval = _mls_x305;
  } else {
    auto _mls_x304 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
    _mls_retval = _mls_x304;
  }
  return _mls_retval;
}
_mlsValue _mls_d_case21(_mlsValue _mls_x307, _mlsValue _mls_x309) {
  _mlsValue _mls_retval;
  auto _mls_x306 = _mlsValue::cast<_mls_Add>(_mls_x307)->_mls_e1;
  auto _mls_x308 = _mlsValue::cast<_mls_Add>(_mls_x307)->_mls_e2;
  _mls_retval = _mls_d_case2_sr_post(_mls_x309, _mls_x306, _mls_x308);
  return _mls_retval;
}
_mlsValue _mls_d_case2(_mlsValue _mls_x311, _mlsValue _mls_x313) {
  _mlsValue _mls_retval;
  auto _mls_x310 = _mlsValue::cast<_mls_Add>(_mls_x311)->_mls_e1;
  auto _mls_x312 = _mlsValue::cast<_mls_Add>(_mls_x311)->_mls_e2;
  _mls_retval = _mls_d_case2_sr_post(_mls_x313, _mls_x310, _mls_x312);
  return _mls_retval;
}
_mlsValue _mls_d_case2_sr_post(_mlsValue _mls_x314, _mlsValue _mls_x315, _mlsValue _mls_x317) {
  _mlsValue _mls_retval;
  auto _mls_x316 = _mls_d(_mls_x314, _mls_x315);
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x317)) {
    auto _mls_x328 = _mls_d_case0();
    auto _mls_x329 = _mls_add(_mls_x316, _mls_x328);
    _mls_retval = _mls_x329;
  } else if (_mlsValue::isValueOf<_mls_Var>(_mls_x317)) {
    auto _mls_x326 = _mls_d_case1(_mls_x317, _mls_x314);
    auto _mls_x327 = _mls_add(_mls_x316, _mls_x326);
    _mls_retval = _mls_x327;
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x317)) {
    auto _mls_x324 = _mls_d_case2(_mls_x317, _mls_x314);
    auto _mls_x325 = _mls_add(_mls_x316, _mls_x324);
    _mls_retval = _mls_x325;
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x317)) {
    auto _mls_x322 = _mls_d_case3(_mls_x317, _mls_x314);
    auto _mls_x323 = _mls_add(_mls_x316, _mls_x322);
    _mls_retval = _mls_x323;
  } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_x317)) {
    auto _mls_x320 = _mls_d_case4(_mls_x317, _mls_x314);
    auto _mls_x321 = _mls_add(_mls_x316, _mls_x320);
    _mls_retval = _mls_x321;
  } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_x317)) {
    auto _mls_x318 = _mls_d_case5(_mls_x317, _mls_x314);
    auto _mls_x319 = _mls_add(_mls_x316, _mls_x318);
    _mls_retval = _mls_x319;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_d_case31(_mlsValue _mls_x331, _mlsValue _mls_x333) {
  _mlsValue _mls_retval;
  auto _mls_x330 = _mlsValue::cast<_mls_Mul>(_mls_x331)->_mls_e1;
  auto _mls_x332 = _mlsValue::cast<_mls_Mul>(_mls_x331)->_mls_e2;
  _mls_retval = _mls_d_case3_sr_post(_mls_x333, _mls_x332, _mls_x330);
  return _mls_retval;
}
_mlsValue _mls_d_case3(_mlsValue _mls_x335, _mlsValue _mls_x337) {
  _mlsValue _mls_retval;
  auto _mls_x334 = _mlsValue::cast<_mls_Mul>(_mls_x335)->_mls_e1;
  auto _mls_x336 = _mlsValue::cast<_mls_Mul>(_mls_x335)->_mls_e2;
  _mls_retval = _mls_d_case3_sr_post(_mls_x337, _mls_x336, _mls_x334);
  return _mls_retval;
}
_mlsValue _mls_d_case3_sr_post(_mlsValue _mls_x339, _mlsValue _mls_x338, _mlsValue _mls_x341) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x338)) {
    auto _mls_x346 = _mls_d_case0();
    _mls_retval = _mls_d_case3_sr_post_caller_post(_mls_x341, _mls_x346, _mls_x339, _mls_x338);
  } else if (_mlsValue::isValueOf<_mls_Var>(_mls_x338)) {
    auto _mls_x345 = _mls_d_case1(_mls_x338, _mls_x339);
    _mls_retval = _mls_d_case3_sr_post_caller_post(_mls_x341, _mls_x345, _mls_x339, _mls_x338);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x338)) {
    auto _mls_x344 = _mls_d_case2(_mls_x338, _mls_x339);
    _mls_retval = _mls_d_case3_sr_post_caller_post(_mls_x341, _mls_x344, _mls_x339, _mls_x338);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x338)) {
    auto _mls_x343 = _mls_d_case3(_mls_x338, _mls_x339);
    _mls_retval = _mls_d_case3_sr_post_caller_post(_mls_x341, _mls_x343, _mls_x339, _mls_x338);
  } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_x338)) {
    auto _mls_x342 = _mls_d_case4(_mls_x338, _mls_x339);
    _mls_retval = _mls_d_case3_sr_post_caller_post(_mls_x341, _mls_x342, _mls_x339, _mls_x338);
  } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_x338)) {
    auto _mls_x340 = _mls_d_case5(_mls_x338, _mls_x339);
    _mls_retval = _mls_d_case3_sr_post_caller_post(_mls_x341, _mls_x340, _mls_x339, _mls_x338);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_d_case3_sr_post_caller_post(_mlsValue _mls_x347, _mlsValue _mls_x348, _mlsValue _mls_x350, _mlsValue _mls_x352) {
  _mlsValue _mls_retval;
  auto _mls_x349 = _mls_mul(_mls_x347, _mls_x348);
  auto _mls_x351 = _mls_d(_mls_x350, _mls_x347);
  auto _mls_x353 = _mls_mul(_mls_x352, _mls_x351);
  auto _mls_x354 = _mls_add(_mls_x349, _mls_x353);
  _mls_retval = _mls_x354;
  return _mls_retval;
}
_mlsValue _mls_d_case4(_mlsValue _mls_x356, _mlsValue _mls_x358) {
  _mlsValue _mls_retval;
  auto _mls_x355 = _mlsValue::cast<_mls_Pow>(_mls_x356)->_mls_e1;
  auto _mls_x357 = _mlsValue::cast<_mls_Pow>(_mls_x356)->_mls_e2;
  _mls_retval = _mls_d_case4_sr_post(_mls_x355, _mls_x357, _mls_x358);
  return _mls_retval;
}
_mlsValue _mls_d_case41(_mlsValue _mls_x360, _mlsValue _mls_x362) {
  _mlsValue _mls_retval;
  auto _mls_x359 = _mlsValue::cast<_mls_Pow>(_mls_x360)->_mls_e1;
  auto _mls_x361 = _mlsValue::cast<_mls_Pow>(_mls_x360)->_mls_e2;
  _mls_retval = _mls_d_case4_sr_post(_mls_x359, _mls_x361, _mls_x362);
  return _mls_retval;
}
_mlsValue _mls_d_case4_caller_post(_mlsValue _mls_x363, _mlsValue _mls_x370, _mlsValue _mls_x364, _mlsValue _mls_x368, _mlsValue _mls_x371) {
  _mlsValue _mls_retval;
  auto _mls_x365 = _mls_mul(_mls_x363, _mls_x364);
  auto _mls_x366 = (-_mlsValue::fromIntLit(1));
  auto _mls_x367 = _mlsValue::create<_mls_Val>(_mls_x366);
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x368)) {
    auto _mls_x372 = _mls_pow_case0(_mls_x368, _mls_x367);
    _mls_retval = _mls_d_case4_caller_post_caller_post(_mls_x368, _mls_x370, _mls_x365, _mls_x371, _mls_x372, _mls_x363);
  } else {
    auto _mls_x369 = _mls_pow_default_case0(_mls_x367, _mls_x368);
    _mls_retval = _mls_d_case4_caller_post_caller_post(_mls_x368, _mls_x370, _mls_x365, _mls_x371, _mls_x369, _mls_x363);
  }
  return _mls_retval;
}
_mlsValue _mls_d_case4_caller_post_caller_post(_mlsValue _mls_x376, _mlsValue _mls_x380, _mlsValue _mls_x373, _mlsValue _mls_x379, _mlsValue _mls_x374, _mlsValue _mls_x378) {
  _mlsValue _mls_retval;
  auto _mls_x375 = _mls_mul(_mls_x373, _mls_x374);
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x376)) {
    auto _mls_x381 = _mls_ln_case0(_mls_x376);
    _mls_retval = _mls_d_case4_caller_post_caller_post_caller_post(_mls_x375, _mls_x378, _mls_x381, _mls_x379, _mls_x380);
  } else {
    auto _mls_x377 = _mls_ln_default(_mls_x376);
    _mls_retval = _mls_d_case4_caller_post_caller_post_caller_post(_mls_x375, _mls_x378, _mls_x377, _mls_x379, _mls_x380);
  }
  return _mls_retval;
}
_mlsValue _mls_d_case4_caller_post_caller_post_caller_post(_mlsValue _mls_x387, _mlsValue _mls_x383, _mlsValue _mls_x385, _mlsValue _mls_x389, _mlsValue _mls_x382) {
  _mlsValue _mls_retval;
  auto _mls_x384 = _mls_d(_mls_x382, _mls_x383);
  auto _mls_x386 = _mls_mul(_mls_x385, _mls_x384);
  auto _mls_x388 = _mls_add(_mls_x387, _mls_x386);
  auto _mls_x390 = _mls_mul(_mls_x389, _mls_x388);
  _mls_retval = _mls_x390;
  return _mls_retval;
}
_mlsValue _mls_d_case4_sr_post(_mlsValue _mls_x391, _mlsValue _mls_x392, _mlsValue _mls_x394) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x391)) {
    auto _mls_x395 = _mls_pow_case0(_mls_x391, _mls_x392);
    _mls_retval = _mls_d_case4_sr_post_caller_post(_mls_x391, _mls_x392, _mls_x394, _mls_x395);
  } else {
    auto _mls_x393 = _mls_pow_default(_mls_x392, _mls_x391);
    _mls_retval = _mls_d_case4_sr_post_caller_post(_mls_x391, _mls_x392, _mls_x394, _mls_x393);
  }
  return _mls_retval;
}
_mlsValue _mls_d_case4_sr_post_caller_post(_mlsValue _mls_x396, _mlsValue _mls_x399, _mlsValue _mls_x397, _mlsValue _mls_x400) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x396)) {
    auto _mls_x405 = _mls_d_case0();
    _mls_retval = _mls_d_case4_caller_post(_mls_x399, _mls_x397, _mls_x405, _mls_x396, _mls_x400);
  } else if (_mlsValue::isValueOf<_mls_Var>(_mls_x396)) {
    auto _mls_x404 = _mls_d_case11(_mls_x396, _mls_x397);
    _mls_retval = _mls_d_case4_caller_post(_mls_x399, _mls_x397, _mls_x404, _mls_x396, _mls_x400);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x396)) {
    auto _mls_x403 = _mls_d_case21(_mls_x396, _mls_x397);
    _mls_retval = _mls_d_case4_caller_post(_mls_x399, _mls_x397, _mls_x403, _mls_x396, _mls_x400);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x396)) {
    auto _mls_x402 = _mls_d_case31(_mls_x396, _mls_x397);
    _mls_retval = _mls_d_case4_caller_post(_mls_x399, _mls_x397, _mls_x402, _mls_x396, _mls_x400);
  } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_x396)) {
    auto _mls_x401 = _mls_d_case41(_mls_x396, _mls_x397);
    _mls_retval = _mls_d_case4_caller_post(_mls_x399, _mls_x397, _mls_x401, _mls_x396, _mls_x400);
  } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_x396)) {
    auto _mls_x398 = _mls_d_case51(_mls_x396, _mls_x397);
    _mls_retval = _mls_d_case4_caller_post(_mls_x399, _mls_x397, _mls_x398, _mls_x396, _mls_x400);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_d_case51(_mlsValue _mls_x407, _mlsValue _mls_x408) {
  _mlsValue _mls_retval;
  auto _mls_x406 = _mlsValue::cast<_mls_Ln>(_mls_x407)->_mls_e;
  _mls_retval = _mls_d_case5_sr_post(_mls_x408, _mls_x406);
  return _mls_retval;
}
_mlsValue _mls_d_case5(_mlsValue _mls_x410, _mlsValue _mls_x411) {
  _mlsValue _mls_retval;
  auto _mls_x409 = _mlsValue::cast<_mls_Ln>(_mls_x410)->_mls_e;
  _mls_retval = _mls_d_case5_sr_post(_mls_x411, _mls_x409);
  return _mls_retval;
}
_mlsValue _mls_d_case5_sr_post(_mlsValue _mls_x413, _mlsValue _mls_x412) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x412)) {
    auto _mls_x419 = _mls_d_case0();
    _mls_retval = _mls_d_case5_sr_post_caller_post(_mls_x412, _mls_x419);
  } else if (_mlsValue::isValueOf<_mls_Var>(_mls_x412)) {
    auto _mls_x418 = _mls_d_case1(_mls_x412, _mls_x413);
    _mls_retval = _mls_d_case5_sr_post_caller_post(_mls_x412, _mls_x418);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x412)) {
    auto _mls_x417 = _mls_d_case2(_mls_x412, _mls_x413);
    _mls_retval = _mls_d_case5_sr_post_caller_post(_mls_x412, _mls_x417);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x412)) {
    auto _mls_x416 = _mls_d_case3(_mls_x412, _mls_x413);
    _mls_retval = _mls_d_case5_sr_post_caller_post(_mls_x412, _mls_x416);
  } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_x412)) {
    auto _mls_x415 = _mls_d_case4(_mls_x412, _mls_x413);
    _mls_retval = _mls_d_case5_sr_post_caller_post(_mls_x412, _mls_x415);
  } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_x412)) {
    auto _mls_x414 = _mls_d_case5(_mls_x412, _mls_x413);
    _mls_retval = _mls_d_case5_sr_post_caller_post(_mls_x412, _mls_x414);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_d_case5_sr_post_caller_post(_mlsValue _mls_x422, _mlsValue _mls_x424) {
  _mlsValue _mls_retval;
  auto _mls_x420 = (-_mlsValue::fromIntLit(1));
  auto _mls_x421 = _mlsValue::create<_mls_Val>(_mls_x420);
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x422)) {
    auto _mls_x426 = _mls_pow_case0(_mls_x422, _mls_x421);
    auto _mls_x427 = _mls_mul(_mls_x424, _mls_x426);
    _mls_retval = _mls_x427;
  } else {
    auto _mls_x423 = _mls_pow_default(_mls_x421, _mls_x422);
    auto _mls_x425 = _mls_mul(_mls_x424, _mls_x423);
    _mls_retval = _mls_x425;
  }
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x88 = _mls_main(_mlsValue::fromIntLit(10));
  _mls_retval = _mls_x88;
  return _mls_retval;
}
_mlsValue _mls_j(_mlsValue _mls_tmp, _mlsValue _mls_tmp1) {
  _mlsValue _mls_retval;
  auto _mls_x89 = (_mls_tmp * _mls_tmp1);
  _mls_retval = _mls_x89;
  return _mls_retval;
}
_mlsValue _mls_ln_case0(_mlsValue _mls_x429) {
  _mlsValue _mls_retval;
  auto _mls_x428 = _mlsValue::cast<_mls_Val>(_mls_x429)->_mls_n;
  if (_mlsValue::isIntLit(_mls_x428, 1)) {
    auto _mls_x431 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
    _mls_retval = _mls_x431;
  } else {
    auto _mls_x430 = _mlsValue::create<_mls_Ln>(_mls_x429);
    _mls_retval = _mls_x430;
  }
  return _mls_retval;
}
_mlsValue _mls_ln_default(_mlsValue _mls_x433) {
  _mlsValue _mls_retval;
  auto _mls_x432 = _mlsValue::create<_mls_Ln>(_mls_x433);
  _mls_retval = _mls_x432;
  return _mls_retval;
}
_mlsValue _mls_main(_mlsValue _mls_n1) {
  _mlsValue _mls_retval;
  auto _mls_x94 = _mlsValue::create<_mls_Var>(_mlsValue::create<_mls_Str>("x"));
  auto _mls_x434 = _mls_pow_default_default(_mls_x94, _mls_x94);
  auto [_mls_x435, _mls_x436, _mls_x437] = _mls_main_caller_post_pre(_mls_n1, _mls_x434);
  if (_mlsValue::isIntLit(_mls_x435, 0)) {
    auto _mls_x440 = _mls_count(_mls_x436);
    _mls_retval = _mls_x440;
  } else {
    auto _mls_x438 = _mls_nestAux_default(_mls_x437, _mls_x436, _mls_x435, _mls_x435);
    auto _mls_x439 = _mls_count(_mls_x438);
    _mls_retval = _mls_x439;
  }
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_main_caller_post_pre(_mlsValue _mls_x442, _mlsValue _mls_x443) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x441 = _mlsValue::create<_mls_LamDeriv>();
  _mls_retval = std::make_tuple(_mls_x442, _mls_x443, _mls_x441);
  return _mls_retval;
}
_mlsValue _mls_mul(_mlsValue _mls_x444, _mlsValue _mls_x445) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x444)) {
    _mls_retval = _mls_mul_case0(_mls_x444, _mls_x445);
  } else {
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x445)) {
      _mls_retval = _mls_mul_default_case0(_mls_x445, _mls_x444);
    } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x445)) {
      _mls_retval = _mls_mul_default_case1(_mls_x445, _mls_x444);
    } else {
      _mls_retval = _mls_mul_default_default(_mls_x444, _mls_x445);
    }
  }
  return _mls_retval;
}
_mlsValue _mls_mul_case0(_mlsValue _mls_x447, _mlsValue _mls_x448) {
  _mlsValue _mls_retval;
  auto _mls_x446 = _mlsValue::cast<_mls_Val>(_mls_x447)->_mls_n;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x448)) {
    auto _mls_x458 = _mlsValue::cast<_mls_Val>(_mls_x448)->_mls_n;
    auto _mls_x459 = (_mls_x446 * _mls_x458);
    auto _mls_x460 = _mlsValue::create<_mls_Val>(_mls_x459);
    _mls_retval = _mls_x460;
  } else {
    if (_mlsValue::isIntLit(_mls_x446, 0)) {
      auto _mls_x457 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
      _mls_retval = _mls_x457;
    } else if (_mlsValue::isIntLit(_mls_x446, 1)) {
      _mls_retval = _mls_x448;
    } else {
      if (_mlsValue::isValueOf<_mls_Mul>(_mls_x448)) {
        auto _mls_x450 = _mlsValue::cast<_mls_Mul>(_mls_x448)->_mls_e1;
        auto _mls_x451 = _mlsValue::cast<_mls_Mul>(_mls_x448)->_mls_e2;
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x450)) {
          auto _mls_x453 = _mlsValue::cast<_mls_Val>(_mls_x450)->_mls_n;
          auto _mls_x454 = (_mls_x446 * _mls_x453);
          auto _mls_x455 = _mlsValue::create<_mls_Val>(_mls_x454);
          auto _mls_x456 = _mls_mul_case01(_mls_x455, _mls_x451);
          _mls_retval = _mls_x456;
        } else {
          auto _mls_x452 = _mlsValue::create<_mls_Mul>(_mls_x447, _mls_x448);
          _mls_retval = _mls_x452;
        }
      } else {
        auto _mls_x449 = _mlsValue::create<_mls_Mul>(_mls_x447, _mls_x448);
        _mls_retval = _mls_x449;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_mul_case01(_mlsValue _mls_x462, _mlsValue _mls_x463) {
  _mlsValue _mls_retval;
  auto _mls_x461 = _mlsValue::cast<_mls_Val>(_mls_x462)->_mls_n;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x463)) {
    auto _mls_x473 = _mlsValue::cast<_mls_Val>(_mls_x463)->_mls_n;
    auto _mls_x474 = (_mls_x461 * _mls_x473);
    auto _mls_x475 = _mlsValue::create<_mls_Val>(_mls_x474);
    _mls_retval = _mls_x475;
  } else {
    if (_mlsValue::isIntLit(_mls_x461, 0)) {
      auto _mls_x472 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
      _mls_retval = _mls_x472;
    } else if (_mlsValue::isIntLit(_mls_x461, 1)) {
      _mls_retval = _mls_x463;
    } else {
      if (_mlsValue::isValueOf<_mls_Mul>(_mls_x463)) {
        auto _mls_x465 = _mlsValue::cast<_mls_Mul>(_mls_x463)->_mls_e1;
        auto _mls_x466 = _mlsValue::cast<_mls_Mul>(_mls_x463)->_mls_e2;
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x465)) {
          auto _mls_x468 = _mlsValue::cast<_mls_Val>(_mls_x465)->_mls_n;
          auto _mls_x469 = (_mls_x461 * _mls_x468);
          auto _mls_x470 = _mlsValue::create<_mls_Val>(_mls_x469);
          auto _mls_x471 = _mls_mul_case0(_mls_x470, _mls_x466);
          _mls_retval = _mls_x471;
        } else {
          auto _mls_x467 = _mlsValue::create<_mls_Mul>(_mls_x462, _mls_x463);
          _mls_retval = _mls_x467;
        }
      } else {
        auto _mls_x464 = _mlsValue::create<_mls_Mul>(_mls_x462, _mls_x463);
        _mls_retval = _mls_x464;
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default(_mlsValue _mls_x476, _mlsValue _mls_x477) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x476)) {
    _mls_retval = _mls_mul_default_case0(_mls_x476, _mls_x477);
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x476)) {
    _mls_retval = _mls_mul_default_case1(_mls_x476, _mls_x477);
  } else {
    _mls_retval = _mls_mul_default_default(_mls_x477, _mls_x476);
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default_case0(_mlsValue _mls_x479, _mlsValue _mls_x481) {
  _mlsValue _mls_retval;
  auto _mls_x478 = _mlsValue::cast<_mls_Val>(_mls_x479)->_mls_n;
  if (_mlsValue::isIntLit(_mls_x478, 0)) {
    auto _mls_x483 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
    _mls_retval = _mls_x483;
  } else if (_mlsValue::isIntLit(_mls_x478, 1)) {
    _mls_retval = _mls_x481;
  } else {
    auto _mls_x480 = _mlsValue::create<_mls_Val>(_mls_x478);
    auto _mls_x482 = _mls_mul_case01(_mls_x480, _mls_x481);
    _mls_retval = _mls_x482;
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default_case0_sr_post(_mlsValue _mls_x484, _mlsValue _mls_x486) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_x484, 0)) {
    auto _mls_x488 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
    _mls_retval = _mls_x488;
  } else if (_mlsValue::isIntLit(_mls_x484, 1)) {
    _mls_retval = _mls_x486;
  } else {
    auto _mls_x485 = _mlsValue::create<_mls_Val>(_mls_x484);
    auto _mls_x487 = _mls_mul_case0(_mls_x485, _mls_x486);
    _mls_retval = _mls_x487;
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default_case1(_mlsValue _mls_x490, _mlsValue _mls_x492) {
  _mlsValue _mls_retval;
  auto _mls_x489 = _mlsValue::cast<_mls_Mul>(_mls_x490)->_mls_e1;
  auto _mls_x491 = _mlsValue::cast<_mls_Mul>(_mls_x490)->_mls_e2;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x489)) {
    auto _mls_x506 = _mlsValue::cast<_mls_Val>(_mls_x489)->_mls_n;
    auto _mls_x507 = _mlsValue::create<_mls_Val>(_mls_x506);
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x492)) {
      auto _mls_x523 = _mls_mul_case01(_mls_x492, _mls_x491);
      auto _mls_x524 = _mls_mul(_mls_x507, _mls_x523);
      _mls_retval = _mls_x524;
    } else {
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x491)) {
        auto _mls_x520 = _mlsValue::cast<_mls_Val>(_mls_x491)->_mls_n;
        auto _mls_x521 = _mls_mul_default_case0_sr_post(_mls_x520, _mls_x492);
        auto _mls_x522 = _mls_mul(_mls_x507, _mls_x521);
        _mls_retval = _mls_x522;
      } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x491)) {
        auto [_mls_x512, _mls_x513, _mls_x514, _mls_x515] = _mls_mul_default_case1_pre(_mls_x491, _mls_x492);
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x512)) {
          auto _mls_x518 = _mls_mul_default_case1_case0(_mls_x512, _mls_x513, _mls_x514);
          auto _mls_x519 = _mls_mul(_mls_x507, _mls_x518);
          _mls_retval = _mls_x519;
        } else {
          auto _mls_x516 = _mls_mul_default_case1_default(_mls_x513, _mls_x515);
          auto _mls_x517 = _mls_mul(_mls_x507, _mls_x516);
          _mls_retval = _mls_x517;
        }
      } else {
        if (_mlsValue::isValueOf<_mls_Mul>(_mls_x492)) {
          auto _mls_x510 = _mls_mul_default_default_case0(_mls_x492, _mls_x491);
          auto _mls_x511 = _mls_mul(_mls_x507, _mls_x510);
          _mls_retval = _mls_x511;
        } else {
          auto _mls_x508 = _mls_mul_default_default_default(_mls_x492, _mls_x491);
          auto _mls_x509 = _mls_mul(_mls_x507, _mls_x508);
          _mls_retval = _mls_x509;
        }
      }
    }
  } else {
    if (_mlsValue::isValueOf<_mls_Mul>(_mls_x492)) {
      auto _mls_x494 = _mlsValue::cast<_mls_Mul>(_mls_x492)->_mls_e1;
      auto _mls_x495 = _mlsValue::cast<_mls_Mul>(_mls_x492)->_mls_e2;
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x495)) {
        auto _mls_x504 = _mls_mul_case01(_mls_x495, _mls_x490);
        auto _mls_x505 = _mls_mul(_mls_x494, _mls_x504);
        _mls_retval = _mls_x505;
      } else {
        auto [_mls_x496, _mls_x497, _mls_x498, _mls_x499] = _mls_mul_default_case1_pre(_mls_x490, _mls_x495);
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x496)) {
          auto _mls_x502 = _mls_mul_default_case1_case0(_mls_x496, _mls_x497, _mls_x498);
          auto _mls_x503 = _mls_mul(_mls_x494, _mls_x502);
          _mls_retval = _mls_x503;
        } else {
          auto _mls_x500 = _mls_mul_default_case1_default(_mls_x497, _mls_x499);
          auto _mls_x501 = _mls_mul(_mls_x494, _mls_x500);
          _mls_retval = _mls_x501;
        }
      }
    } else {
      auto _mls_x493 = _mlsValue::create<_mls_Mul>(_mls_x492, _mls_x490);
      _mls_retval = _mls_x493;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default_case1_case0(_mlsValue _mls_x526, _mlsValue _mls_x528, _mlsValue _mls_x529) {
  _mlsValue _mls_retval;
  auto _mls_x525 = _mlsValue::cast<_mls_Val>(_mls_x526)->_mls_n;
  auto _mls_x527 = _mlsValue::create<_mls_Val>(_mls_x525);
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x528)) {
    auto _mls_x536 = _mls_mul_case0(_mls_x528, _mls_x529);
    auto _mls_x537 = _mls_mul(_mls_x527, _mls_x536);
    _mls_retval = _mls_x537;
  } else {
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x529)) {
      auto _mls_x534 = _mls_mul_default_case0(_mls_x529, _mls_x528);
      auto _mls_x535 = _mls_mul(_mls_x527, _mls_x534);
      _mls_retval = _mls_x535;
    } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x529)) {
      auto _mls_x532 = _mls_mul_default_case1(_mls_x529, _mls_x528);
      auto _mls_x533 = _mls_mul(_mls_x527, _mls_x532);
      _mls_retval = _mls_x533;
    } else {
      auto _mls_x530 = _mls_mul_default_default(_mls_x528, _mls_x529);
      auto _mls_x531 = _mls_mul(_mls_x527, _mls_x530);
      _mls_retval = _mls_x531;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default_case1_default(_mlsValue _mls_x538, _mlsValue _mls_x540) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Mul>(_mls_x538)) {
    auto _mls_x541 = _mlsValue::cast<_mls_Mul>(_mls_x538)->_mls_e1;
    auto _mls_x542 = _mlsValue::cast<_mls_Mul>(_mls_x538)->_mls_e2;
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x542)) {
      auto _mls_x549 = _mls_mul_case0(_mls_x542, _mls_x540);
      auto _mls_x550 = _mls_mul(_mls_x541, _mls_x549);
      _mls_retval = _mls_x550;
    } else {
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x540)) {
        auto _mls_x547 = _mls_mul_default_case0(_mls_x540, _mls_x542);
        auto _mls_x548 = _mls_mul(_mls_x541, _mls_x547);
        _mls_retval = _mls_x548;
      } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x540)) {
        auto _mls_x545 = _mls_mul_default_case1(_mls_x540, _mls_x542);
        auto _mls_x546 = _mls_mul(_mls_x541, _mls_x545);
        _mls_retval = _mls_x546;
      } else {
        auto _mls_x543 = _mls_mul_default_default(_mls_x542, _mls_x540);
        auto _mls_x544 = _mls_mul(_mls_x541, _mls_x543);
        _mls_retval = _mls_x544;
      }
    }
  } else {
    auto _mls_x539 = _mlsValue::create<_mls_Mul>(_mls_x538, _mls_x540);
    _mls_retval = _mls_x539;
  }
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_mul_default_case1_pre(_mlsValue _mls_x552, _mlsValue _mls_x554) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x551 = _mlsValue::cast<_mls_Mul>(_mls_x552)->_mls_e1;
  auto _mls_x553 = _mlsValue::cast<_mls_Mul>(_mls_x552)->_mls_e2;
  _mls_retval = std::make_tuple(_mls_x551, _mls_x554, _mls_x553, _mls_x552);
  return _mls_retval;
}
_mlsValue _mls_mul_default_default(_mlsValue _mls_x555, _mlsValue _mls_x557) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Mul>(_mls_x555)) {
    auto _mls_x558 = _mlsValue::cast<_mls_Mul>(_mls_x555)->_mls_e1;
    auto _mls_x559 = _mlsValue::cast<_mls_Mul>(_mls_x555)->_mls_e2;
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x559)) {
      auto _mls_x575 = _mls_mul_case01(_mls_x559, _mls_x557);
      auto _mls_x576 = _mls_mul(_mls_x558, _mls_x575);
      _mls_retval = _mls_x576;
    } else {
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x557)) {
        auto _mls_x572 = _mlsValue::cast<_mls_Val>(_mls_x557)->_mls_n;
        auto _mls_x573 = _mls_mul_default_case0_sr_post(_mls_x572, _mls_x559);
        auto _mls_x574 = _mls_mul(_mls_x558, _mls_x573);
        _mls_retval = _mls_x574;
      } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x557)) {
        auto [_mls_x564, _mls_x565, _mls_x566, _mls_x567] = _mls_mul_default_case1_pre(_mls_x557, _mls_x559);
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x564)) {
          auto _mls_x570 = _mls_mul_default_case1_case0(_mls_x564, _mls_x565, _mls_x566);
          auto _mls_x571 = _mls_mul(_mls_x558, _mls_x570);
          _mls_retval = _mls_x571;
        } else {
          auto _mls_x568 = _mls_mul_default_case1_default(_mls_x565, _mls_x567);
          auto _mls_x569 = _mls_mul(_mls_x558, _mls_x568);
          _mls_retval = _mls_x569;
        }
      } else {
        if (_mlsValue::isValueOf<_mls_Mul>(_mls_x559)) {
          auto _mls_x562 = _mls_mul_default_default_case0(_mls_x559, _mls_x557);
          auto _mls_x563 = _mls_mul(_mls_x558, _mls_x562);
          _mls_retval = _mls_x563;
        } else {
          auto _mls_x560 = _mls_mul_default_default_default(_mls_x559, _mls_x557);
          auto _mls_x561 = _mls_mul(_mls_x558, _mls_x560);
          _mls_retval = _mls_x561;
        }
      }
    }
  } else {
    auto _mls_x556 = _mlsValue::create<_mls_Mul>(_mls_x555, _mls_x557);
    _mls_retval = _mls_x556;
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default_default_case0(_mlsValue _mls_x578, _mlsValue _mls_x580) {
  _mlsValue _mls_retval;
  auto _mls_x577 = _mlsValue::cast<_mls_Mul>(_mls_x578)->_mls_e1;
  auto _mls_x579 = _mlsValue::cast<_mls_Mul>(_mls_x578)->_mls_e2;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x579)) {
    auto _mls_x583 = _mls_mul_case0(_mls_x579, _mls_x580);
    auto _mls_x584 = _mls_mul(_mls_x577, _mls_x583);
    _mls_retval = _mls_x584;
  } else {
    auto _mls_x581 = _mls_mul_default(_mls_x580, _mls_x579);
    auto _mls_x582 = _mls_mul(_mls_x577, _mls_x581);
    _mls_retval = _mls_x582;
  }
  return _mls_retval;
}
_mlsValue _mls_mul_default_default_default(_mlsValue _mls_x586, _mlsValue _mls_x587) {
  _mlsValue _mls_retval;
  auto _mls_x585 = _mlsValue::create<_mls_Mul>(_mls_x586, _mls_x587);
  _mls_retval = _mls_x585;
  return _mls_retval;
}
_mlsValue _mls_nestAux(_mlsValue _mls_x591, _mlsValue _mls_x589, _mlsValue _mls_x588, _mlsValue _mls_x590) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_x588, 0)) {
    _mls_retval = _mls_x590;
  } else {
    _mls_retval = _mls_nestAux_default(_mls_x589, _mls_x590, _mls_x588, _mls_x591);
  }
  return _mls_retval;
}
_mlsValue _mls_nestAux_caller_post(_mlsValue _mls_x592, _mlsValue _mls_x593, _mlsValue _mls_x594, _mlsValue _mls_x595) {
  _mlsValue _mls_retval;
  auto [_mls_x596, _mls_x597, _mls_x598, _mls_x599] = _mls_nestAux_caller_post_pre(_mls_x592, _mls_x593, _mls_x594, _mls_x595);
  auto _mls_x600 = _mls_nestAux(_mls_x596, _mls_x597, _mls_x598, _mls_x599);
  _mls_retval = _mls_x600;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_nestAux_caller_post_pre(_mlsValue _mls_x602, _mlsValue _mls_x603, _mlsValue _mls_x604, _mlsValue _mls_x605) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x601 = (_mls_x602 - _mlsValue::fromIntLit(1));
  _mls_retval = std::make_tuple(_mls_x603, _mls_x604, _mls_x601, _mls_x605);
  return _mls_retval;
}
_mlsValue _mls_nestAux_default(_mlsValue _mls_x606, _mlsValue _mls_x607, _mlsValue _mls_x610, _mlsValue _mls_x611) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_LamDeriv>(_mls_x606)) {
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x607)) {
      auto _mls_x623 = _mls_d_case0();
      auto [_mls_x624, _mls_x625, _mls_x626, _mls_x627] = _mls_nestAux_caller_post_pre(_mls_x610, _mls_x611, _mls_x606, _mls_x623);
      auto _mls_x628 = _mls_nestAux(_mls_x624, _mls_x625, _mls_x626, _mls_x627);
      _mls_retval = _mls_x628;
    } else if (_mlsValue::isValueOf<_mls_Var>(_mls_x607)) {
      auto _mls_x621 = _mlsValue::cast<_mls_Var>(_mls_x607)->_mls_x;
      auto _mls_x622 = _mls_d_case1_sr_post(_mlsValue::create<_mls_Str>("x"), _mls_x621);
      _mls_retval = _mls_nestAux_caller_post(_mls_x610, _mls_x611, _mls_x606, _mls_x622);
    } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x607)) {
      auto _mls_x618 = _mlsValue::cast<_mls_Add>(_mls_x607)->_mls_e1;
      auto _mls_x619 = _mlsValue::cast<_mls_Add>(_mls_x607)->_mls_e2;
      auto _mls_x620 = _mls_d_case2_sr_post(_mlsValue::create<_mls_Str>("x"), _mls_x618, _mls_x619);
      _mls_retval = _mls_nestAux_caller_post(_mls_x610, _mls_x611, _mls_x606, _mls_x620);
    } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x607)) {
      auto _mls_x615 = _mlsValue::cast<_mls_Mul>(_mls_x607)->_mls_e1;
      auto _mls_x616 = _mlsValue::cast<_mls_Mul>(_mls_x607)->_mls_e2;
      auto _mls_x617 = _mls_d_case3_sr_post(_mlsValue::create<_mls_Str>("x"), _mls_x616, _mls_x615);
      _mls_retval = _mls_nestAux_caller_post(_mls_x610, _mls_x611, _mls_x606, _mls_x617);
    } else if (_mlsValue::isValueOf<_mls_Pow>(_mls_x607)) {
      auto _mls_x612 = _mlsValue::cast<_mls_Pow>(_mls_x607)->_mls_e1;
      auto _mls_x613 = _mlsValue::cast<_mls_Pow>(_mls_x607)->_mls_e2;
      auto _mls_x614 = _mls_d_case4_sr_post(_mls_x612, _mls_x613, _mlsValue::create<_mls_Str>("x"));
      _mls_retval = _mls_nestAux_caller_post(_mls_x610, _mls_x611, _mls_x606, _mls_x614);
    } else if (_mlsValue::isValueOf<_mls_Ln>(_mls_x607)) {
      auto _mls_x608 = _mlsValue::cast<_mls_Ln>(_mls_x607)->_mls_e;
      auto _mls_x609 = _mls_d_case5_sr_post(_mlsValue::create<_mls_Str>("x"), _mls_x608);
      _mls_retval = _mls_nestAux_caller_post(_mls_x610, _mls_x611, _mls_x606, _mls_x609);
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_pow_case0(_mlsValue _mls_x630, _mlsValue _mls_x631) {
  _mlsValue _mls_retval;
  auto _mls_x629 = _mlsValue::cast<_mls_Val>(_mls_x630)->_mls_n;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x631)) {
    auto _mls_x634 = _mlsValue::cast<_mls_Val>(_mls_x631)->_mls_n;
    auto _mls_x635 = _mls_pown(_mls_x629, _mls_x634);
    auto _mls_x636 = _mlsValue::create<_mls_Val>(_mls_x635);
    _mls_retval = _mls_x636;
  } else {
    if (_mlsValue::isIntLit(_mls_x629, 0)) {
      auto _mls_x633 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(0));
      _mls_retval = _mls_x633;
    } else {
      auto _mls_x632 = _mlsValue::create<_mls_Pow>(_mls_x630, _mls_x631);
      _mls_retval = _mls_x632;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_pow_default(_mlsValue _mls_x637, _mlsValue _mls_x638) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x637)) {
    _mls_retval = _mls_pow_default_case0(_mls_x637, _mls_x638);
  } else {
    _mls_retval = _mls_pow_default_default(_mls_x638, _mls_x637);
  }
  return _mls_retval;
}
_mlsValue _mls_pow_default_case0(_mlsValue _mls_x640, _mlsValue _mls_x642) {
  _mlsValue _mls_retval;
  auto _mls_x639 = _mlsValue::cast<_mls_Val>(_mls_x640)->_mls_n;
  if (_mlsValue::isIntLit(_mls_x639, 0)) {
    auto _mls_x643 = _mlsValue::create<_mls_Val>(_mlsValue::fromIntLit(1));
    _mls_retval = _mls_x643;
  } else if (_mlsValue::isIntLit(_mls_x639, 1)) {
    _mls_retval = _mls_x642;
  } else {
    auto _mls_x641 = _mlsValue::create<_mls_Pow>(_mls_x642, _mls_x640);
    _mls_retval = _mls_x641;
  }
  return _mls_retval;
}
_mlsValue _mls_pow_default_default(_mlsValue _mls_x645, _mlsValue _mls_x646) {
  _mlsValue _mls_retval;
  auto _mls_x644 = _mlsValue::create<_mls_Pow>(_mls_x645, _mls_x646);
  _mls_retval = _mls_x644;
  return _mls_retval;
}
_mlsValue _mls_pown(_mlsValue _mls_x147, _mlsValue _mls_n3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_n3, 0)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else if (_mlsValue::isIntLit(_mls_n3, 1)) {
    _mls_retval = _mls_x147;
  } else {
    auto _mls_x146 = (_mls_n3 / _mlsValue::fromIntLit(2));
    auto _mls_x148 = _mls_pown(_mls_x147, _mls_x146);
    auto _mls_x149 = (_mls_x148 * _mls_x148);
    auto _mls_x150 = (_mls_n3 % _mlsValue::fromIntLit(2));
    auto _mls_x151 = (_mls_x150 == _mlsValue::fromIntLit(0));
    if (_mlsValue::isIntLit(_mls_x151, 1)) {
      _mls_retval = _mls_j(_mls_x149, _mlsValue::fromIntLit(1));
    } else {
      _mls_retval = _mls_j(_mls_x149, _mls_x147);
    }
  }
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
