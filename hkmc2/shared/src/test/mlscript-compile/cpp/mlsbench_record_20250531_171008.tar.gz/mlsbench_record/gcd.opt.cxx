#include "mlsprelude.h"
struct _mls_Tuple2;
struct _mls_List;
struct _mls_Cons;
struct _mls_Tuple3;
struct _mls_LamF2;
struct _mls_Nil;
struct _mls_LamF1;
_mlsValue _mls_quotRem(_mlsValue, _mlsValue);
_mlsValue _mls_test(_mlsValue);
_mlsValue _mls_g_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_gcdE(_mlsValue, _mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_lscomp2(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_map_case0(_mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_enumFromTo_pre(_mlsValue, _mlsValue);
_mlsValue _mls_g_case0(_mlsValue, _mlsValue);
_mlsValue _mls_max__case0_sr_post(_mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_test_caller_post_pre(_mlsValue, _mlsValue);
_mlsValue _mls_test_caller_post_caller_post(_mlsValue);
_mlsValue _mls_apply(_mlsValue, _mlsValue);
_mlsValue _mls_g_case0_sr_post_case0(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_enumFromTo(_mlsValue, _mlsValue);
_mlsValue _mls_test_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_map_case1();
_mlsValue _mls_enumFromTo_default();
_mlsValue _mls_lscomp1_case0();
_mlsValue _mls_map(_mlsValue, _mlsValue);
_mlsValue _mls_enumFromTo_case0(_mlsValue, _mlsValue);
_mlsValue _mls_lscomp1(_mlsValue, _mlsValue);
_mlsValue _mls_test_caller_post_caller_post_caller_post(_mlsValue);
std::tuple<_mlsValue, _mlsValue> _mls_test_caller_post_caller_post_pre(_mlsValue);
_mlsValue _mls_max_(_mlsValue);
struct _mls_Tuple2: public _mlsObject {
  _mlsValue _mls_field0;
  _mlsValue _mls_field1;
  constexpr static inline const char *typeName = "Tuple2";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_field0.print(); std::printf(", "); this->_mls_field1.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_field0); _mlsValue::destroy(this->_mls_field1);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_field0.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field0.asObject()) && this->_mls_field1.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field1.asObject()); }
  static _mlsValue create(_mlsValue _mls_field0, _mlsValue _mls_field1) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Tuple2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_field0 = _mls_field0; _mlsVal->_mls_field1 = _mls_field1;  return _mlsValue(_mlsVal); }
  
};
struct _mls_List: public _mlsObject {
  
  constexpr static inline const char *typeName = "List";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_List; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Cons: public _mls_List {
  _mlsValue _mls_head;
  _mlsValue _mls_tail;
  constexpr static inline const char *typeName = "Cons";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_head.print(); std::printf(", "); this->_mls_tail.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_head); _mlsValue::destroy(this->_mls_tail);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_head.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_head.asObject()) && this->_mls_tail.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_tail.asObject()); }
  static _mlsValue create(_mlsValue _mls_head, _mlsValue _mls_tail) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Cons; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_head = _mls_head; _mlsVal->_mls_tail = _mls_tail;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Tuple3: public _mlsObject {
  _mlsValue _mls_field0;
  _mlsValue _mls_field1;
  _mlsValue _mls_field2;
  constexpr static inline const char *typeName = "Tuple3";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_field0.print(); std::printf(", "); this->_mls_field1.print(); std::printf(", "); this->_mls_field2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_field0); _mlsValue::destroy(this->_mls_field1); _mlsValue::destroy(this->_mls_field2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_field0.asObject()->operator==(*other.cast<_mls_Tuple3>()->_mls_field0.asObject()) && this->_mls_field1.asObject()->operator==(*other.cast<_mls_Tuple3>()->_mls_field1.asObject()) && this->_mls_field2.asObject()->operator==(*other.cast<_mls_Tuple3>()->_mls_field2.asObject()); }
  static _mlsValue create(_mlsValue _mls_field0, _mlsValue _mls_field1, _mlsValue _mls_field2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Tuple3; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_field0 = _mls_field0; _mlsVal->_mls_field1 = _mls_field1; _mlsVal->_mls_field2 = _mls_field2;  return _mlsValue(_mlsVal); }
  
};
struct _mls_LamF2: public _mlsObject {
  
  constexpr static inline const char *typeName = "LamF2";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_LamF2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Nil: public _mls_List {
  
  constexpr static inline const char *typeName = "Nil";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Nil; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_LamF1: public _mlsObject {
  
  constexpr static inline const char *typeName = "LamF1";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_LamF1; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_apply(_mlsValue _mls_f, _mlsValue _mls_xs) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_LamF1>(_mls_f)) {
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_xs)) {
      auto _mls_x19 = _mlsValue::cast<_mls_Tuple2>(_mls_xs)->_mls_field0;
      auto _mls_x20 = _mlsValue::cast<_mls_Tuple2>(_mls_xs)->_mls_field1;
      auto _mls_x21 = _mls_gcdE(_mls_x19, _mls_x20);
      auto _mls_x22 = _mlsValue::create<_mls_Tuple3>(_mls_x19, _mls_x20, _mls_x21);
      _mls_retval = _mls_x22;
    } else {
      throw std::runtime_error("match error" LINE_STRING);
    }
  } else if (_mlsValue::isValueOf<_mls_LamF2>(_mls_f)) {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_xs)) {
      auto _mls_x12 = _mlsValue::cast<_mls_Tuple3>(_mls_xs)->_mls_field2;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x12)) {
        auto _mls_x13 = _mlsValue::cast<_mls_Tuple3>(_mls_x12)->_mls_field0;
        auto _mls_x14 = _mlsValue::cast<_mls_Tuple3>(_mls_x12)->_mls_field1;
        auto _mls_x15 = _mlsValue::cast<_mls_Tuple3>(_mls_x12)->_mls_field2;
        auto _mls_x16 = (_mls_x13 + _mls_x14);
        auto _mls_x17 = (_mls_x16 + _mls_x15);
        auto _mls_x113 = _mls_builtin_abs(_mls_x17);
        _mls_retval = _mls_x113;
      } else {
        throw std::runtime_error("match error" LINE_STRING);
      }
    } else {
      throw std::runtime_error("match error" LINE_STRING);
    }
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue> _mls_test_caller_post_caller_post_pre(_mlsValue _mls_x163) {
  std::tuple<_mlsValue, _mlsValue> _mls_retval;
  auto _mls_x162 = _mlsValue::create<_mls_LamF1>();
  _mls_retval = std::make_tuple(_mls_x163, _mls_x162);
  return _mls_retval;
}
_mlsValue _mls_enumFromTo_case0(_mlsValue _mls_x143, _mlsValue _mls_x144) {
  _mlsValue _mls_retval;
  auto _mls_x142 = (_mls_x143 + _mlsValue::fromIntLit(1));
  auto _mls_x145 = _mls_enumFromTo(_mls_x142, _mls_x144);
  auto _mls_x146 = _mlsValue::create<_mls_Cons>(_mls_x143, _mls_x145);
  _mls_retval = _mls_x146;
  return _mls_retval;
}
_mlsValue _mls_g_case0_sr_post_case0(_mlsValue _mls_x94, _mlsValue _mls_x98, _mlsValue _mls_x104, _mlsValue _mls_x107) {
  _mlsValue _mls_retval;
  auto _mls_x93 = _mlsValue::cast<_mls_Tuple3>(_mls_x94)->_mls_field0;
  auto _mls_x95 = _mlsValue::cast<_mls_Tuple3>(_mls_x94)->_mls_field1;
  auto _mls_x96 = _mlsValue::cast<_mls_Tuple3>(_mls_x94)->_mls_field2;
  auto _mls_x97 = (_mls_x96 == _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x97, 1)) {
    auto _mls_x111 = _mlsValue::create<_mls_Tuple3>(_mls_x98, _mls_x104, _mls_x107);
    _mls_retval = _mls_x111;
  } else {
    auto _mls_x99 = _mls_quotRem(_mls_x98, _mls_x96);
    auto _mls_x100 = _mlsValue::cast<_mls_Tuple2>(_mls_x99)->_mls_field0;
    auto _mls_x101 = _mlsValue::cast<_mls_Tuple2>(_mls_x99)->_mls_field1;
    auto _mls_x102 = (_mls_x100 * _mls_x93);
    auto _mls_x103 = (_mls_x104 - _mls_x102);
    auto _mls_x105 = (_mls_x100 * _mls_x95);
    auto _mls_x106 = (_mls_x107 - _mls_x105);
    auto _mls_x108 = _mlsValue::create<_mls_Tuple3>(_mls_x93, _mls_x95, _mls_x96);
    auto _mls_x109 = _mlsValue::create<_mls_Tuple3>(_mls_x103, _mls_x106, _mls_x101);
    auto _mls_x110 = _mls_g_case0(_mls_x108, _mls_x109);
    _mls_retval = _mls_x110;
  }
  return _mls_retval;
}
_mlsValue _mls_quotRem(_mlsValue _mls_a, _mlsValue _mls_b) {
  _mlsValue _mls_retval;
  auto _mls_x164 = _mls_builtin_trunc_div(_mls_a, _mls_b);
  auto _mls_x165 = _mls_builtin_trunc_mod(_mls_a, _mls_b);
  auto _mls_x6 = _mlsValue::create<_mls_Tuple2>(_mls_x164, _mls_x165);
  _mls_retval = _mls_x6;
  return _mls_retval;
}
_mlsValue _mls_test_caller_post_caller_post_caller_post(_mlsValue _mls_x148) {
  _mlsValue _mls_retval;
  auto _mls_x147 = _mlsValue::create<_mls_LamF2>();
  auto _mls_x149 = _mls_map(_mls_x147, _mls_x148);
  auto _mls_x150 = _mls_max_(_mls_x149);
  _mls_retval = _mls_x150;
  return _mls_retval;
}
_mlsValue _mls_max_(_mlsValue _mls_ls) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls)) {
    auto _mls_x70 = _mlsValue::cast<_mls_Cons>(_mls_ls)->_mls_head;
    auto _mls_x71 = _mlsValue::cast<_mls_Cons>(_mls_ls)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x71)) {
      _mls_retval = _mls_x70;
    } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x71)) {
      auto _mls_x72 = _mlsValue::cast<_mls_Cons>(_mls_x71)->_mls_head;
      auto _mls_x73 = _mlsValue::cast<_mls_Cons>(_mls_x71)->_mls_tail;
      auto _mls_x74 = (_mls_x70 < _mls_x72);
      if (_mlsValue::isIntLit(_mls_x74, 1)) {
        auto _mls_x180 = _mls_max__case0_sr_post(_mls_x73, _mls_x72);
        _mls_retval = _mls_x180;
      } else {
        auto _mls_x179 = _mls_max__case0_sr_post(_mls_x73, _mls_x70);
        _mls_retval = _mls_x179;
      }
    } else {
      throw std::runtime_error("match error" LINE_STRING);
    }
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_map_case0(_mlsValue _mls_x173, _mlsValue _mls_x175) {
  _mlsValue _mls_retval;
  auto _mls_x172 = _mlsValue::cast<_mls_Cons>(_mls_x173)->_mls_head;
  auto _mls_x174 = _mlsValue::cast<_mls_Cons>(_mls_x173)->_mls_tail;
  auto _mls_x176 = _mls_apply(_mls_x175, _mls_x172);
  auto _mls_x177 = _mls_map(_mls_x175, _mls_x174);
  auto _mls_x178 = _mlsValue::create<_mls_Cons>(_mls_x176, _mls_x177);
  _mls_retval = _mls_x178;
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x121 = _mls_test(_mlsValue::fromIntLit(1500));
  _mls_retval = _mls_x121;
  return _mls_retval;
}
_mlsValue _mls_g_case0_sr_post(_mlsValue _mls_x79, _mlsValue _mls_x80, _mlsValue _mls_x81, _mlsValue _mls_x82) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x79)) {
    _mls_retval = _mls_g_case0_sr_post_case0(_mls_x79, _mls_x80, _mls_x81, _mls_x82);
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_map(_mlsValue _mls_x187, _mlsValue _mls_x186) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x186)) {
    _mls_retval = _mls_map_case0(_mls_x186, _mls_x187);
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x186)) {
    _mls_retval = _mls_map_case1();
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_enumFromTo_default() {
  _mlsValue _mls_retval;
  auto _mls_x166 = _mlsValue::create<_mls_Nil>();
  _mls_retval = _mls_x166;
  return _mls_retval;
}
_mlsValue _mls_max__case0_sr_post(_mlsValue _mls_x114, _mlsValue _mls_x118) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x114)) {
    _mls_retval = _mls_x118;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x114)) {
    auto _mls_x115 = _mlsValue::cast<_mls_Cons>(_mls_x114)->_mls_head;
    auto _mls_x116 = _mlsValue::cast<_mls_Cons>(_mls_x114)->_mls_tail;
    auto _mls_x117 = (_mls_x118 < _mls_x115);
    if (_mlsValue::isIntLit(_mls_x117, 1)) {
      auto _mls_x120 = _mls_max__case0_sr_post(_mls_x116, _mls_x115);
      _mls_retval = _mls_x120;
    } else {
      auto _mls_x119 = _mls_max__case0_sr_post(_mls_x116, _mls_x118);
      _mls_retval = _mls_x119;
    }
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_gcdE(_mlsValue _mls_x47, _mlsValue _mls_y) {
  _mlsValue _mls_retval;
  auto _mls_x46 = (_mls_x47 == _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x46, 1)) {
    auto _mls_x51 = _mlsValue::create<_mls_Tuple3>(_mls_y, _mlsValue::fromIntLit(0), _mlsValue::fromIntLit(1));
    _mls_retval = _mls_x51;
  } else {
    auto _mls_x49 = _mlsValue::create<_mls_Tuple3>(_mlsValue::fromIntLit(0), _mlsValue::fromIntLit(1), _mls_y);
    auto _mls_x189 = _mls_g_case0_sr_post_case0(_mls_x49, _mls_x47, _mlsValue::fromIntLit(1), _mlsValue::fromIntLit(0));
    _mls_retval = _mls_x189;
  }
  return _mls_retval;
}
_mlsValue _mls_map_case1() {
  _mlsValue _mls_retval;
  auto _mls_x112 = _mlsValue::create<_mls_Nil>();
  _mls_retval = _mls_x112;
  return _mls_retval;
}
_mlsValue _mls_test_caller_post(_mlsValue _mls_x83, _mlsValue _mls_x86) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x83)) {
    auto _mls_x88 = _mls_lscomp1_case0();
    auto [_mls_x89, _mls_x90] = _mls_test_caller_post_caller_post_pre(_mls_x88);
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x89)) {
      auto _mls_x92 = _mls_map_case0(_mls_x89, _mls_x90);
      _mls_retval = _mls_test_caller_post_caller_post_caller_post(_mls_x92);
    } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x89)) {
      auto _mls_x91 = _mls_map_case1();
      _mls_retval = _mls_test_caller_post_caller_post_caller_post(_mls_x91);
    } else {
      throw std::runtime_error("match error" LINE_STRING);
    }
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x83)) {
    auto _mls_x84 = _mlsValue::cast<_mls_Cons>(_mls_x83)->_mls_head;
    auto _mls_x85 = _mlsValue::cast<_mls_Cons>(_mls_x83)->_mls_tail;
    auto _mls_x87 = _mls_lscomp2(_mls_x84, _mls_x85, _mls_x86, _mls_x86);
    _mls_retval = _mls_test_caller_post_caller_post(_mls_x87);
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_lscomp2(_mlsValue _mls_h1, _mlsValue _mls_t1, _mlsValue _mls_p2, _mlsValue _mls_initMs) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_p2)) {
    auto _mls_x28 = _mls_lscomp1(_mls_t1, _mls_initMs);
    _mls_retval = _mls_x28;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_p2)) {
    auto _mls_x23 = _mlsValue::cast<_mls_Cons>(_mls_p2)->_mls_head;
    auto _mls_x24 = _mlsValue::cast<_mls_Cons>(_mls_p2)->_mls_tail;
    auto _mls_x25 = _mls_lscomp2(_mls_h1, _mls_t1, _mls_x24, _mls_initMs);
    auto _mls_x26 = _mlsValue::create<_mls_Tuple2>(_mls_h1, _mls_x23);
    auto _mls_x27 = _mlsValue::create<_mls_Cons>(_mls_x26, _mls_x25);
    _mls_retval = _mls_x27;
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_lscomp1_case0() {
  _mlsValue _mls_retval;
  auto _mls_x188 = _mlsValue::create<_mls_Nil>();
  _mls_retval = _mls_x188;
  return _mls_retval;
}
_mlsValue _mls_g_case0(_mlsValue _mls_x191, _mlsValue _mls_x194) {
  _mlsValue _mls_retval;
  auto _mls_x190 = _mlsValue::cast<_mls_Tuple3>(_mls_x191)->_mls_field0;
  auto _mls_x192 = _mlsValue::cast<_mls_Tuple3>(_mls_x191)->_mls_field1;
  auto _mls_x193 = _mlsValue::cast<_mls_Tuple3>(_mls_x191)->_mls_field2;
  _mls_retval = _mls_g_case0_sr_post(_mls_x194, _mls_x193, _mls_x190, _mls_x192);
  return _mls_retval;
}
_mlsValue _mls_test(_mlsValue _mls_d) {
  _mlsValue _mls_retval;
  auto _mls_x36 = (_mlsValue::fromIntLit(5000) + _mls_d);
  auto [_mls_x125, _mls_x126, _mls_x127] = _mls_enumFromTo_pre(_mlsValue::fromIntLit(5000), _mls_x36);
  if (_mlsValue::isIntLit(_mls_x125, 1)) {
    auto _mls_x135 = _mls_enumFromTo_case0(_mls_x126, _mls_x127);
    auto [_mls_x136, _mls_x137, _mls_x138, _mls_x139] = _mls_test_caller_post_pre(_mls_d, _mls_x135);
    if (_mlsValue::isIntLit(_mls_x136, 1)) {
      auto _mls_x141 = _mls_enumFromTo_case0(_mls_x137, _mls_x138);
      _mls_retval = _mls_test_caller_post(_mls_x139, _mls_x141);
    } else {
      auto _mls_x140 = _mls_enumFromTo_default();
      _mls_retval = _mls_test_caller_post(_mls_x139, _mls_x140);
    }
  } else {
    auto _mls_x128 = _mls_enumFromTo_default();
    auto [_mls_x129, _mls_x130, _mls_x131, _mls_x132] = _mls_test_caller_post_pre(_mls_d, _mls_x128);
    if (_mlsValue::isIntLit(_mls_x129, 1)) {
      auto _mls_x134 = _mls_enumFromTo_case0(_mls_x130, _mls_x131);
      _mls_retval = _mls_test_caller_post(_mls_x132, _mls_x134);
    } else {
      auto _mls_x133 = _mls_enumFromTo_default();
      _mls_retval = _mls_test_caller_post(_mls_x132, _mls_x133);
    }
  }
  return _mls_retval;
}
_mlsValue _mls_lscomp1(_mlsValue _mls_x151, _mlsValue _mls_x154) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x151)) {
    _mls_retval = _mls_lscomp1_case0();
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x151)) {
    auto _mls_x152 = _mlsValue::cast<_mls_Cons>(_mls_x151)->_mls_head;
    auto _mls_x153 = _mlsValue::cast<_mls_Cons>(_mls_x151)->_mls_tail;
    auto _mls_x155 = _mls_lscomp2(_mls_x152, _mls_x153, _mls_x154, _mls_x154);
    _mls_retval = _mls_x155;
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_enumFromTo(_mlsValue _mls_x167, _mlsValue _mls_x168) {
  _mlsValue _mls_retval;
  auto [_mls_x169, _mls_x170, _mls_x171] = _mls_enumFromTo_pre(_mls_x167, _mls_x168);
  if (_mlsValue::isIntLit(_mls_x169, 1)) {
    _mls_retval = _mls_enumFromTo_case0(_mls_x170, _mls_x171);
  } else {
    _mls_retval = _mls_enumFromTo_default();
  }
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_enumFromTo_pre(_mlsValue _mls_x123, _mlsValue _mls_x124) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x122 = (_mls_x123 <= _mls_x124);
  _mls_retval = std::make_tuple(_mls_x122, _mls_x123, _mls_x124);
  return _mls_retval;
}
_mlsValue _mls_test_caller_post_caller_post(_mlsValue _mls_x181) {
  _mlsValue _mls_retval;
  auto [_mls_x182, _mls_x183] = _mls_test_caller_post_caller_post_pre(_mls_x181);
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x182)) {
    auto _mls_x185 = _mls_map_case0(_mls_x182, _mls_x183);
    _mls_retval = _mls_test_caller_post_caller_post_caller_post(_mls_x185);
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x182)) {
    auto _mls_x184 = _mls_map_case1();
    _mls_retval = _mls_test_caller_post_caller_post_caller_post(_mls_x184);
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_test_caller_post_pre(_mlsValue _mls_x157, _mlsValue _mls_x161) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x156 = (_mlsValue::fromIntLit(10000) + _mls_x157);
  auto [_mls_x158, _mls_x159, _mls_x160] = _mls_enumFromTo_pre(_mlsValue::fromIntLit(10000), _mls_x156);
  _mls_retval = std::make_tuple(_mls_x158, _mls_x159, _mls_x160, _mls_x161);
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
