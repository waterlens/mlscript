#include "mlsprelude.h"
struct _mls_Branch;
struct _mls_Evaluation;
struct _mls_Lambda_best_;
struct _mls_Lambda_board;
struct _mls_Lambda_cropTree;
struct _mls_Lambda_lambda;
struct _mls_Lambda_lambda1;
struct _mls_Lambda_lambda10;
struct _mls_Lambda_lambda2;
struct _mls_Lambda_lambda3;
struct _mls_Lambda_lambda4;
struct _mls_Lambda_lambda5;
struct _mls_Lambda_lambda6;
struct _mls_Lambda_lambda7;
struct _mls_Lambda_lambda8;
struct _mls_Lambda_lambda9;
struct _mls_Lambda_lscomp1;
struct _mls_Lambda_lscomp2;
struct _mls_Lambda_max_;
struct _mls_Lambda_min_;
struct _mls_Lambda_scorePiece;
struct _mls_Lambda_showMove;
struct _mls_Lambda_static;
struct _mls_Lambda_sum;
struct _mls_List;
struct _mls_Cons;
struct _mls_Nil;
struct _mls_OWin;
struct _mls_Piece;
struct _mls_Empty;
struct _mls_O;
struct _mls_Score;
struct _mls_Tuple2;
struct _mls_X;
struct _mls_XWin;
_mlsValue _mls_alternate(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_alternate_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_alternate_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_alternate_caller_post_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_alternate_caller_post_caller_post_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_alternate_caller_post_caller_post_case0();
_mlsValue _mls_alternate_caller_post_caller_post_default(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_alternate_caller_post_caller_post_default_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_alternate_caller_post_case0();
_mlsValue _mls_alternate_caller_post_default(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_alternate_case0();
_mlsValue _mls_alternate_default(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_andd(_mlsValue);
_mlsValue _mls_andd_case1_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_append(_mlsValue, _mlsValue);
_mlsValue _mls_best(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_bestMove(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_bestMove_caller_post_case0(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_concat(_mlsValue);
_mlsValue _mls_concat_case0();
_mlsValue _mls_concat_case1(_mlsValue);
_mlsValue _mls_concat_case1_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_cropTree(_mlsValue);
_mlsValue _mls_cropTree_case0(_mlsValue);
_mlsValue _mls_cropTree_case0_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_cropTree_case0_sr_post_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_empty_(_mlsValue, _mlsValue);
_mlsValue _mls_empty_case0_sr_post_case0_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_eqPiece(_mlsValue, _mlsValue);
_mlsValue _mls_eval1(_mlsValue);
_mlsValue _mls_evaluationEq(_mlsValue, _mlsValue);
_mlsValue _mls_evaluationEq_case0(_mlsValue);
_mlsValue _mls_evaluationEq_case1(_mlsValue);
_mlsValue _mls_evaluationEq_case2_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_evaluationEq_case2_sr_post_case0(_mlsValue, _mlsValue);
_mlsValue _mls_foldr(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_foldr_case1(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_foldr_case1_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_fullBoard_caller_post(_mlsValue);
_mlsValue _mls_fullBoard_caller_post_case0(_mlsValue, _mlsValue);
_mlsValue _mls_fullBoard_caller_post_case0_sr_post(_mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue> _mls_fullBoard_caller_post_pre(_mlsValue);
std::tuple<_mlsValue, _mlsValue> _mls_fullBoard_case0_pre();
_mlsValue _mls_fullBoard_case1(_mlsValue);
_mlsValue _mls_go(_mlsValue, _mlsValue);
_mlsValue _mls_insert(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_interpret(_mlsValue, _mlsValue);
_mlsValue _mls_interpret_case0(_mlsValue);
_mlsValue _mls_interpret_case1_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_map(_mlsValue, _mlsValue);
_mlsValue _mls_map2(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_map2_case0();
_mlsValue _mls_map2_case1_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_mapTree(_mlsValue, _mlsValue);
_mlsValue _mls_mapTree_case0_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_map_case01(_mlsValue, _mlsValue);
_mlsValue _mls_map_case0(_mlsValue, _mlsValue);
_mlsValue _mls_map_case0_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_map_case1();
_mlsValue _mls_max_(_mlsValue, _mlsValue);
_mlsValue _mls_min_(_mlsValue, _mlsValue);
_mlsValue _mls_mise(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_mise_case0(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_newPositions(_mlsValue, _mlsValue);
_mlsValue _mls_newPositions_case0(_mlsValue, _mlsValue);
_mlsValue _mls_newPositions_case0_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_newPositions_case1();
std::tuple<_mlsValue, _mlsValue> _mls_newPositions_pre(_mlsValue, _mlsValue);
_mlsValue _mls_not(_mlsValue);
_mlsValue _mls_opposite(_mlsValue);
_mlsValue _mls_opposite_case0();
_mlsValue _mls_opposite_case1();
_mlsValue _mls_placePiece(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_placePiece_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_placePiece_caller_post_caller_post_case0();
_mlsValue _mls_placePiece_caller_post_caller_post_default(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_prog(_mlsValue);
_mlsValue _mls_prog_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_prog_caller_post2(_mlsValue);
_mlsValue _mls_prog_caller_post1(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_prog_caller_post_caller_post(_mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_prog_caller_post_caller_post_pre(_mlsValue, _mlsValue);
_mlsValue _mls_prune(_mlsValue, _mlsValue);
_mlsValue _mls_prune_case0_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_repTree(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_run(_mlsValue);
_mlsValue _mls_score(_mlsValue, _mlsValue);
_mlsValue _mls_scorePiece(_mlsValue, _mlsValue);
_mlsValue _mls_score_caller_post(_mlsValue);
_mlsValue _mls_score_caller_post_post(_mlsValue);
std::tuple<_mlsValue, _mlsValue> _mls_score_caller_post_pre(_mlsValue);
_mlsValue _mls_searchTree(_mlsValue, _mlsValue);
_mlsValue _mls_showBoard(_mlsValue);
_mlsValue _mls_showBoard_caller_post1(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_showBoard_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_showBoard_caller_post2(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue> _mls_showEvaluation_caller_post_pre(_mlsValue, _mlsValue);
_mlsValue _mls_showEvaluation_case2_sr_post_case0(_mlsValue);
_mlsValue _mls_showEvaluation_case2_sr_post_default(_mlsValue);
_mlsValue _mls_showMove(_mlsValue);
_mlsValue _mls_showMove_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_showMove_caller_post_case0(_mlsValue, _mlsValue);
_mlsValue _mls_showMove_caller_post_default(_mlsValue, _mlsValue);
_mlsValue _mls_showPiece(_mlsValue);
_mlsValue _mls_showRow(_mlsValue);
_mlsValue _mls_showRow_case0_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_showRow_case0_sr_post_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_showRow_case0_sr_post_case0(_mlsValue, _mlsValue);
_mlsValue _mls_static1(_mlsValue);
_mlsValue _mls_str_to_list(_mlsValue);
_mlsValue _mls_str_to_list_case0();
_mlsValue _mls_str_to_list_default(_mlsValue);
_mlsValue _mls_sum(_mlsValue);
_mlsValue _mls_win1();
_mlsValue _mls_win2();
_mlsValue _mls_win3();
_mlsValue _mls_win4();
_mlsValue _mls_win5();
_mlsValue _mls_win6();
_mlsValue _mls_win7();
_mlsValue _mls_win8();
_mlsValue _mls_wins();
struct _mls_Branch: public _mlsObject {
  _mlsValue _mls_a;
  _mlsValue _mls_cs;
  constexpr static inline const char *typeName = "Branch";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_a.print(); std::printf(", "); this->_mls_cs.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_a); _mlsValue::destroy(this->_mls_cs);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_a.asObject()->operator==(*other.cast<_mls_Branch>()->_mls_a.asObject()) && this->_mls_cs.asObject()->operator==(*other.cast<_mls_Branch>()->_mls_cs.asObject()); }
  static _mlsValue create(_mlsValue _mls_a, _mlsValue _mls_cs) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Branch; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_a = _mls_a; _mlsVal->_mls_cs = _mls_cs;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Evaluation: public _mlsObject {
  
  constexpr static inline const char *typeName = "Evaluation";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Evaluation; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Lambda_best_: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_best_";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_best_>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_best_; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply4(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
};
struct _mls_Lambda_board: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_board";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_board; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_cropTree: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_cropTree";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_cropTree; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  _mlsValue _mls_lam_arg1;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print(); std::printf(", "); this->_mls_lam_arg1.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0); _mlsValue::destroy(this->_mls_lam_arg1);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda>()->_mls_lam_arg0.asObject()) && this->_mls_lam_arg1.asObject()->operator==(*other.cast<_mls_Lambda_lambda>()->_mls_lam_arg1.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0, _mlsValue _mls_lam_arg1) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0; _mlsVal->_mls_lam_arg1 = _mls_lam_arg1;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda1: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda1; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda10: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda10; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_lambda2: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda2>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda3: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  _mlsValue _mls_lam_arg1;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print(); std::printf(", "); this->_mls_lam_arg1.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0); _mlsValue::destroy(this->_mls_lam_arg1);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda3>()->_mls_lam_arg0.asObject()) && this->_mls_lam_arg1.asObject()->operator==(*other.cast<_mls_Lambda_lambda3>()->_mls_lam_arg1.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0, _mlsValue _mls_lam_arg1) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda3; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0; _mlsVal->_mls_lam_arg1 = _mls_lam_arg1;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda4: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda4>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda4; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda5: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda5>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda5; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda6: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda6>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda6; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda7: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  _mlsValue _mls_lam_arg1;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print(); std::printf(", "); this->_mls_lam_arg1.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0); _mlsValue::destroy(this->_mls_lam_arg1);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda7>()->_mls_lam_arg0.asObject()) && this->_mls_lam_arg1.asObject()->operator==(*other.cast<_mls_Lambda_lambda7>()->_mls_lam_arg1.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0, _mlsValue _mls_lam_arg1) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda7; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0; _mlsVal->_mls_lam_arg1 = _mls_lam_arg1;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda8: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda8>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda8; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda9: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  _mlsValue _mls_lam_arg1;
  _mlsValue _mls_lam_arg2;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print(); std::printf(", "); this->_mls_lam_arg1.print(); std::printf(", "); this->_mls_lam_arg2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0); _mlsValue::destroy(this->_mls_lam_arg1); _mlsValue::destroy(this->_mls_lam_arg2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda9>()->_mls_lam_arg0.asObject()) && this->_mls_lam_arg1.asObject()->operator==(*other.cast<_mls_Lambda_lambda9>()->_mls_lam_arg1.asObject()) && this->_mls_lam_arg2.asObject()->operator==(*other.cast<_mls_Lambda_lambda9>()->_mls_lam_arg2.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0, _mlsValue _mls_lam_arg1, _mlsValue _mls_lam_arg2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda9; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0; _mlsVal->_mls_lam_arg1 = _mls_lam_arg1; _mlsVal->_mls_lam_arg2 = _mls_lam_arg2;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lscomp1: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lscomp1";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lscomp1; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lscomp2: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  _mlsValue _mls_lam_arg1;
  _mlsValue _mls_lam_arg2;
  constexpr static inline const char *typeName = "Lambda_lscomp2";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print(); std::printf(", "); this->_mls_lam_arg1.print(); std::printf(", "); this->_mls_lam_arg2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0); _mlsValue::destroy(this->_mls_lam_arg1); _mlsValue::destroy(this->_mls_lam_arg2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lscomp2>()->_mls_lam_arg0.asObject()) && this->_mls_lam_arg1.asObject()->operator==(*other.cast<_mls_Lambda_lscomp2>()->_mls_lam_arg1.asObject()) && this->_mls_lam_arg2.asObject()->operator==(*other.cast<_mls_Lambda_lscomp2>()->_mls_lam_arg2.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0, _mlsValue _mls_lam_arg1, _mlsValue _mls_lam_arg2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lscomp2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0; _mlsVal->_mls_lam_arg1 = _mls_lam_arg1; _mlsVal->_mls_lam_arg2 = _mls_lam_arg2;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_max_: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_max_";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_max_; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_min_: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_min_";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_min_; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_scorePiece: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_scorePiece";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_scorePiece; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_showMove: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_showMove";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_showMove; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_static: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_static";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_static; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_sum: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_sum";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_sum; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_List: public _mlsObject {
  
  constexpr static inline const char *typeName = "List";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_List; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Cons: public _mls_List {
  _mlsValue _mls_head;
  _mlsValue _mls_tail;
  constexpr static inline const char *typeName = "Cons";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_head.print(); std::printf(", "); this->_mls_tail.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_head); _mlsValue::destroy(this->_mls_tail);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_head.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_head.asObject()) && this->_mls_tail.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_tail.asObject()); }
  static _mlsValue create(_mlsValue _mls_head, _mlsValue _mls_tail) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Cons; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_head = _mls_head; _mlsVal->_mls_tail = _mls_tail;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Nil: public _mls_List {
  
  constexpr static inline const char *typeName = "Nil";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Nil; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_OWin: public _mls_Evaluation {
  
  constexpr static inline const char *typeName = "OWin";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_OWin; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Piece: public _mlsObject {
  
  constexpr static inline const char *typeName = "Piece";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Piece; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Empty: public _mls_Piece {
  
  constexpr static inline const char *typeName = "Empty";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Empty; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_O: public _mls_Piece {
  
  constexpr static inline const char *typeName = "O";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_O; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Score: public _mls_Evaluation {
  _mlsValue _mls_i;
  constexpr static inline const char *typeName = "Score";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_i.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_i);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_i.asObject()->operator==(*other.cast<_mls_Score>()->_mls_i.asObject()); }
  static _mlsValue create(_mlsValue _mls_i) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Score; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_i = _mls_i;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Tuple2: public _mlsObject {
  _mlsValue _mls_field0;
  _mlsValue _mls_field1;
  constexpr static inline const char *typeName = "Tuple2";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_field0.print(); std::printf(", "); this->_mls_field1.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_field0); _mlsValue::destroy(this->_mls_field1);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_field0.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field0.asObject()) && this->_mls_field1.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field1.asObject()); }
  static _mlsValue create(_mlsValue _mls_field0, _mlsValue _mls_field1) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Tuple2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_field0 = _mls_field0; _mlsVal->_mls_field1 = _mls_field1;  return _mlsValue(_mlsVal); }
  
};
struct _mls_X: public _mls_Piece {
  
  constexpr static inline const char *typeName = "X";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_X; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_XWin: public _mls_Evaluation {
  
  constexpr static inline const char *typeName = "XWin";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_XWin; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_alternate(_mlsValue _mls_x593, _mlsValue _mls_x595, _mlsValue _mls_x594, _mlsValue _mls_x591) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x591)) {
    auto [_mls_x596, _mls_x597] = _mls_fullBoard_case0_pre();
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x596)) {
      auto _mls_x599 = _mls_fullBoard_caller_post_case0(_mls_x596, _mls_x597);
      _mls_retval = _mls_alternate_caller_post(_mls_x593, _mls_x591, _mls_x599, _mls_x594, _mls_x595);
    } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x596)) {
      auto _mls_x598 = _mls_map_case1();
      _mls_retval = _mls_alternate_caller_post(_mls_x593, _mls_x591, _mlsValue::fromIntLit(1), _mls_x594, _mls_x595);
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x591)) {
    auto _mls_x592 = _mls_fullBoard_case1(_mls_x591);
    _mls_retval = _mls_alternate_caller_post(_mls_x593, _mls_x591, _mls_x592, _mls_x594, _mls_x595);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_alternate_caller_post(_mlsValue _mls_x604, _mlsValue _mls_x601, _mlsValue _mls_x600, _mlsValue _mls_x603, _mlsValue _mls_x602) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_x600, 1)) {
    _mls_retval = _mls_alternate_case0();
  } else {
    _mls_retval = _mls_alternate_default(_mls_x601, _mls_x602, _mls_x603, _mls_x604);
  }
  return _mls_retval;
}
_mlsValue _mls_alternate_caller_post_caller_post(_mlsValue _mls_x605, _mlsValue _mls_x609, _mlsValue _mls_x606, _mlsValue _mls_x607, _mlsValue _mls_x608) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_x605, 1)) {
    _mls_retval = _mls_alternate_caller_post_caller_post_case0();
  } else {
    _mls_retval = _mls_alternate_caller_post_caller_post_default(_mls_x606, _mls_x607, _mls_x608, _mls_x609);
  }
  return _mls_retval;
}
_mlsValue _mls_alternate_caller_post_caller_post_caller_post(_mlsValue _mls_x611, _mlsValue _mls_x612, _mlsValue _mls_x613, _mlsValue _mls_x614) {
  _mlsValue _mls_retval;
  auto _mls_x610 = _mlsValue::create<_mls_Lambda_lambda9>(_mls_x611, _mls_x612, _mls_x613);
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x614)) {
    auto _mls_x616 = _mls_map_case0(_mls_x614, _mls_x610);
    _mls_retval = _mls_alternate_caller_post_caller_post_caller_post_caller_post(_mls_x616, _mls_x613, _mls_x611, _mls_x612, _mls_x614);
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x614)) {
    auto _mls_x615 = _mls_map_case1();
    _mls_retval = _mls_alternate_caller_post_caller_post_caller_post_caller_post(_mls_x615, _mls_x613, _mls_x611, _mls_x612, _mls_x614);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_alternate_caller_post_caller_post_caller_post_caller_post(_mlsValue _mls_x619, _mlsValue _mls_x624, _mlsValue _mls_x617, _mlsValue _mls_x623, _mlsValue _mls_x618) {
  _mlsValue _mls_retval;
  auto _mls_x620 = _mls_best(_mls_x617, _mls_x618, _mls_x619);
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x620)) {
    auto _mls_x621 = _mlsValue::cast<_mls_Tuple2>(_mls_x620)->_mls_field0;
    auto _mls_x622 = _mlsValue::cast<_mls_Tuple2>(_mls_x620)->_mls_field1;
    auto _mls_x625 = _mls_alternate(_mls_x623, _mls_x624, _mls_x617, _mls_x621);
    auto _mls_x626 = _mlsValue::create<_mls_Tuple2>(_mls_x621, _mls_x622);
    auto _mls_x627 = _mlsValue::create<_mls_Cons>(_mls_x626, _mls_x625);
    _mls_retval = _mls_x627;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_alternate_caller_post_caller_post_case0() {
  _mlsValue _mls_retval;
  auto _mls_x628 = _mlsValue::create<_mls_Nil>();
  _mls_retval = _mls_x628;
  return _mls_retval;
}
_mlsValue _mls_alternate_caller_post_caller_post_default(_mlsValue _mls_x629, _mlsValue _mls_x631, _mlsValue _mls_x633, _mlsValue _mls_x632) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_X>(_mls_x629)) {
    auto _mls_x634 = _mls_opposite_case0();
    _mls_retval = _mls_alternate_caller_post_caller_post_default_caller_post(_mls_x631, _mls_x629, _mls_x632, _mls_x633, _mls_x634);
  } else if (_mlsValue::isValueOf<_mls_O>(_mls_x629)) {
    auto _mls_x630 = _mls_opposite_case1();
    _mls_retval = _mls_alternate_caller_post_caller_post_default_caller_post(_mls_x631, _mls_x629, _mls_x632, _mls_x633, _mls_x630);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_alternate_caller_post_caller_post_default_caller_post(_mlsValue _mls_x636, _mlsValue _mls_x635, _mlsValue _mls_x642, _mlsValue _mls_x640, _mlsValue _mls_x641) {
  _mlsValue _mls_retval;
  auto [_mls_x637, _mls_x638] = _mls_newPositions_pre(_mls_x635, _mls_x636);
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x637)) {
    auto _mls_x643 = _mls_newPositions_case0(_mls_x637, _mls_x638);
    _mls_retval = _mls_alternate_caller_post_caller_post_caller_post(_mls_x640, _mls_x641, _mls_x642, _mls_x643);
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x637)) {
    auto _mls_x639 = _mls_newPositions_case1();
    _mls_retval = _mls_alternate_caller_post_caller_post_caller_post(_mls_x640, _mls_x641, _mls_x642, _mls_x639);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_alternate_caller_post_case0() {
  _mlsValue _mls_retval;
  auto _mls_x644 = _mlsValue::create<_mls_Nil>();
  _mls_retval = _mls_x644;
  return _mls_retval;
}
_mlsValue _mls_alternate_caller_post_default(_mlsValue _mls_x645, _mlsValue _mls_x649, _mlsValue _mls_x647, _mlsValue _mls_x648) {
  _mlsValue _mls_retval;
  auto _mls_x646 = _mls_static1(_mls_x645);
  if (_mlsValue::isValueOf<_mls_XWin>(_mls_x646)) {
    _mls_retval = _mls_alternate_caller_post_caller_post_default(_mls_x647, _mls_x645, _mls_x648, _mls_x649);
  } else if (_mlsValue::isValueOf<_mls_OWin>(_mls_x646)) {
    _mls_retval = _mls_alternate_caller_post_caller_post_case0();
  } else if (_mlsValue::isValueOf<_mls_Score>(_mls_x646)) {
    _mls_retval = _mls_alternate_caller_post_caller_post(_mlsValue::fromIntLit(0), _mls_x649, _mls_x647, _mls_x645, _mls_x648);
  } else {
    _mls_retval = _mls_alternate_caller_post_caller_post_default(_mls_x647, _mls_x645, _mls_x648, _mls_x649);
  }
  return _mls_retval;
}
_mlsValue _mls_alternate_case0() {
  _mlsValue _mls_retval;
  auto _mls_x650 = _mlsValue::create<_mls_Nil>();
  _mls_retval = _mls_x650;
  return _mls_retval;
}
_mlsValue _mls_alternate_default(_mlsValue _mls_x651, _mlsValue _mls_x655, _mlsValue _mls_x653, _mlsValue _mls_x654) {
  _mlsValue _mls_retval;
  auto _mls_x652 = _mls_static1(_mls_x651);
  if (_mlsValue::isValueOf<_mls_XWin>(_mls_x652)) {
    _mls_retval = _mls_alternate_caller_post_case0();
  } else if (_mlsValue::isValueOf<_mls_OWin>(_mls_x652)) {
    _mls_retval = _mls_alternate_caller_post_default(_mls_x651, _mls_x653, _mls_x654, _mls_x655);
  } else if (_mlsValue::isValueOf<_mls_Score>(_mls_x652)) {
    _mls_retval = _mls_alternate_caller_post_default(_mls_x651, _mls_x653, _mls_x654, _mls_x655);
  } else {
    _mls_retval = _mls_alternate_caller_post_default(_mls_x651, _mls_x653, _mls_x654, _mls_x655);
  }
  return _mls_retval;
}
_mlsValue _mls_andd(_mlsValue _mls_x656) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x656)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x656)) {
    auto _mls_x657 = _mlsValue::cast<_mls_Cons>(_mls_x656)->_mls_head;
    auto _mls_x658 = _mlsValue::cast<_mls_Cons>(_mls_x656)->_mls_tail;
    _mls_retval = _mls_andd_case1_sr_post(_mls_x658, _mls_x657);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_andd_case1_sr_post(_mlsValue _mls_x659, _mlsValue _mls_x662) {
  _mlsValue _mls_retval;
  auto _mls_x660 = _mls_andd(_mls_x659);
  auto _mls_x661 = (_mls_x662 && _mls_x660);
  _mls_retval = _mls_x661;
  return _mls_retval;
}
_mlsValue _mls_append(_mlsValue _mls_xs, _mlsValue _mls_ys) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs)) {
    _mls_retval = _mls_ys;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs)) {
    auto _mls_x109 = _mlsValue::cast<_mls_Cons>(_mls_xs)->_mls_head;
    auto _mls_x110 = _mlsValue::cast<_mls_Cons>(_mls_xs)->_mls_tail;
    auto _mls_x111 = _mls_append(_mls_x110, _mls_ys);
    auto _mls_x112 = _mlsValue::create<_mls_Cons>(_mls_x109, _mls_x111);
    _mls_retval = _mls_x112;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_best(_mlsValue _mls_f1, _mlsValue _mls_bs, _mlsValue _mls_ss) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_bs)) {
    auto _mls_x113 = _mlsValue::cast<_mls_Cons>(_mls_bs)->_mls_head;
    auto _mls_x114 = _mlsValue::cast<_mls_Cons>(_mls_bs)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_ss)) {
      auto _mls_x115 = _mlsValue::cast<_mls_Cons>(_mls_ss)->_mls_head;
      auto _mls_x116 = _mlsValue::cast<_mls_Cons>(_mls_ss)->_mls_tail;
      auto _mls_x117 = _mlsValue::create<_mls_Lambda_best_>(_mls_f1);
      auto _mls_x118 = _mlsMethodCall<_mls_Callable>(_mls_x117)->_mls_apply4(_mls_x113, _mls_x115, _mls_x114, _mls_x116);
      _mls_retval = _mls_x118;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_bestMove(_mlsValue _mls_p, _mlsValue _mls_f2, _mlsValue _mls_g1, _mlsValue _mls_b1) {
  _mlsValue _mls_retval;
  auto _mls_x119 = _mls_searchTree(_mls_p, _mls_b1);
  auto _mls_x120 = _mlsValue::create<_mls_Lambda_static>();
  if (_mlsValue::isValueOf<_mls_Branch>(_mls_x119)) {
    auto _mls_x663 = _mlsValue::cast<_mls_Branch>(_mls_x119)->_mls_a;
    auto _mls_x664 = _mlsValue::cast<_mls_Branch>(_mls_x119)->_mls_cs;
    auto _mls_x665 = _mls_mapTree_case0_sr_post(_mls_x120, _mls_x663, _mls_x664);
    _mls_retval = _mls_bestMove_caller_post_case0(_mls_x665, _mls_f2, _mls_g1);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_bestMove_caller_post_case0(_mlsValue _mls_x666, _mlsValue _mls_x669, _mlsValue _mls_x668) {
  _mlsValue _mls_retval;
  auto _mls_x667 = _mls_cropTree_case0(_mls_x666);
  auto _mls_x670 = _mls_mise_case0(_mls_x667, _mls_x668, _mls_x669);
  _mls_retval = _mls_x670;
  return _mls_retval;
}
_mlsValue _mls_concat(_mlsValue _mls_x671) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x671)) {
    _mls_retval = _mls_concat_case0();
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x671)) {
    auto _mls_x672 = _mlsValue::cast<_mls_Cons>(_mls_x671)->_mls_head;
    auto _mls_x673 = _mlsValue::cast<_mls_Cons>(_mls_x671)->_mls_tail;
    _mls_retval = _mls_concat_case1_sr_post(_mls_x673, _mls_x672);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_concat_case0() {
  _mlsValue _mls_retval;
  auto _mls_x674 = _mlsValue::create<_mls_Nil>();
  _mls_retval = _mls_x674;
  return _mls_retval;
}
_mlsValue _mls_concat_case1(_mlsValue _mls_x676) {
  _mlsValue _mls_retval;
  auto _mls_x675 = _mlsValue::cast<_mls_Cons>(_mls_x676)->_mls_head;
  auto _mls_x677 = _mlsValue::cast<_mls_Cons>(_mls_x676)->_mls_tail;
  _mls_retval = _mls_concat_case1_sr_post(_mls_x677, _mls_x675);
  return _mls_retval;
}
_mlsValue _mls_concat_case1_sr_post(_mlsValue _mls_x678, _mlsValue _mls_x680) {
  _mlsValue _mls_retval;
  auto _mls_x679 = _mls_concat(_mls_x678);
  auto _mls_x681 = _mls_append(_mls_x680, _mls_x679);
  _mls_retval = _mls_x681;
  return _mls_retval;
}
_mlsValue _mls_cropTree(_mlsValue _mls_x682) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Branch>(_mls_x682)) {
    auto _mls_x683 = _mlsValue::cast<_mls_Branch>(_mls_x682)->_mls_a;
    auto _mls_x684 = _mlsValue::cast<_mls_Branch>(_mls_x682)->_mls_cs;
    _mls_retval = _mls_cropTree_case0_sr_post(_mls_x684, _mls_x683);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_cropTree_case0(_mlsValue _mls_x686) {
  _mlsValue _mls_retval;
  auto _mls_x685 = _mlsValue::cast<_mls_Branch>(_mls_x686)->_mls_a;
  auto _mls_x687 = _mlsValue::cast<_mls_Branch>(_mls_x686)->_mls_cs;
  _mls_retval = _mls_cropTree_case0_sr_post(_mls_x687, _mls_x685);
  return _mls_retval;
}
_mlsValue _mls_cropTree_case0_sr_post(_mlsValue _mls_x688, _mlsValue _mls_x689) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x688)) {
    auto _mls_x697 = _mlsValue::create<_mls_Nil>();
    auto _mls_x698 = _mlsValue::create<_mls_Branch>(_mls_x689, _mls_x697);
    _mls_retval = _mls_x698;
  } else {
    if (_mlsValue::isValueOf<_mls_Score>(_mls_x689)) {
      auto _mls_x692 = _mlsValue::cast<_mls_Score>(_mls_x689)->_mls_i;
      auto _mls_x693 = _mlsValue::create<_mls_Score>(_mls_x692);
      auto _mls_x694 = _mlsValue::create<_mls_Lambda_cropTree>();
      if (_mlsValue::isValueOf<_mls_Cons>(_mls_x688)) {
        auto _mls_x696 = _mls_map_case0(_mls_x688, _mls_x694);
        _mls_retval = _mls_cropTree_case0_sr_post_caller_post(_mls_x693, _mls_x696);
      } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x688)) {
        auto _mls_x695 = _mls_map_case1();
        _mls_retval = _mls_cropTree_case0_sr_post_caller_post(_mls_x693, _mls_x695);
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      auto _mls_x690 = _mlsValue::create<_mls_Nil>();
      auto _mls_x691 = _mlsValue::create<_mls_Branch>(_mls_x689, _mls_x690);
      _mls_retval = _mls_x691;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_cropTree_case0_sr_post_caller_post(_mlsValue _mls_x700, _mlsValue _mls_x701) {
  _mlsValue _mls_retval;
  auto _mls_x699 = _mlsValue::create<_mls_Branch>(_mls_x700, _mls_x701);
  _mls_retval = _mls_x699;
  return _mls_retval;
}
_mlsValue _mls_empty_(_mlsValue _mls_x152, _mlsValue _mls_r) {
  _mlsValue _mls_retval;
  auto _mls_x151 = (_mls_x152 == _mlsValue::fromIntLit(1));
  if (_mlsValue::isIntLit(_mls_x151, 1)) {
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_r)) {
      auto _mls_x174 = _mlsValue::cast<_mls_Cons>(_mls_r)->_mls_head;
      auto _mls_x175 = _mlsValue::cast<_mls_Cons>(_mls_r)->_mls_tail;
      if (_mlsValue::isValueOf<_mls_Empty>(_mls_x174)) {
        if (_mlsValue::isValueOf<_mls_Cons>(_mls_x175)) {
          auto _mls_x194 = _mlsValue::cast<_mls_Cons>(_mls_x175)->_mls_head;
          auto _mls_x195 = _mlsValue::cast<_mls_Cons>(_mls_x175)->_mls_tail;
          if (_mlsValue::isValueOf<_mls_Cons>(_mls_x195)) {
            auto _mls_x200 = _mlsValue::cast<_mls_Cons>(_mls_x195)->_mls_head;
            auto _mls_x201 = _mlsValue::cast<_mls_Cons>(_mls_x195)->_mls_tail;
            if (_mlsValue::isValueOf<_mls_Nil>(_mls_x201)) {
              _mls_retval = _mlsValue::fromIntLit(1);
            } else {
              auto _mls_x202 = (_mls_x152 == _mlsValue::fromIntLit(2));
              if (_mlsValue::isIntLit(_mls_x202, 1)) {
                if (_mlsValue::isValueOf<_mls_Empty>(_mls_x194)) {
                  auto _mls_x205 = (_mls_x152 == _mlsValue::fromIntLit(3));
                  if (_mlsValue::isIntLit(_mls_x205, 1)) {
                    if (_mlsValue::isValueOf<_mls_Empty>(_mls_x200)) {
                      _mls_retval = _mlsValue::fromIntLit(0);
                    } else {
                      _mls_retval = _mlsValue::fromIntLit(0);
                    }
                  } else {
                    _mls_retval = _mlsValue::fromIntLit(0);
                  }
                } else {
                  auto _mls_x204 = (_mls_x152 == _mlsValue::fromIntLit(3));
                  if (_mlsValue::isIntLit(_mls_x204, 1)) {
                    if (_mlsValue::isValueOf<_mls_Empty>(_mls_x200)) {
                      _mls_retval = _mlsValue::fromIntLit(0);
                    } else {
                      _mls_retval = _mlsValue::fromIntLit(0);
                    }
                  } else {
                    _mls_retval = _mlsValue::fromIntLit(0);
                  }
                }
              } else {
                auto _mls_x203 = (_mls_x152 == _mlsValue::fromIntLit(3));
                if (_mlsValue::isIntLit(_mls_x203, 1)) {
                  if (_mlsValue::isValueOf<_mls_Empty>(_mls_x200)) {
                    _mls_retval = _mlsValue::fromIntLit(0);
                  } else {
                    _mls_retval = _mlsValue::fromIntLit(0);
                  }
                } else {
                  _mls_retval = _mlsValue::fromIntLit(0);
                }
              }
            }
          } else {
            auto _mls_x196 = (_mls_x152 == _mlsValue::fromIntLit(2));
            if (_mlsValue::isIntLit(_mls_x196, 1)) {
              if (_mlsValue::isValueOf<_mls_Empty>(_mls_x194)) {
                auto _mls_x199 = (_mls_x152 == _mlsValue::fromIntLit(3));
                if (_mlsValue::isIntLit(_mls_x199, 1)) {
                  _mls_retval = _mlsValue::fromIntLit(0);
                } else {
                  _mls_retval = _mlsValue::fromIntLit(0);
                }
              } else {
                auto _mls_x198 = (_mls_x152 == _mlsValue::fromIntLit(3));
                if (_mlsValue::isIntLit(_mls_x198, 1)) {
                  _mls_retval = _mlsValue::fromIntLit(0);
                } else {
                  _mls_retval = _mlsValue::fromIntLit(0);
                }
              }
            } else {
              auto _mls_x197 = (_mls_x152 == _mlsValue::fromIntLit(3));
              if (_mlsValue::isIntLit(_mls_x197, 1)) {
                _mls_retval = _mlsValue::fromIntLit(0);
              } else {
                _mls_retval = _mlsValue::fromIntLit(0);
              }
            }
          }
        } else {
          auto _mls_x191 = (_mls_x152 == _mlsValue::fromIntLit(2));
          if (_mlsValue::isIntLit(_mls_x191, 1)) {
            auto _mls_x193 = (_mls_x152 == _mlsValue::fromIntLit(3));
            if (_mlsValue::isIntLit(_mls_x193, 1)) {
              _mls_retval = _mlsValue::fromIntLit(0);
            } else {
              _mls_retval = _mlsValue::fromIntLit(0);
            }
          } else {
            auto _mls_x192 = (_mls_x152 == _mlsValue::fromIntLit(3));
            if (_mlsValue::isIntLit(_mls_x192, 1)) {
              _mls_retval = _mlsValue::fromIntLit(0);
            } else {
              _mls_retval = _mlsValue::fromIntLit(0);
            }
          }
        }
      } else {
        auto _mls_x176 = (_mls_x152 == _mlsValue::fromIntLit(2));
        if (_mlsValue::isIntLit(_mls_x176, 1)) {
          if (_mlsValue::isValueOf<_mls_Cons>(_mls_x175)) {
            auto _mls_x182 = _mlsValue::cast<_mls_Cons>(_mls_x175)->_mls_head;
            auto _mls_x183 = _mlsValue::cast<_mls_Cons>(_mls_x175)->_mls_tail;
            if (_mlsValue::isValueOf<_mls_Empty>(_mls_x182)) {
              if (_mlsValue::isValueOf<_mls_Cons>(_mls_x183)) {
                auto _mls_x188 = _mlsValue::cast<_mls_Cons>(_mls_x183)->_mls_head;
                auto _mls_x189 = _mlsValue::cast<_mls_Cons>(_mls_x183)->_mls_tail;
                if (_mlsValue::isValueOf<_mls_Nil>(_mls_x189)) {
                  _mls_retval = _mlsValue::fromIntLit(1);
                } else {
                  auto _mls_x190 = (_mls_x152 == _mlsValue::fromIntLit(3));
                  if (_mlsValue::isIntLit(_mls_x190, 1)) {
                    if (_mlsValue::isValueOf<_mls_Empty>(_mls_x188)) {
                      _mls_retval = _mlsValue::fromIntLit(0);
                    } else {
                      _mls_retval = _mlsValue::fromIntLit(0);
                    }
                  } else {
                    _mls_retval = _mlsValue::fromIntLit(0);
                  }
                }
              } else {
                auto _mls_x187 = (_mls_x152 == _mlsValue::fromIntLit(3));
                if (_mlsValue::isIntLit(_mls_x187, 1)) {
                  _mls_retval = _mlsValue::fromIntLit(0);
                } else {
                  _mls_retval = _mlsValue::fromIntLit(0);
                }
              }
            } else {
              auto _mls_x184 = (_mls_x152 == _mlsValue::fromIntLit(3));
              if (_mlsValue::isIntLit(_mls_x184, 1)) {
                if (_mlsValue::isValueOf<_mls_Cons>(_mls_x183)) {
                  auto _mls_x185 = _mlsValue::cast<_mls_Cons>(_mls_x183)->_mls_head;
                  auto _mls_x186 = _mlsValue::cast<_mls_Cons>(_mls_x183)->_mls_tail;
                  if (_mlsValue::isValueOf<_mls_Empty>(_mls_x185)) {
                    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x186)) {
                      _mls_retval = _mlsValue::fromIntLit(1);
                    } else {
                      _mls_retval = _mlsValue::fromIntLit(0);
                    }
                  } else {
                    _mls_retval = _mlsValue::fromIntLit(0);
                  }
                } else {
                  _mls_retval = _mlsValue::fromIntLit(0);
                }
              } else {
                _mls_retval = _mlsValue::fromIntLit(0);
              }
            }
          } else {
            auto _mls_x181 = (_mls_x152 == _mlsValue::fromIntLit(3));
            if (_mlsValue::isIntLit(_mls_x181, 1)) {
              _mls_retval = _mlsValue::fromIntLit(0);
            } else {
              _mls_retval = _mlsValue::fromIntLit(0);
            }
          }
        } else {
          auto _mls_x177 = (_mls_x152 == _mlsValue::fromIntLit(3));
          if (_mlsValue::isIntLit(_mls_x177, 1)) {
            if (_mlsValue::isValueOf<_mls_Cons>(_mls_x175)) {
              auto _mls_x178 = _mlsValue::cast<_mls_Cons>(_mls_x175)->_mls_tail;
              if (_mlsValue::isValueOf<_mls_Cons>(_mls_x178)) {
                auto _mls_x179 = _mlsValue::cast<_mls_Cons>(_mls_x178)->_mls_head;
                auto _mls_x180 = _mlsValue::cast<_mls_Cons>(_mls_x178)->_mls_tail;
                if (_mlsValue::isValueOf<_mls_Empty>(_mls_x179)) {
                  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x180)) {
                    _mls_retval = _mlsValue::fromIntLit(1);
                  } else {
                    _mls_retval = _mlsValue::fromIntLit(0);
                  }
                } else {
                  _mls_retval = _mlsValue::fromIntLit(0);
                }
              } else {
                _mls_retval = _mlsValue::fromIntLit(0);
              }
            } else {
              _mls_retval = _mlsValue::fromIntLit(0);
            }
          } else {
            _mls_retval = _mlsValue::fromIntLit(0);
          }
        }
      }
    } else {
      auto _mls_x171 = (_mls_x152 == _mlsValue::fromIntLit(2));
      if (_mlsValue::isIntLit(_mls_x171, 1)) {
        auto _mls_x173 = (_mls_x152 == _mlsValue::fromIntLit(3));
        if (_mlsValue::isIntLit(_mls_x173, 1)) {
          _mls_retval = _mlsValue::fromIntLit(0);
        } else {
          _mls_retval = _mlsValue::fromIntLit(0);
        }
      } else {
        auto _mls_x172 = (_mls_x152 == _mlsValue::fromIntLit(3));
        if (_mlsValue::isIntLit(_mls_x172, 1)) {
          _mls_retval = _mlsValue::fromIntLit(0);
        } else {
          _mls_retval = _mlsValue::fromIntLit(0);
        }
      }
    }
  } else {
    auto _mls_x153 = (_mls_x152 == _mlsValue::fromIntLit(2));
    if (_mlsValue::isIntLit(_mls_x153, 1)) {
      if (_mlsValue::isValueOf<_mls_Cons>(_mls_r)) {
        auto _mls_x160 = _mlsValue::cast<_mls_Cons>(_mls_r)->_mls_tail;
        if (_mlsValue::isValueOf<_mls_Cons>(_mls_x160)) {
          auto _mls_x162 = _mlsValue::cast<_mls_Cons>(_mls_x160)->_mls_head;
          auto _mls_x163 = _mlsValue::cast<_mls_Cons>(_mls_x160)->_mls_tail;
          if (_mlsValue::isValueOf<_mls_Empty>(_mls_x162)) {
            if (_mlsValue::isValueOf<_mls_Cons>(_mls_x163)) {
              auto _mls_x168 = _mlsValue::cast<_mls_Cons>(_mls_x163)->_mls_head;
              auto _mls_x169 = _mlsValue::cast<_mls_Cons>(_mls_x163)->_mls_tail;
              if (_mlsValue::isValueOf<_mls_Nil>(_mls_x169)) {
                _mls_retval = _mlsValue::fromIntLit(1);
              } else {
                auto _mls_x170 = (_mls_x152 == _mlsValue::fromIntLit(3));
                if (_mlsValue::isIntLit(_mls_x170, 1)) {
                  if (_mlsValue::isValueOf<_mls_Empty>(_mls_x168)) {
                    _mls_retval = _mlsValue::fromIntLit(0);
                  } else {
                    _mls_retval = _mlsValue::fromIntLit(0);
                  }
                } else {
                  _mls_retval = _mlsValue::fromIntLit(0);
                }
              }
            } else {
              auto _mls_x167 = (_mls_x152 == _mlsValue::fromIntLit(3));
              if (_mlsValue::isIntLit(_mls_x167, 1)) {
                _mls_retval = _mlsValue::fromIntLit(0);
              } else {
                _mls_retval = _mlsValue::fromIntLit(0);
              }
            }
          } else {
            auto _mls_x164 = (_mls_x152 == _mlsValue::fromIntLit(3));
            if (_mlsValue::isIntLit(_mls_x164, 1)) {
              if (_mlsValue::isValueOf<_mls_Cons>(_mls_x163)) {
                auto _mls_x165 = _mlsValue::cast<_mls_Cons>(_mls_x163)->_mls_head;
                auto _mls_x166 = _mlsValue::cast<_mls_Cons>(_mls_x163)->_mls_tail;
                if (_mlsValue::isValueOf<_mls_Empty>(_mls_x165)) {
                  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x166)) {
                    _mls_retval = _mlsValue::fromIntLit(1);
                  } else {
                    _mls_retval = _mlsValue::fromIntLit(0);
                  }
                } else {
                  _mls_retval = _mlsValue::fromIntLit(0);
                }
              } else {
                _mls_retval = _mlsValue::fromIntLit(0);
              }
            } else {
              _mls_retval = _mlsValue::fromIntLit(0);
            }
          }
        } else {
          auto _mls_x161 = (_mls_x152 == _mlsValue::fromIntLit(3));
          if (_mlsValue::isIntLit(_mls_x161, 1)) {
            _mls_retval = _mlsValue::fromIntLit(0);
          } else {
            _mls_retval = _mlsValue::fromIntLit(0);
          }
        }
      } else {
        auto _mls_x159 = (_mls_x152 == _mlsValue::fromIntLit(3));
        if (_mlsValue::isIntLit(_mls_x159, 1)) {
          _mls_retval = _mlsValue::fromIntLit(0);
        } else {
          _mls_retval = _mlsValue::fromIntLit(0);
        }
      }
    } else {
      auto _mls_x154 = (_mls_x152 == _mlsValue::fromIntLit(3));
      if (_mlsValue::isIntLit(_mls_x154, 1)) {
        if (_mlsValue::isValueOf<_mls_Cons>(_mls_r)) {
          auto _mls_x155 = _mlsValue::cast<_mls_Cons>(_mls_r)->_mls_tail;
          if (_mlsValue::isValueOf<_mls_Cons>(_mls_x155)) {
            auto _mls_x156 = _mlsValue::cast<_mls_Cons>(_mls_x155)->_mls_tail;
            if (_mlsValue::isValueOf<_mls_Cons>(_mls_x156)) {
              auto _mls_x157 = _mlsValue::cast<_mls_Cons>(_mls_x156)->_mls_head;
              auto _mls_x158 = _mlsValue::cast<_mls_Cons>(_mls_x156)->_mls_tail;
              if (_mlsValue::isValueOf<_mls_Empty>(_mls_x157)) {
                if (_mlsValue::isValueOf<_mls_Nil>(_mls_x158)) {
                  _mls_retval = _mlsValue::fromIntLit(1);
                } else {
                  _mls_retval = _mlsValue::fromIntLit(0);
                }
              } else {
                _mls_retval = _mlsValue::fromIntLit(0);
              }
            } else {
              _mls_retval = _mlsValue::fromIntLit(0);
            }
          } else {
            _mls_retval = _mlsValue::fromIntLit(0);
          }
        } else {
          _mls_retval = _mlsValue::fromIntLit(0);
        }
      } else {
        _mls_retval = _mlsValue::fromIntLit(0);
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_empty_case0_sr_post_case0_sr_post(_mlsValue _mls_x702, _mlsValue _mls_x705, _mlsValue _mls_x711, _mlsValue _mls_x709) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x702)) {
    auto _mls_x703 = _mlsValue::cast<_mls_Cons>(_mls_x702)->_mls_head;
    auto _mls_x704 = _mlsValue::cast<_mls_Cons>(_mls_x702)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x704)) {
      if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x705)) {
        auto _mls_x706 = _mlsValue::cast<_mls_Tuple2>(_mls_x705)->_mls_field0;
        auto _mls_x707 = _mlsValue::cast<_mls_Tuple2>(_mls_x705)->_mls_field1;
        if (_mlsValue::isIntLit(_mls_x706, 1)) {
          auto _mls_x712 = _mls_empty_(_mls_x707, _mls_x711);
          _mls_retval = _mls_x712;
        } else if (_mlsValue::isIntLit(_mls_x706, 2)) {
          auto _mls_x710 = _mls_empty_(_mls_x707, _mls_x709);
          _mls_retval = _mls_x710;
        } else if (_mlsValue::isIntLit(_mls_x706, 3)) {
          auto _mls_x708 = _mls_empty_(_mls_x707, _mls_x703);
          _mls_retval = _mls_x708;
        } else {
          _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x206 = _mls_run(_mlsValue::fromIntLit(10));
  _mls_retval = _mls_x206;
  return _mls_retval;
}
_mlsValue _mls_eqPiece(_mlsValue _mls_p1, _mlsValue _mls_p2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_X>(_mls_p1)) {
    if (_mlsValue::isValueOf<_mls_X>(_mls_p2)) {
      _mls_retval = _mlsValue::fromIntLit(1);
    } else {
      _mls_retval = _mlsValue::fromIntLit(0);
    }
  } else if (_mlsValue::isValueOf<_mls_O>(_mls_p1)) {
    if (_mlsValue::isValueOf<_mls_O>(_mls_p2)) {
      _mls_retval = _mlsValue::fromIntLit(1);
    } else {
      _mls_retval = _mlsValue::fromIntLit(0);
    }
  } else if (_mlsValue::isValueOf<_mls_Empty>(_mls_p1)) {
    if (_mlsValue::isValueOf<_mls_Empty>(_mls_p2)) {
      _mls_retval = _mlsValue::fromIntLit(1);
    } else {
      _mls_retval = _mlsValue::fromIntLit(0);
    }
  } else {
    _mls_retval = _mlsValue::fromIntLit(0);
  }
  return _mls_retval;
}
_mlsValue _mls_eval1(_mlsValue _mls_x208) {
  _mlsValue _mls_retval;
  auto _mls_x207 = (_mls_x208 == _mlsValue::fromIntLit(3));
  if (_mlsValue::isIntLit(_mls_x207, 1)) {
    auto _mls_x213 = _mlsValue::create<_mls_XWin>();
    _mls_retval = _mls_x213;
  } else {
    auto _mls_x209 = (-_mlsValue::fromIntLit(3));
    auto _mls_x210 = (_mls_x208 == _mls_x209);
    if (_mlsValue::isIntLit(_mls_x210, 1)) {
      auto _mls_x212 = _mlsValue::create<_mls_OWin>();
      _mls_retval = _mls_x212;
    } else {
      auto _mls_x211 = _mlsValue::create<_mls_Score>(_mls_x208);
      _mls_retval = _mls_x211;
    }
  }
  return _mls_retval;
}
_mlsValue _mls_evaluationEq(_mlsValue _mls_x713, _mlsValue _mls_x715) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_XWin>(_mls_x713)) {
    _mls_retval = _mls_evaluationEq_case0(_mls_x715);
  } else if (_mlsValue::isValueOf<_mls_OWin>(_mls_x713)) {
    _mls_retval = _mls_evaluationEq_case1(_mls_x715);
  } else if (_mlsValue::isValueOf<_mls_Score>(_mls_x713)) {
    auto _mls_x714 = _mlsValue::cast<_mls_Score>(_mls_x713)->_mls_i;
    _mls_retval = _mls_evaluationEq_case2_sr_post(_mls_x715, _mls_x714);
  } else {
    _mls_retval = _mlsValue::fromIntLit(0);
  }
  return _mls_retval;
}
_mlsValue _mls_evaluationEq_case0(_mlsValue _mls_x716) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_XWin>(_mls_x716)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else {
    _mls_retval = _mlsValue::fromIntLit(0);
  }
  return _mls_retval;
}
_mlsValue _mls_evaluationEq_case1(_mlsValue _mls_x717) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_OWin>(_mls_x717)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else {
    _mls_retval = _mlsValue::fromIntLit(0);
  }
  return _mls_retval;
}
_mlsValue _mls_evaluationEq_case2_sr_post(_mlsValue _mls_x718, _mlsValue _mls_x719) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Score>(_mls_x718)) {
    _mls_retval = _mls_evaluationEq_case2_sr_post_case0(_mls_x718, _mls_x719);
  } else {
    _mls_retval = _mlsValue::fromIntLit(0);
  }
  return _mls_retval;
}
_mlsValue _mls_evaluationEq_case2_sr_post_case0(_mlsValue _mls_x721, _mlsValue _mls_x723) {
  _mlsValue _mls_retval;
  auto _mls_x720 = _mlsValue::cast<_mls_Score>(_mls_x721)->_mls_i;
  auto _mls_x722 = (_mls_x723 == _mls_x720);
  if (_mlsValue::isIntLit(_mls_x722, 1)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else {
    _mls_retval = _mlsValue::fromIntLit(0);
  }
  return _mls_retval;
}
_mlsValue _mls_foldr(_mlsValue _mls_x727, _mlsValue _mls_x728, _mlsValue _mls_x724) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x724)) {
    _mls_retval = _mls_x728;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x724)) {
    auto _mls_x725 = _mlsValue::cast<_mls_Cons>(_mls_x724)->_mls_head;
    auto _mls_x726 = _mlsValue::cast<_mls_Cons>(_mls_x724)->_mls_tail;
    _mls_retval = _mls_foldr_case1_sr_post(_mls_x727, _mls_x728, _mls_x726, _mls_x725);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_foldr_case1(_mlsValue _mls_x730, _mlsValue _mls_x732, _mlsValue _mls_x733) {
  _mlsValue _mls_retval;
  auto _mls_x729 = _mlsValue::cast<_mls_Cons>(_mls_x730)->_mls_head;
  auto _mls_x731 = _mlsValue::cast<_mls_Cons>(_mls_x730)->_mls_tail;
  _mls_retval = _mls_foldr_case1_sr_post(_mls_x732, _mls_x733, _mls_x731, _mls_x729);
  return _mls_retval;
}
_mlsValue _mls_foldr_case1_sr_post(_mlsValue _mls_x734, _mlsValue _mls_x735, _mlsValue _mls_x736, _mlsValue _mls_x738) {
  _mlsValue _mls_retval;
  auto _mls_x737 = _mls_foldr(_mls_x734, _mls_x735, _mls_x736);
  auto _mls_x739 = _mlsMethodCall<_mls_Callable>(_mls_x734)->_mls_apply2(_mls_x738, _mls_x737);
  _mls_retval = _mls_x739;
  return _mls_retval;
}
_mlsValue _mls_fullBoard_caller_post(_mlsValue _mls_x740) {
  _mlsValue _mls_retval;
  auto [_mls_x741, _mls_x742] = _mls_fullBoard_caller_post_pre(_mls_x740);
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x741)) {
    auto _mls_x744 = _mlsValue::cast<_mls_Cons>(_mls_x741)->_mls_head;
    auto _mls_x745 = _mlsValue::cast<_mls_Cons>(_mls_x741)->_mls_tail;
    _mls_retval = _mls_fullBoard_caller_post_case0_sr_post(_mls_x742, _mls_x744, _mls_x745);
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x741)) {
    auto _mls_x743 = _mls_map_case1();
    _mls_retval = _mlsValue::fromIntLit(1);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_fullBoard_caller_post_case0(_mlsValue _mls_x747, _mlsValue _mls_x749) {
  _mlsValue _mls_retval;
  auto _mls_x746 = _mlsValue::cast<_mls_Cons>(_mls_x747)->_mls_head;
  auto _mls_x748 = _mlsValue::cast<_mls_Cons>(_mls_x747)->_mls_tail;
  _mls_retval = _mls_fullBoard_caller_post_case0_sr_post(_mls_x749, _mls_x746, _mls_x748);
  return _mls_retval;
}
_mlsValue _mls_fullBoard_caller_post_case0_sr_post(_mlsValue _mls_x750, _mlsValue _mls_x751, _mlsValue _mls_x752) {
  _mlsValue _mls_retval;
  auto _mls_x753 = _mls_map_case0_sr_post(_mls_x750, _mls_x751, _mls_x752);
  auto _mls_x754 = _mls_andd(_mls_x753);
  _mls_retval = _mls_x754;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue> _mls_fullBoard_caller_post_pre(_mlsValue _mls_x756) {
  std::tuple<_mlsValue, _mlsValue> _mls_retval;
  auto _mls_x755 = _mlsValue::create<_mls_Lambda_lambda1>();
  _mls_retval = std::make_tuple(_mls_x756, _mls_x755);
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue> _mls_fullBoard_case0_pre() {
  std::tuple<_mlsValue, _mlsValue> _mls_retval;
  auto _mls_x757 = _mls_concat_case0();
  auto [_mls_x758, _mls_x759] = _mls_fullBoard_caller_post_pre(_mls_x757);
  _mls_retval = std::make_tuple(_mls_x758, _mls_x759);
  return _mls_retval;
}
_mlsValue _mls_fullBoard_case1(_mlsValue _mls_x760) {
  _mlsValue _mls_retval;
  auto _mls_x761 = _mls_concat_case1(_mls_x760);
  _mls_retval = _mls_fullBoard_caller_post(_mls_x761);
  return _mls_retval;
}
_mlsValue _mls_go(_mlsValue _mls_xs2, _mlsValue _mls_a1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs2)) {
    _mls_retval = _mls_a1;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs2)) {
    auto _mls_x226 = _mlsValue::cast<_mls_Cons>(_mls_xs2)->_mls_head;
    auto _mls_x227 = _mlsValue::cast<_mls_Cons>(_mls_xs2)->_mls_tail;
    auto _mls_x228 = (_mls_a1 + _mls_x226);
    auto _mls_x229 = _mls_go(_mls_x227, _mls_x228);
    _mls_retval = _mls_x229;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_insert(_mlsValue _mls_p3, _mlsValue _mls_ps, _mlsValue _mls_i1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_ps)) {
    auto _mls_x230 = _mlsValue::cast<_mls_Cons>(_mls_ps)->_mls_head;
    auto _mls_x231 = _mlsValue::cast<_mls_Cons>(_mls_ps)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x231)) {
      auto _mls_x232 = _mlsValue::cast<_mls_Cons>(_mls_x231)->_mls_head;
      auto _mls_x233 = _mlsValue::cast<_mls_Cons>(_mls_x231)->_mls_tail;
      if (_mlsValue::isValueOf<_mls_Cons>(_mls_x233)) {
        auto _mls_x234 = _mlsValue::cast<_mls_Cons>(_mls_x233)->_mls_head;
        auto _mls_x235 = _mlsValue::cast<_mls_Cons>(_mls_x233)->_mls_tail;
        if (_mlsValue::isValueOf<_mls_Nil>(_mls_x235)) {
          auto _mls_x236 = (_mls_i1 == _mlsValue::fromIntLit(1));
          if (_mlsValue::isIntLit(_mls_x236, 1)) {
            auto _mls_x247 = _mlsValue::create<_mls_Nil>();
            auto _mls_x248 = _mlsValue::create<_mls_Cons>(_mls_x234, _mls_x247);
            auto _mls_x249 = _mlsValue::create<_mls_Cons>(_mls_x232, _mls_x248);
            auto _mls_x250 = _mlsValue::create<_mls_Cons>(_mls_p3, _mls_x249);
            _mls_retval = _mls_x250;
          } else {
            auto _mls_x237 = (_mls_i1 == _mlsValue::fromIntLit(2));
            if (_mlsValue::isIntLit(_mls_x237, 1)) {
              auto _mls_x243 = _mlsValue::create<_mls_Nil>();
              auto _mls_x244 = _mlsValue::create<_mls_Cons>(_mls_x234, _mls_x243);
              auto _mls_x245 = _mlsValue::create<_mls_Cons>(_mls_p3, _mls_x244);
              auto _mls_x246 = _mlsValue::create<_mls_Cons>(_mls_x230, _mls_x245);
              _mls_retval = _mls_x246;
            } else {
              auto _mls_x238 = (_mls_i1 == _mlsValue::fromIntLit(3));
              if (_mlsValue::isIntLit(_mls_x238, 1)) {
                auto _mls_x239 = _mlsValue::create<_mls_Nil>();
                auto _mls_x240 = _mlsValue::create<_mls_Cons>(_mls_p3, _mls_x239);
                auto _mls_x241 = _mlsValue::create<_mls_Cons>(_mls_x232, _mls_x240);
                auto _mls_x242 = _mlsValue::create<_mls_Cons>(_mls_x230, _mls_x241);
                _mls_retval = _mls_x242;
              } else {
                _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
              }
            }
          }
        } else {
          _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_interpret(_mlsValue _mls_x765, _mlsValue _mls_x762) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x762)) {
    _mls_retval = _mls_interpret_case0(_mls_x765);
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x762)) {
    auto _mls_x763 = _mlsValue::cast<_mls_Cons>(_mls_x762)->_mls_head;
    auto _mls_x764 = _mlsValue::cast<_mls_Cons>(_mls_x762)->_mls_tail;
    _mls_retval = _mls_interpret_case1_sr_post(_mls_x763, _mls_x765, _mls_x764);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_interpret_case0(_mlsValue _mls_x767) {
  _mlsValue _mls_retval;
  auto _mls_x766 = _mlsValue::create<_mls_Score>(_mls_x767);
  _mls_retval = _mls_x766;
  return _mls_retval;
}
_mlsValue _mls_interpret_case1_sr_post(_mlsValue _mls_x768, _mlsValue _mls_x773, _mlsValue _mls_x774) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Score>(_mls_x768)) {
    auto _mls_x771 = _mlsValue::cast<_mls_Score>(_mls_x768)->_mls_i;
    auto _mls_x772 = (_mls_x773 + _mls_x771);
    auto _mls_x775 = _mls_interpret(_mls_x772, _mls_x774);
    _mls_retval = _mls_x775;
  } else if (_mlsValue::isValueOf<_mls_XWin>(_mls_x768)) {
    auto _mls_x770 = _mlsValue::create<_mls_XWin>();
    _mls_retval = _mls_x770;
  } else if (_mlsValue::isValueOf<_mls_OWin>(_mls_x768)) {
    auto _mls_x769 = _mlsValue::create<_mls_OWin>();
    _mls_retval = _mls_x769;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_map(_mlsValue _mls_x777, _mlsValue _mls_x776) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x776)) {
    _mls_retval = _mls_map_case0(_mls_x776, _mls_x777);
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x776)) {
    _mls_retval = _mls_map_case1();
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_map2(_mlsValue _mls_x782, _mlsValue _mls_x778, _mlsValue _mls_x781) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x778)) {
    _mls_retval = _mls_map2_case0();
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x778)) {
    auto _mls_x779 = _mlsValue::cast<_mls_Cons>(_mls_x778)->_mls_head;
    auto _mls_x780 = _mlsValue::cast<_mls_Cons>(_mls_x778)->_mls_tail;
    _mls_retval = _mls_map2_case1_sr_post(_mls_x781, _mls_x782, _mls_x779, _mls_x780);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_map2_case0() {
  _mlsValue _mls_retval;
  auto _mls_x783 = _mlsValue::create<_mls_Nil>();
  _mls_retval = _mls_x783;
  return _mls_retval;
}
_mlsValue _mls_map2_case1_sr_post(_mlsValue _mls_x784, _mlsValue _mls_x787, _mlsValue _mls_x788, _mlsValue _mls_x790) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x784)) {
    auto _mls_x785 = _mlsValue::cast<_mls_Cons>(_mls_x784)->_mls_head;
    auto _mls_x786 = _mlsValue::cast<_mls_Cons>(_mls_x784)->_mls_tail;
    auto _mls_x789 = _mlsMethodCall<_mls_Callable>(_mls_x787)->_mls_apply2(_mls_x788, _mls_x785);
    auto _mls_x791 = _mls_map2(_mls_x787, _mls_x790, _mls_x786);
    auto _mls_x792 = _mlsValue::create<_mls_Cons>(_mls_x789, _mls_x791);
    _mls_retval = _mls_x792;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_mapTree(_mlsValue _mls_x796, _mlsValue _mls_x793) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Branch>(_mls_x793)) {
    auto _mls_x794 = _mlsValue::cast<_mls_Branch>(_mls_x793)->_mls_a;
    auto _mls_x795 = _mlsValue::cast<_mls_Branch>(_mls_x793)->_mls_cs;
    _mls_retval = _mls_mapTree_case0_sr_post(_mls_x796, _mls_x794, _mls_x795);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_mapTree_case0_sr_post(_mlsValue _mls_x797, _mlsValue _mls_x798, _mlsValue _mls_x801) {
  _mlsValue _mls_retval;
  auto _mls_x799 = _mlsMethodCall<_mls_Callable>(_mls_x797)->_mls_apply1(_mls_x798);
  auto _mls_x800 = _mlsValue::create<_mls_Lambda_lambda6>(_mls_x797);
  auto _mls_x802 = _mls_map(_mls_x800, _mls_x801);
  auto _mls_x803 = _mlsValue::create<_mls_Branch>(_mls_x799, _mls_x802);
  _mls_retval = _mls_x803;
  return _mls_retval;
}
_mlsValue _mls_map_case01(_mlsValue _mls_x805, _mlsValue _mls_x807) {
  _mlsValue _mls_retval;
  auto _mls_x804 = _mlsValue::cast<_mls_Cons>(_mls_x805)->_mls_head;
  auto _mls_x806 = _mlsValue::cast<_mls_Cons>(_mls_x805)->_mls_tail;
  _mls_retval = _mls_map_case0_sr_post(_mls_x807, _mls_x804, _mls_x806);
  return _mls_retval;
}
_mlsValue _mls_map_case0(_mlsValue _mls_x809, _mlsValue _mls_x811) {
  _mlsValue _mls_retval;
  auto _mls_x808 = _mlsValue::cast<_mls_Cons>(_mls_x809)->_mls_head;
  auto _mls_x810 = _mlsValue::cast<_mls_Cons>(_mls_x809)->_mls_tail;
  _mls_retval = _mls_map_case0_sr_post(_mls_x811, _mls_x808, _mls_x810);
  return _mls_retval;
}
_mlsValue _mls_map_case0_sr_post(_mlsValue _mls_x812, _mlsValue _mls_x813, _mlsValue _mls_x815) {
  _mlsValue _mls_retval;
  auto _mls_x814 = _mlsMethodCall<_mls_Callable>(_mls_x812)->_mls_apply1(_mls_x813);
  auto _mls_x816 = _mls_map(_mls_x812, _mls_x815);
  auto _mls_x817 = _mlsValue::create<_mls_Cons>(_mls_x814, _mls_x816);
  _mls_retval = _mls_x817;
  return _mls_retval;
}
_mlsValue _mls_map_case1() {
  _mlsValue _mls_retval;
  auto _mls_x818 = _mlsValue::create<_mls_Nil>();
  _mls_retval = _mls_x818;
  return _mls_retval;
}
_mlsValue _mls_max_(_mlsValue _mls_e1, _mlsValue _mls_e2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_XWin>(_mls_e1)) {
    auto _mls_x286 = _mlsValue::create<_mls_XWin>();
    _mls_retval = _mls_x286;
  } else {
    if (_mlsValue::isValueOf<_mls_XWin>(_mls_e2)) {
      auto _mls_x285 = _mlsValue::create<_mls_XWin>();
      _mls_retval = _mls_x285;
    } else if (_mlsValue::isValueOf<_mls_OWin>(_mls_e2)) {
      _mls_retval = _mls_e1;
    } else {
      if (_mlsValue::isValueOf<_mls_OWin>(_mls_e1)) {
        _mls_retval = _mls_e2;
      } else if (_mlsValue::isValueOf<_mls_Score>(_mls_e1)) {
        auto _mls_x280 = _mlsValue::cast<_mls_Score>(_mls_e1)->_mls_i;
        if (_mlsValue::isValueOf<_mls_Score>(_mls_e2)) {
          auto _mls_x281 = _mlsValue::cast<_mls_Score>(_mls_e2)->_mls_i;
          auto _mls_x282 = (_mls_x280 > _mls_x281);
          if (_mlsValue::isIntLit(_mls_x282, 1)) {
            auto _mls_x284 = _mlsValue::create<_mls_Score>(_mls_x280);
            _mls_retval = _mls_x284;
          } else {
            auto _mls_x283 = _mlsValue::create<_mls_Score>(_mls_x281);
            _mls_retval = _mls_x283;
          }
        } else {
          _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_min_(_mlsValue _mls_e11, _mlsValue _mls_e21) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_OWin>(_mls_e11)) {
    auto _mls_x293 = _mlsValue::create<_mls_OWin>();
    _mls_retval = _mls_x293;
  } else {
    if (_mlsValue::isValueOf<_mls_OWin>(_mls_e21)) {
      auto _mls_x292 = _mlsValue::create<_mls_OWin>();
      _mls_retval = _mls_x292;
    } else if (_mlsValue::isValueOf<_mls_XWin>(_mls_e21)) {
      _mls_retval = _mls_e11;
    } else {
      if (_mlsValue::isValueOf<_mls_XWin>(_mls_e11)) {
        _mls_retval = _mls_e21;
      } else if (_mlsValue::isValueOf<_mls_Score>(_mls_e11)) {
        auto _mls_x287 = _mlsValue::cast<_mls_Score>(_mls_e11)->_mls_i;
        if (_mlsValue::isValueOf<_mls_Score>(_mls_e21)) {
          auto _mls_x288 = _mlsValue::cast<_mls_Score>(_mls_e21)->_mls_i;
          auto _mls_x289 = (_mls_x287 < _mls_x288);
          if (_mlsValue::isIntLit(_mls_x289, 1)) {
            auto _mls_x291 = _mlsValue::create<_mls_Score>(_mls_x287);
            _mls_retval = _mls_x291;
          } else {
            auto _mls_x290 = _mlsValue::create<_mls_Score>(_mls_x288);
            _mls_retval = _mls_x290;
          }
        } else {
          _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_mise(_mlsValue _mls_x821, _mlsValue _mls_x820, _mlsValue _mls_x819) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Branch>(_mls_x819)) {
    _mls_retval = _mls_mise_case0(_mls_x819, _mls_x820, _mls_x821);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_mise_case0(_mlsValue _mls_x823, _mlsValue _mls_x827, _mlsValue _mls_x830) {
  _mlsValue _mls_retval;
  auto _mls_x822 = _mlsValue::cast<_mls_Branch>(_mls_x823)->_mls_a;
  auto _mls_x824 = _mlsValue::cast<_mls_Branch>(_mls_x823)->_mls_cs;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x824)) {
    _mls_retval = _mls_x822;
  } else {
    auto _mls_x825 = _mlsValue::create<_mls_OWin>();
    auto _mls_x826 = _mlsValue::create<_mls_XWin>();
    auto _mls_x828 = _mlsMethodCall<_mls_Callable>(_mls_x827)->_mls_apply2(_mls_x825, _mls_x826);
    auto _mls_x829 = _mlsValue::create<_mls_Lambda_lambda>(_mls_x827, _mls_x830);
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x824)) {
      auto _mls_x832 = _mlsValue::cast<_mls_Cons>(_mls_x824)->_mls_head;
      auto _mls_x833 = _mlsValue::cast<_mls_Cons>(_mls_x824)->_mls_tail;
      auto _mls_x834 = _mls_map_case0_sr_post(_mls_x829, _mls_x832, _mls_x833);
      auto _mls_x835 = _mls_foldr_case1(_mls_x834, _mls_x830, _mls_x828);
      _mls_retval = _mls_x835;
    } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x824)) {
      auto _mls_x831 = _mls_map_case1();
      _mls_retval = _mls_x828;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  }
  return _mls_retval;
}
_mlsValue _mls_newPositions(_mlsValue _mls_x836, _mlsValue _mls_x837) {
  _mlsValue _mls_retval;
  auto [_mls_x838, _mls_x839] = _mls_newPositions_pre(_mls_x836, _mls_x837);
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x838)) {
    auto _mls_x840 = _mlsValue::cast<_mls_Cons>(_mls_x838)->_mls_head;
    auto _mls_x841 = _mlsValue::cast<_mls_Cons>(_mls_x838)->_mls_tail;
    _mls_retval = _mls_newPositions_case0_sr_post(_mls_x839, _mls_x840, _mls_x841);
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x838)) {
    _mls_retval = _mls_newPositions_case1();
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_newPositions_case0(_mlsValue _mls_x843, _mlsValue _mls_x845) {
  _mlsValue _mls_retval;
  auto _mls_x842 = _mlsValue::cast<_mls_Cons>(_mls_x843)->_mls_head;
  auto _mls_x844 = _mlsValue::cast<_mls_Cons>(_mls_x843)->_mls_tail;
  _mls_retval = _mls_newPositions_case0_sr_post(_mls_x845, _mls_x842, _mls_x844);
  return _mls_retval;
}
_mlsValue _mls_newPositions_case0_sr_post(_mlsValue _mls_x846, _mlsValue _mls_x847, _mlsValue _mls_x848) {
  _mlsValue _mls_retval;
  auto _mls_x849 = _mls_map_case0_sr_post(_mls_x846, _mls_x847, _mls_x848);
  auto _mls_x850 = _mls_concat(_mls_x849);
  _mls_retval = _mls_x850;
  return _mls_retval;
}
_mlsValue _mls_newPositions_case1() {
  _mlsValue _mls_retval;
  auto _mls_x851 = _mls_map_case1();
  auto _mls_x852 = _mls_concat_case0();
  _mls_retval = _mls_x852;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue> _mls_newPositions_pre(_mlsValue _mls_x860, _mlsValue _mls_x861) {
  std::tuple<_mlsValue, _mlsValue> _mls_retval;
  auto _mls_x853 = _mlsValue::create<_mls_Lambda_lscomp1>();
  auto _mls_x854 = _mlsValue::create<_mls_Nil>();
  auto _mls_x855 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(3), _mls_x854);
  auto _mls_x856 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(2), _mls_x855);
  auto _mls_x857 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x856);
  auto _mls_x858 = _mlsMethodCall<_mls_Callable>(_mls_x853)->_mls_apply1(_mls_x857);
  auto _mls_x859 = _mlsValue::create<_mls_Lambda_lambda3>(_mls_x860, _mls_x861);
  _mls_retval = std::make_tuple(_mls_x858, _mls_x859);
  return _mls_retval;
}
_mlsValue _mls_not(_mlsValue _mls_x862) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_x862, 1)) {
    _mls_retval = _mlsValue::fromIntLit(0);
  } else {
    _mls_retval = _mlsValue::fromIntLit(1);
  }
  return _mls_retval;
}
_mlsValue _mls_opposite(_mlsValue _mls_x863) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_X>(_mls_x863)) {
    _mls_retval = _mls_opposite_case0();
  } else if (_mlsValue::isValueOf<_mls_O>(_mls_x863)) {
    _mls_retval = _mls_opposite_case1();
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_opposite_case0() {
  _mlsValue _mls_retval;
  auto _mls_x864 = _mlsValue::create<_mls_O>();
  _mls_retval = _mls_x864;
  return _mls_retval;
}
_mlsValue _mls_opposite_case1() {
  _mlsValue _mls_retval;
  auto _mls_x865 = _mlsValue::create<_mls_X>();
  _mls_retval = _mls_x865;
  return _mls_retval;
}
_mlsValue _mls_placePiece(_mlsValue _mls_p5, _mlsValue _mls_board3, _mlsValue _mls_pos2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_board3)) {
    auto _mls_x866 = _mlsValue::cast<_mls_Cons>(_mls_board3)->_mls_head;
    auto _mls_x867 = _mlsValue::cast<_mls_Cons>(_mls_board3)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x867)) {
      auto _mls_x868 = _mlsValue::cast<_mls_Cons>(_mls_x867)->_mls_head;
      auto _mls_x869 = _mlsValue::cast<_mls_Cons>(_mls_x867)->_mls_tail;
      auto _mls_x870 = _mls_empty_case0_sr_post_case0_sr_post(_mls_x869, _mls_pos2, _mls_x866, _mls_x868);
      _mls_retval = _mls_placePiece_caller_post(_mls_x870, _mls_board3, _mls_pos2, _mls_p5);
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_placePiece_caller_post(_mlsValue _mls_x871, _mlsValue _mls_x872, _mlsValue _mls_x873, _mlsValue _mls_x874) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_x871, 1)) {
    _mls_retval = _mls_placePiece_caller_post_caller_post_default(_mls_x872, _mls_x873, _mls_x874);
  } else {
    _mls_retval = _mls_placePiece_caller_post_caller_post_case0();
  }
  return _mls_retval;
}
_mlsValue _mls_placePiece_caller_post_caller_post_case0() {
  _mlsValue _mls_retval;
  auto _mls_x875 = _mlsValue::create<_mls_Nil>();
  _mls_retval = _mls_x875;
  return _mls_retval;
}
_mlsValue _mls_placePiece_caller_post_caller_post_default(_mlsValue _mls_x876, _mlsValue _mls_x883, _mlsValue _mls_x886) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x876)) {
    auto _mls_x877 = _mlsValue::cast<_mls_Cons>(_mls_x876)->_mls_head;
    auto _mls_x878 = _mlsValue::cast<_mls_Cons>(_mls_x876)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x878)) {
      auto _mls_x879 = _mlsValue::cast<_mls_Cons>(_mls_x878)->_mls_head;
      auto _mls_x880 = _mlsValue::cast<_mls_Cons>(_mls_x878)->_mls_tail;
      if (_mlsValue::isValueOf<_mls_Cons>(_mls_x880)) {
        auto _mls_x881 = _mlsValue::cast<_mls_Cons>(_mls_x880)->_mls_head;
        auto _mls_x882 = _mlsValue::cast<_mls_Cons>(_mls_x880)->_mls_tail;
        if (_mlsValue::isValueOf<_mls_Nil>(_mls_x882)) {
          if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x883)) {
            auto _mls_x884 = _mlsValue::cast<_mls_Tuple2>(_mls_x883)->_mls_field0;
            auto _mls_x885 = _mlsValue::cast<_mls_Tuple2>(_mls_x883)->_mls_field1;
            if (_mlsValue::isIntLit(_mls_x884, 1)) {
              auto _mls_x901 = _mls_insert(_mls_x886, _mls_x877, _mls_x885);
              auto _mls_x902 = _mlsValue::create<_mls_Nil>();
              auto _mls_x903 = _mlsValue::create<_mls_Cons>(_mls_x881, _mls_x902);
              auto _mls_x904 = _mlsValue::create<_mls_Cons>(_mls_x879, _mls_x903);
              auto _mls_x905 = _mlsValue::create<_mls_Cons>(_mls_x901, _mls_x904);
              auto _mls_x906 = _mlsValue::create<_mls_Nil>();
              auto _mls_x907 = _mlsValue::create<_mls_Cons>(_mls_x905, _mls_x906);
              _mls_retval = _mls_x907;
            } else if (_mlsValue::isIntLit(_mls_x884, 2)) {
              auto _mls_x894 = _mls_insert(_mls_x886, _mls_x879, _mls_x885);
              auto _mls_x895 = _mlsValue::create<_mls_Nil>();
              auto _mls_x896 = _mlsValue::create<_mls_Cons>(_mls_x881, _mls_x895);
              auto _mls_x897 = _mlsValue::create<_mls_Cons>(_mls_x894, _mls_x896);
              auto _mls_x898 = _mlsValue::create<_mls_Cons>(_mls_x877, _mls_x897);
              auto _mls_x899 = _mlsValue::create<_mls_Nil>();
              auto _mls_x900 = _mlsValue::create<_mls_Cons>(_mls_x898, _mls_x899);
              _mls_retval = _mls_x900;
            } else if (_mlsValue::isIntLit(_mls_x884, 3)) {
              auto _mls_x887 = _mls_insert(_mls_x886, _mls_x881, _mls_x885);
              auto _mls_x888 = _mlsValue::create<_mls_Nil>();
              auto _mls_x889 = _mlsValue::create<_mls_Cons>(_mls_x887, _mls_x888);
              auto _mls_x890 = _mlsValue::create<_mls_Cons>(_mls_x879, _mls_x889);
              auto _mls_x891 = _mlsValue::create<_mls_Cons>(_mls_x877, _mls_x890);
              auto _mls_x892 = _mlsValue::create<_mls_Nil>();
              auto _mls_x893 = _mlsValue::create<_mls_Cons>(_mls_x891, _mls_x892);
              _mls_retval = _mls_x893;
            } else {
              _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
            }
          } else {
            _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
          }
        } else {
          _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_prog(_mlsValue _mls_input) {
  _mlsValue _mls_retval;
  auto _mls_x345 = _mlsValue::create<_mls_Lambda_board>();
  auto _mls_x346 = _mlsMethodCall<_mls_Callable>(_mls_x345)->_mls_apply1(_mls_input);
  auto _mls_x347 = _mlsValue::create<_mls_X>();
  auto _mls_x348 = _mlsValue::create<_mls_Lambda_max_>();
  auto _mls_x349 = _mlsValue::create<_mls_Lambda_min_>();
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x346)) {
    auto [_mls_x910, _mls_x911] = _mls_fullBoard_case0_pre();
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x910)) {
      auto _mls_x913 = _mls_fullBoard_caller_post_case0(_mls_x910, _mls_x911);
      _mls_retval = _mls_prog_caller_post1(_mls_x347, _mls_x348, _mls_x346, _mls_x349, _mls_x913);
    } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x910)) {
      auto _mls_x912 = _mls_map_case1();
      _mls_retval = _mls_prog_caller_post1(_mls_x347, _mls_x348, _mls_x346, _mls_x349, _mlsValue::fromIntLit(1));
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x346)) {
    auto _mls_x908 = _mls_concat_case1(_mls_x346);
    auto _mls_x909 = _mls_fullBoard_caller_post(_mls_x908);
    _mls_retval = _mls_prog_caller_post(_mls_x347, _mls_x348, _mls_x346, _mls_x909, _mls_x349);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_prog_caller_post(_mlsValue _mls_x918, _mlsValue _mls_x916, _mlsValue _mls_x915, _mlsValue _mls_x914, _mlsValue _mls_x917) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_x914, 1)) {
    auto _mls_x920 = _mls_alternate_case0();
    _mls_retval = _mls_prog_caller_post2(_mls_x920);
  } else {
    auto _mls_x919 = _mls_alternate_default(_mls_x915, _mls_x916, _mls_x917, _mls_x918);
    _mls_retval = _mls_prog_caller_post2(_mls_x919);
  }
  return _mls_retval;
}
_mlsValue _mls_prog_caller_post2(_mlsValue _mls_x923) {
  _mlsValue _mls_retval;
  auto _mls_x921 = _mls_builtin_str_head(_mlsValue::create<_mls_Str>("OXO\n"));
  if (_mlsValue::isValueOf<_mls_Unit>(_mls_x921)) {
    auto _mls_x929 = _mls_str_to_list_case0();
    auto [_mls_x930, _mls_x931, _mls_x932] = _mls_prog_caller_post_caller_post_pre(_mls_x923, _mls_x929);
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x930)) {
      auto _mls_x934 = _mls_map_case01(_mls_x930, _mls_x931);
      _mls_retval = _mls_prog_caller_post_caller_post(_mls_x934, _mls_x932);
    } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x930)) {
      auto _mls_x933 = _mls_map_case1();
      _mls_retval = _mls_prog_caller_post_caller_post(_mls_x933, _mls_x932);
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    auto _mls_x922 = _mls_str_to_list_default(_mlsValue::create<_mls_Str>("OXO\n"));
    auto [_mls_x924, _mls_x925, _mls_x926] = _mls_prog_caller_post_caller_post_pre(_mls_x923, _mls_x922);
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x924)) {
      auto _mls_x928 = _mls_map_case01(_mls_x924, _mls_x925);
      _mls_retval = _mls_prog_caller_post_caller_post(_mls_x928, _mls_x926);
    } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x924)) {
      auto _mls_x927 = _mls_map_case1();
      _mls_retval = _mls_prog_caller_post_caller_post(_mls_x927, _mls_x926);
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  }
  return _mls_retval;
}
_mlsValue _mls_prog_caller_post1(_mlsValue _mls_x939, _mlsValue _mls_x937, _mlsValue _mls_x936, _mlsValue _mls_x938, _mlsValue _mls_x935) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_x935, 1)) {
    auto _mls_x941 = _mls_alternate_case0();
    _mls_retval = _mls_prog_caller_post2(_mls_x941);
  } else {
    auto _mls_x940 = _mls_alternate_default(_mls_x936, _mls_x937, _mls_x938, _mls_x939);
    _mls_retval = _mls_prog_caller_post2(_mls_x940);
  }
  return _mls_retval;
}
_mlsValue _mls_prog_caller_post_caller_post(_mlsValue _mls_x942, _mlsValue _mls_x944) {
  _mlsValue _mls_retval;
  auto _mls_x943 = _mls_concat(_mls_x942);
  auto _mls_x945 = _mls_append(_mls_x944, _mls_x943);
  _mls_retval = _mls_x945;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_prog_caller_post_caller_post_pre(_mlsValue _mls_x947, _mlsValue _mls_x948) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x946 = _mlsValue::create<_mls_Lambda_showMove>();
  _mls_retval = std::make_tuple(_mls_x947, _mls_x946, _mls_x948);
  return _mls_retval;
}
_mlsValue _mls_prune(_mlsValue _mls_x952, _mlsValue _mls_x949) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Branch>(_mls_x949)) {
    auto _mls_x950 = _mlsValue::cast<_mls_Branch>(_mls_x949)->_mls_a;
    auto _mls_x951 = _mlsValue::cast<_mls_Branch>(_mls_x949)->_mls_cs;
    _mls_retval = _mls_prune_case0_sr_post(_mls_x952, _mls_x950, _mls_x951);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_prune_case0_sr_post(_mlsValue _mls_x954, _mlsValue _mls_x960, _mlsValue _mls_x957) {
  _mlsValue _mls_retval;
  auto _mls_x953 = (_mls_x954 == _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x953, 1)) {
    auto _mls_x961 = _mlsValue::create<_mls_Nil>();
    auto _mls_x962 = _mlsValue::create<_mls_Branch>(_mls_x960, _mls_x961);
    _mls_retval = _mls_x962;
  } else {
    auto _mls_x955 = (_mls_x954 > _mlsValue::fromIntLit(0));
    if (_mlsValue::isIntLit(_mls_x955, 1)) {
      auto _mls_x956 = _mlsValue::create<_mls_Lambda_lambda2>(_mls_x954);
      auto _mls_x958 = _mls_map(_mls_x956, _mls_x957);
      auto _mls_x959 = _mlsValue::create<_mls_Branch>(_mls_x960, _mls_x958);
      _mls_retval = _mls_x959;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  }
  return _mls_retval;
}
_mlsValue _mls_repTree(_mlsValue _mls_f8, _mlsValue _mls_g3, _mlsValue _mls_a2) {
  _mlsValue _mls_retval;
  auto _mls_x365 = _mlsMethodCall<_mls_Callable>(_mls_f8)->_mls_apply1(_mls_a2);
  auto _mls_x366 = _mlsValue::create<_mls_Lambda_lambda7>(_mls_g3, _mls_f8);
  auto _mls_x367 = _mls_map(_mls_x366, _mls_x365);
  auto _mls_x368 = _mlsValue::create<_mls_Branch>(_mls_a2, _mls_x367);
  _mls_retval = _mls_x368;
  return _mls_retval;
}
_mlsValue _mls_run(_mlsValue _mls_n1) {
  _mlsValue _mls_retval;
  auto _mls_x369 = (_mls_n1 == _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x369, 1)) {
    auto _mls_x373 = _mls_prog(_mlsValue::create<_mls_Str>("180000"));
    _mls_retval = _mls_x373;
  } else {
    auto _mls_x370 = _mls_prog(_mlsValue::create<_mls_Str>("180000"));
    auto _mls_x371 = (_mls_n1 - _mlsValue::fromIntLit(1));
    auto _mls_x372 = _mls_run(_mls_x371);
    _mls_retval = _mls_x372;
  }
  return _mls_retval;
}
_mlsValue _mls_score(_mlsValue _mls_board4, _mlsValue _mls_win) {
  _mlsValue _mls_retval;
  auto _mls_x374 = _mlsValue::create<_mls_Lambda_lambda10>();
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_board4)) {
    auto _mls_x966 = _mls_map2_case0();
    auto [_mls_x967, _mls_x968] = _mls_score_caller_post_pre(_mls_x966);
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x968)) {
      auto _mls_x972 = _mlsValue::cast<_mls_Cons>(_mls_x968)->_mls_head;
      auto _mls_x973 = _mlsValue::cast<_mls_Cons>(_mls_x968)->_mls_tail;
      auto _mls_x974 = _mls_map_case0_sr_post(_mls_x967, _mls_x972, _mls_x973);
      _mls_retval = _mls_score_caller_post_post(_mls_x974);
    } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x968)) {
      auto _mls_x969 = _mls_map_case1();
      auto _mls_x970 = _mls_go(_mls_x969, _mlsValue::fromIntLit(0));
      auto _mls_x971 = _mls_eval1(_mls_x970);
      _mls_retval = _mls_x971;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_board4)) {
    auto _mls_x963 = _mlsValue::cast<_mls_Cons>(_mls_board4)->_mls_head;
    auto _mls_x964 = _mlsValue::cast<_mls_Cons>(_mls_board4)->_mls_tail;
    auto _mls_x965 = _mls_map2_case1_sr_post(_mls_win, _mls_x374, _mls_x963, _mls_x964);
    _mls_retval = _mls_score_caller_post(_mls_x965);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_scorePiece(_mlsValue _mls_p6, _mlsValue _mls_score1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_X>(_mls_p6)) {
    _mls_retval = _mls_score1;
  } else if (_mlsValue::isValueOf<_mls_Empty>(_mls_p6)) {
    _mls_retval = _mlsValue::fromIntLit(0);
  } else if (_mlsValue::isValueOf<_mls_O>(_mls_p6)) {
    auto _mls_x380 = (-_mls_score1);
    _mls_retval = _mls_x380;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_score_caller_post(_mlsValue _mls_x975) {
  _mlsValue _mls_retval;
  auto [_mls_x976, _mls_x977] = _mls_score_caller_post_pre(_mls_x975);
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x977)) {
    auto _mls_x981 = _mlsValue::cast<_mls_Cons>(_mls_x977)->_mls_head;
    auto _mls_x982 = _mlsValue::cast<_mls_Cons>(_mls_x977)->_mls_tail;
    auto _mls_x983 = _mls_map_case0_sr_post(_mls_x976, _mls_x981, _mls_x982);
    _mls_retval = _mls_score_caller_post_post(_mls_x983);
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x977)) {
    auto _mls_x978 = _mls_map_case1();
    auto _mls_x979 = _mls_go(_mls_x978, _mlsValue::fromIntLit(0));
    auto _mls_x980 = _mls_eval1(_mls_x979);
    _mls_retval = _mls_x980;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_score_caller_post_post(_mlsValue _mls_x984) {
  _mlsValue _mls_retval;
  auto _mls_x985 = _mls_go(_mls_x984, _mlsValue::fromIntLit(0));
  auto _mls_x986 = _mls_eval1(_mls_x985);
  _mls_retval = _mls_x986;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue> _mls_score_caller_post_pre(_mlsValue _mls_x988) {
  std::tuple<_mlsValue, _mlsValue> _mls_retval;
  auto _mls_x987 = _mlsValue::create<_mls_Lambda_sum>();
  _mls_retval = std::make_tuple(_mls_x987, _mls_x988);
  return _mls_retval;
}
_mlsValue _mls_searchTree(_mlsValue _mls_p7, _mlsValue _mls_board5) {
  _mlsValue _mls_retval;
  auto _mls_x381 = _mlsValue::create<_mls_Lambda_lambda5>(_mls_p7);
  auto _mls_x382 = _mlsValue::create<_mls_Lambda_lambda4>(_mls_p7);
  auto _mls_x383 = _mls_repTree(_mls_x381, _mls_x382, _mls_board5);
  auto _mls_x989 = _mlsValue::cast<_mls_Branch>(_mls_x383)->_mls_a;
  auto _mls_x990 = _mlsValue::cast<_mls_Branch>(_mls_x383)->_mls_cs;
  auto _mls_x991 = _mls_prune_case0_sr_post(_mlsValue::fromIntLit(5), _mls_x989, _mls_x990);
  _mls_retval = _mls_x991;
  return _mls_retval;
}
_mlsValue _mls_showBoard(_mlsValue _mls_rs) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_rs)) {
    auto _mls_x385 = _mlsValue::cast<_mls_Cons>(_mls_rs)->_mls_head;
    auto _mls_x386 = _mlsValue::cast<_mls_Cons>(_mls_rs)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x386)) {
      auto _mls_x387 = _mlsValue::cast<_mls_Cons>(_mls_x386)->_mls_head;
      auto _mls_x388 = _mlsValue::cast<_mls_Cons>(_mls_x386)->_mls_tail;
      if (_mlsValue::isValueOf<_mls_Cons>(_mls_x388)) {
        auto _mls_x389 = _mlsValue::cast<_mls_Cons>(_mls_x388)->_mls_head;
        auto _mls_x390 = _mlsValue::cast<_mls_Cons>(_mls_x388)->_mls_tail;
        if (_mlsValue::isValueOf<_mls_Nil>(_mls_x390)) {
          auto _mls_x391 = _mls_showRow(_mls_x385);
          auto _mls_x992 = _mls_builtin_str_head(_mlsValue::create<_mls_Str>("\n-------\n"));
          if (_mlsValue::isValueOf<_mls_Unit>(_mls_x992)) {
            auto _mls_x994 = _mls_str_to_list_case0();
            _mls_retval = _mls_showBoard_caller_post(_mls_x387, _mls_x994, _mls_x389, _mls_x391);
          } else {
            auto _mls_x993 = _mls_str_to_list_default(_mlsValue::create<_mls_Str>("\n-------\n"));
            _mls_retval = _mls_showBoard_caller_post(_mls_x387, _mls_x993, _mls_x389, _mls_x391);
          }
        } else {
          _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_showBoard_caller_post1(_mlsValue _mls_x1002, _mlsValue _mls_x1000, _mlsValue _mls_x996, _mlsValue _mls_x1004, _mlsValue _mls_x998) {
  _mlsValue _mls_retval;
  auto _mls_x995 = _mls_str_to_list(_mlsValue::create<_mls_Str>("\n\n"));
  auto _mls_x997 = _mls_append(_mls_x996, _mls_x995);
  auto _mls_x999 = _mls_append(_mls_x998, _mls_x997);
  auto _mls_x1001 = _mls_append(_mls_x1000, _mls_x999);
  auto _mls_x1003 = _mls_append(_mls_x1002, _mls_x1001);
  auto _mls_x1005 = _mls_append(_mls_x1004, _mls_x1003);
  _mls_retval = _mls_x1005;
  return _mls_retval;
}
_mlsValue _mls_showBoard_caller_post(_mlsValue _mls_x1006, _mlsValue _mls_x1010, _mlsValue _mls_x1011, _mlsValue _mls_x1012) {
  _mlsValue _mls_retval;
  auto _mls_x1007 = _mls_showRow(_mls_x1006);
  auto _mls_x1008 = _mls_builtin_str_head(_mlsValue::create<_mls_Str>("\n------\n"));
  if (_mlsValue::isValueOf<_mls_Unit>(_mls_x1008)) {
    auto _mls_x1013 = _mls_str_to_list_case0();
    _mls_retval = _mls_showBoard_caller_post2(_mls_x1010, _mls_x1007, _mls_x1011, _mls_x1012, _mls_x1013);
  } else {
    auto _mls_x1009 = _mls_str_to_list_default(_mlsValue::create<_mls_Str>("\n------\n"));
    _mls_retval = _mls_showBoard_caller_post2(_mls_x1010, _mls_x1007, _mls_x1011, _mls_x1012, _mls_x1009);
  }
  return _mls_retval;
}
_mlsValue _mls_showBoard_caller_post2(_mlsValue _mls_x1018, _mlsValue _mls_x1019, _mlsValue _mls_x1014, _mlsValue _mls_x1020, _mlsValue _mls_x1021) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1014)) {
    auto _mls_x1015 = _mlsValue::cast<_mls_Cons>(_mls_x1014)->_mls_head;
    auto _mls_x1016 = _mlsValue::cast<_mls_Cons>(_mls_x1014)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1016)) {
      auto _mls_x1017 = _mls_showRow_case0_sr_post_case0(_mls_x1016, _mls_x1015);
      _mls_retval = _mls_showBoard_caller_post1(_mls_x1018, _mls_x1019, _mls_x1017, _mls_x1020, _mls_x1021);
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue> _mls_showEvaluation_caller_post_pre(_mlsValue _mls_x1023, _mlsValue _mls_x1025) {
  std::tuple<_mlsValue, _mlsValue> _mls_retval;
  auto _mls_x1022 = _mls_builtin_int2str(_mls_x1023);
  auto _mls_x1024 = _mls_str_to_list(_mls_x1022);
  _mls_retval = std::make_tuple(_mls_x1025, _mls_x1024);
  return _mls_retval;
}
_mlsValue _mls_showEvaluation_case2_sr_post_case0(_mlsValue _mls_x1027) {
  _mlsValue _mls_retval;
  auto _mls_x1026 = _mls_str_to_list_case0();
  auto [_mls_x1028, _mls_x1029] = _mls_showEvaluation_caller_post_pre(_mls_x1027, _mls_x1026);
  auto _mls_x1030 = _mls_append(_mls_x1028, _mls_x1029);
  _mls_retval = _mls_x1030;
  return _mls_retval;
}
_mlsValue _mls_showEvaluation_case2_sr_post_default(_mlsValue _mls_x1032) {
  _mlsValue _mls_retval;
  auto _mls_x1031 = _mls_str_to_list_default(_mlsValue::create<_mls_Str>("Score "));
  auto [_mls_x1033, _mls_x1034] = _mls_showEvaluation_caller_post_pre(_mls_x1032, _mls_x1031);
  auto _mls_x1035 = _mls_append(_mls_x1033, _mls_x1034);
  _mls_retval = _mls_x1035;
  return _mls_retval;
}
_mlsValue _mls_showMove(_mlsValue _mls_m) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_m)) {
    auto _mls_x409 = _mlsValue::cast<_mls_Tuple2>(_mls_m)->_mls_field0;
    auto _mls_x410 = _mlsValue::cast<_mls_Tuple2>(_mls_m)->_mls_field1;
    if (_mlsValue::isValueOf<_mls_XWin>(_mls_x410)) {
      auto _mls_x1045 = _mls_builtin_str_head(_mlsValue::create<_mls_Str>("XWin"));
      if (_mlsValue::isValueOf<_mls_Unit>(_mls_x1045)) {
        auto _mls_x1048 = _mls_str_to_list_case0();
        auto _mls_x1049 = _mls_builtin_str_head(_mlsValue::create<_mls_Str>("\n"));
        if (_mlsValue::isValueOf<_mls_Unit>(_mls_x1049)) {
          _mls_retval = _mls_showMove_caller_post_case0(_mls_x409, _mls_x1048);
        } else {
          _mls_retval = _mls_showMove_caller_post_default(_mls_x409, _mls_x1048);
        }
      } else {
        auto _mls_x1046 = _mls_str_to_list_default(_mlsValue::create<_mls_Str>("XWin"));
        auto _mls_x1047 = _mls_builtin_str_head(_mlsValue::create<_mls_Str>("\n"));
        if (_mlsValue::isValueOf<_mls_Unit>(_mls_x1047)) {
          _mls_retval = _mls_showMove_caller_post_case0(_mls_x409, _mls_x1046);
        } else {
          _mls_retval = _mls_showMove_caller_post_default(_mls_x409, _mls_x1046);
        }
      }
    } else if (_mlsValue::isValueOf<_mls_OWin>(_mls_x410)) {
      auto _mls_x1040 = _mls_builtin_str_head(_mlsValue::create<_mls_Str>("OWin"));
      if (_mlsValue::isValueOf<_mls_Unit>(_mls_x1040)) {
        auto _mls_x1043 = _mls_str_to_list_case0();
        auto _mls_x1044 = _mls_builtin_str_head(_mlsValue::create<_mls_Str>("\n"));
        if (_mlsValue::isValueOf<_mls_Unit>(_mls_x1044)) {
          _mls_retval = _mls_showMove_caller_post_case0(_mls_x409, _mls_x1043);
        } else {
          _mls_retval = _mls_showMove_caller_post_default(_mls_x409, _mls_x1043);
        }
      } else {
        auto _mls_x1041 = _mls_str_to_list_default(_mlsValue::create<_mls_Str>("OWin"));
        auto _mls_x1042 = _mls_builtin_str_head(_mlsValue::create<_mls_Str>("\n"));
        if (_mlsValue::isValueOf<_mls_Unit>(_mls_x1042)) {
          _mls_retval = _mls_showMove_caller_post_case0(_mls_x409, _mls_x1041);
        } else {
          _mls_retval = _mls_showMove_caller_post_default(_mls_x409, _mls_x1041);
        }
      }
    } else if (_mlsValue::isValueOf<_mls_Score>(_mls_x410)) {
      auto _mls_x1036 = _mlsValue::cast<_mls_Score>(_mls_x410)->_mls_i;
      auto _mls_x1037 = _mls_builtin_str_head(_mlsValue::create<_mls_Str>("Score "));
      if (_mlsValue::isValueOf<_mls_Unit>(_mls_x1037)) {
        auto _mls_x1039 = _mls_showEvaluation_case2_sr_post_case0(_mls_x1036);
        _mls_retval = _mls_showMove_caller_post(_mls_x409, _mls_x1039);
      } else {
        auto _mls_x1038 = _mls_showEvaluation_case2_sr_post_default(_mls_x1036);
        _mls_retval = _mls_showMove_caller_post(_mls_x409, _mls_x1038);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_showMove_caller_post(_mlsValue _mls_x1051, _mlsValue _mls_x1052) {
  _mlsValue _mls_retval;
  auto _mls_x1050 = _mls_builtin_str_head(_mlsValue::create<_mls_Str>("\n"));
  if (_mlsValue::isValueOf<_mls_Unit>(_mls_x1050)) {
    _mls_retval = _mls_showMove_caller_post_case0(_mls_x1051, _mls_x1052);
  } else {
    _mls_retval = _mls_showMove_caller_post_default(_mls_x1051, _mls_x1052);
  }
  return _mls_retval;
}
_mlsValue _mls_showMove_caller_post_case0(_mlsValue _mls_x1054, _mlsValue _mls_x1057) {
  _mlsValue _mls_retval;
  auto _mls_x1053 = _mls_str_to_list_case0();
  auto _mls_x1055 = _mls_showBoard(_mls_x1054);
  auto _mls_x1056 = _mls_append(_mls_x1053, _mls_x1055);
  auto _mls_x1058 = _mls_append(_mls_x1057, _mls_x1056);
  _mls_retval = _mls_x1058;
  return _mls_retval;
}
_mlsValue _mls_showMove_caller_post_default(_mlsValue _mls_x1060, _mlsValue _mls_x1063) {
  _mlsValue _mls_retval;
  auto _mls_x1059 = _mls_str_to_list_default(_mlsValue::create<_mls_Str>("\n"));
  auto _mls_x1061 = _mls_showBoard(_mls_x1060);
  auto _mls_x1062 = _mls_append(_mls_x1059, _mls_x1061);
  auto _mls_x1064 = _mls_append(_mls_x1063, _mls_x1062);
  _mls_retval = _mls_x1064;
  return _mls_retval;
}
_mlsValue _mls_showPiece(_mlsValue _mls_p8) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_X>(_mls_p8)) {
    auto _mls_x418 = _mls_str_to_list(_mlsValue::create<_mls_Str>("X"));
    _mls_retval = _mls_x418;
  } else if (_mlsValue::isValueOf<_mls_O>(_mls_p8)) {
    auto _mls_x417 = _mls_str_to_list(_mlsValue::create<_mls_Str>("O"));
    _mls_retval = _mls_x417;
  } else if (_mlsValue::isValueOf<_mls_Empty>(_mls_p8)) {
    auto _mls_x416 = _mls_str_to_list(_mlsValue::create<_mls_Str>(" "));
    _mls_retval = _mls_x416;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_showRow(_mlsValue _mls_x1065) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1065)) {
    auto _mls_x1066 = _mlsValue::cast<_mls_Cons>(_mls_x1065)->_mls_head;
    auto _mls_x1067 = _mlsValue::cast<_mls_Cons>(_mls_x1065)->_mls_tail;
    _mls_retval = _mls_showRow_case0_sr_post(_mls_x1067, _mls_x1066);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_showRow_case0_sr_post(_mlsValue _mls_x1068, _mlsValue _mls_x1069) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1068)) {
    _mls_retval = _mls_showRow_case0_sr_post_case0(_mls_x1068, _mls_x1069);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_showRow_case0_sr_post_caller_post(_mlsValue _mls_x1072, _mlsValue _mls_x1078, _mlsValue _mls_x1074, _mlsValue _mls_x1076, _mlsValue _mls_x1070) {
  _mlsValue _mls_retval;
  auto _mls_x1071 = _mls_showPiece(_mls_x1070);
  auto _mls_x1073 = _mls_append(_mls_x1072, _mls_x1071);
  auto _mls_x1075 = _mls_append(_mls_x1074, _mls_x1073);
  auto _mls_x1077 = _mls_append(_mls_x1076, _mls_x1075);
  auto _mls_x1079 = _mls_append(_mls_x1078, _mls_x1077);
  _mls_retval = _mls_x1079;
  return _mls_retval;
}
_mlsValue _mls_showRow_case0_sr_post_case0(_mlsValue _mls_x1081, _mlsValue _mls_x1085) {
  _mlsValue _mls_retval;
  auto _mls_x1080 = _mlsValue::cast<_mls_Cons>(_mls_x1081)->_mls_head;
  auto _mls_x1082 = _mlsValue::cast<_mls_Cons>(_mls_x1081)->_mls_tail;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x1082)) {
    auto _mls_x1083 = _mlsValue::cast<_mls_Cons>(_mls_x1082)->_mls_head;
    auto _mls_x1084 = _mlsValue::cast<_mls_Cons>(_mls_x1082)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x1084)) {
      auto _mls_x1086 = _mls_showPiece(_mls_x1085);
      auto _mls_x1087 = _mls_str_to_list(_mlsValue::create<_mls_Str>("|"));
      auto _mls_x1088 = _mls_showPiece(_mls_x1080);
      auto _mls_x1089 = _mls_builtin_str_head(_mlsValue::create<_mls_Str>("|"));
      if (_mlsValue::isValueOf<_mls_Unit>(_mls_x1089)) {
        auto _mls_x1091 = _mls_str_to_list_case0();
        _mls_retval = _mls_showRow_case0_sr_post_caller_post(_mls_x1091, _mls_x1086, _mls_x1088, _mls_x1087, _mls_x1083);
      } else {
        auto _mls_x1090 = _mls_str_to_list_default(_mlsValue::create<_mls_Str>("|"));
        _mls_retval = _mls_showRow_case0_sr_post_caller_post(_mls_x1090, _mls_x1086, _mls_x1088, _mls_x1087, _mls_x1083);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_static1(_mlsValue _mls_board6) {
  _mlsValue _mls_retval;
  auto _mls_x434 = _mls_wins();
  auto _mls_x435 = _mlsValue::create<_mls_Lambda_lambda8>(_mls_board6);
  auto _mls_x1092 = _mlsValue::cast<_mls_Cons>(_mls_x434)->_mls_head;
  auto _mls_x1093 = _mlsValue::cast<_mls_Cons>(_mls_x434)->_mls_tail;
  auto _mls_x1094 = _mls_map_case0_sr_post(_mls_x435, _mls_x1092, _mls_x1093);
  auto _mls_x1095 = _mlsValue::cast<_mls_Cons>(_mls_x1094)->_mls_head;
  auto _mls_x1096 = _mlsValue::cast<_mls_Cons>(_mls_x1094)->_mls_tail;
  auto _mls_x1097 = _mls_interpret_case1_sr_post(_mls_x1095, _mlsValue::fromIntLit(0), _mls_x1096);
  _mls_retval = _mls_x1097;
  return _mls_retval;
}
_mlsValue _mls_str_to_list(_mlsValue _mls_x1099) {
  _mlsValue _mls_retval;
  auto _mls_x1098 = _mls_builtin_str_head(_mls_x1099);
  if (_mlsValue::isValueOf<_mls_Unit>(_mls_x1098)) {
    _mls_retval = _mls_str_to_list_case0();
  } else {
    _mls_retval = _mls_str_to_list_default(_mls_x1099);
  }
  return _mls_retval;
}
_mlsValue _mls_str_to_list_case0() {
  _mlsValue _mls_retval;
  auto _mls_x1100 = _mlsValue::create<_mls_Nil>();
  _mls_retval = _mls_x1100;
  return _mls_retval;
}
_mlsValue _mls_str_to_list_default(_mlsValue _mls_x1102) {
  _mlsValue _mls_retval;
  auto _mls_x1101 = _mls_builtin_str_head(_mls_x1102);
  auto _mls_x1103 = _mls_builtin_str_tail(_mls_x1102);
  auto _mls_x1104 = _mls_str_to_list(_mls_x1103);
  auto _mls_x1105 = _mlsValue::create<_mls_Cons>(_mls_x1101, _mls_x1104);
  _mls_retval = _mls_x1105;
  return _mls_retval;
}
_mlsValue _mls_sum(_mlsValue _mls_xs5) {
  _mlsValue _mls_retval;
  auto _mls_x445 = _mls_go(_mls_xs5, _mlsValue::fromIntLit(0));
  _mls_retval = _mls_x445;
  return _mls_retval;
}
_mlsValue _mls_win1() {
  _mlsValue _mls_retval;
  auto _mls_x446 = _mlsValue::create<_mls_Nil>();
  auto _mls_x447 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x446);
  auto _mls_x448 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x447);
  auto _mls_x449 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x448);
  auto _mls_x450 = _mlsValue::create<_mls_Nil>();
  auto _mls_x451 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x450);
  auto _mls_x452 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x451);
  auto _mls_x453 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x452);
  auto _mls_x454 = _mlsValue::create<_mls_Nil>();
  auto _mls_x455 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x454);
  auto _mls_x456 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x455);
  auto _mls_x457 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x456);
  auto _mls_x458 = _mlsValue::create<_mls_Nil>();
  auto _mls_x459 = _mlsValue::create<_mls_Cons>(_mls_x457, _mls_x458);
  auto _mls_x460 = _mlsValue::create<_mls_Cons>(_mls_x453, _mls_x459);
  auto _mls_x461 = _mlsValue::create<_mls_Cons>(_mls_x449, _mls_x460);
  _mls_retval = _mls_x461;
  return _mls_retval;
}
_mlsValue _mls_win2() {
  _mlsValue _mls_retval;
  auto _mls_x462 = _mlsValue::create<_mls_Nil>();
  auto _mls_x463 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x462);
  auto _mls_x464 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x463);
  auto _mls_x465 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x464);
  auto _mls_x466 = _mlsValue::create<_mls_Nil>();
  auto _mls_x467 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x466);
  auto _mls_x468 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x467);
  auto _mls_x469 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x468);
  auto _mls_x470 = _mlsValue::create<_mls_Nil>();
  auto _mls_x471 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x470);
  auto _mls_x472 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x471);
  auto _mls_x473 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x472);
  auto _mls_x474 = _mlsValue::create<_mls_Nil>();
  auto _mls_x475 = _mlsValue::create<_mls_Cons>(_mls_x473, _mls_x474);
  auto _mls_x476 = _mlsValue::create<_mls_Cons>(_mls_x469, _mls_x475);
  auto _mls_x477 = _mlsValue::create<_mls_Cons>(_mls_x465, _mls_x476);
  _mls_retval = _mls_x477;
  return _mls_retval;
}
_mlsValue _mls_win3() {
  _mlsValue _mls_retval;
  auto _mls_x478 = _mlsValue::create<_mls_Nil>();
  auto _mls_x479 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x478);
  auto _mls_x480 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x479);
  auto _mls_x481 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x480);
  auto _mls_x482 = _mlsValue::create<_mls_Nil>();
  auto _mls_x483 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x482);
  auto _mls_x484 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x483);
  auto _mls_x485 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x484);
  auto _mls_x486 = _mlsValue::create<_mls_Nil>();
  auto _mls_x487 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x486);
  auto _mls_x488 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x487);
  auto _mls_x489 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x488);
  auto _mls_x490 = _mlsValue::create<_mls_Nil>();
  auto _mls_x491 = _mlsValue::create<_mls_Cons>(_mls_x489, _mls_x490);
  auto _mls_x492 = _mlsValue::create<_mls_Cons>(_mls_x485, _mls_x491);
  auto _mls_x493 = _mlsValue::create<_mls_Cons>(_mls_x481, _mls_x492);
  _mls_retval = _mls_x493;
  return _mls_retval;
}
_mlsValue _mls_win4() {
  _mlsValue _mls_retval;
  auto _mls_x494 = _mlsValue::create<_mls_Nil>();
  auto _mls_x495 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x494);
  auto _mls_x496 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x495);
  auto _mls_x497 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x496);
  auto _mls_x498 = _mlsValue::create<_mls_Nil>();
  auto _mls_x499 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x498);
  auto _mls_x500 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x499);
  auto _mls_x501 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x500);
  auto _mls_x502 = _mlsValue::create<_mls_Nil>();
  auto _mls_x503 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x502);
  auto _mls_x504 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x503);
  auto _mls_x505 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x504);
  auto _mls_x506 = _mlsValue::create<_mls_Nil>();
  auto _mls_x507 = _mlsValue::create<_mls_Cons>(_mls_x505, _mls_x506);
  auto _mls_x508 = _mlsValue::create<_mls_Cons>(_mls_x501, _mls_x507);
  auto _mls_x509 = _mlsValue::create<_mls_Cons>(_mls_x497, _mls_x508);
  _mls_retval = _mls_x509;
  return _mls_retval;
}
_mlsValue _mls_win5() {
  _mlsValue _mls_retval;
  auto _mls_x510 = _mlsValue::create<_mls_Nil>();
  auto _mls_x511 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x510);
  auto _mls_x512 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x511);
  auto _mls_x513 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x512);
  auto _mls_x514 = _mlsValue::create<_mls_Nil>();
  auto _mls_x515 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x514);
  auto _mls_x516 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x515);
  auto _mls_x517 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x516);
  auto _mls_x518 = _mlsValue::create<_mls_Nil>();
  auto _mls_x519 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x518);
  auto _mls_x520 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x519);
  auto _mls_x521 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x520);
  auto _mls_x522 = _mlsValue::create<_mls_Nil>();
  auto _mls_x523 = _mlsValue::create<_mls_Cons>(_mls_x521, _mls_x522);
  auto _mls_x524 = _mlsValue::create<_mls_Cons>(_mls_x517, _mls_x523);
  auto _mls_x525 = _mlsValue::create<_mls_Cons>(_mls_x513, _mls_x524);
  _mls_retval = _mls_x525;
  return _mls_retval;
}
_mlsValue _mls_win6() {
  _mlsValue _mls_retval;
  auto _mls_x526 = _mlsValue::create<_mls_Nil>();
  auto _mls_x527 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x526);
  auto _mls_x528 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x527);
  auto _mls_x529 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x528);
  auto _mls_x530 = _mlsValue::create<_mls_Nil>();
  auto _mls_x531 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x530);
  auto _mls_x532 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x531);
  auto _mls_x533 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x532);
  auto _mls_x534 = _mlsValue::create<_mls_Nil>();
  auto _mls_x535 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x534);
  auto _mls_x536 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x535);
  auto _mls_x537 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x536);
  auto _mls_x538 = _mlsValue::create<_mls_Nil>();
  auto _mls_x539 = _mlsValue::create<_mls_Cons>(_mls_x537, _mls_x538);
  auto _mls_x540 = _mlsValue::create<_mls_Cons>(_mls_x533, _mls_x539);
  auto _mls_x541 = _mlsValue::create<_mls_Cons>(_mls_x529, _mls_x540);
  _mls_retval = _mls_x541;
  return _mls_retval;
}
_mlsValue _mls_win7() {
  _mlsValue _mls_retval;
  auto _mls_x542 = _mlsValue::create<_mls_Nil>();
  auto _mls_x543 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x542);
  auto _mls_x544 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x543);
  auto _mls_x545 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x544);
  auto _mls_x546 = _mlsValue::create<_mls_Nil>();
  auto _mls_x547 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x546);
  auto _mls_x548 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x547);
  auto _mls_x549 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x548);
  auto _mls_x550 = _mlsValue::create<_mls_Nil>();
  auto _mls_x551 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x550);
  auto _mls_x552 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x551);
  auto _mls_x553 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x552);
  auto _mls_x554 = _mlsValue::create<_mls_Nil>();
  auto _mls_x555 = _mlsValue::create<_mls_Cons>(_mls_x553, _mls_x554);
  auto _mls_x556 = _mlsValue::create<_mls_Cons>(_mls_x549, _mls_x555);
  auto _mls_x557 = _mlsValue::create<_mls_Cons>(_mls_x545, _mls_x556);
  _mls_retval = _mls_x557;
  return _mls_retval;
}
_mlsValue _mls_win8() {
  _mlsValue _mls_retval;
  auto _mls_x558 = _mlsValue::create<_mls_Nil>();
  auto _mls_x559 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x558);
  auto _mls_x560 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x559);
  auto _mls_x561 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x560);
  auto _mls_x562 = _mlsValue::create<_mls_Nil>();
  auto _mls_x563 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x562);
  auto _mls_x564 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x563);
  auto _mls_x565 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x564);
  auto _mls_x566 = _mlsValue::create<_mls_Nil>();
  auto _mls_x567 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x566);
  auto _mls_x568 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(0), _mls_x567);
  auto _mls_x569 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x568);
  auto _mls_x570 = _mlsValue::create<_mls_Nil>();
  auto _mls_x571 = _mlsValue::create<_mls_Cons>(_mls_x569, _mls_x570);
  auto _mls_x572 = _mlsValue::create<_mls_Cons>(_mls_x565, _mls_x571);
  auto _mls_x573 = _mlsValue::create<_mls_Cons>(_mls_x561, _mls_x572);
  _mls_retval = _mls_x573;
  return _mls_retval;
}
_mlsValue _mls_wins() {
  _mlsValue _mls_retval;
  auto _mls_x574 = _mls_win1();
  auto _mls_x575 = _mls_win2();
  auto _mls_x576 = _mls_win3();
  auto _mls_x577 = _mls_win4();
  auto _mls_x578 = _mls_win5();
  auto _mls_x579 = _mls_win6();
  auto _mls_x580 = _mls_win7();
  auto _mls_x581 = _mls_win8();
  auto _mls_x582 = _mlsValue::create<_mls_Nil>();
  auto _mls_x583 = _mlsValue::create<_mls_Cons>(_mls_x581, _mls_x582);
  auto _mls_x584 = _mlsValue::create<_mls_Cons>(_mls_x580, _mls_x583);
  auto _mls_x585 = _mlsValue::create<_mls_Cons>(_mls_x579, _mls_x584);
  auto _mls_x586 = _mlsValue::create<_mls_Cons>(_mls_x578, _mls_x585);
  auto _mls_x587 = _mlsValue::create<_mls_Cons>(_mls_x577, _mls_x586);
  auto _mls_x588 = _mlsValue::create<_mls_Cons>(_mls_x576, _mls_x587);
  auto _mls_x589 = _mlsValue::create<_mls_Cons>(_mls_x575, _mls_x588);
  auto _mls_x590 = _mlsValue::create<_mls_Cons>(_mls_x574, _mls_x589);
  _mls_retval = _mls_x590;
  return _mls_retval;
}
_mlsValue _mls_Lambda_best_::_mls_apply4(_mlsValue _mls_b, _mlsValue _mls_s, _mlsValue _mls_ls1, _mlsValue _mls_ls2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls1)) {
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls2)) {
      auto _mls_x8 = _mlsValue::create<_mls_Tuple2>(_mls_b, _mls_s);
      _mls_retval = _mls_x8;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls1)) {
    auto _mls_x = _mlsValue::cast<_mls_Cons>(_mls_ls1)->_mls_head;
    auto _mls_x1 = _mlsValue::cast<_mls_Cons>(_mls_ls1)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls2)) {
      auto _mls_x2 = _mlsValue::cast<_mls_Cons>(_mls_ls2)->_mls_head;
      auto _mls_x3 = _mlsValue::cast<_mls_Cons>(_mls_ls2)->_mls_tail;
      auto _mls_x4 = _mlsMethodCall<_mls_Callable>(_mls_lam_arg0)->_mls_apply2(_mls_s, _mls_x2);
      auto _mls_x5 = _mls_evaluationEq(_mls_s, _mls_x4);
      if (_mlsValue::isIntLit(_mls_x5, 1)) {
        auto _mls_x7 = this->_mls_apply4(_mls_b, _mls_s, _mls_x1, _mls_x3);
        _mls_retval = _mls_x7;
      } else {
        auto _mls_x6 = this->_mls_apply4(_mls_x, _mls_x2, _mls_x1, _mls_x3);
        _mls_retval = _mls_x6;
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_board::_mls_apply1(_mlsValue _mls_x35) {
  _mlsValue _mls_retval;
  auto _mls_x9 = _mlsValue::create<_mls_Empty>();
  auto _mls_x10 = _mlsValue::create<_mls_Nil>();
  auto _mls_x11 = _mlsValue::create<_mls_Cons>(_mls_x9, _mls_x10);
  auto _mls_x12 = _mlsValue::create<_mls_O>();
  auto _mls_x13 = _mlsValue::create<_mls_Cons>(_mls_x12, _mls_x11);
  auto _mls_x14 = _mlsValue::create<_mls_Empty>();
  auto _mls_x15 = _mlsValue::create<_mls_Cons>(_mls_x14, _mls_x13);
  auto _mls_x16 = _mlsValue::create<_mls_Empty>();
  auto _mls_x17 = _mlsValue::create<_mls_Nil>();
  auto _mls_x18 = _mlsValue::create<_mls_Cons>(_mls_x16, _mls_x17);
  auto _mls_x19 = _mlsValue::create<_mls_X>();
  auto _mls_x20 = _mlsValue::create<_mls_Cons>(_mls_x19, _mls_x18);
  auto _mls_x21 = _mlsValue::create<_mls_Empty>();
  auto _mls_x22 = _mlsValue::create<_mls_Cons>(_mls_x21, _mls_x20);
  auto _mls_x23 = _mlsValue::create<_mls_Empty>();
  auto _mls_x24 = _mlsValue::create<_mls_Nil>();
  auto _mls_x25 = _mlsValue::create<_mls_Cons>(_mls_x23, _mls_x24);
  auto _mls_x26 = _mlsValue::create<_mls_Empty>();
  auto _mls_x27 = _mlsValue::create<_mls_Cons>(_mls_x26, _mls_x25);
  auto _mls_x28 = _mlsValue::create<_mls_Empty>();
  auto _mls_x29 = _mlsValue::create<_mls_Cons>(_mls_x28, _mls_x27);
  auto _mls_x30 = _mlsValue::create<_mls_Nil>();
  auto _mls_x31 = _mlsValue::create<_mls_Cons>(_mls_x29, _mls_x30);
  auto _mls_x32 = _mlsValue::create<_mls_Cons>(_mls_x22, _mls_x31);
  auto _mls_x33 = _mlsValue::create<_mls_Cons>(_mls_x15, _mls_x32);
  auto _mls_x34 = (_mls_x35 == _mlsValue::create<_mls_Str>("doesn't happen"));
  if (_mlsValue::isIntLit(_mls_x34, 1)) {
    auto _mls_x36 = _mls_append(_mls_x33, _mls_x33);
    _mls_retval = _mls_x36;
  } else {
    _mls_retval = _mls_x33;
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_cropTree::_mls_apply1(_mlsValue _mls_arg) {
  _mlsValue _mls_retval;
  auto _mls_x37 = _mls_cropTree(_mls_arg);
  _mls_retval = _mls_x37;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda::_mls_apply1(_mlsValue _mls_x38) {
  _mlsValue _mls_retval;
  auto _mls_x39 = _mls_mise(_mls_lam_arg0, _mls_lam_arg1, _mls_x38);
  _mls_retval = _mls_x39;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda1::_mls_apply1(_mlsValue _mls_x41) {
  _mlsValue _mls_retval;
  auto _mls_x40 = _mlsValue::create<_mls_Empty>();
  auto _mls_x42 = _mls_eqPiece(_mls_x41, _mls_x40);
  auto _mls_x43 = _mls_not(_mls_x42);
  _mls_retval = _mls_x43;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda10::_mls_apply2(_mlsValue _mls_x45, _mlsValue _mls_y) {
  _mlsValue _mls_retval;
  auto _mls_x44 = _mlsValue::create<_mls_Lambda_scorePiece>();
  auto _mls_x46 = _mls_map2(_mls_x44, _mls_x45, _mls_y);
  _mls_retval = _mls_x46;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda2::_mls_apply1(_mlsValue _mls_x48) {
  _mlsValue _mls_retval;
  auto _mls_x47 = (_mls_lam_arg0 - _mlsValue::fromIntLit(1));
  auto _mls_x49 = _mls_prune(_mls_x47, _mls_x48);
  _mls_retval = _mls_x49;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda3::_mls_apply1(_mlsValue _mls_pos) {
  _mlsValue _mls_retval;
  auto _mls_x50 = _mls_placePiece(_mls_lam_arg0, _mls_lam_arg1, _mls_pos);
  _mls_retval = _mls_x50;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda4::_mls_apply1(_mlsValue _mls_x52) {
  _mlsValue _mls_retval;
  auto _mls_x51 = _mls_opposite(_mls_lam_arg0);
  auto _mls_x53 = _mls_newPositions(_mls_x51, _mls_x52);
  _mls_retval = _mls_x53;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda5::_mls_apply1(_mlsValue _mls_x54) {
  _mlsValue _mls_retval;
  auto _mls_x55 = _mls_newPositions(_mls_lam_arg0, _mls_x54);
  _mls_retval = _mls_x55;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda6::_mls_apply1(_mlsValue _mls_x56) {
  _mlsValue _mls_retval;
  auto _mls_x57 = _mls_mapTree(_mls_lam_arg0, _mls_x56);
  _mls_retval = _mls_x57;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda7::_mls_apply1(_mlsValue _mls_x58) {
  _mlsValue _mls_retval;
  auto _mls_x59 = _mls_repTree(_mls_lam_arg0, _mls_lam_arg1, _mls_x58);
  _mls_retval = _mls_x59;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda8::_mls_apply1(_mlsValue _mls_x60) {
  _mlsValue _mls_retval;
  auto _mls_x61 = _mls_score(_mls_lam_arg0, _mls_x60);
  _mls_retval = _mls_x61;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda9::_mls_apply1(_mlsValue _mls_x62) {
  _mlsValue _mls_retval;
  auto _mls_x63 = _mls_bestMove(_mls_lam_arg1, _mls_lam_arg2, _mls_lam_arg0, _mls_x62);
  _mls_retval = _mls_x63;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lscomp1::_mls_apply1(_mlsValue _mls_ls) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls)) {
    auto _mls_x72 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x72;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls)) {
    auto _mls_x64 = _mlsValue::cast<_mls_Cons>(_mls_ls)->_mls_head;
    auto _mls_x65 = _mlsValue::cast<_mls_Cons>(_mls_ls)->_mls_tail;
    auto _mls_x66 = _mlsValue::create<_mls_Lambda_lscomp2>(_mls_x65, _mls_x64, _mlsValue(this, _mlsValue::inc_ref_tag{}));
    auto _mls_x67 = _mlsValue::create<_mls_Nil>();
    auto _mls_x68 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(3), _mls_x67);
    auto _mls_x69 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(2), _mls_x68);
    auto _mls_x70 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x69);
    auto _mls_x71 = _mlsMethodCall<_mls_Callable>(_mls_x66)->_mls_apply1(_mls_x70);
    _mls_retval = _mls_x71;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lscomp2::_mls_apply1(_mlsValue _mls_ls3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls3)) {
    auto _mls_x78 = _mlsMethodCall<_mls_Callable>(_mls_lam_arg2)->_mls_apply1(_mls_lam_arg0);
    _mls_retval = _mls_x78;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls3)) {
    auto _mls_x73 = _mlsValue::cast<_mls_Cons>(_mls_ls3)->_mls_head;
    auto _mls_x74 = _mlsValue::cast<_mls_Cons>(_mls_ls3)->_mls_tail;
    auto _mls_x75 = this->_mls_apply1(_mls_x74);
    auto _mls_x76 = _mlsValue::create<_mls_Tuple2>(_mls_lam_arg1, _mls_x73);
    auto _mls_x77 = _mlsValue::create<_mls_Cons>(_mls_x76, _mls_x75);
    _mls_retval = _mls_x77;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_max_::_mls_apply2(_mlsValue _mls_arg1, _mlsValue _mls_arg2) {
  _mlsValue _mls_retval;
  auto _mls_x79 = _mls_max_(_mls_arg1, _mls_arg2);
  _mls_retval = _mls_x79;
  return _mls_retval;
}
_mlsValue _mls_Lambda_min_::_mls_apply2(_mlsValue _mls_arg3, _mlsValue _mls_arg4) {
  _mlsValue _mls_retval;
  auto _mls_x80 = _mls_min_(_mls_arg3, _mls_arg4);
  _mls_retval = _mls_x80;
  return _mls_retval;
}
_mlsValue _mls_Lambda_scorePiece::_mls_apply2(_mlsValue _mls_arg5, _mlsValue _mls_arg6) {
  _mlsValue _mls_retval;
  auto _mls_x81 = _mls_scorePiece(_mls_arg5, _mls_arg6);
  _mls_retval = _mls_x81;
  return _mls_retval;
}
_mlsValue _mls_Lambda_showMove::_mls_apply1(_mlsValue _mls_arg7) {
  _mlsValue _mls_retval;
  auto _mls_x82 = _mls_showMove(_mls_arg7);
  _mls_retval = _mls_x82;
  return _mls_retval;
}
_mlsValue _mls_Lambda_static::_mls_apply1(_mlsValue _mls_arg8) {
  _mlsValue _mls_retval;
  auto _mls_x83 = _mls_static1(_mls_arg8);
  _mls_retval = _mls_x83;
  return _mls_retval;
}
_mlsValue _mls_Lambda_sum::_mls_apply1(_mlsValue _mls_arg9) {
  _mlsValue _mls_retval;
  auto _mls_x84 = _mls_sum(_mls_arg9);
  _mls_retval = _mls_x84;
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
