#include "mlsprelude.h"
struct _mls_Tuple2;
struct _mls_List;
struct _mls_Cons;
struct _mls_Tuple3;
struct _mls_LamF2;
struct _mls_Nil;
struct _mls_LamF1;
_mlsValue _mls_quotRem(_mlsValue, _mlsValue);
_mlsValue _mls_test(_mlsValue);
_mlsValue _mls_enumFromTo(_mlsValue, _mlsValue);
_mlsValue _mls_gcdE(_mlsValue, _mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_lscomp2(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_g(_mlsValue, _mlsValue);
_mlsValue _mls_map(_mlsValue, _mlsValue);
_mlsValue _mls_lscomp1(_mlsValue, _mlsValue);
_mlsValue _mls_apply(_mlsValue, _mlsValue);
_mlsValue _mls_max_(_mlsValue);
struct _mls_Tuple2: public _mlsObject {
  _mlsValue _mls_field0;
  _mlsValue _mls_field1;
  constexpr static inline const char *typeName = "Tuple2";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_field0.print(); std::printf(", "); this->_mls_field1.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_field0); _mlsValue::destroy(this->_mls_field1);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_field0.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field0.asObject()) && this->_mls_field1.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field1.asObject()); }
  static _mlsValue create(_mlsValue _mls_field0, _mlsValue _mls_field1) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Tuple2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_field0 = _mls_field0; _mlsVal->_mls_field1 = _mls_field1;  return _mlsValue(_mlsVal); }
  
};
struct _mls_List: public _mlsObject {
  
  constexpr static inline const char *typeName = "List";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_List; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Cons: public _mls_List {
  _mlsValue _mls_head;
  _mlsValue _mls_tail;
  constexpr static inline const char *typeName = "Cons";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_head.print(); std::printf(", "); this->_mls_tail.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_head); _mlsValue::destroy(this->_mls_tail);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_head.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_head.asObject()) && this->_mls_tail.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_tail.asObject()); }
  static _mlsValue create(_mlsValue _mls_head, _mlsValue _mls_tail) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Cons; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_head = _mls_head; _mlsVal->_mls_tail = _mls_tail;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Tuple3: public _mlsObject {
  _mlsValue _mls_field0;
  _mlsValue _mls_field1;
  _mlsValue _mls_field2;
  constexpr static inline const char *typeName = "Tuple3";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_field0.print(); std::printf(", "); this->_mls_field1.print(); std::printf(", "); this->_mls_field2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_field0); _mlsValue::destroy(this->_mls_field1); _mlsValue::destroy(this->_mls_field2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_field0.asObject()->operator==(*other.cast<_mls_Tuple3>()->_mls_field0.asObject()) && this->_mls_field1.asObject()->operator==(*other.cast<_mls_Tuple3>()->_mls_field1.asObject()) && this->_mls_field2.asObject()->operator==(*other.cast<_mls_Tuple3>()->_mls_field2.asObject()); }
  static _mlsValue create(_mlsValue _mls_field0, _mlsValue _mls_field1, _mlsValue _mls_field2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Tuple3; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_field0 = _mls_field0; _mlsVal->_mls_field1 = _mls_field1; _mlsVal->_mls_field2 = _mls_field2;  return _mlsValue(_mlsVal); }
  
};
struct _mls_LamF2: public _mlsObject {
  
  constexpr static inline const char *typeName = "LamF2";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_LamF2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Nil: public _mls_List {
  
  constexpr static inline const char *typeName = "Nil";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Nil; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_LamF1: public _mlsObject {
  
  constexpr static inline const char *typeName = "LamF1";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_LamF1; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_quotRem(_mlsValue _mls_a, _mlsValue _mls_b) {
  _mlsValue _mls_retval;
  auto _mls_x4 = _mls_builtin_trunc_div(_mls_a, _mls_b);
  auto _mls_x5 = _mls_builtin_trunc_mod(_mls_a, _mls_b);
  auto _mls_x6 = _mlsValue::create<_mls_Tuple2>(_mls_x4, _mls_x5);
  _mls_retval = _mls_x6;
  return _mls_retval;
}
_mlsValue _mls_test(_mlsValue _mls_d) {
  _mlsValue _mls_retval;
  auto _mls_x36 = (_mlsValue::fromIntLit(5000) + _mls_d);
  auto _mls_x37 = _mls_enumFromTo(_mlsValue::fromIntLit(5000), _mls_x36);
  auto _mls_x38 = (_mlsValue::fromIntLit(10000) + _mls_d);
  auto _mls_x39 = _mls_enumFromTo(_mlsValue::fromIntLit(10000), _mls_x38);
  auto _mls_x40 = _mls_lscomp1(_mls_x37, _mls_x39);
  auto _mls_x41 = _mlsValue::create<_mls_LamF1>();
  auto _mls_x42 = _mls_map(_mls_x41, _mls_x40);
  auto _mls_x43 = _mlsValue::create<_mls_LamF2>();
  auto _mls_x44 = _mls_map(_mls_x43, _mls_x42);
  auto _mls_x45 = _mls_max_(_mls_x44);
  _mls_retval = _mls_x45;
  return _mls_retval;
}
_mlsValue _mls_enumFromTo(_mlsValue _mls_a1, _mlsValue _mls_b1) {
  _mlsValue _mls_retval;
  auto _mls_x7 = (_mls_a1 <= _mls_b1);
  if (_mlsValue::isIntLit(_mls_x7, 1)) {
    auto _mls_x9 = (_mls_a1 + _mlsValue::fromIntLit(1));
    auto _mls_x10 = _mls_enumFromTo(_mls_x9, _mls_b1);
    auto _mls_x11 = _mlsValue::create<_mls_Cons>(_mls_a1, _mls_x10);
    _mls_retval = _mls_x11;
  } else {
    auto _mls_x8 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x8;
  }
  return _mls_retval;
}
_mlsValue _mls_max_(_mlsValue _mls_ls) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls)) {
    auto _mls_x70 = _mlsValue::cast<_mls_Cons>(_mls_ls)->_mls_head;
    auto _mls_x71 = _mlsValue::cast<_mls_Cons>(_mls_ls)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x71)) {
      _mls_retval = _mls_x70;
    } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x71)) {
      auto _mls_x72 = _mlsValue::cast<_mls_Cons>(_mls_x71)->_mls_head;
      auto _mls_x73 = _mlsValue::cast<_mls_Cons>(_mls_x71)->_mls_tail;
      auto _mls_x74 = (_mls_x70 < _mls_x72);
      if (_mlsValue::isIntLit(_mls_x74, 1)) {
        auto _mls_x77 = _mlsValue::create<_mls_Cons>(_mls_x72, _mls_x73);
        auto _mls_x78 = _mls_max_(_mls_x77);
        _mls_retval = _mls_x78;
      } else {
        auto _mls_x75 = _mlsValue::create<_mls_Cons>(_mls_x70, _mls_x73);
        auto _mls_x76 = _mls_max_(_mls_x75);
        _mls_retval = _mls_x76;
      }
    } else {
      throw std::runtime_error("match error" LINE_STRING);
    }
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_lscomp1(_mlsValue _mls_p1, _mlsValue _mls_ms) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_p1)) {
    auto _mls_x3 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x3;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_p1)) {
    auto _mls_x = _mlsValue::cast<_mls_Cons>(_mls_p1)->_mls_head;
    auto _mls_x1 = _mlsValue::cast<_mls_Cons>(_mls_p1)->_mls_tail;
    auto _mls_x2 = _mls_lscomp2(_mls_x, _mls_x1, _mls_ms, _mls_ms);
    _mls_retval = _mls_x2;
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_map(_mlsValue _mls_f1, _mlsValue _mls_xs1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs1)) {
    auto _mls_x31 = _mlsValue::cast<_mls_Cons>(_mls_xs1)->_mls_head;
    auto _mls_x32 = _mlsValue::cast<_mls_Cons>(_mls_xs1)->_mls_tail;
    auto _mls_x33 = _mls_apply(_mls_f1, _mls_x31);
    auto _mls_x34 = _mls_map(_mls_f1, _mls_x32);
    auto _mls_x35 = _mlsValue::create<_mls_Cons>(_mls_x33, _mls_x34);
    _mls_retval = _mls_x35;
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs1)) {
    auto _mls_x30 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x30;
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_g(_mlsValue _mls_u1u2u3, _mlsValue _mls_v1v2v3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_u1u2u3)) {
    auto _mls_x52 = _mlsValue::cast<_mls_Tuple3>(_mls_u1u2u3)->_mls_field0;
    auto _mls_x53 = _mlsValue::cast<_mls_Tuple3>(_mls_u1u2u3)->_mls_field1;
    auto _mls_x54 = _mlsValue::cast<_mls_Tuple3>(_mls_u1u2u3)->_mls_field2;
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_v1v2v3)) {
      auto _mls_x55 = _mlsValue::cast<_mls_Tuple3>(_mls_v1v2v3)->_mls_field0;
      auto _mls_x56 = _mlsValue::cast<_mls_Tuple3>(_mls_v1v2v3)->_mls_field1;
      auto _mls_x57 = _mlsValue::cast<_mls_Tuple3>(_mls_v1v2v3)->_mls_field2;
      auto _mls_x58 = (_mls_x57 == _mlsValue::fromIntLit(0));
      if (_mlsValue::isIntLit(_mls_x58, 1)) {
        auto _mls_x69 = _mlsValue::create<_mls_Tuple3>(_mls_x54, _mls_x52, _mls_x53);
        _mls_retval = _mls_x69;
      } else {
        auto _mls_x59 = _mls_quotRem(_mls_x54, _mls_x57);
        if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x59)) {
          auto _mls_x60 = _mlsValue::cast<_mls_Tuple2>(_mls_x59)->_mls_field0;
          auto _mls_x61 = _mlsValue::cast<_mls_Tuple2>(_mls_x59)->_mls_field1;
          auto _mls_x62 = (_mls_x60 * _mls_x55);
          auto _mls_x63 = (_mls_x52 - _mls_x62);
          auto _mls_x64 = (_mls_x60 * _mls_x56);
          auto _mls_x65 = (_mls_x53 - _mls_x64);
          auto _mls_x66 = _mlsValue::create<_mls_Tuple3>(_mls_x55, _mls_x56, _mls_x57);
          auto _mls_x67 = _mlsValue::create<_mls_Tuple3>(_mls_x63, _mls_x65, _mls_x61);
          auto _mls_x68 = _mls_g(_mls_x66, _mls_x67);
          _mls_retval = _mls_x68;
        } else {
          throw std::runtime_error("match error" LINE_STRING);
        }
      }
    } else {
      throw std::runtime_error("match error" LINE_STRING);
    }
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x29 = _mls_test(_mlsValue::fromIntLit(1500));
  _mls_retval = _mls_x29;
  return _mls_retval;
}
_mlsValue _mls_gcdE(_mlsValue _mls_x47, _mlsValue _mls_y) {
  _mlsValue _mls_retval;
  auto _mls_x46 = (_mls_x47 == _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x46, 1)) {
    auto _mls_x51 = _mlsValue::create<_mls_Tuple3>(_mls_y, _mlsValue::fromIntLit(0), _mlsValue::fromIntLit(1));
    _mls_retval = _mls_x51;
  } else {
    auto _mls_x48 = _mlsValue::create<_mls_Tuple3>(_mlsValue::fromIntLit(1), _mlsValue::fromIntLit(0), _mls_x47);
    auto _mls_x49 = _mlsValue::create<_mls_Tuple3>(_mlsValue::fromIntLit(0), _mlsValue::fromIntLit(1), _mls_y);
    auto _mls_x50 = _mls_g(_mls_x48, _mls_x49);
    _mls_retval = _mls_x50;
  }
  return _mls_retval;
}
_mlsValue _mls_apply(_mlsValue _mls_f, _mlsValue _mls_xs) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_LamF1>(_mls_f)) {
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_xs)) {
      auto _mls_x19 = _mlsValue::cast<_mls_Tuple2>(_mls_xs)->_mls_field0;
      auto _mls_x20 = _mlsValue::cast<_mls_Tuple2>(_mls_xs)->_mls_field1;
      auto _mls_x21 = _mls_gcdE(_mls_x19, _mls_x20);
      auto _mls_x22 = _mlsValue::create<_mls_Tuple3>(_mls_x19, _mls_x20, _mls_x21);
      _mls_retval = _mls_x22;
    } else {
      throw std::runtime_error("match error" LINE_STRING);
    }
  } else if (_mlsValue::isValueOf<_mls_LamF2>(_mls_f)) {
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_xs)) {
      auto _mls_x12 = _mlsValue::cast<_mls_Tuple3>(_mls_xs)->_mls_field2;
      if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x12)) {
        auto _mls_x13 = _mlsValue::cast<_mls_Tuple3>(_mls_x12)->_mls_field0;
        auto _mls_x14 = _mlsValue::cast<_mls_Tuple3>(_mls_x12)->_mls_field1;
        auto _mls_x15 = _mlsValue::cast<_mls_Tuple3>(_mls_x12)->_mls_field2;
        auto _mls_x16 = (_mls_x13 + _mls_x14);
        auto _mls_x17 = (_mls_x16 + _mls_x15);
        auto _mls_x18 = _mls_builtin_abs(_mls_x17);
        _mls_retval = _mls_x18;
      } else {
        throw std::runtime_error("match error" LINE_STRING);
      }
    } else {
      throw std::runtime_error("match error" LINE_STRING);
    }
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_lscomp2(_mlsValue _mls_h1, _mlsValue _mls_t1, _mlsValue _mls_p2, _mlsValue _mls_initMs) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_p2)) {
    auto _mls_x28 = _mls_lscomp1(_mls_t1, _mls_initMs);
    _mls_retval = _mls_x28;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_p2)) {
    auto _mls_x23 = _mlsValue::cast<_mls_Cons>(_mls_p2)->_mls_head;
    auto _mls_x24 = _mlsValue::cast<_mls_Cons>(_mls_p2)->_mls_tail;
    auto _mls_x25 = _mls_lscomp2(_mls_h1, _mls_t1, _mls_x24, _mls_initMs);
    auto _mls_x26 = _mlsValue::create<_mls_Tuple2>(_mls_h1, _mls_x23);
    auto _mls_x27 = _mlsValue::create<_mls_Cons>(_mls_x26, _mls_x25);
    _mls_retval = _mls_x27;
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
