#include "mlsprelude.h"
struct _mls_Lambda_delete_;
struct _mls_Lambda_lambda;
struct _mls_Lambda_lambda1;
struct _mls_Lambda_lambda10;
struct _mls_Lambda_lambda11;
struct _mls_Lambda_lambda2;
struct _mls_Lambda_lambda3;
struct _mls_Lambda_lambda4;
struct _mls_Lambda_lambda5;
struct _mls_Lambda_lambda6;
struct _mls_Lambda_lambda7;
struct _mls_Lambda_lambda8;
struct _mls_Lambda_lambda9;
struct _mls_List;
struct _mls_Cons;
struct _mls_Nil;
struct _mls_Tuple2;
_mlsValue _mls_append(_mlsValue, _mlsValue);
_mlsValue _mls_atleast(_mlsValue, _mlsValue);
_mlsValue _mls_award(_mlsValue, _mlsValue);
_mlsValue _mls_awards(_mlsValue);
_mlsValue _mls_competitors(_mlsValue);
_mlsValue _mls_delete1(_mlsValue, _mlsValue);
_mlsValue _mls_delete_(_mlsValue, _mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_enumFromTo(_mlsValue, _mlsValue);
_mlsValue _mls_filter(_mlsValue, _mlsValue);
_mlsValue _mls_findallawards(_mlsValue);
_mlsValue _mls_findawards(_mlsValue);
_mlsValue _mls_foldl(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_intMod(_mlsValue, _mlsValue);
_mlsValue _mls_leTup2(_mlsValue, _mlsValue);
_mlsValue _mls_listDiff(_mlsValue, _mlsValue);
_mlsValue _mls_ltList(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_ltTup2(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_map(_mlsValue, _mlsValue);
_mlsValue _mls_perms(_mlsValue, _mlsValue);
_mlsValue _mls_print(_mlsValue);
_mlsValue _mls_qpart(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_qsort(_mlsValue, _mlsValue);
_mlsValue _mls_rqpart(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_rqsort(_mlsValue, _mlsValue);
_mlsValue _mls_sort(_mlsValue);
_mlsValue _mls_sum(_mlsValue);
_mlsValue _mls_sum_go(_mlsValue, _mlsValue);
_mlsValue _mls_testAwards_nofib(_mlsValue);
struct _mls_Lambda_delete_: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_delete_";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_delete_; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_lambda: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda1: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda1; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda10: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda10; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda11: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda11; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_lambda2: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda2>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda3: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda3; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda4: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda4>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda4; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda5: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda5; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda6: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda6; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_lambda7: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda7; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_lambda8: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda8; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_lambda9: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda9; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_List: public _mlsObject {
  
  constexpr static inline const char *typeName = "List";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_List; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Cons: public _mls_List {
  _mlsValue _mls_head;
  _mlsValue _mls_tail;
  constexpr static inline const char *typeName = "Cons";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_head.print(); std::printf(", "); this->_mls_tail.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_head); _mlsValue::destroy(this->_mls_tail);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_head.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_head.asObject()) && this->_mls_tail.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_tail.asObject()); }
  static _mlsValue create(_mlsValue _mls_head, _mlsValue _mls_tail) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Cons; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_head = _mls_head; _mlsVal->_mls_tail = _mls_tail;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Nil: public _mls_List {
  
  constexpr static inline const char *typeName = "Nil";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Nil; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Tuple2: public _mlsObject {
  _mlsValue _mls_field0;
  _mlsValue _mls_field1;
  constexpr static inline const char *typeName = "Tuple2";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_field0.print(); std::printf(", "); this->_mls_field1.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_field0); _mlsValue::destroy(this->_mls_field1);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_field0.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field0.asObject()) && this->_mls_field1.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field1.asObject()); }
  static _mlsValue create(_mlsValue _mls_field0, _mlsValue _mls_field1) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Tuple2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_field0 = _mls_field0; _mlsVal->_mls_field1 = _mls_field1;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_append(_mlsValue _mls_xs, _mlsValue _mls_ys) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs)) {
    _mls_retval = _mls_ys;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs)) {
    auto _mls_x28 = _mlsValue::cast<_mls_Cons>(_mls_xs)->_mls_head;
    auto _mls_x29 = _mlsValue::cast<_mls_Cons>(_mls_xs)->_mls_tail;
    auto _mls_x30 = _mls_append(_mls_x29, _mls_ys);
    auto _mls_x31 = _mlsValue::create<_mls_Cons>(_mls_x28, _mls_x30);
    _mls_retval = _mls_x31;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_atleast(_mlsValue _mls_sumscores, _mlsValue _mls_threshold) {
  _mlsValue _mls_retval;
  auto _mls_x32 = _mlsValue::create<_mls_Lambda_lambda2>(_mls_threshold);
  auto _mls_x33 = _mls_filter(_mls_x32, _mls_sumscores);
  _mls_retval = _mls_x33;
  return _mls_retval;
}
_mlsValue _mls_award(_mlsValue _mls_sumscores1, _mlsValue _mls_name_threshold) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_name_threshold)) {
    auto _mls_x34 = _mlsValue::cast<_mls_Tuple2>(_mls_name_threshold)->_mls_field0;
    auto _mls_x35 = _mlsValue::cast<_mls_Tuple2>(_mls_name_threshold)->_mls_field1;
    auto _mls_x36 = _mls_atleast(_mls_sumscores1, _mls_x35);
    auto _mls_x37 = _mls_sort(_mls_x36);
    auto _mls_x38 = _mlsValue::create<_mls_Lambda_lambda>(_mls_x34);
    auto _mls_x39 = _mls_map(_mls_x38, _mls_x37);
    _mls_retval = _mls_x39;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_awards(_mlsValue _mls_scores) {
  _mlsValue _mls_retval;
  auto _mls_x40 = _mls_perms(_mlsValue::fromIntLit(3), _mls_scores);
  auto _mls_x41 = _mlsValue::create<_mls_Lambda_lambda5>();
  auto _mls_x42 = _mls_map(_mls_x41, _mls_x40);
  auto _mls_x43 = _mlsValue::create<_mls_Tuple2>(_mlsValue::create<_mls_Str>("Gold"), _mlsValue::fromIntLit(70));
  auto _mls_x44 = _mls_award(_mls_x42, _mls_x43);
  auto _mls_x45 = _mlsValue::create<_mls_Tuple2>(_mlsValue::create<_mls_Str>("Silver"), _mlsValue::fromIntLit(60));
  auto _mls_x46 = _mls_award(_mls_x42, _mls_x45);
  auto _mls_x47 = _mlsValue::create<_mls_Tuple2>(_mlsValue::create<_mls_Str>("Bronze"), _mlsValue::fromIntLit(50));
  auto _mls_x48 = _mls_award(_mls_x42, _mls_x47);
  auto _mls_x49 = _mls_append(_mls_x46, _mls_x48);
  auto _mls_x50 = _mls_append(_mls_x44, _mls_x49);
  _mls_retval = _mls_x50;
  return _mls_retval;
}
_mlsValue _mls_competitors(_mlsValue _mls_i) {
  _mlsValue _mls_retval;
  auto _mls_x51 = _mlsValue::create<_mls_Nil>();
  auto _mls_x52 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(21), _mls_x51);
  auto _mls_x53 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(34), _mls_x52);
  auto _mls_x54 = _mlsValue::create<_mls_Cons>(_mls_i, _mls_x53);
  auto _mls_x55 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(40), _mls_x54);
  auto _mls_x56 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(27), _mls_x55);
  auto _mls_x57 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(35), _mls_x56);
  auto _mls_x58 = _mlsValue::create<_mls_Nil>();
  auto _mls_x59 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(14), _mls_x58);
  auto _mls_x60 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(8), _mls_x59);
  auto _mls_x61 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(5), _mls_x60);
  auto _mls_x62 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(10), _mls_x61);
  auto _mls_x63 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(17), _mls_x62);
  auto _mls_x64 = _mlsValue::create<_mls_Cons>(_mls_i, _mls_x63);
  auto _mls_x65 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(45), _mls_x64);
  auto _mls_x66 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(19), _mls_x65);
  auto _mls_x67 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(23), _mls_x66);
  auto _mls_x68 = _mlsValue::create<_mls_Nil>();
  auto _mls_x69 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(21), _mls_x68);
  auto _mls_x70 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(16), _mls_x69);
  auto _mls_x71 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(8), _mls_x70);
  auto _mls_x72 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(34), _mls_x71);
  auto _mls_x73 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(19), _mls_x72);
  auto _mls_x74 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(21), _mls_x73);
  auto _mls_x75 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(20), _mls_x74);
  auto _mls_x76 = _mlsValue::create<_mls_Cons>(_mls_i, _mls_x75);
  auto _mls_x77 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(18), _mls_x76);
  auto _mls_x78 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x77);
  auto _mls_x79 = _mlsValue::create<_mls_Nil>();
  auto _mls_x80 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(14), _mls_x79);
  auto _mls_x81 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(18), _mls_x80);
  auto _mls_x82 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(9), _mls_x81);
  auto _mls_x83 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(41), _mls_x82);
  auto _mls_x84 = _mlsValue::create<_mls_Cons>(_mls_i, _mls_x83);
  auto _mls_x85 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(54), _mls_x84);
  auto _mls_x86 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(17), _mls_x85);
  auto _mls_x87 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(23), _mls_x86);
  auto _mls_x88 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(9), _mls_x87);
  auto _mls_x89 = _mlsValue::create<_mls_Tuple2>(_mlsValue::create<_mls_Str>("Kevin"), _mls_x88);
  auto _mls_x90 = _mlsValue::create<_mls_Nil>();
  auto _mls_x91 = _mlsValue::create<_mls_Cons>(_mls_x89, _mls_x90);
  auto _mls_x92 = _mlsValue::create<_mls_Tuple2>(_mlsValue::create<_mls_Str>("Phil"), _mls_x78);
  auto _mls_x93 = _mlsValue::create<_mls_Cons>(_mls_x92, _mls_x91);
  auto _mls_x94 = _mlsValue::create<_mls_Tuple2>(_mlsValue::create<_mls_Str>("Hans"), _mls_x67);
  auto _mls_x95 = _mlsValue::create<_mls_Cons>(_mls_x94, _mls_x93);
  auto _mls_x96 = _mlsValue::create<_mls_Tuple2>(_mlsValue::create<_mls_Str>("Simon"), _mls_x57);
  auto _mls_x97 = _mlsValue::create<_mls_Cons>(_mls_x96, _mls_x95);
  _mls_retval = _mls_x97;
  return _mls_retval;
}
_mlsValue _mls_delete1(_mlsValue _mls_x101, _mlsValue _mls_ys1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ys1)) {
    auto _mls_x104 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x104;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ys1)) {
    auto _mls_x98 = _mlsValue::cast<_mls_Cons>(_mls_ys1)->_mls_head;
    auto _mls_x99 = _mlsValue::cast<_mls_Cons>(_mls_ys1)->_mls_tail;
    auto _mls_x100 = (_mls_x101 == _mls_x98);
    if (_mlsValue::isIntLit(_mls_x100, 1)) {
      _mls_retval = _mls_x99;
    } else {
      auto _mls_x102 = _mls_delete1(_mls_x101, _mls_x99);
      auto _mls_x103 = _mlsValue::create<_mls_Cons>(_mls_x98, _mls_x102);
      _mls_retval = _mls_x103;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_delete_(_mlsValue _mls_xs1, _mlsValue _mls_e) {
  _mlsValue _mls_retval;
  auto _mls_x105 = _mls_delete1(_mls_e, _mls_xs1);
  _mls_retval = _mls_x105;
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x106 = _mls_testAwards_nofib(_mlsValue::fromIntLit(2000));
  _mls_retval = _mls_x106;
  return _mls_retval;
}
_mlsValue _mls_enumFromTo(_mlsValue _mls_a5, _mlsValue _mls_b5) {
  _mlsValue _mls_retval;
  auto _mls_x107 = (_mls_a5 <= _mls_b5);
  if (_mlsValue::isIntLit(_mls_x107, 1)) {
    auto _mls_x109 = (_mls_a5 + _mlsValue::fromIntLit(1));
    auto _mls_x110 = _mls_enumFromTo(_mls_x109, _mls_b5);
    auto _mls_x111 = _mlsValue::create<_mls_Cons>(_mls_a5, _mls_x110);
    _mls_retval = _mls_x111;
  } else {
    auto _mls_x108 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x108;
  }
  return _mls_retval;
}
_mlsValue _mls_filter(_mlsValue _mls_f, _mlsValue _mls_ls) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls)) {
    auto _mls_x118 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x118;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls)) {
    auto _mls_x112 = _mlsValue::cast<_mls_Cons>(_mls_ls)->_mls_head;
    auto _mls_x113 = _mlsValue::cast<_mls_Cons>(_mls_ls)->_mls_tail;
    auto _mls_x114 = _mlsMethodCall<_mls_Callable>(_mls_f)->_mls_apply1(_mls_x112);
    if (_mlsValue::isIntLit(_mls_x114, 1)) {
      auto _mls_x116 = _mls_filter(_mls_f, _mls_x113);
      auto _mls_x117 = _mlsValue::create<_mls_Cons>(_mls_x112, _mls_x116);
      _mls_retval = _mls_x117;
    } else {
      auto _mls_x115 = _mls_filter(_mls_f, _mls_x113);
      _mls_retval = _mls_x115;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_findallawards(_mlsValue _mls_competitors1) {
  _mlsValue _mls_retval;
  auto _mls_x119 = _mlsValue::create<_mls_Lambda_lambda3>();
  auto _mls_x120 = _mls_map(_mls_x119, _mls_competitors1);
  _mls_retval = _mls_x120;
  return _mls_retval;
}
_mlsValue _mls_findawards(_mlsValue _mls_scores1) {
  _mlsValue _mls_retval;
  auto _mls_x121 = _mls_awards(_mls_scores1);
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x121)) {
    auto _mls_x132 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x132;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x121)) {
    auto _mls_x122 = _mlsValue::cast<_mls_Cons>(_mls_x121)->_mls_head;
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x122)) {
      auto _mls_x123 = _mlsValue::cast<_mls_Tuple2>(_mls_x122)->_mls_field0;
      auto _mls_x124 = _mlsValue::cast<_mls_Tuple2>(_mls_x122)->_mls_field1;
      if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x124)) {
        auto _mls_x125 = _mlsValue::cast<_mls_Tuple2>(_mls_x124)->_mls_field0;
        auto _mls_x126 = _mlsValue::cast<_mls_Tuple2>(_mls_x124)->_mls_field1;
        auto _mls_x127 = _mls_listDiff(_mls_scores1, _mls_x126);
        auto _mls_x128 = _mls_findawards(_mls_x127);
        auto _mls_x129 = _mlsValue::create<_mls_Tuple2>(_mls_x125, _mls_x126);
        auto _mls_x130 = _mlsValue::create<_mls_Tuple2>(_mls_x123, _mls_x129);
        auto _mls_x131 = _mlsValue::create<_mls_Cons>(_mls_x130, _mls_x128);
        _mls_retval = _mls_x131;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_foldl(_mlsValue _mls_f1, _mlsValue _mls_a6, _mlsValue _mls_xs2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs2)) {
    _mls_retval = _mls_a6;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs2)) {
    auto _mls_x133 = _mlsValue::cast<_mls_Cons>(_mls_xs2)->_mls_head;
    auto _mls_x134 = _mlsValue::cast<_mls_Cons>(_mls_xs2)->_mls_tail;
    auto _mls_x135 = _mlsMethodCall<_mls_Callable>(_mls_f1)->_mls_apply2(_mls_a6, _mls_x133);
    auto _mls_x136 = _mls_foldl(_mls_f1, _mls_x135, _mls_x134);
    _mls_retval = _mls_x136;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_intMod(_mlsValue _mls_a7, _mlsValue _mls_b6) {
  _mlsValue _mls_retval;
  auto _mls_x137 = _mls_builtin_floor_mod(_mls_a7, _mls_b6);
  _mls_retval = _mls_x137;
  return _mls_retval;
}
_mlsValue _mls_leTup2(_mlsValue _mls_a8, _mlsValue _mls_b7) {
  _mlsValue _mls_retval;
  auto _mls_x138 = _mlsValue::create<_mls_Lambda_lambda6>();
  auto _mls_x139 = _mlsValue::create<_mls_Lambda_lambda9>();
  auto _mls_x140 = _mlsValue::create<_mls_Lambda_lambda11>();
  auto _mls_x141 = _mls_ltTup2(_mls_a8, _mls_b7, _mls_x138, _mls_x139, _mls_x140);
  _mls_retval = _mls_x141;
  return _mls_retval;
}
_mlsValue _mls_listDiff(_mlsValue _mls_a9, _mlsValue _mls_ls1) {
  _mlsValue _mls_retval;
  auto _mls_x142 = _mlsValue::create<_mls_Lambda_delete_>();
  auto _mls_x143 = _mls_foldl(_mls_x142, _mls_a9, _mls_ls1);
  _mls_retval = _mls_x143;
  return _mls_retval;
}
_mlsValue _mls_ltList(_mlsValue _mls_xs3, _mlsValue _mls_ys2, _mlsValue _mls_lt, _mlsValue _mls_gt) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs3)) {
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_ys2)) {
      _mls_retval = _mlsValue::fromIntLit(0);
    } else {
      _mls_retval = _mlsValue::fromIntLit(1);
    }
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs3)) {
    auto _mls_x144 = _mlsValue::cast<_mls_Cons>(_mls_xs3)->_mls_head;
    auto _mls_x145 = _mlsValue::cast<_mls_Cons>(_mls_xs3)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_ys2)) {
      _mls_retval = _mlsValue::fromIntLit(0);
    } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ys2)) {
      auto _mls_x146 = _mlsValue::cast<_mls_Cons>(_mls_ys2)->_mls_head;
      auto _mls_x147 = _mlsValue::cast<_mls_Cons>(_mls_ys2)->_mls_tail;
      auto _mls_x148 = _mlsMethodCall<_mls_Callable>(_mls_lt)->_mls_apply2(_mls_x144, _mls_x146);
      if (_mlsValue::isIntLit(_mls_x148, 1)) {
        _mls_retval = _mlsValue::fromIntLit(1);
      } else {
        auto _mls_x149 = _mlsMethodCall<_mls_Callable>(_mls_gt)->_mls_apply2(_mls_x144, _mls_x146);
        if (_mlsValue::isIntLit(_mls_x149, 1)) {
          _mls_retval = _mlsValue::fromIntLit(0);
        } else {
          auto _mls_x150 = _mls_ltList(_mls_x145, _mls_x147, _mls_lt, _mls_gt);
          _mls_retval = _mls_x150;
        }
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_ltTup2(_mlsValue _mls_t1, _mlsValue _mls_t2, _mlsValue _mls_lt1, _mlsValue _mls_gt1, _mlsValue _mls_lt2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_t1)) {
    auto _mls_x151 = _mlsValue::cast<_mls_Tuple2>(_mls_t1)->_mls_field0;
    auto _mls_x152 = _mlsValue::cast<_mls_Tuple2>(_mls_t1)->_mls_field1;
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_t2)) {
      auto _mls_x153 = _mlsValue::cast<_mls_Tuple2>(_mls_t2)->_mls_field0;
      auto _mls_x154 = _mlsValue::cast<_mls_Tuple2>(_mls_t2)->_mls_field1;
      auto _mls_x155 = _mlsMethodCall<_mls_Callable>(_mls_lt1)->_mls_apply2(_mls_x151, _mls_x153);
      if (_mlsValue::isIntLit(_mls_x155, 1)) {
        _mls_retval = _mlsValue::fromIntLit(1);
      } else {
        auto _mls_x156 = _mlsMethodCall<_mls_Callable>(_mls_gt1)->_mls_apply2(_mls_x151, _mls_x153);
        if (_mlsValue::isIntLit(_mls_x156, 1)) {
          _mls_retval = _mlsValue::fromIntLit(0);
        } else {
          auto _mls_x157 = _mlsMethodCall<_mls_Callable>(_mls_lt2)->_mls_apply2(_mls_x152, _mls_x154);
          _mls_retval = _mls_x157;
        }
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_map(_mlsValue _mls_f2, _mlsValue _mls_xs4) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs4)) {
    auto _mls_x159 = _mlsValue::cast<_mls_Cons>(_mls_xs4)->_mls_head;
    auto _mls_x160 = _mlsValue::cast<_mls_Cons>(_mls_xs4)->_mls_tail;
    auto _mls_x161 = _mlsMethodCall<_mls_Callable>(_mls_f2)->_mls_apply1(_mls_x159);
    auto _mls_x162 = _mls_map(_mls_f2, _mls_x160);
    auto _mls_x163 = _mlsValue::create<_mls_Cons>(_mls_x161, _mls_x162);
    _mls_retval = _mls_x163;
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs4)) {
    auto _mls_x158 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x158;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_perms(_mlsValue _mls_m, _mlsValue _mls_nns) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_nns)) {
    auto _mls_x175 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x175;
  } else {
    auto _mls_x164 = (_mls_m == _mlsValue::fromIntLit(1));
    if (_mlsValue::isIntLit(_mls_x164, 1)) {
      auto _mls_x173 = _mlsValue::create<_mls_Lambda_lambda10>();
      auto _mls_x174 = _mls_map(_mls_x173, _mls_nns);
      _mls_retval = _mls_x174;
    } else {
      if (_mlsValue::isValueOf<_mls_Cons>(_mls_nns)) {
        auto _mls_x165 = _mlsValue::cast<_mls_Cons>(_mls_nns)->_mls_head;
        auto _mls_x166 = _mlsValue::cast<_mls_Cons>(_mls_nns)->_mls_tail;
        auto _mls_x167 = (_mls_m - _mlsValue::fromIntLit(1));
        auto _mls_x168 = _mls_perms(_mls_x167, _mls_x166);
        auto _mls_x169 = _mlsValue::create<_mls_Lambda_lambda4>(_mls_x165);
        auto _mls_x170 = _mls_map(_mls_x169, _mls_x168);
        auto _mls_x171 = _mls_perms(_mls_m, _mls_x166);
        auto _mls_x172 = _mls_append(_mls_x170, _mls_x171);
        _mls_retval = _mls_x172;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    }
  }
  return _mls_retval;
}
_mlsValue _mls_print(_mlsValue _mls_x177) {
  _mlsValue _mls_retval;
  auto _mls_x176 = _mls_builtin_println(_mls_x177);
  _mls_retval = _mls_x176;
  return _mls_retval;
}
_mlsValue _mls_qpart(_mlsValue _mls_x180, _mlsValue _mls_ys3, _mlsValue _mls_rlt, _mlsValue _mls_rge, _mlsValue _mls_r) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ys3)) {
    auto _mls_x186 = _mls_rqsort(_mls_rge, _mls_r);
    auto _mls_x187 = _mlsValue::create<_mls_Cons>(_mls_x180, _mls_x186);
    auto _mls_x188 = _mls_rqsort(_mls_rlt, _mls_x187);
    _mls_retval = _mls_x188;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ys3)) {
    auto _mls_x178 = _mlsValue::cast<_mls_Cons>(_mls_ys3)->_mls_head;
    auto _mls_x179 = _mlsValue::cast<_mls_Cons>(_mls_ys3)->_mls_tail;
    auto _mls_x181 = _mls_leTup2(_mls_x180, _mls_x178);
    if (_mlsValue::isIntLit(_mls_x181, 1)) {
      auto _mls_x184 = _mlsValue::create<_mls_Cons>(_mls_x178, _mls_rge);
      auto _mls_x185 = _mls_qpart(_mls_x180, _mls_x179, _mls_rlt, _mls_x184, _mls_r);
      _mls_retval = _mls_x185;
    } else {
      auto _mls_x182 = _mlsValue::create<_mls_Cons>(_mls_x178, _mls_rlt);
      auto _mls_x183 = _mls_qpart(_mls_x180, _mls_x179, _mls_x182, _mls_rge, _mls_r);
      _mls_retval = _mls_x183;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_qsort(_mlsValue _mls_ls2, _mlsValue _mls_r1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls2)) {
    _mls_retval = _mls_r1;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls2)) {
    auto _mls_x189 = _mlsValue::cast<_mls_Cons>(_mls_ls2)->_mls_head;
    auto _mls_x190 = _mlsValue::cast<_mls_Cons>(_mls_ls2)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x190)) {
      auto _mls_x194 = _mlsValue::create<_mls_Cons>(_mls_x189, _mls_r1);
      _mls_retval = _mls_x194;
    } else {
      auto _mls_x191 = _mlsValue::create<_mls_Nil>();
      auto _mls_x192 = _mlsValue::create<_mls_Nil>();
      auto _mls_x193 = _mls_qpart(_mls_x189, _mls_x190, _mls_x191, _mls_x192, _mls_r1);
      _mls_retval = _mls_x193;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_rqpart(_mlsValue _mls_x197, _mlsValue _mls_yss, _mlsValue _mls_rle, _mlsValue _mls_rgt, _mlsValue _mls_r2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_yss)) {
    auto _mls_x203 = _mls_qsort(_mls_rgt, _mls_r2);
    auto _mls_x204 = _mlsValue::create<_mls_Cons>(_mls_x197, _mls_x203);
    auto _mls_x205 = _mls_qsort(_mls_rle, _mls_x204);
    _mls_retval = _mls_x205;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_yss)) {
    auto _mls_x195 = _mlsValue::cast<_mls_Cons>(_mls_yss)->_mls_head;
    auto _mls_x196 = _mlsValue::cast<_mls_Cons>(_mls_yss)->_mls_tail;
    auto _mls_x198 = _mls_leTup2(_mls_x195, _mls_x197);
    if (_mlsValue::isIntLit(_mls_x198, 1)) {
      auto _mls_x201 = _mlsValue::create<_mls_Cons>(_mls_x195, _mls_rle);
      auto _mls_x202 = _mls_rqpart(_mls_x197, _mls_x196, _mls_x201, _mls_rgt, _mls_r2);
      _mls_retval = _mls_x202;
    } else {
      auto _mls_x199 = _mlsValue::create<_mls_Cons>(_mls_x195, _mls_rgt);
      auto _mls_x200 = _mls_rqpart(_mls_x197, _mls_x196, _mls_rle, _mls_x199, _mls_r2);
      _mls_retval = _mls_x200;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_rqsort(_mlsValue _mls_ls3, _mlsValue _mls_r3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls3)) {
    _mls_retval = _mls_r3;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls3)) {
    auto _mls_x206 = _mlsValue::cast<_mls_Cons>(_mls_ls3)->_mls_head;
    auto _mls_x207 = _mlsValue::cast<_mls_Cons>(_mls_ls3)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x207)) {
      auto _mls_x211 = _mlsValue::create<_mls_Cons>(_mls_x206, _mls_r3);
      _mls_retval = _mls_x211;
    } else {
      auto _mls_x208 = _mlsValue::create<_mls_Nil>();
      auto _mls_x209 = _mlsValue::create<_mls_Nil>();
      auto _mls_x210 = _mls_rqpart(_mls_x206, _mls_x207, _mls_x208, _mls_x209, _mls_r3);
      _mls_retval = _mls_x210;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_sort(_mlsValue _mls_l) {
  _mlsValue _mls_retval;
  auto _mls_x212 = _mlsValue::create<_mls_Nil>();
  auto _mls_x213 = _mls_qsort(_mls_l, _mls_x212);
  _mls_retval = _mls_x213;
  return _mls_retval;
}
_mlsValue _mls_sum(_mlsValue _mls_xs5) {
  _mlsValue _mls_retval;
  auto _mls_x214 = _mls_sum_go(_mls_xs5, _mlsValue::fromIntLit(0));
  _mls_retval = _mls_x214;
  return _mls_retval;
}
_mlsValue _mls_sum_go(_mlsValue _mls_xs6, _mlsValue _mls_a10) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs6)) {
    _mls_retval = _mls_a10;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs6)) {
    auto _mls_x215 = _mlsValue::cast<_mls_Cons>(_mls_xs6)->_mls_head;
    auto _mls_x216 = _mlsValue::cast<_mls_Cons>(_mls_xs6)->_mls_tail;
    auto _mls_x217 = (_mls_a10 + _mls_x215);
    auto _mls_x218 = _mls_sum_go(_mls_x216, _mls_x217);
    _mls_retval = _mls_x218;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_testAwards_nofib(_mlsValue _mls_n) {
  _mlsValue _mls_retval;
  auto _mls_x219 = _mlsValue::create<_mls_Lambda_lambda1>();
  auto _mls_x220 = _mls_enumFromTo(_mlsValue::fromIntLit(1), _mls_n);
  auto _mls_x221 = _mls_map(_mls_x219, _mls_x220);
  _mls_retval = _mls_x221;
  return _mls_retval;
}
_mlsValue _mls_Lambda_delete_::_mls_apply2(_mlsValue _mls_arg, _mlsValue _mls_arg1) {
  _mlsValue _mls_retval;
  auto _mls_x = _mls_delete_(_mls_arg, _mls_arg1);
  _mls_retval = _mls_x;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda::_mls_apply1(_mlsValue _mls_ps) {
  _mlsValue _mls_retval;
  auto _mls_x1 = _mlsValue::create<_mls_Tuple2>(_mls_lam_arg0, _mls_ps);
  _mls_retval = _mls_x1;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda1::_mls_apply1(_mlsValue _mls_x2) {
  _mlsValue _mls_retval;
  auto _mls_x3 = _mls_intMod(_mls_x2, _mlsValue::fromIntLit(100));
  auto _mls_x4 = _mls_competitors(_mls_x3);
  auto _mls_x5 = _mls_findallawards(_mls_x4);
  auto _mls_x6 = _mls_print(_mls_x5);
  _mls_retval = _mls_x6;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda10::_mls_apply1(_mlsValue _mls_x9) {
  _mlsValue _mls_retval;
  auto _mls_x7 = _mlsValue::create<_mls_Nil>();
  auto _mls_x8 = _mlsValue::create<_mls_Cons>(_mls_x9, _mls_x7);
  _mls_retval = _mls_x8;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda11::_mls_apply2(_mlsValue _mls_a, _mlsValue _mls_b) {
  _mlsValue _mls_retval;
  auto _mls_x10 = _mlsValue::create<_mls_Lambda_lambda7>();
  auto _mls_x11 = _mlsValue::create<_mls_Lambda_lambda8>();
  auto _mls_x12 = _mls_ltList(_mls_a, _mls_b, _mls_x10, _mls_x11);
  _mls_retval = _mls_x12;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda2::_mls_apply1(_mlsValue _mls_caseScrut) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_caseScrut)) {
    auto _mls_x13 = _mlsValue::cast<_mls_Tuple2>(_mls_caseScrut)->_mls_field0;
    auto _mls_x14 = _mlsValue::cast<_mls_Tuple2>(_mls_caseScrut)->_mls_field1;
    auto _mls_x15 = (_mls_x13 >= _mls_lam_arg0);
    _mls_retval = _mls_x15;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda3::_mls_apply1(_mlsValue _mls_caseScrut1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_caseScrut1)) {
    auto _mls_x16 = _mlsValue::cast<_mls_Tuple2>(_mls_caseScrut1)->_mls_field0;
    auto _mls_x17 = _mlsValue::cast<_mls_Tuple2>(_mls_caseScrut1)->_mls_field1;
    auto _mls_x18 = _mls_findawards(_mls_x17);
    auto _mls_x19 = _mlsValue::create<_mls_Tuple2>(_mls_x16, _mls_x18);
    _mls_retval = _mls_x19;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda4::_mls_apply1(_mlsValue _mls_x21) {
  _mlsValue _mls_retval;
  auto _mls_x20 = _mlsValue::create<_mls_Cons>(_mls_lam_arg0, _mls_x21);
  _mls_retval = _mls_x20;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda5::_mls_apply1(_mlsValue _mls_p) {
  _mlsValue _mls_retval;
  auto _mls_x22 = _mls_sum(_mls_p);
  auto _mls_x23 = _mlsValue::create<_mls_Tuple2>(_mls_x22, _mls_p);
  _mls_retval = _mls_x23;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda6::_mls_apply2(_mlsValue _mls_a1, _mlsValue _mls_b1) {
  _mlsValue _mls_retval;
  auto _mls_x24 = (_mls_a1 < _mls_b1);
  _mls_retval = _mls_x24;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda7::_mls_apply2(_mlsValue _mls_a2, _mlsValue _mls_b2) {
  _mlsValue _mls_retval;
  auto _mls_x25 = (_mls_a2 < _mls_b2);
  _mls_retval = _mls_x25;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda8::_mls_apply2(_mlsValue _mls_a3, _mlsValue _mls_b3) {
  _mlsValue _mls_retval;
  auto _mls_x26 = (_mls_a3 > _mls_b3);
  _mls_retval = _mls_x26;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda9::_mls_apply2(_mlsValue _mls_a4, _mlsValue _mls_b4) {
  _mlsValue _mls_retval;
  auto _mls_x27 = (_mls_a4 > _mls_b4);
  _mls_retval = _mls_x27;
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
