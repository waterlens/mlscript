#include "mlsprelude.h"
struct _mls_Tree;
struct _mls_LamF;
struct _mls_Color;
struct _mls_Leaf;
struct _mls_Node;
struct _mls_Black;
struct _mls_Red;
_mlsValue _mls_mkMapAux(_mlsValue, _mlsValue);
_mlsValue _mls_main();
_mlsValue _mls_mkMap(_mlsValue);
_mlsValue _mls_balance1(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_fold(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_insert(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_apply_f(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_ins(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_balance2(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_setBlack(_mlsValue);
_mlsValue _mls_isRed(_mlsValue);
struct _mls_Tree: public _mlsObject {
  
  constexpr static inline const char *typeName = "Tree";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Tree; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_LamF: public _mlsObject {
  
  constexpr static inline const char *typeName = "LamF";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_LamF; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Color: public _mlsObject {
  
  constexpr static inline const char *typeName = "Color";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Color; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Leaf: public _mls_Tree {
  
  constexpr static inline const char *typeName = "Leaf";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Leaf; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Node: public _mls_Tree {
  _mlsValue _mls_color;
  _mlsValue _mls_left;
  _mlsValue _mls_key;
  _mlsValue _mls_value;
  _mlsValue _mls_right;
  constexpr static inline const char *typeName = "Node";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_color.print(); std::printf(", "); this->_mls_left.print(); std::printf(", "); this->_mls_key.print(); std::printf(", "); this->_mls_value.print(); std::printf(", "); this->_mls_right.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_color); _mlsValue::destroy(this->_mls_left); _mlsValue::destroy(this->_mls_key); _mlsValue::destroy(this->_mls_value); _mlsValue::destroy(this->_mls_right);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_color.asObject()->operator==(*other.cast<_mls_Node>()->_mls_color.asObject()) && this->_mls_left.asObject()->operator==(*other.cast<_mls_Node>()->_mls_left.asObject()) && this->_mls_key.asObject()->operator==(*other.cast<_mls_Node>()->_mls_key.asObject()) && this->_mls_value.asObject()->operator==(*other.cast<_mls_Node>()->_mls_value.asObject()) && this->_mls_right.asObject()->operator==(*other.cast<_mls_Node>()->_mls_right.asObject()); }
  static _mlsValue create(_mlsValue _mls_color, _mlsValue _mls_left, _mlsValue _mls_key, _mlsValue _mls_value, _mlsValue _mls_right) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Node; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_color = _mls_color; _mlsVal->_mls_left = _mls_left; _mlsVal->_mls_key = _mls_key; _mlsVal->_mls_value = _mls_value; _mlsVal->_mls_right = _mls_right;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Black: public _mls_Color {
  
  constexpr static inline const char *typeName = "Black";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Black; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Red: public _mls_Color {
  
  constexpr static inline const char *typeName = "Red";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Red; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_isRed(_mlsValue _mls_t5) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Node>(_mls_t5)) {
    auto _mls_x154 = _mlsValue::cast<_mls_Node>(_mls_t5)->_mls_color;
    if (_mlsValue::isValueOf<_mls_Red>(_mls_x154)) {
      _mls_retval = _mlsValue::fromIntLit(1);
    } else {
      _mls_retval = _mlsValue::fromIntLit(0);
    }
  } else {
    _mls_retval = _mlsValue::fromIntLit(0);
  }
  return _mls_retval;
}
_mlsValue _mls_mkMap(_mlsValue _mls_n1) {
  _mlsValue _mls_retval;
  auto _mls_x155 = _mlsValue::create<_mls_Leaf>();
  auto _mls_x156 = _mls_mkMapAux(_mls_n1, _mls_x155);
  _mls_retval = _mls_x156;
  return _mls_retval;
}
_mlsValue _mls_balance2(_mlsValue _mls_t11, _mlsValue _mls_k1, _mlsValue _mls_v1, _mlsValue _mls_t21) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Node>(_mls_t21)) {
    auto _mls_x55 = _mlsValue::cast<_mls_Node>(_mls_t21)->_mls_left;
    auto _mls_x56 = _mlsValue::cast<_mls_Node>(_mls_t21)->_mls_key;
    auto _mls_x57 = _mlsValue::cast<_mls_Node>(_mls_t21)->_mls_value;
    auto _mls_x58 = _mlsValue::cast<_mls_Node>(_mls_t21)->_mls_right;
    if (_mlsValue::isValueOf<_mls_Node>(_mls_x55)) {
      auto _mls_x78 = _mlsValue::cast<_mls_Node>(_mls_x55)->_mls_color;
      auto _mls_x79 = _mlsValue::cast<_mls_Node>(_mls_x55)->_mls_left;
      auto _mls_x80 = _mlsValue::cast<_mls_Node>(_mls_x55)->_mls_key;
      auto _mls_x81 = _mlsValue::cast<_mls_Node>(_mls_x55)->_mls_value;
      auto _mls_x82 = _mlsValue::cast<_mls_Node>(_mls_x55)->_mls_right;
      if (_mlsValue::isValueOf<_mls_Red>(_mls_x78)) {
        auto _mls_x102 = _mlsValue::create<_mls_Black>();
        auto _mls_x103 = _mlsValue::create<_mls_Node>(_mls_x102, _mls_t11, _mls_k1, _mls_v1, _mls_x79);
        auto _mls_x104 = _mlsValue::create<_mls_Black>();
        auto _mls_x105 = _mlsValue::create<_mls_Node>(_mls_x104, _mls_x82, _mls_x56, _mls_x57, _mls_x58);
        auto _mls_x106 = _mlsValue::create<_mls_Red>();
        auto _mls_x107 = _mlsValue::create<_mls_Node>(_mls_x106, _mls_x103, _mls_x80, _mls_x81, _mls_x105);
        _mls_retval = _mls_x107;
      } else {
        if (_mlsValue::isValueOf<_mls_Node>(_mls_x58)) {
          auto _mls_x87 = _mlsValue::cast<_mls_Node>(_mls_x58)->_mls_color;
          auto _mls_x88 = _mlsValue::cast<_mls_Node>(_mls_x58)->_mls_left;
          auto _mls_x89 = _mlsValue::cast<_mls_Node>(_mls_x58)->_mls_key;
          auto _mls_x90 = _mlsValue::cast<_mls_Node>(_mls_x58)->_mls_value;
          auto _mls_x91 = _mlsValue::cast<_mls_Node>(_mls_x58)->_mls_right;
          if (_mlsValue::isValueOf<_mls_Red>(_mls_x87)) {
            auto _mls_x96 = _mlsValue::create<_mls_Black>();
            auto _mls_x97 = _mlsValue::create<_mls_Node>(_mls_x96, _mls_t11, _mls_k1, _mls_v1, _mls_x55);
            auto _mls_x98 = _mlsValue::create<_mls_Black>();
            auto _mls_x99 = _mlsValue::create<_mls_Node>(_mls_x98, _mls_x88, _mls_x89, _mls_x90, _mls_x91);
            auto _mls_x100 = _mlsValue::create<_mls_Red>();
            auto _mls_x101 = _mlsValue::create<_mls_Node>(_mls_x100, _mls_x97, _mls_x56, _mls_x57, _mls_x99);
            _mls_retval = _mls_x101;
          } else {
            auto _mls_x92 = _mlsValue::create<_mls_Red>();
            auto _mls_x93 = _mlsValue::create<_mls_Node>(_mls_x92, _mls_x55, _mls_x56, _mls_x57, _mls_x58);
            auto _mls_x94 = _mlsValue::create<_mls_Black>();
            auto _mls_x95 = _mlsValue::create<_mls_Node>(_mls_x94, _mls_t11, _mls_k1, _mls_v1, _mls_x93);
            _mls_retval = _mls_x95;
          }
        } else {
          auto _mls_x83 = _mlsValue::create<_mls_Red>();
          auto _mls_x84 = _mlsValue::create<_mls_Node>(_mls_x83, _mls_x55, _mls_x56, _mls_x57, _mls_x58);
          auto _mls_x85 = _mlsValue::create<_mls_Black>();
          auto _mls_x86 = _mlsValue::create<_mls_Node>(_mls_x85, _mls_t11, _mls_k1, _mls_v1, _mls_x84);
          _mls_retval = _mls_x86;
        }
      }
    } else {
      if (_mlsValue::isValueOf<_mls_Node>(_mls_x58)) {
        auto _mls_x63 = _mlsValue::cast<_mls_Node>(_mls_x58)->_mls_color;
        auto _mls_x64 = _mlsValue::cast<_mls_Node>(_mls_x58)->_mls_left;
        auto _mls_x65 = _mlsValue::cast<_mls_Node>(_mls_x58)->_mls_key;
        auto _mls_x66 = _mlsValue::cast<_mls_Node>(_mls_x58)->_mls_value;
        auto _mls_x67 = _mlsValue::cast<_mls_Node>(_mls_x58)->_mls_right;
        if (_mlsValue::isValueOf<_mls_Red>(_mls_x63)) {
          auto _mls_x72 = _mlsValue::create<_mls_Black>();
          auto _mls_x73 = _mlsValue::create<_mls_Node>(_mls_x72, _mls_t11, _mls_k1, _mls_v1, _mls_x55);
          auto _mls_x74 = _mlsValue::create<_mls_Black>();
          auto _mls_x75 = _mlsValue::create<_mls_Node>(_mls_x74, _mls_x64, _mls_x65, _mls_x66, _mls_x67);
          auto _mls_x76 = _mlsValue::create<_mls_Red>();
          auto _mls_x77 = _mlsValue::create<_mls_Node>(_mls_x76, _mls_x73, _mls_x56, _mls_x57, _mls_x75);
          _mls_retval = _mls_x77;
        } else {
          auto _mls_x68 = _mlsValue::create<_mls_Red>();
          auto _mls_x69 = _mlsValue::create<_mls_Node>(_mls_x68, _mls_x55, _mls_x56, _mls_x57, _mls_x58);
          auto _mls_x70 = _mlsValue::create<_mls_Black>();
          auto _mls_x71 = _mlsValue::create<_mls_Node>(_mls_x70, _mls_t11, _mls_k1, _mls_v1, _mls_x69);
          _mls_retval = _mls_x71;
        }
      } else {
        auto _mls_x59 = _mlsValue::create<_mls_Red>();
        auto _mls_x60 = _mlsValue::create<_mls_Node>(_mls_x59, _mls_x55, _mls_x56, _mls_x57, _mls_x58);
        auto _mls_x61 = _mlsValue::create<_mls_Black>();
        auto _mls_x62 = _mlsValue::create<_mls_Node>(_mls_x61, _mls_t11, _mls_k1, _mls_v1, _mls_x60);
        _mls_retval = _mls_x62;
      }
    }
  } else {
    auto _mls_x54 = _mlsValue::create<_mls_Leaf>();
    _mls_retval = _mls_x54;
  }
  return _mls_retval;
}
_mlsValue _mls_setBlack(_mlsValue _mls_t6) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Node>(_mls_t6)) {
    auto _mls_x160 = _mlsValue::cast<_mls_Node>(_mls_t6)->_mls_left;
    auto _mls_x161 = _mlsValue::cast<_mls_Node>(_mls_t6)->_mls_key;
    auto _mls_x162 = _mlsValue::cast<_mls_Node>(_mls_t6)->_mls_value;
    auto _mls_x163 = _mlsValue::cast<_mls_Node>(_mls_t6)->_mls_right;
    auto _mls_x164 = _mlsValue::create<_mls_Black>();
    auto _mls_x165 = _mlsValue::create<_mls_Node>(_mls_x164, _mls_x160, _mls_x161, _mls_x162, _mls_x163);
    _mls_retval = _mls_x165;
  } else {
    _mls_retval = _mls_t6;
  }
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x108 = _mls_main();
  _mls_retval = _mls_x108;
  return _mls_retval;
}
_mlsValue _mls_ins(_mlsValue _mls_kx, _mlsValue _mls_vx, _mlsValue _mls_t3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Leaf>(_mls_t3)) {
    auto _mls_x146 = _mlsValue::create<_mls_Red>();
    auto _mls_x147 = _mlsValue::create<_mls_Leaf>();
    auto _mls_x148 = _mlsValue::create<_mls_Leaf>();
    auto _mls_x149 = _mlsValue::create<_mls_Node>(_mls_x146, _mls_x147, _mls_kx, _mls_vx, _mls_x148);
    _mls_retval = _mls_x149;
  } else if (_mlsValue::isValueOf<_mls_Node>(_mls_t3)) {
    auto _mls_x115 = _mlsValue::cast<_mls_Node>(_mls_t3)->_mls_color;
    auto _mls_x116 = _mlsValue::cast<_mls_Node>(_mls_t3)->_mls_left;
    auto _mls_x117 = _mlsValue::cast<_mls_Node>(_mls_t3)->_mls_key;
    auto _mls_x118 = _mlsValue::cast<_mls_Node>(_mls_t3)->_mls_value;
    auto _mls_x119 = _mlsValue::cast<_mls_Node>(_mls_t3)->_mls_right;
    if (_mlsValue::isValueOf<_mls_Red>(_mls_x115)) {
      auto _mls_x136 = (_mls_kx < _mls_x117);
      if (_mlsValue::isIntLit(_mls_x136, 1)) {
        auto _mls_x143 = _mls_ins(_mls_kx, _mls_vx, _mls_x116);
        auto _mls_x144 = _mlsValue::create<_mls_Red>();
        auto _mls_x145 = _mlsValue::create<_mls_Node>(_mls_x144, _mls_x143, _mls_x117, _mls_x118, _mls_x119);
        _mls_retval = _mls_x145;
      } else {
        auto _mls_x137 = (_mls_kx == _mls_x117);
        if (_mlsValue::isIntLit(_mls_x137, 1)) {
          auto _mls_x141 = _mlsValue::create<_mls_Red>();
          auto _mls_x142 = _mlsValue::create<_mls_Node>(_mls_x141, _mls_x116, _mls_kx, _mls_vx, _mls_x119);
          _mls_retval = _mls_x142;
        } else {
          auto _mls_x138 = _mls_ins(_mls_kx, _mls_vx, _mls_x119);
          auto _mls_x139 = _mlsValue::create<_mls_Red>();
          auto _mls_x140 = _mlsValue::create<_mls_Node>(_mls_x139, _mls_x116, _mls_x117, _mls_x118, _mls_x138);
          _mls_retval = _mls_x140;
        }
      }
    } else if (_mlsValue::isValueOf<_mls_Black>(_mls_x115)) {
      auto _mls_x120 = (_mls_kx < _mls_x117);
      if (_mlsValue::isIntLit(_mls_x120, 1)) {
        auto _mls_x130 = _mls_isRed(_mls_x116);
        if (_mlsValue::isIntLit(_mls_x130, 1)) {
          auto _mls_x134 = _mls_ins(_mls_kx, _mls_vx, _mls_x119);
          auto _mls_x135 = _mls_balance1(_mls_x117, _mls_x118, _mls_x134, _mls_x116);
          _mls_retval = _mls_x135;
        } else {
          auto _mls_x131 = _mls_ins(_mls_kx, _mls_vx, _mls_x116);
          auto _mls_x132 = _mlsValue::create<_mls_Black>();
          auto _mls_x133 = _mlsValue::create<_mls_Node>(_mls_x132, _mls_x131, _mls_x117, _mls_x118, _mls_x119);
          _mls_retval = _mls_x133;
        }
      } else {
        auto _mls_x121 = (_mls_kx == _mls_x117);
        if (_mlsValue::isIntLit(_mls_x121, 1)) {
          auto _mls_x128 = _mlsValue::create<_mls_Black>();
          auto _mls_x129 = _mlsValue::create<_mls_Node>(_mls_x128, _mls_x116, _mls_kx, _mls_vx, _mls_x119);
          _mls_retval = _mls_x129;
        } else {
          auto _mls_x122 = _mls_isRed(_mls_x119);
          if (_mlsValue::isIntLit(_mls_x122, 1)) {
            auto _mls_x126 = _mls_ins(_mls_kx, _mls_vx, _mls_x119);
            auto _mls_x127 = _mls_balance2(_mls_x116, _mls_x117, _mls_x118, _mls_x126);
            _mls_retval = _mls_x127;
          } else {
            auto _mls_x123 = _mls_ins(_mls_kx, _mls_vx, _mls_x119);
            auto _mls_x124 = _mlsValue::create<_mls_Black>();
            auto _mls_x125 = _mlsValue::create<_mls_Node>(_mls_x124, _mls_x116, _mls_x117, _mls_x118, _mls_x123);
            _mls_retval = _mls_x125;
          }
        }
      }
    } else {
      throw std::runtime_error("match error" LINE_STRING);
    }
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_mkMapAux(_mlsValue _mls_n, _mlsValue _mls_t) {
  _mlsValue _mls_retval;
  auto _mls_x109 = (_mls_n == _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x109, 1)) {
    _mls_retval = _mls_t;
  } else {
    auto _mls_x110 = (_mls_n - _mlsValue::fromIntLit(1));
    auto _mls_x111 = (_mls_n % _mlsValue::fromIntLit(10));
    auto _mls_x112 = (_mls_x111 == _mlsValue::fromIntLit(0));
    auto _mls_x113 = _mls_insert(_mls_n, _mls_x112, _mls_t);
    auto _mls_x114 = _mls_mkMapAux(_mls_x110, _mls_x113);
    _mls_retval = _mls_x114;
  }
  return _mls_retval;
}
_mlsValue _mls_insert(_mlsValue _mls_k2, _mlsValue _mls_v2, _mlsValue _mls_t4) {
  _mlsValue _mls_retval;
  auto _mls_x150 = _mls_isRed(_mls_t4);
  if (_mlsValue::isIntLit(_mls_x150, 1)) {
    auto _mls_x152 = _mls_ins(_mls_k2, _mls_v2, _mls_t4);
    auto _mls_x153 = _mls_setBlack(_mls_x152);
    _mls_retval = _mls_x153;
  } else {
    auto _mls_x151 = _mls_ins(_mls_k2, _mls_v2, _mls_t4);
    _mls_retval = _mls_x151;
  }
  return _mls_retval;
}
_mlsValue _mls_balance1(_mlsValue _mls_k, _mlsValue _mls_v, _mlsValue _mls_t1, _mlsValue _mls_t2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Node>(_mls_t2)) {
    auto _mls_x1 = _mlsValue::cast<_mls_Node>(_mls_t2)->_mls_left;
    auto _mls_x2 = _mlsValue::cast<_mls_Node>(_mls_t2)->_mls_key;
    auto _mls_x3 = _mlsValue::cast<_mls_Node>(_mls_t2)->_mls_value;
    auto _mls_x4 = _mlsValue::cast<_mls_Node>(_mls_t2)->_mls_right;
    if (_mlsValue::isValueOf<_mls_Node>(_mls_x1)) {
      auto _mls_x24 = _mlsValue::cast<_mls_Node>(_mls_x1)->_mls_color;
      auto _mls_x25 = _mlsValue::cast<_mls_Node>(_mls_x1)->_mls_left;
      auto _mls_x26 = _mlsValue::cast<_mls_Node>(_mls_x1)->_mls_key;
      auto _mls_x27 = _mlsValue::cast<_mls_Node>(_mls_x1)->_mls_value;
      auto _mls_x28 = _mlsValue::cast<_mls_Node>(_mls_x1)->_mls_right;
      if (_mlsValue::isValueOf<_mls_Red>(_mls_x24)) {
        auto _mls_x48 = _mlsValue::create<_mls_Black>();
        auto _mls_x49 = _mlsValue::create<_mls_Node>(_mls_x48, _mls_x25, _mls_x26, _mls_x27, _mls_x28);
        auto _mls_x50 = _mlsValue::create<_mls_Black>();
        auto _mls_x51 = _mlsValue::create<_mls_Node>(_mls_x50, _mls_x4, _mls_k, _mls_v, _mls_t1);
        auto _mls_x52 = _mlsValue::create<_mls_Red>();
        auto _mls_x53 = _mlsValue::create<_mls_Node>(_mls_x52, _mls_x49, _mls_x2, _mls_x3, _mls_x51);
        _mls_retval = _mls_x53;
      } else {
        if (_mlsValue::isValueOf<_mls_Node>(_mls_x4)) {
          auto _mls_x33 = _mlsValue::cast<_mls_Node>(_mls_x4)->_mls_color;
          auto _mls_x34 = _mlsValue::cast<_mls_Node>(_mls_x4)->_mls_left;
          auto _mls_x35 = _mlsValue::cast<_mls_Node>(_mls_x4)->_mls_key;
          auto _mls_x36 = _mlsValue::cast<_mls_Node>(_mls_x4)->_mls_value;
          auto _mls_x37 = _mlsValue::cast<_mls_Node>(_mls_x4)->_mls_right;
          if (_mlsValue::isValueOf<_mls_Red>(_mls_x33)) {
            auto _mls_x42 = _mlsValue::create<_mls_Black>();
            auto _mls_x43 = _mlsValue::create<_mls_Node>(_mls_x42, _mls_x1, _mls_x2, _mls_x3, _mls_x34);
            auto _mls_x44 = _mlsValue::create<_mls_Black>();
            auto _mls_x45 = _mlsValue::create<_mls_Node>(_mls_x44, _mls_x37, _mls_k, _mls_v, _mls_t1);
            auto _mls_x46 = _mlsValue::create<_mls_Red>();
            auto _mls_x47 = _mlsValue::create<_mls_Node>(_mls_x46, _mls_x43, _mls_x35, _mls_x36, _mls_x45);
            _mls_retval = _mls_x47;
          } else {
            auto _mls_x38 = _mlsValue::create<_mls_Red>();
            auto _mls_x39 = _mlsValue::create<_mls_Node>(_mls_x38, _mls_x1, _mls_x2, _mls_x3, _mls_x4);
            auto _mls_x40 = _mlsValue::create<_mls_Black>();
            auto _mls_x41 = _mlsValue::create<_mls_Node>(_mls_x40, _mls_x39, _mls_k, _mls_v, _mls_t1);
            _mls_retval = _mls_x41;
          }
        } else {
          auto _mls_x29 = _mlsValue::create<_mls_Red>();
          auto _mls_x30 = _mlsValue::create<_mls_Node>(_mls_x29, _mls_x1, _mls_x2, _mls_x3, _mls_x4);
          auto _mls_x31 = _mlsValue::create<_mls_Black>();
          auto _mls_x32 = _mlsValue::create<_mls_Node>(_mls_x31, _mls_x30, _mls_k, _mls_v, _mls_t1);
          _mls_retval = _mls_x32;
        }
      }
    } else {
      if (_mlsValue::isValueOf<_mls_Node>(_mls_x4)) {
        auto _mls_x9 = _mlsValue::cast<_mls_Node>(_mls_x4)->_mls_color;
        auto _mls_x10 = _mlsValue::cast<_mls_Node>(_mls_x4)->_mls_left;
        auto _mls_x11 = _mlsValue::cast<_mls_Node>(_mls_x4)->_mls_key;
        auto _mls_x12 = _mlsValue::cast<_mls_Node>(_mls_x4)->_mls_value;
        auto _mls_x13 = _mlsValue::cast<_mls_Node>(_mls_x4)->_mls_right;
        if (_mlsValue::isValueOf<_mls_Red>(_mls_x9)) {
          auto _mls_x18 = _mlsValue::create<_mls_Black>();
          auto _mls_x19 = _mlsValue::create<_mls_Node>(_mls_x18, _mls_x1, _mls_x2, _mls_x3, _mls_x10);
          auto _mls_x20 = _mlsValue::create<_mls_Black>();
          auto _mls_x21 = _mlsValue::create<_mls_Node>(_mls_x20, _mls_x13, _mls_k, _mls_v, _mls_t1);
          auto _mls_x22 = _mlsValue::create<_mls_Red>();
          auto _mls_x23 = _mlsValue::create<_mls_Node>(_mls_x22, _mls_x19, _mls_x11, _mls_x12, _mls_x21);
          _mls_retval = _mls_x23;
        } else {
          auto _mls_x14 = _mlsValue::create<_mls_Red>();
          auto _mls_x15 = _mlsValue::create<_mls_Node>(_mls_x14, _mls_x1, _mls_x2, _mls_x3, _mls_x4);
          auto _mls_x16 = _mlsValue::create<_mls_Black>();
          auto _mls_x17 = _mlsValue::create<_mls_Node>(_mls_x16, _mls_x15, _mls_k, _mls_v, _mls_t1);
          _mls_retval = _mls_x17;
        }
      } else {
        auto _mls_x5 = _mlsValue::create<_mls_Red>();
        auto _mls_x6 = _mlsValue::create<_mls_Node>(_mls_x5, _mls_x1, _mls_x2, _mls_x3, _mls_x4);
        auto _mls_x7 = _mlsValue::create<_mls_Black>();
        auto _mls_x8 = _mlsValue::create<_mls_Node>(_mls_x7, _mls_x6, _mls_k, _mls_v, _mls_t1);
        _mls_retval = _mls_x8;
      }
    }
  } else {
    auto _mls_x = _mlsValue::create<_mls_Leaf>();
    _mls_retval = _mls_x;
  }
  return _mls_retval;
}
_mlsValue _mls_main() {
  _mlsValue _mls_retval;
  auto _mls_x157 = _mls_mkMap(_mlsValue::fromIntLit(6000));
  auto _mls_x158 = _mlsValue::create<_mls_LamF>();
  auto _mls_x159 = _mls_fold(_mls_x158, _mls_x157, _mlsValue::fromIntLit(0));
  _mls_retval = _mls_x159;
  return _mls_retval;
}
_mlsValue _mls_fold(_mlsValue _mls_f, _mlsValue _mls_t7, _mlsValue _mls_b) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Leaf>(_mls_t7)) {
    _mls_retval = _mls_b;
  } else if (_mlsValue::isValueOf<_mls_Node>(_mls_t7)) {
    auto _mls_x166 = _mlsValue::cast<_mls_Node>(_mls_t7)->_mls_left;
    auto _mls_x167 = _mlsValue::cast<_mls_Node>(_mls_t7)->_mls_key;
    auto _mls_x168 = _mlsValue::cast<_mls_Node>(_mls_t7)->_mls_value;
    auto _mls_x169 = _mlsValue::cast<_mls_Node>(_mls_t7)->_mls_right;
    auto _mls_x170 = _mls_fold(_mls_f, _mls_x166, _mls_b);
    auto _mls_x171 = _mls_apply_f(_mls_f, _mls_x167, _mls_x168, _mls_x170);
    auto _mls_x172 = _mls_fold(_mls_f, _mls_x169, _mls_x171);
    _mls_retval = _mls_x172;
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_apply_f(_mlsValue _mls_f1, _mlsValue _mls_a, _mlsValue _mls_b1, _mlsValue _mls_c) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_LamF>(_mls_f1)) {
    if (_mlsValue::isIntLit(_mls_b1, 1)) {
      auto _mls_x173 = (_mls_c + _mlsValue::fromIntLit(1));
      _mls_retval = _mls_x173;
    } else {
      _mls_retval = _mls_c;
    }
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
