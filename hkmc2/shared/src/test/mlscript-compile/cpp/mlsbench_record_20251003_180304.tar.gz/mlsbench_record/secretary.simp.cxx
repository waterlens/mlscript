#include "mlsprelude.h"
struct _mls_Lambda_l;
struct _mls_Lambda_lambda;
struct _mls_Lambda_lambda1;
struct _mls_Lambda_loop;
struct _mls_Lambda_lscomp;
struct _mls_Lambda_proc;
struct _mls_List;
struct _mls_Cons;
struct _mls_Nil;
struct _mls_Tuple2;
_mlsValue _mls_drop(_mlsValue, _mlsValue);
_mlsValue _mls_dropWhile(_mlsValue, _mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_enumFromTo(_mlsValue, _mlsValue);
_mlsValue _mls_filter(_mlsValue, _mlsValue);
_mlsValue _mls_listEq(_mlsValue, _mlsValue);
_mlsValue _mls_listLen(_mlsValue);
_mlsValue _mls_listcomp(_mlsValue, _mlsValue);
_mlsValue _mls_maximum(_mlsValue);
_mlsValue _mls_member(_mlsValue, _mlsValue);
_mlsValue _mls_nextRandStep(_mlsValue, _mlsValue);
_mlsValue _mls_rev_f(_mlsValue, _mlsValue);
_mlsValue _mls_reverse(_mlsValue);
_mlsValue _mls_sim(_mlsValue, _mlsValue);
_mlsValue _mls_simulate(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_take(_mlsValue, _mlsValue);
_mlsValue _mls_takeRandUnique(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_testSecretary_nofib(_mlsValue);
struct _mls_Lambda_l: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_l";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_l; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_lambda: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda1: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda1; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_loop: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_loop";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_loop; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply5(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
};
struct _mls_Lambda_lscomp: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  _mlsValue _mls_lam_arg1;
  constexpr static inline const char *typeName = "Lambda_lscomp";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print(); std::printf(", "); this->_mls_lam_arg1.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0); _mlsValue::destroy(this->_mls_lam_arg1);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lscomp>()->_mls_lam_arg0.asObject()) && this->_mls_lam_arg1.asObject()->operator==(*other.cast<_mls_Lambda_lscomp>()->_mls_lam_arg1.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0, _mlsValue _mls_lam_arg1) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lscomp; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0; _mlsVal->_mls_lam_arg1 = _mls_lam_arg1;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_proc: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_proc";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_proc>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_proc; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_List: public _mlsObject {
  
  constexpr static inline const char *typeName = "List";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_List; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Cons: public _mls_List {
  _mlsValue _mls_head;
  _mlsValue _mls_tail;
  constexpr static inline const char *typeName = "Cons";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_head.print(); std::printf(", "); this->_mls_tail.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_head); _mlsValue::destroy(this->_mls_tail);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_head.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_head.asObject()) && this->_mls_tail.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_tail.asObject()); }
  static _mlsValue create(_mlsValue _mls_head, _mlsValue _mls_tail) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Cons; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_head = _mls_head; _mlsVal->_mls_tail = _mls_tail;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Nil: public _mls_List {
  
  constexpr static inline const char *typeName = "Nil";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Nil; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Tuple2: public _mlsObject {
  _mlsValue _mls_field0;
  _mlsValue _mls_field1;
  constexpr static inline const char *typeName = "Tuple2";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_field0.print(); std::printf(", "); this->_mls_field1.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_field0); _mlsValue::destroy(this->_mls_field1);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_field0.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field0.asObject()) && this->_mls_field1.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field1.asObject()); }
  static _mlsValue create(_mlsValue _mls_field0, _mlsValue _mls_field1) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Tuple2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_field0 = _mls_field0; _mlsVal->_mls_field1 = _mls_field1;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_drop(_mlsValue _mls_n, _mlsValue _mls_ls2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls2)) {
    auto _mls_x39 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x39;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls2)) {
    auto _mls_x35 = _mlsValue::cast<_mls_Cons>(_mls_ls2)->_mls_tail;
    auto _mls_x36 = (_mls_n <= _mlsValue::fromIntLit(0));
    if (_mlsValue::isIntLit(_mls_x36, 1)) {
      _mls_retval = _mls_ls2;
    } else {
      auto _mls_x37 = (_mls_n - _mlsValue::fromIntLit(1));
      auto _mls_x38 = _mls_drop(_mls_x37, _mls_x35);
      _mls_retval = _mls_x38;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_dropWhile(_mlsValue _mls_f, _mlsValue _mls_ls3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls3)) {
    auto _mls_x45 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x45;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls3)) {
    auto _mls_x40 = _mlsValue::cast<_mls_Cons>(_mls_ls3)->_mls_head;
    auto _mls_x41 = _mlsValue::cast<_mls_Cons>(_mls_ls3)->_mls_tail;
    auto _mls_x42 = _mlsMethodCall<_mls_Callable>(_mls_f)->_mls_apply1(_mls_x40);
    if (_mlsValue::isIntLit(_mls_x42, 1)) {
      auto _mls_x44 = _mls_dropWhile(_mls_f, _mls_x41);
      _mls_retval = _mls_x44;
    } else {
      auto _mls_x43 = _mlsValue::create<_mls_Cons>(_mls_x40, _mls_x41);
      _mls_retval = _mls_x43;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x46 = _mls_testSecretary_nofib(_mlsValue::fromIntLit(2000));
  _mls_retval = _mls_x46;
  return _mls_retval;
}
_mlsValue _mls_enumFromTo(_mlsValue _mls_a1, _mlsValue _mls_b) {
  _mlsValue _mls_retval;
  auto _mls_x47 = (_mls_a1 <= _mls_b);
  if (_mlsValue::isIntLit(_mls_x47, 1)) {
    auto _mls_x49 = (_mls_a1 + _mlsValue::fromIntLit(1));
    auto _mls_x50 = _mls_enumFromTo(_mls_x49, _mls_b);
    auto _mls_x51 = _mlsValue::create<_mls_Cons>(_mls_a1, _mls_x50);
    _mls_retval = _mls_x51;
  } else {
    auto _mls_x48 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x48;
  }
  return _mls_retval;
}
_mlsValue _mls_filter(_mlsValue _mls_f1, _mlsValue _mls_ls4) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls4)) {
    auto _mls_x58 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x58;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls4)) {
    auto _mls_x52 = _mlsValue::cast<_mls_Cons>(_mls_ls4)->_mls_head;
    auto _mls_x53 = _mlsValue::cast<_mls_Cons>(_mls_ls4)->_mls_tail;
    auto _mls_x54 = _mlsMethodCall<_mls_Callable>(_mls_f1)->_mls_apply1(_mls_x52);
    if (_mlsValue::isIntLit(_mls_x54, 1)) {
      auto _mls_x56 = _mls_filter(_mls_f1, _mls_x53);
      auto _mls_x57 = _mlsValue::create<_mls_Cons>(_mls_x52, _mls_x56);
      _mls_retval = _mls_x57;
    } else {
      auto _mls_x55 = _mls_filter(_mls_f1, _mls_x53);
      _mls_retval = _mls_x55;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_listEq(_mlsValue _mls_xs, _mlsValue _mls_ys) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs)) {
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_ys)) {
      _mls_retval = _mlsValue::fromIntLit(1);
    } else {
      _mls_retval = _mlsValue::fromIntLit(0);
    }
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs)) {
    auto _mls_x59 = _mlsValue::cast<_mls_Cons>(_mls_xs)->_mls_head;
    auto _mls_x60 = _mlsValue::cast<_mls_Cons>(_mls_xs)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_ys)) {
      auto _mls_x61 = _mlsValue::cast<_mls_Cons>(_mls_ys)->_mls_head;
      auto _mls_x62 = _mlsValue::cast<_mls_Cons>(_mls_ys)->_mls_tail;
      auto _mls_x63 = (_mls_x59 == _mls_x61);
      if (_mlsValue::isIntLit(_mls_x63, 1)) {
        auto _mls_x64 = _mls_listEq(_mls_x60, _mls_x62);
        _mls_retval = _mls_x64;
      } else {
        _mls_retval = _mlsValue::fromIntLit(0);
      }
    } else {
      _mls_retval = _mlsValue::fromIntLit(0);
    }
  } else {
    _mls_retval = _mlsValue::fromIntLit(0);
  }
  return _mls_retval;
}
_mlsValue _mls_listLen(_mlsValue _mls_ls5) {
  _mlsValue _mls_retval;
  auto _mls_x65 = _mlsValue::create<_mls_Lambda_l>();
  auto _mls_x66 = _mlsMethodCall<_mls_Callable>(_mls_x65)->_mls_apply2(_mls_ls5, _mlsValue::fromIntLit(0));
  _mls_retval = _mls_x66;
  return _mls_retval;
}
_mlsValue _mls_listcomp(_mlsValue _mls_n1, _mlsValue _mls_ls6) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls6)) {
    auto _mls_x72 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x72;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls6)) {
    auto _mls_x67 = _mlsValue::cast<_mls_Cons>(_mls_ls6)->_mls_head;
    auto _mls_x68 = _mlsValue::cast<_mls_Cons>(_mls_ls6)->_mls_tail;
    auto _mls_x69 = _mls_sim(_mls_n1, _mls_x67);
    auto _mls_x70 = _mls_listcomp(_mls_n1, _mls_x68);
    auto _mls_x71 = _mlsValue::create<_mls_Cons>(_mls_x69, _mls_x70);
    _mls_retval = _mls_x71;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_maximum(_mlsValue _mls_xs1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs1)) {
    auto _mls_x73 = _mlsValue::cast<_mls_Cons>(_mls_xs1)->_mls_head;
    auto _mls_x74 = _mlsValue::cast<_mls_Cons>(_mls_xs1)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x74)) {
      _mls_retval = _mls_x73;
    } else {
      auto _mls_x75 = _mls_maximum(_mls_x74);
      auto _mls_x76 = (_mls_x73 > _mls_x75);
      if (_mlsValue::isIntLit(_mls_x76, 1)) {
        _mls_retval = _mls_x73;
      } else {
        _mls_retval = _mls_x75;
      }
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_member(_mlsValue _mls_x80, _mlsValue _mls_ls7) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls7)) {
    _mls_retval = _mlsValue::fromIntLit(0);
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls7)) {
    auto _mls_x77 = _mlsValue::cast<_mls_Cons>(_mls_ls7)->_mls_head;
    auto _mls_x78 = _mlsValue::cast<_mls_Cons>(_mls_ls7)->_mls_tail;
    auto _mls_x79 = (_mls_x77 == _mls_x80);
    auto _mls_x81 = _mls_member(_mls_x80, _mls_x78);
    auto _mls_x82 = (_mls_x79 || _mls_x81);
    _mls_retval = _mls_x82;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_nextRandStep(_mlsValue _mls_m2, _mlsValue _mls_s1) {
  _mlsValue _mls_retval;
  auto _mls_x83 = _mls_builtin_floor_mod(_mls_s1, _mls_m2);
  auto _mls_x84 = (_mls_x83 + _mlsValue::fromIntLit(1));
  auto _mls_x85 = (_mlsValue::fromIntLit(97) * _mls_s1);
  auto _mls_x86 = (_mls_x85 + _mlsValue::fromIntLit(11));
  auto _mls_x87 = _mls_builtin_pow(_mlsValue::fromIntLit(2), _mlsValue::fromIntLit(7));
  auto _mls_x88 = _mls_builtin_floor_mod(_mls_x86, _mls_x87);
  auto _mls_x89 = _mlsValue::create<_mls_Tuple2>(_mls_x84, _mls_x88);
  _mls_retval = _mls_x89;
  return _mls_retval;
}
_mlsValue _mls_rev_f(_mlsValue _mls_ls8, _mlsValue _mls_acc1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls8)) {
    _mls_retval = _mls_acc1;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls8)) {
    auto _mls_x90 = _mlsValue::cast<_mls_Cons>(_mls_ls8)->_mls_head;
    auto _mls_x91 = _mlsValue::cast<_mls_Cons>(_mls_ls8)->_mls_tail;
    auto _mls_x92 = _mlsValue::create<_mls_Cons>(_mls_x90, _mls_acc1);
    auto _mls_x93 = _mls_rev_f(_mls_x91, _mls_x92);
    _mls_retval = _mls_x93;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_reverse(_mlsValue _mls_ls9) {
  _mlsValue _mls_retval;
  auto _mls_x94 = _mlsValue::create<_mls_Nil>();
  auto _mls_x95 = _mls_rev_f(_mls_ls9, _mls_x94);
  _mls_retval = _mls_x95;
  return _mls_retval;
}
_mlsValue _mls_sim(_mlsValue _mls_n2, _mlsValue _mls_k1) {
  _mlsValue _mls_retval;
  auto _mls_x96 = _mlsValue::create<_mls_Lambda_proc>(_mls_k1);
  auto _mls_x97 = _mls_simulate(_mls_n2, _mlsValue::fromIntLit(100), _mls_x96);
  _mls_retval = _mls_x97;
  return _mls_retval;
}
_mlsValue _mls_simulate(_mlsValue _mls_n3, _mlsValue _mls_m3, _mlsValue _mls_proc) {
  _mlsValue _mls_retval;
  auto _mls_x98 = _mlsValue::create<_mls_Lambda_lscomp>(_mls_proc, _mls_m3);
  auto _mls_x99 = _mls_enumFromTo(_mlsValue::fromIntLit(1), _mls_n3);
  auto _mls_x100 = _mlsMethodCall<_mls_Callable>(_mls_x98)->_mls_apply1(_mls_x99);
  auto _mls_x101 = _mlsValue::create<_mls_Lambda_lambda1>();
  auto _mls_x102 = _mls_filter(_mls_x101, _mls_x100);
  auto _mls_x103 = _mls_listLen(_mls_x102);
  auto _mls_x104 = _mls_builtin_int2float(_mls_x103);
  auto _mls_x105 = _mls_builtin_int2float(_mls_n3);
  auto _mls_x106 = (_mls_x104 / _mls_x105);
  _mls_retval = _mls_x106;
  return _mls_retval;
}
_mlsValue _mls_take(_mlsValue _mls_n4, _mlsValue _mls_ls10) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls10)) {
    auto _mls_x114 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x114;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls10)) {
    auto _mls_x107 = _mlsValue::cast<_mls_Cons>(_mls_ls10)->_mls_head;
    auto _mls_x108 = _mlsValue::cast<_mls_Cons>(_mls_ls10)->_mls_tail;
    auto _mls_x109 = (_mls_n4 <= _mlsValue::fromIntLit(0));
    if (_mlsValue::isIntLit(_mls_x109, 1)) {
      auto _mls_x113 = _mlsValue::create<_mls_Nil>();
      _mls_retval = _mls_x113;
    } else {
      auto _mls_x110 = (_mls_n4 - _mlsValue::fromIntLit(1));
      auto _mls_x111 = _mls_take(_mls_x110, _mls_x108);
      auto _mls_x112 = _mlsValue::create<_mls_Cons>(_mls_x107, _mls_x111);
      _mls_retval = _mls_x112;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_takeRandUnique(_mlsValue _mls_k2, _mlsValue _mls_m4, _mlsValue _mls_s2) {
  _mlsValue _mls_retval;
  auto _mls_x115 = _mlsValue::create<_mls_Lambda_loop>();
  auto _mls_x116 = _mlsValue::create<_mls_Nil>();
  auto _mls_x117 = _mlsValue::create<_mls_Nil>();
  auto _mls_x118 = _mlsMethodCall<_mls_Callable>(_mls_x115)->_mls_apply5(_mls_k2, _mls_m4, _mls_s2, _mls_x116, _mls_x117);
  _mls_retval = _mls_x118;
  return _mls_retval;
}
_mlsValue _mls_testSecretary_nofib(_mlsValue _mls_n5) {
  _mlsValue _mls_retval;
  auto _mls_x119 = _mls_enumFromTo(_mlsValue::fromIntLit(35), _mlsValue::fromIntLit(39));
  auto _mls_x120 = _mls_listcomp(_mls_n5, _mls_x119);
  _mls_retval = _mls_x120;
  return _mls_retval;
}
_mlsValue _mls_Lambda_l::_mls_apply2(_mlsValue _mls_ls, _mlsValue _mls_a) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls)) {
    _mls_retval = _mls_a;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls)) {
    auto _mls_x = _mlsValue::cast<_mls_Cons>(_mls_ls)->_mls_head;
    auto _mls_x1 = _mlsValue::cast<_mls_Cons>(_mls_ls)->_mls_tail;
    auto _mls_x2 = (_mls_a + _mlsValue::fromIntLit(1));
    auto _mls_x3 = this->_mls_apply2(_mls_x1, _mls_x2);
    _mls_retval = _mls_x3;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda::_mls_apply1(_mlsValue _mls_x5) {
  _mlsValue _mls_retval;
  auto _mls_x4 = (_mls_x5 < _mls_lam_arg0);
  _mls_retval = _mls_x4;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda1::_mls_apply1(_mlsValue _mls_x6) {
  _mlsValue _mls_retval;
  _mls_retval = _mls_x6;
  return _mls_retval;
}
_mlsValue _mls_Lambda_loop::_mls_apply5(_mlsValue _mls_k, _mlsValue _mls_m, _mlsValue _mls_s, _mlsValue _mls_seen, _mlsValue _mls_acc) {
  _mlsValue _mls_retval;
  auto _mls_x7 = (_mls_k == _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x7, 1)) {
    auto _mls_x17 = _mls_reverse(_mls_acc);
    _mls_retval = _mls_x17;
  } else {
    auto _mls_x8 = _mls_nextRandStep(_mls_m, _mls_s);
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x8)) {
      auto _mls_x9 = _mlsValue::cast<_mls_Tuple2>(_mls_x8)->_mls_field0;
      auto _mls_x10 = _mlsValue::cast<_mls_Tuple2>(_mls_x8)->_mls_field1;
      auto _mls_x11 = _mls_member(_mls_x9, _mls_seen);
      if (_mlsValue::isIntLit(_mls_x11, 1)) {
        auto _mls_x16 = this->_mls_apply5(_mls_k, _mls_m, _mls_x10, _mls_seen, _mls_acc);
        _mls_retval = _mls_x16;
      } else {
        auto _mls_x12 = (_mls_k - _mlsValue::fromIntLit(1));
        auto _mls_x13 = _mlsValue::create<_mls_Cons>(_mls_x9, _mls_seen);
        auto _mls_x14 = _mlsValue::create<_mls_Cons>(_mls_x9, _mls_acc);
        auto _mls_x15 = this->_mls_apply5(_mls_x12, _mls_m, _mls_x10, _mls_x13, _mls_x14);
        _mls_retval = _mls_x15;
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lscomp::_mls_apply1(_mlsValue _mls_ls1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls1)) {
    auto _mls_x23 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x23;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls1)) {
    auto _mls_x18 = _mlsValue::cast<_mls_Cons>(_mls_ls1)->_mls_head;
    auto _mls_x19 = _mlsValue::cast<_mls_Cons>(_mls_ls1)->_mls_tail;
    auto _mls_x20 = _mlsMethodCall<_mls_Callable>(_mls_lam_arg0)->_mls_apply2(_mls_lam_arg1, _mls_x18);
    auto _mls_x21 = this->_mls_apply1(_mls_x19);
    auto _mls_x22 = _mlsValue::create<_mls_Cons>(_mls_x20, _mls_x21);
    _mls_retval = _mls_x22;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_proc::_mls_apply2(_mlsValue _mls_m1, _mlsValue _mls_seed) {
  _mlsValue _mls_retval;
  auto _mls_x24 = _mls_takeRandUnique(_mlsValue::fromIntLit(100), _mls_m1, _mls_seed);
  auto _mls_x25 = _mlsValue::fromIntLit(100);
  auto _mls_x26 = _mls_take(_mls_lam_arg0, _mls_x24);
  auto _mls_x27 = _mls_maximum(_mls_x26);
  auto _mls_x28 = _mls_drop(_mls_lam_arg0, _mls_x24);
  auto _mls_x29 = _mlsValue::create<_mls_Lambda_lambda>(_mls_x27);
  auto _mls_x30 = _mls_dropWhile(_mls_x29, _mls_x28);
  auto _mls_x31 = _mlsValue::create<_mls_Nil>();
  auto _mls_x32 = _mlsValue::create<_mls_Cons>(_mls_x25, _mls_x31);
  auto _mls_x33 = _mls_take(_mlsValue::fromIntLit(1), _mls_x30);
  auto _mls_x34 = _mls_listEq(_mls_x32, _mls_x33);
  _mls_retval = _mls_x34;
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
