#include "mlsprelude.h"
struct _mls_Expr;
struct _mls_Add;
struct _mls_Mul;
struct _mls_Val;
struct _mls_Var;
_mlsValue _mls_appendAdd(_mlsValue, _mlsValue);
_mlsValue _mls_appendMul(_mlsValue, _mlsValue);
_mlsValue _mls_constFolding(_mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_eval1(_mlsValue);
_mlsValue _mls_main();
_mlsValue _mls_mkExpr(_mlsValue, _mlsValue);
_mlsValue _mls_reassoc(_mlsValue);
struct _mls_Expr: public _mlsObject {
  
  constexpr static inline const char *typeName = "Expr";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Expr; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Add: public _mls_Expr {
  _mlsValue _mls_e1;
  _mlsValue _mls_e2;
  constexpr static inline const char *typeName = "Add";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e1.print(); std::printf(", "); this->_mls_e2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e1); _mlsValue::destroy(this->_mls_e2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e1.asObject()->operator==(*other.cast<_mls_Add>()->_mls_e1.asObject()) && this->_mls_e2.asObject()->operator==(*other.cast<_mls_Add>()->_mls_e2.asObject()); }
  static _mlsValue create(_mlsValue _mls_e1, _mlsValue _mls_e2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Add; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e1 = _mls_e1; _mlsVal->_mls_e2 = _mls_e2;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Mul: public _mls_Expr {
  _mlsValue _mls_e1;
  _mlsValue _mls_e2;
  constexpr static inline const char *typeName = "Mul";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e1.print(); std::printf(", "); this->_mls_e2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e1); _mlsValue::destroy(this->_mls_e2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e1.asObject()->operator==(*other.cast<_mls_Mul>()->_mls_e1.asObject()) && this->_mls_e2.asObject()->operator==(*other.cast<_mls_Mul>()->_mls_e2.asObject()); }
  static _mlsValue create(_mlsValue _mls_e1, _mlsValue _mls_e2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Mul; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e1 = _mls_e1; _mlsVal->_mls_e2 = _mls_e2;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Val: public _mls_Expr {
  _mlsValue _mls_n;
  constexpr static inline const char *typeName = "Val";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_n.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_n);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_n.asObject()->operator==(*other.cast<_mls_Val>()->_mls_n.asObject()); }
  static _mlsValue create(_mlsValue _mls_n) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Val; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_n = _mls_n;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Var: public _mls_Expr {
  _mlsValue _mls_x;
  constexpr static inline const char *typeName = "Var";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_x.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_x);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_x.asObject()->operator==(*other.cast<_mls_Var>()->_mls_x.asObject()); }
  static _mlsValue create(_mlsValue _mls_x) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Var; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_x = _mls_x;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_appendAdd(_mlsValue _mls_e12, _mlsValue _mls_e22) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_e12)) {
    auto _mls_x2 = _mlsValue::cast<_mls_Add>(_mls_e12)->_mls_e1;
    auto _mls_x3 = _mlsValue::cast<_mls_Add>(_mls_e12)->_mls_e2;
    auto _mls_x4 = _mls_appendAdd(_mls_x3, _mls_e22);
    auto _mls_x5 = _mlsValue::create<_mls_Add>(_mls_x2, _mls_x4);
    _mls_retval = _mls_x5;
  } else {
    auto _mls_x1 = _mlsValue::create<_mls_Add>(_mls_e12, _mls_e22);
    _mls_retval = _mls_x1;
  }
  return _mls_retval;
}
_mlsValue _mls_appendMul(_mlsValue _mls_e13, _mlsValue _mls_e23) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Mul>(_mls_e13)) {
    auto _mls_x7 = _mlsValue::cast<_mls_Mul>(_mls_e13)->_mls_e1;
    auto _mls_x8 = _mlsValue::cast<_mls_Mul>(_mls_e13)->_mls_e2;
    auto _mls_x9 = _mls_appendMul(_mls_x8, _mls_e23);
    auto _mls_x10 = _mlsValue::create<_mls_Mul>(_mls_x7, _mls_x9);
    _mls_retval = _mls_x10;
  } else {
    auto _mls_x6 = _mlsValue::create<_mls_Mul>(_mls_e13, _mls_e23);
    _mls_retval = _mls_x6;
  }
  return _mls_retval;
}
_mlsValue _mls_constFolding(_mlsValue _mls_e) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_e)) {
    auto _mls_x32 = _mlsValue::cast<_mls_Add>(_mls_e)->_mls_e1;
    auto _mls_x33 = _mlsValue::cast<_mls_Add>(_mls_e)->_mls_e2;
    auto _mls_x34 = _mls_constFolding(_mls_x32);
    auto _mls_x35 = _mls_constFolding(_mls_x33);
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x34)) {
      auto _mls_x37 = _mlsValue::cast<_mls_Val>(_mls_x34)->_mls_n;
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x35)) {
        auto _mls_x50 = _mlsValue::cast<_mls_Val>(_mls_x35)->_mls_n;
        auto _mls_x51 = (_mls_x37 + _mls_x50);
        auto _mls_x52 = _mlsValue::create<_mls_Val>(_mls_x51);
        _mls_retval = _mls_x52;
      } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x35)) {
        auto _mls_x39 = _mlsValue::cast<_mls_Add>(_mls_x35)->_mls_e1;
        auto _mls_x40 = _mlsValue::cast<_mls_Add>(_mls_x35)->_mls_e2;
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x40)) {
          auto _mls_x46 = _mlsValue::cast<_mls_Val>(_mls_x40)->_mls_n;
          auto _mls_x47 = (_mls_x37 + _mls_x46);
          auto _mls_x48 = _mlsValue::create<_mls_Val>(_mls_x47);
          auto _mls_x49 = _mlsValue::create<_mls_Add>(_mls_x48, _mls_x39);
          _mls_retval = _mls_x49;
        } else {
          if (_mlsValue::isValueOf<_mls_Val>(_mls_x39)) {
            auto _mls_x42 = _mlsValue::cast<_mls_Val>(_mls_x39)->_mls_n;
            auto _mls_x43 = (_mls_x37 + _mls_x42);
            auto _mls_x44 = _mlsValue::create<_mls_Val>(_mls_x43);
            auto _mls_x45 = _mlsValue::create<_mls_Add>(_mls_x44, _mls_x40);
            _mls_retval = _mls_x45;
          } else {
            auto _mls_x41 = _mlsValue::create<_mls_Add>(_mls_x34, _mls_x35);
            _mls_retval = _mls_x41;
          }
        }
      } else {
        auto _mls_x38 = _mlsValue::create<_mls_Add>(_mls_x34, _mls_x35);
        _mls_retval = _mls_x38;
      }
    } else {
      auto _mls_x36 = _mlsValue::create<_mls_Add>(_mls_x34, _mls_x35);
      _mls_retval = _mls_x36;
    }
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_e)) {
    auto _mls_x11 = _mlsValue::cast<_mls_Mul>(_mls_e)->_mls_e1;
    auto _mls_x12 = _mlsValue::cast<_mls_Mul>(_mls_e)->_mls_e2;
    auto _mls_x13 = _mls_constFolding(_mls_x11);
    auto _mls_x14 = _mls_constFolding(_mls_x12);
    if (_mlsValue::isValueOf<_mls_Val>(_mls_x13)) {
      auto _mls_x16 = _mlsValue::cast<_mls_Val>(_mls_x13)->_mls_n;
      if (_mlsValue::isValueOf<_mls_Val>(_mls_x14)) {
        auto _mls_x29 = _mlsValue::cast<_mls_Val>(_mls_x14)->_mls_n;
        auto _mls_x30 = (_mls_x16 * _mls_x29);
        auto _mls_x31 = _mlsValue::create<_mls_Val>(_mls_x30);
        _mls_retval = _mls_x31;
      } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_x14)) {
        auto _mls_x18 = _mlsValue::cast<_mls_Mul>(_mls_x14)->_mls_e1;
        auto _mls_x19 = _mlsValue::cast<_mls_Mul>(_mls_x14)->_mls_e2;
        if (_mlsValue::isValueOf<_mls_Val>(_mls_x19)) {
          auto _mls_x25 = _mlsValue::cast<_mls_Val>(_mls_x19)->_mls_n;
          auto _mls_x26 = (_mls_x16 * _mls_x25);
          auto _mls_x27 = _mlsValue::create<_mls_Val>(_mls_x26);
          auto _mls_x28 = _mlsValue::create<_mls_Mul>(_mls_x27, _mls_x18);
          _mls_retval = _mls_x28;
        } else {
          if (_mlsValue::isValueOf<_mls_Val>(_mls_x18)) {
            auto _mls_x21 = _mlsValue::cast<_mls_Val>(_mls_x18)->_mls_n;
            auto _mls_x22 = (_mls_x16 * _mls_x21);
            auto _mls_x23 = _mlsValue::create<_mls_Val>(_mls_x22);
            auto _mls_x24 = _mlsValue::create<_mls_Mul>(_mls_x23, _mls_x19);
            _mls_retval = _mls_x24;
          } else {
            auto _mls_x20 = _mlsValue::create<_mls_Mul>(_mls_x13, _mls_x14);
            _mls_retval = _mls_x20;
          }
        }
      } else {
        auto _mls_x17 = _mlsValue::create<_mls_Mul>(_mls_x13, _mls_x14);
        _mls_retval = _mls_x17;
      }
    } else {
      auto _mls_x15 = _mlsValue::create<_mls_Mul>(_mls_x13, _mls_x14);
      _mls_retval = _mls_x15;
    }
  } else {
    _mls_retval = _mls_e;
  }
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x53 = _mls_main();
  _mls_retval = _mls_x53;
  return _mls_retval;
}
_mlsValue _mls_eval1(_mlsValue _mls_e3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Var>(_mls_e3)) {
    _mls_retval = _mlsValue::fromIntLit(0);
  } else if (_mlsValue::isValueOf<_mls_Val>(_mls_e3)) {
    auto _mls_x64 = _mlsValue::cast<_mls_Val>(_mls_e3)->_mls_n;
    _mls_retval = _mls_x64;
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_e3)) {
    auto _mls_x59 = _mlsValue::cast<_mls_Add>(_mls_e3)->_mls_e1;
    auto _mls_x60 = _mlsValue::cast<_mls_Add>(_mls_e3)->_mls_e2;
    auto _mls_x61 = _mls_eval1(_mls_x59);
    auto _mls_x62 = _mls_eval1(_mls_x60);
    auto _mls_x63 = (_mls_x61 + _mls_x62);
    _mls_retval = _mls_x63;
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_e3)) {
    auto _mls_x54 = _mlsValue::cast<_mls_Mul>(_mls_e3)->_mls_e1;
    auto _mls_x55 = _mlsValue::cast<_mls_Mul>(_mls_e3)->_mls_e2;
    auto _mls_x56 = _mls_eval1(_mls_x54);
    auto _mls_x57 = _mls_eval1(_mls_x55);
    auto _mls_x58 = (_mls_x56 * _mls_x57);
    _mls_retval = _mls_x58;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_main() {
  _mlsValue _mls_retval;
  auto _mls_x65 = _mls_mkExpr(_mlsValue::fromIntLit(21), _mlsValue::fromIntLit(1));
  auto _mls_x66 = _mls_eval1(_mls_x65);
  auto _mls_x67 = _mls_reassoc(_mls_x65);
  auto _mls_x68 = _mls_constFolding(_mls_x67);
  auto _mls_x69 = _mls_eval1(_mls_x68);
  auto _mls_x70 = (_mls_x66 == _mls_x69);
  _mls_retval = _mls_x70;
  return _mls_retval;
}
_mlsValue _mls_mkExpr(_mlsValue _mls_n1, _mlsValue _mls_v) {
  _mlsValue _mls_retval;
  auto _mls_x71 = (_mls_n1 == _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x71, 1)) {
    auto _mls_x79 = (_mls_v == _mlsValue::fromIntLit(0));
    if (_mlsValue::isIntLit(_mls_x79, 1)) {
      auto _mls_x81 = _mlsValue::create<_mls_Var>(_mlsValue::fromIntLit(1));
      _mls_retval = _mls_x81;
    } else {
      auto _mls_x80 = _mlsValue::create<_mls_Val>(_mls_v);
      _mls_retval = _mls_x80;
    }
  } else {
    auto _mls_x72 = (_mls_n1 - _mlsValue::fromIntLit(1));
    auto _mls_x73 = (_mls_v + _mlsValue::fromIntLit(1));
    auto _mls_x74 = _mls_mkExpr(_mls_x72, _mls_x73);
    auto _mls_x75 = (_mls_n1 - _mlsValue::fromIntLit(1));
    auto _mls_x76 = (_mls_v - _mlsValue::fromIntLit(1));
    auto _mls_x77 = _mls_mkExpr(_mls_x75, _mls_x76);
    auto _mls_x78 = _mlsValue::create<_mls_Add>(_mls_x74, _mls_x77);
    _mls_retval = _mls_x78;
  }
  return _mls_retval;
}
_mlsValue _mls_reassoc(_mlsValue _mls_e4) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Add>(_mls_e4)) {
    auto _mls_x87 = _mlsValue::cast<_mls_Add>(_mls_e4)->_mls_e1;
    auto _mls_x88 = _mlsValue::cast<_mls_Add>(_mls_e4)->_mls_e2;
    auto _mls_x89 = _mls_reassoc(_mls_x87);
    auto _mls_x90 = _mls_reassoc(_mls_x88);
    auto _mls_x91 = _mls_appendAdd(_mls_x89, _mls_x90);
    _mls_retval = _mls_x91;
  } else if (_mlsValue::isValueOf<_mls_Mul>(_mls_e4)) {
    auto _mls_x82 = _mlsValue::cast<_mls_Mul>(_mls_e4)->_mls_e1;
    auto _mls_x83 = _mlsValue::cast<_mls_Mul>(_mls_e4)->_mls_e2;
    auto _mls_x84 = _mls_reassoc(_mls_x82);
    auto _mls_x85 = _mls_reassoc(_mls_x83);
    auto _mls_x86 = _mls_appendMul(_mls_x84, _mls_x85);
    _mls_retval = _mls_x86;
  } else {
    _mls_retval = _mls_e4;
  }
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
