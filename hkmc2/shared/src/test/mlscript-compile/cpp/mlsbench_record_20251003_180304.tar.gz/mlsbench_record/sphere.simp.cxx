#include "mlsprelude.h"
struct _mls_Lambda_f;
struct _mls_Lambda_f1;
struct _mls_Lambda_lambda;
struct _mls_Lambda_lscomp;
struct _mls_Lambda_lscomp1;
struct _mls_Lambda_lscomp2;
struct _mls_Lambda_lscomp21;
struct _mls_Lambda_lscomp3;
struct _mls_Lambda_lscomp4;
struct _mls_Lambda_lscomp5;
struct _mls_Lambda_lscomp6;
struct _mls_Lambda_lscomp7;
struct _mls_Lambda_lscomp8;
struct _mls_Lambda_snd;
struct _mls_Lambda_sphmap;
struct _mls_Lambda_vecadd;
struct _mls_Light;
struct _mls_Directional;
struct _mls_List;
struct _mls_Cons;
struct _mls_Nil;
struct _mls_Point;
struct _mls_Sphere;
struct _mls_Surfspec;
struct _mls_Ambient;
struct _mls_Body;
struct _mls_Diffuse;
struct _mls_Reflect;
struct _mls_Refract;
struct _mls_Specpow;
struct _mls_Specular;
struct _mls_Transmit;
struct _mls_Tuple2;
struct _mls_Tuple3;
_mlsValue _mls_ambientsurf(_mlsValue);
_mlsValue _mls_append(_mlsValue, _mlsValue);
_mlsValue _mls_bodysurf(_mlsValue);
_mlsValue _mls_camparams(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_diffusesurf(_mlsValue);
_mlsValue _mls_dtor(_mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_enumFromTo(_mlsValue, _mlsValue);
_mlsValue _mls_foldr(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_fst(_mlsValue);
_mlsValue _mls_head1(_mlsValue);
_mlsValue _mls_is_zerovector(_mlsValue);
_mlsValue _mls_j1(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_j2(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_j4(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_j3(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_j5(_mlsValue, _mlsValue);
_mlsValue _mls_lightcolour(_mlsValue);
_mlsValue _mls_lightdirection(_mlsValue, _mlsValue);
_mlsValue _mls_lightray(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_map(_mlsValue, _mlsValue);
_mlsValue _mls_not(_mlsValue);
_mlsValue _mls_null_(_mlsValue);
_mlsValue _mls_ray(_mlsValue);
_mlsValue _mls_reflectray(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_reflectsurf(_mlsValue);
_mlsValue _mls_refractray(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_refractsurf(_mlsValue);
_mlsValue _mls_repeatRun(_mlsValue, _mlsValue);
_mlsValue _mls_run(_mlsValue);
_mlsValue _mls_s2();
_mlsValue _mls_shade(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_shadowed(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_snd(_mlsValue);
_mlsValue _mls_specpowsurf(_mlsValue);
_mlsValue _mls_specularsurf(_mlsValue);
_mlsValue _mls_sphereintersect(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_spherenormal(_mlsValue, _mlsValue);
_mlsValue _mls_spheresurf(_mlsValue);
_mlsValue _mls_tail1(_mlsValue);
_mlsValue _mls_testlights();
_mlsValue _mls_testspheres();
_mlsValue _mls_trace(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_tracepixel(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_transmitray(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_transmitsurf(_mlsValue);
_mlsValue _mls_vecadd(_mlsValue, _mlsValue);
_mlsValue _mls_veccross(_mlsValue, _mlsValue);
_mlsValue _mls_vecdot(_mlsValue, _mlsValue);
_mlsValue _mls_vecmult(_mlsValue, _mlsValue);
_mlsValue _mls_vecnorm(_mlsValue);
_mlsValue _mls_vecscale(_mlsValue, _mlsValue);
_mlsValue _mls_vecsub(_mlsValue, _mlsValue);
_mlsValue _mls_vecsum(_mlsValue);
struct _mls_Lambda_f: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  _mlsValue _mls_lam_arg1;
  _mlsValue _mls_lam_arg2;
  _mlsValue _mls_lam_arg3;
  constexpr static inline const char *typeName = "Lambda_f";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print(); std::printf(", "); this->_mls_lam_arg1.print(); std::printf(", "); this->_mls_lam_arg2.print(); std::printf(", "); this->_mls_lam_arg3.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0); _mlsValue::destroy(this->_mls_lam_arg1); _mlsValue::destroy(this->_mls_lam_arg2); _mlsValue::destroy(this->_mls_lam_arg3);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_f>()->_mls_lam_arg0.asObject()) && this->_mls_lam_arg1.asObject()->operator==(*other.cast<_mls_Lambda_f>()->_mls_lam_arg1.asObject()) && this->_mls_lam_arg2.asObject()->operator==(*other.cast<_mls_Lambda_f>()->_mls_lam_arg2.asObject()) && this->_mls_lam_arg3.asObject()->operator==(*other.cast<_mls_Lambda_f>()->_mls_lam_arg3.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0, _mlsValue _mls_lam_arg1, _mlsValue _mls_lam_arg2, _mlsValue _mls_lam_arg3) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_f; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0; _mlsVal->_mls_lam_arg1 = _mls_lam_arg1; _mlsVal->_mls_lam_arg2 = _mls_lam_arg2; _mlsVal->_mls_lam_arg3 = _mls_lam_arg3;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_f1: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_f";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_f1; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_lambda: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  _mlsValue _mls_lam_arg1;
  _mlsValue _mls_lam_arg2;
  _mlsValue _mls_lam_arg3;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print(); std::printf(", "); this->_mls_lam_arg1.print(); std::printf(", "); this->_mls_lam_arg2.print(); std::printf(", "); this->_mls_lam_arg3.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0); _mlsValue::destroy(this->_mls_lam_arg1); _mlsValue::destroy(this->_mls_lam_arg2); _mlsValue::destroy(this->_mls_lam_arg3);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda>()->_mls_lam_arg0.asObject()) && this->_mls_lam_arg1.asObject()->operator==(*other.cast<_mls_Lambda_lambda>()->_mls_lam_arg1.asObject()) && this->_mls_lam_arg2.asObject()->operator==(*other.cast<_mls_Lambda_lambda>()->_mls_lam_arg2.asObject()) && this->_mls_lam_arg3.asObject()->operator==(*other.cast<_mls_Lambda_lambda>()->_mls_lam_arg3.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0, _mlsValue _mls_lam_arg1, _mlsValue _mls_lam_arg2, _mlsValue _mls_lam_arg3) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0; _mlsVal->_mls_lam_arg1 = _mls_lam_arg1; _mlsVal->_mls_lam_arg2 = _mls_lam_arg2; _mlsVal->_mls_lam_arg3 = _mls_lam_arg3;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lscomp: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lscomp";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lscomp; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lscomp1: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  _mlsValue _mls_lam_arg1;
  constexpr static inline const char *typeName = "Lambda_lscomp1";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print(); std::printf(", "); this->_mls_lam_arg1.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0); _mlsValue::destroy(this->_mls_lam_arg1);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lscomp1>()->_mls_lam_arg0.asObject()) && this->_mls_lam_arg1.asObject()->operator==(*other.cast<_mls_Lambda_lscomp1>()->_mls_lam_arg1.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0, _mlsValue _mls_lam_arg1) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lscomp1; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0; _mlsVal->_mls_lam_arg1 = _mls_lam_arg1;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lscomp2: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lscomp";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lscomp2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lscomp21: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  _mlsValue _mls_lam_arg1;
  _mlsValue _mls_lam_arg2;
  _mlsValue _mls_lam_arg3;
  constexpr static inline const char *typeName = "Lambda_lscomp2";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print(); std::printf(", "); this->_mls_lam_arg1.print(); std::printf(", "); this->_mls_lam_arg2.print(); std::printf(", "); this->_mls_lam_arg3.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0); _mlsValue::destroy(this->_mls_lam_arg1); _mlsValue::destroy(this->_mls_lam_arg2); _mlsValue::destroy(this->_mls_lam_arg3);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lscomp21>()->_mls_lam_arg0.asObject()) && this->_mls_lam_arg1.asObject()->operator==(*other.cast<_mls_Lambda_lscomp21>()->_mls_lam_arg1.asObject()) && this->_mls_lam_arg2.asObject()->operator==(*other.cast<_mls_Lambda_lscomp21>()->_mls_lam_arg2.asObject()) && this->_mls_lam_arg3.asObject()->operator==(*other.cast<_mls_Lambda_lscomp21>()->_mls_lam_arg3.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0, _mlsValue _mls_lam_arg1, _mlsValue _mls_lam_arg2, _mlsValue _mls_lam_arg3) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lscomp21; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0; _mlsVal->_mls_lam_arg1 = _mls_lam_arg1; _mlsVal->_mls_lam_arg2 = _mls_lam_arg2; _mlsVal->_mls_lam_arg3 = _mls_lam_arg3;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lscomp3: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lscomp";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lscomp3; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lscomp4: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lscomp";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lscomp4; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lscomp5: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lscomp";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lscomp5; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lscomp6: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lscomp";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lscomp6; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lscomp7: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lscomp";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lscomp7; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lscomp8: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lscomp";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lscomp8; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_snd: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_snd";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_snd; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_sphmap: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  _mlsValue _mls_lam_arg1;
  constexpr static inline const char *typeName = "Lambda_sphmap";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print(); std::printf(", "); this->_mls_lam_arg1.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0); _mlsValue::destroy(this->_mls_lam_arg1);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_sphmap>()->_mls_lam_arg0.asObject()) && this->_mls_lam_arg1.asObject()->operator==(*other.cast<_mls_Lambda_sphmap>()->_mls_lam_arg1.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0, _mlsValue _mls_lam_arg1) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_sphmap; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0; _mlsVal->_mls_lam_arg1 = _mls_lam_arg1;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_vecadd: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_vecadd";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_vecadd; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Light: public _mlsObject {
  
  constexpr static inline const char *typeName = "Light";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Light; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Directional: public _mls_Light {
  _mlsValue _mls_x;
  _mlsValue _mls_y;
  constexpr static inline const char *typeName = "Directional";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_x.print(); std::printf(", "); this->_mls_y.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_x); _mlsValue::destroy(this->_mls_y);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_x.asObject()->operator==(*other.cast<_mls_Directional>()->_mls_x.asObject()) && this->_mls_y.asObject()->operator==(*other.cast<_mls_Directional>()->_mls_y.asObject()); }
  static _mlsValue create(_mlsValue _mls_x, _mlsValue _mls_y) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Directional; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_x = _mls_x; _mlsVal->_mls_y = _mls_y;  return _mlsValue(_mlsVal); }
  
};
struct _mls_List: public _mlsObject {
  
  constexpr static inline const char *typeName = "List";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_List; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Cons: public _mls_List {
  _mlsValue _mls_head;
  _mlsValue _mls_tail;
  constexpr static inline const char *typeName = "Cons";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_head.print(); std::printf(", "); this->_mls_tail.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_head); _mlsValue::destroy(this->_mls_tail);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_head.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_head.asObject()) && this->_mls_tail.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_tail.asObject()); }
  static _mlsValue create(_mlsValue _mls_head, _mlsValue _mls_tail) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Cons; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_head = _mls_head; _mlsVal->_mls_tail = _mls_tail;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Nil: public _mls_List {
  
  constexpr static inline const char *typeName = "Nil";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Nil; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Point: public _mls_Light {
  _mlsValue _mls_x;
  _mlsValue _mls_y;
  constexpr static inline const char *typeName = "Point";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_x.print(); std::printf(", "); this->_mls_y.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_x); _mlsValue::destroy(this->_mls_y);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_x.asObject()->operator==(*other.cast<_mls_Point>()->_mls_x.asObject()) && this->_mls_y.asObject()->operator==(*other.cast<_mls_Point>()->_mls_y.asObject()); }
  static _mlsValue create(_mlsValue _mls_x, _mlsValue _mls_y) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Point; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_x = _mls_x; _mlsVal->_mls_y = _mls_y;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Sphere: public _mlsObject {
  _mlsValue _mls_pos;
  _mlsValue _mls_radius;
  _mlsValue _mls_surface;
  constexpr static inline const char *typeName = "Sphere";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_pos.print(); std::printf(", "); this->_mls_radius.print(); std::printf(", "); this->_mls_surface.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_pos); _mlsValue::destroy(this->_mls_radius); _mlsValue::destroy(this->_mls_surface);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_pos.asObject()->operator==(*other.cast<_mls_Sphere>()->_mls_pos.asObject()) && this->_mls_radius.asObject()->operator==(*other.cast<_mls_Sphere>()->_mls_radius.asObject()) && this->_mls_surface.asObject()->operator==(*other.cast<_mls_Sphere>()->_mls_surface.asObject()); }
  static _mlsValue create(_mlsValue _mls_pos, _mlsValue _mls_radius, _mlsValue _mls_surface) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Sphere; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_pos = _mls_pos; _mlsVal->_mls_radius = _mls_radius; _mlsVal->_mls_surface = _mls_surface;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Surfspec: public _mlsObject {
  
  constexpr static inline const char *typeName = "Surfspec";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Surfspec; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Ambient: public _mls_Surfspec {
  _mlsValue _mls_v;
  constexpr static inline const char *typeName = "Ambient";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_v.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_v);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_v.asObject()->operator==(*other.cast<_mls_Ambient>()->_mls_v.asObject()); }
  static _mlsValue create(_mlsValue _mls_v) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Ambient; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_v = _mls_v;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Body: public _mls_Surfspec {
  _mlsValue _mls_v;
  constexpr static inline const char *typeName = "Body";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_v.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_v);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_v.asObject()->operator==(*other.cast<_mls_Body>()->_mls_v.asObject()); }
  static _mlsValue create(_mlsValue _mls_v) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Body; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_v = _mls_v;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Diffuse: public _mls_Surfspec {
  _mlsValue _mls_v;
  constexpr static inline const char *typeName = "Diffuse";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_v.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_v);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_v.asObject()->operator==(*other.cast<_mls_Diffuse>()->_mls_v.asObject()); }
  static _mlsValue create(_mlsValue _mls_v) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Diffuse; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_v = _mls_v;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Reflect: public _mls_Surfspec {
  _mlsValue _mls_v;
  constexpr static inline const char *typeName = "Reflect";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_v.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_v);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_v.asObject()->operator==(*other.cast<_mls_Reflect>()->_mls_v.asObject()); }
  static _mlsValue create(_mlsValue _mls_v) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Reflect; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_v = _mls_v;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Refract: public _mls_Surfspec {
  _mlsValue _mls_v;
  constexpr static inline const char *typeName = "Refract";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_v.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_v);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_v.asObject()->operator==(*other.cast<_mls_Refract>()->_mls_v.asObject()); }
  static _mlsValue create(_mlsValue _mls_v) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Refract; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_v = _mls_v;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Specpow: public _mls_Surfspec {
  _mlsValue _mls_v;
  constexpr static inline const char *typeName = "Specpow";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_v.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_v);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_v.asObject()->operator==(*other.cast<_mls_Specpow>()->_mls_v.asObject()); }
  static _mlsValue create(_mlsValue _mls_v) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Specpow; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_v = _mls_v;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Specular: public _mls_Surfspec {
  _mlsValue _mls_v;
  constexpr static inline const char *typeName = "Specular";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_v.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_v);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_v.asObject()->operator==(*other.cast<_mls_Specular>()->_mls_v.asObject()); }
  static _mlsValue create(_mlsValue _mls_v) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Specular; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_v = _mls_v;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Transmit: public _mls_Surfspec {
  _mlsValue _mls_v;
  constexpr static inline const char *typeName = "Transmit";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_v.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_v);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_v.asObject()->operator==(*other.cast<_mls_Transmit>()->_mls_v.asObject()); }
  static _mlsValue create(_mlsValue _mls_v) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Transmit; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_v = _mls_v;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Tuple2: public _mlsObject {
  _mlsValue _mls_field0;
  _mlsValue _mls_field1;
  constexpr static inline const char *typeName = "Tuple2";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_field0.print(); std::printf(", "); this->_mls_field1.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_field0); _mlsValue::destroy(this->_mls_field1);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_field0.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field0.asObject()) && this->_mls_field1.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field1.asObject()); }
  static _mlsValue create(_mlsValue _mls_field0, _mlsValue _mls_field1) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Tuple2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_field0 = _mls_field0; _mlsVal->_mls_field1 = _mls_field1;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Tuple3: public _mlsObject {
  _mlsValue _mls_field0;
  _mlsValue _mls_field1;
  _mlsValue _mls_field2;
  constexpr static inline const char *typeName = "Tuple3";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_field0.print(); std::printf(", "); this->_mls_field1.print(); std::printf(", "); this->_mls_field2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_field0); _mlsValue::destroy(this->_mls_field1); _mlsValue::destroy(this->_mls_field2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_field0.asObject()->operator==(*other.cast<_mls_Tuple3>()->_mls_field0.asObject()) && this->_mls_field1.asObject()->operator==(*other.cast<_mls_Tuple3>()->_mls_field1.asObject()) && this->_mls_field2.asObject()->operator==(*other.cast<_mls_Tuple3>()->_mls_field2.asObject()); }
  static _mlsValue create(_mlsValue _mls_field0, _mlsValue _mls_field1, _mlsValue _mls_field2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Tuple3; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_field0 = _mls_field0; _mlsVal->_mls_field1 = _mls_field1; _mlsVal->_mls_field2 = _mls_field2;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_ambientsurf(_mlsValue _mls_ss) {
  _mlsValue _mls_retval;
  auto _mls_x95 = _mlsValue::create<_mls_Lambda_lscomp4>();
  auto _mls_x96 = _mlsMethodCall<_mls_Callable>(_mls_x95)->_mls_apply1(_mls_ss);
  auto _mls_x97 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
  auto _mls_x98 = _mlsValue::create<_mls_Nil>();
  auto _mls_x99 = _mlsValue::create<_mls_Cons>(_mls_x97, _mls_x98);
  auto _mls_x100 = _mls_append(_mls_x96, _mls_x99);
  auto _mls_x101 = _mls_head1(_mls_x100);
  _mls_retval = _mls_x101;
  return _mls_retval;
}
_mlsValue _mls_append(_mlsValue _mls_xs, _mlsValue _mls_ys) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs)) {
    _mls_retval = _mls_ys;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs)) {
    auto _mls_x102 = _mlsValue::cast<_mls_Cons>(_mls_xs)->_mls_head;
    auto _mls_x103 = _mlsValue::cast<_mls_Cons>(_mls_xs)->_mls_tail;
    auto _mls_x104 = _mls_append(_mls_x103, _mls_ys);
    auto _mls_x105 = _mlsValue::create<_mls_Cons>(_mls_x102, _mls_x104);
    _mls_retval = _mls_x105;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_bodysurf(_mlsValue _mls_ss1) {
  _mlsValue _mls_retval;
  auto _mls_x106 = _mlsValue::create<_mls_Lambda_lscomp2>();
  auto _mls_x107 = _mlsMethodCall<_mls_Callable>(_mls_x106)->_mls_apply1(_mls_ss1);
  auto _mls_x108 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0));
  auto _mls_x109 = _mlsValue::create<_mls_Nil>();
  auto _mls_x110 = _mlsValue::create<_mls_Cons>(_mls_x108, _mls_x109);
  auto _mls_x111 = _mls_append(_mls_x107, _mls_x110);
  auto _mls_x112 = _mls_head1(_mls_x111);
  _mls_retval = _mls_x112;
  return _mls_retval;
}
_mlsValue _mls_camparams(_mlsValue _mls_lookfrom, _mlsValue _mls_lookat, _mlsValue _mls_vup, _mlsValue _mls_fov, _mlsValue _mls_winsize) {
  _mlsValue _mls_retval;
  auto _mls_x113 = _mls_vecsub(_mls_lookat, _mls_lookfrom);
  auto _mls_x114 = _mls_vecnorm(_mls_x113);
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x114)) {
    auto _mls_x115 = _mlsValue::cast<_mls_Tuple2>(_mls_x114)->_mls_field0;
    auto _mls_x116 = _mlsValue::cast<_mls_Tuple2>(_mls_x114)->_mls_field1;
    auto _mls_x117 = _mls_veccross(_mls_x115, _mls_vup);
    auto _mls_x118 = _mls_vecnorm(_mls_x117);
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x118)) {
      auto _mls_x119 = _mlsValue::cast<_mls_Tuple2>(_mls_x118)->_mls_field0;
      auto _mls_x120 = _mls_veccross(_mls_x119, _mls_x115);
      auto _mls_x121 = _mls_vecnorm(_mls_x120);
      if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x121)) {
        auto _mls_x122 = _mlsValue::cast<_mls_Tuple2>(_mls_x121)->_mls_field0;
        auto _mls_x123 = (_mlsValue::create<_mls_Float>(2.0) * _mls_x116);
        auto _mls_x124 = (_mls_fov / _mlsValue::create<_mls_Float>(2.0));
        auto _mls_x125 = _mls_dtor(_mls_x124);
        auto _mls_x126 = _mls_builtin_tan(_mls_x125);
        auto _mls_x127 = (_mls_x123 * _mls_x126);
        auto _mls_x128 = (_mls_x127 / _mls_winsize);
        auto _mls_x129 = (_mlsValue::create<_mls_Float>(2.0) * _mls_x116);
        auto _mls_x130 = (_mls_fov / _mlsValue::create<_mls_Float>(2.0));
        auto _mls_x131 = _mls_dtor(_mls_x130);
        auto _mls_x132 = _mls_builtin_tan(_mls_x131);
        auto _mls_x133 = (_mls_x129 * _mls_x132);
        auto _mls_x134 = (_mls_x133 / _mls_winsize);
        auto _mls_x135 = _mls_vecscale(_mls_x119, _mls_x128);
        auto _mls_x136 = _mls_vecscale(_mls_x122, _mls_x134);
        auto _mls_x137 = (_mlsValue::create<_mls_Float>(0.5) * _mls_winsize);
        auto _mls_x138 = _mls_vecscale(_mls_x135, _mls_x137);
        auto _mls_x139 = (_mlsValue::create<_mls_Float>(0.5) * _mls_winsize);
        auto _mls_x140 = _mls_vecscale(_mls_x136, _mls_x139);
        auto _mls_x141 = _mls_vecadd(_mls_x138, _mls_x140);
        auto _mls_x142 = _mls_vecsub(_mls_x113, _mls_x141);
        auto _mls_x143 = _mlsValue::create<_mls_Tuple3>(_mls_x142, _mls_x135, _mls_x136);
        _mls_retval = _mls_x143;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_diffusesurf(_mlsValue _mls_ss2) {
  _mlsValue _mls_retval;
  auto _mls_x144 = _mlsValue::create<_mls_Lambda_lscomp3>();
  auto _mls_x145 = _mlsMethodCall<_mls_Callable>(_mls_x144)->_mls_apply1(_mls_ss2);
  auto _mls_x146 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
  auto _mls_x147 = _mlsValue::create<_mls_Nil>();
  auto _mls_x148 = _mlsValue::create<_mls_Cons>(_mls_x146, _mls_x147);
  auto _mls_x149 = _mls_append(_mls_x145, _mls_x148);
  auto _mls_x150 = _mls_head1(_mls_x149);
  _mls_retval = _mls_x150;
  return _mls_retval;
}
_mlsValue _mls_dtor(_mlsValue _mls_x152) {
  _mlsValue _mls_retval;
  auto _mls_x151 = (_mls_x152 * _mlsValue::create<_mls_Float>(3.141592653589793));
  auto _mls_x153 = (_mls_x151 / _mlsValue::create<_mls_Float>(180.0));
  _mls_retval = _mls_x153;
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x154 = _mls_repeatRun(_mlsValue::create<_mls_Float>(30.0), _mlsValue::fromIntLit(50));
  _mls_retval = _mls_x154;
  return _mls_retval;
}
_mlsValue _mls_enumFromTo(_mlsValue _mls_a, _mlsValue _mls_b) {
  _mlsValue _mls_retval;
  auto _mls_x155 = (_mls_a <= _mls_b);
  if (_mlsValue::isIntLit(_mls_x155, 1)) {
    auto _mls_x157 = (_mls_a + _mlsValue::create<_mls_Float>(1.0));
    auto _mls_x158 = _mls_enumFromTo(_mls_x157, _mls_b);
    auto _mls_x159 = _mlsValue::create<_mls_Cons>(_mls_a, _mls_x158);
    _mls_retval = _mls_x159;
  } else {
    auto _mls_x156 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x156;
  }
  return _mls_retval;
}
_mlsValue _mls_foldr(_mlsValue _mls_f, _mlsValue _mls_z, _mlsValue _mls_xs1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs1)) {
    _mls_retval = _mls_z;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs1)) {
    auto _mls_x160 = _mlsValue::cast<_mls_Cons>(_mls_xs1)->_mls_head;
    auto _mls_x161 = _mlsValue::cast<_mls_Cons>(_mls_xs1)->_mls_tail;
    auto _mls_x162 = _mls_foldr(_mls_f, _mls_z, _mls_x161);
    auto _mls_x163 = _mlsMethodCall<_mls_Callable>(_mls_f)->_mls_apply2(_mls_x160, _mls_x162);
    _mls_retval = _mls_x163;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_fst(_mlsValue _mls_x164) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x164)) {
    auto _mls_x165 = _mlsValue::cast<_mls_Tuple2>(_mls_x164)->_mls_field0;
    _mls_retval = _mls_x165;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_head1(_mlsValue _mls_xs2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs2)) {
    auto _mls_x166 = _mlsValue::cast<_mls_Cons>(_mls_xs2)->_mls_head;
    _mls_retval = _mls_x166;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_is_zerovector(_mlsValue _mls_x167) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x167)) {
    auto _mls_x168 = _mlsValue::cast<_mls_Tuple3>(_mls_x167)->_mls_field0;
    auto _mls_x169 = _mlsValue::cast<_mls_Tuple3>(_mls_x167)->_mls_field1;
    auto _mls_x170 = _mlsValue::cast<_mls_Tuple3>(_mls_x167)->_mls_field2;
    auto _mls_x171 = (_mls_x168 < _mlsValue::create<_mls_Float>(1.0E-6));
    auto _mls_x172 = (_mls_x169 < _mlsValue::create<_mls_Float>(1.0E-6));
    auto _mls_x173 = (_mls_x171 && _mls_x172);
    auto _mls_x174 = (_mls_x170 < _mlsValue::create<_mls_Float>(1.0E-6));
    auto _mls_x175 = (_mls_x173 && _mls_x174);
    _mls_retval = _mls_x175;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_j1(_mlsValue _mls_tmp, _mlsValue _mls_intens, _mlsValue _mls_newcontrib, _mlsValue _mls_colour) {
  _mlsValue _mls_retval;
  auto _mls_x176 = _mls_is_zerovector(_mls_newcontrib);
  if (_mlsValue::isIntLit(_mls_x176, 1)) {
    _mls_retval = _mls_colour;
  } else {
    auto _mls_x177 = _mls_vecmult(_mls_tmp, _mls_intens);
    auto _mls_x178 = _mls_vecadd(_mls_colour, _mls_x177);
    _mls_retval = _mls_x178;
  }
  return _mls_retval;
}
_mlsValue _mls_j2(_mlsValue _mls_colour1, _mlsValue _mls_newcontrib1, _mlsValue _mls_intens1, _mlsValue _mls_tmp1) {
  _mlsValue _mls_retval;
  auto _mls_x179 = _mls_is_zerovector(_mls_newcontrib1);
  if (_mlsValue::isIntLit(_mls_x179, 1)) {
    auto _mls_x183 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_colour1);
    _mls_retval = _mls_x183;
  } else {
    auto _mls_x180 = _mls_vecmult(_mls_tmp1, _mls_intens1);
    auto _mls_x181 = _mls_vecadd(_mls_x180, _mls_colour1);
    auto _mls_x182 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x181);
    _mls_retval = _mls_x182;
  }
  return _mls_retval;
}
_mlsValue _mls_j4(_mlsValue _mls_tmp2, _mlsValue _mls_lights, _mlsValue _mls_trintensity, _mlsValue _mls_hitpos, _mlsValue _mls_refl, _mlsValue _mls_contrib, _mlsValue _mls_surf) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_tmp2)) {
    auto _mls_x184 = _mlsValue::cast<_mls_Tuple2>(_mls_tmp2)->_mls_field0;
    auto _mls_x185 = _mlsValue::cast<_mls_Tuple2>(_mls_tmp2)->_mls_field1;
    auto _mls_x186 = _mls_specularsurf(_mls_surf);
    auto _mls_x187 = _mls_reflectsurf(_mls_surf);
    auto _mls_x188 = _mls_vecscale(_mls_x186, _mls_x187);
    if (_mlsValue::isIntLit(_mls_x184, 1)) {
      auto _mls_x189 = _mls_vecadd(_mls_trintensity, _mls_x188);
      _mls_retval = _mls_j3(_mls_lights, _mls_x189, _mls_refl, _mls_contrib, _mls_x185, _mls_hitpos);
    } else {
      _mls_retval = _mls_j3(_mls_lights, _mls_x188, _mls_refl, _mls_contrib, _mls_x185, _mls_hitpos);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_j3(_mlsValue _mls_lights, _mlsValue _mls_tmp3, _mlsValue _mls_refl, _mlsValue _mls_contrib, _mlsValue _mls_trcol, _mlsValue _mls_hitpos) {
  _mlsValue _mls_retval;
  auto _mls_x190 = _mls_is_zerovector(_mls_tmp3);
  if (_mlsValue::isIntLit(_mls_x190, 1)) {
    _mls_retval = _mls_trcol;
  } else {
    auto _mls_x191 = _mls_reflectray(_mls_hitpos, _mls_refl, _mls_lights, _mls_tmp3, _mls_contrib, _mls_trcol);
    _mls_retval = _mls_x191;
  }
  return _mls_retval;
}
_mlsValue _mls_j5(_mlsValue _mls_tmp4, _mlsValue _mls_olddir) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_tmp4)) {
    auto _mls_x192 = _mlsValue::cast<_mls_Tuple3>(_mls_tmp4)->_mls_field0;
    auto _mls_x193 = _mlsValue::cast<_mls_Tuple3>(_mls_tmp4)->_mls_field1;
    auto _mls_x194 = _mlsValue::cast<_mls_Tuple3>(_mls_tmp4)->_mls_field2;
    auto _mls_x195 = (_mls_x194 * _mls_x194);
    auto _mls_x196 = (_mls_x193 * _mls_x193);
    auto _mls_x197 = (_mlsValue::create<_mls_Float>(1.0) - _mls_x196);
    auto _mls_x198 = (_mls_x195 * _mls_x197);
    auto _mls_x199 = (_mlsValue::create<_mls_Float>(1.0) - _mls_x198);
    auto _mls_x200 = (_mls_x194 * _mls_x193);
    auto _mls_x201 = _mls_builtin_sqrt(_mls_x199);
    auto _mls_x202 = (_mls_x200 - _mls_x201);
    auto _mls_x203 = (_mls_x199 < _mlsValue::create<_mls_Float>(0.0));
    if (_mlsValue::isIntLit(_mls_x203, 1)) {
      auto _mls_x208 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
      auto _mls_x209 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(1), _mls_x208);
      _mls_retval = _mls_x209;
    } else {
      auto _mls_x204 = _mls_vecscale(_mls_x192, _mls_x202);
      auto _mls_x205 = _mls_vecscale(_mls_olddir, _mls_x194);
      auto _mls_x206 = _mls_vecadd(_mls_x204, _mls_x205);
      auto _mls_x207 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x206);
      _mls_retval = _mls_x207;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_lightcolour(_mlsValue _mls_x210) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Directional>(_mls_x210)) {
    auto _mls_x212 = _mlsValue::cast<_mls_Directional>(_mls_x210)->_mls_y;
    _mls_retval = _mls_x212;
  } else if (_mlsValue::isValueOf<_mls_Point>(_mls_x210)) {
    auto _mls_x211 = _mlsValue::cast<_mls_Point>(_mls_x210)->_mls_y;
    _mls_retval = _mls_x211;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_lightdirection(_mlsValue _mls_l1, _mlsValue _mls_pt) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Directional>(_mls_l1)) {
    auto _mls_x216 = _mlsValue::cast<_mls_Directional>(_mls_l1)->_mls_x;
    auto _mls_x217 = _mls_vecnorm(_mls_x216);
    auto _mls_x218 = _mls_fst(_mls_x217);
    auto _mls_x219 = _mlsValue::create<_mls_Tuple2>(_mls_x218, _mlsValue::create<_mls_Float>(1.0E8));
    _mls_retval = _mls_x219;
  } else if (_mlsValue::isValueOf<_mls_Point>(_mls_l1)) {
    auto _mls_x213 = _mlsValue::cast<_mls_Point>(_mls_l1)->_mls_x;
    auto _mls_x214 = _mls_vecsub(_mls_x213, _mls_pt);
    auto _mls_x215 = _mls_vecnorm(_mls_x214);
    _mls_retval = _mls_x215;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_lightray(_mlsValue _mls_l2, _mlsValue _mls_pos1, _mlsValue _mls_norm, _mlsValue _mls_refl1, _mlsValue _mls_surf1) {
  _mlsValue _mls_retval;
  auto _mls_x220 = _mls_lightdirection(_mls_l2, _mls_pos1);
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x220)) {
    auto _mls_x221 = _mlsValue::cast<_mls_Tuple2>(_mls_x220)->_mls_field0;
    auto _mls_x222 = _mls_vecdot(_mls_x221, _mls_norm);
    auto _mls_x223 = _mls_lightcolour(_mls_l2);
    auto _mls_x224 = _mls_shadowed(_mls_pos1, _mls_x221, _mls_x223);
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x224)) {
      auto _mls_x225 = _mlsValue::cast<_mls_Tuple2>(_mls_x224)->_mls_field0;
      auto _mls_x226 = _mlsValue::cast<_mls_Tuple2>(_mls_x224)->_mls_field1;
      if (_mlsValue::isIntLit(_mls_x225, 1)) {
        auto _mls_x254 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
        _mls_retval = _mls_x254;
      } else {
        auto _mls_x227 = _mls_diffusesurf(_mls_surf1);
        auto _mls_x228 = _mls_specpowsurf(_mls_surf1);
        auto _mls_x229 = (_mls_x222 <= _mlsValue::create<_mls_Float>(0.0));
        if (_mlsValue::isIntLit(_mls_x229, 1)) {
          auto _mls_x241 = _mls_bodysurf(_mls_surf1);
          auto _mls_x242 = _mls_vecdot(_mls_refl1, _mls_x221);
          auto _mls_x243 = (-_mls_x242);
          auto _mls_x244 = (-_mls_x222);
          auto _mls_x245 = _mls_vecscale(_mls_x227, _mls_x244);
          auto _mls_x246 = _mls_vecmult(_mls_x245, _mls_x226);
          auto _mls_x247 = (_mls_x243 <= _mlsValue::create<_mls_Float>(0.0));
          if (_mlsValue::isIntLit(_mls_x247, 1)) {
            auto _mls_x252 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
            auto _mls_x253 = _mls_vecadd(_mls_x246, _mls_x252);
            _mls_retval = _mls_x253;
          } else {
            auto _mls_x248 = _mls_builtin_pow(_mls_x243, _mls_x228);
            auto _mls_x249 = _mls_vecscale(_mls_x241, _mls_x248);
            auto _mls_x250 = _mls_vecmult(_mls_x249, _mls_x226);
            auto _mls_x251 = _mls_vecadd(_mls_x246, _mls_x250);
            _mls_retval = _mls_x251;
          }
        } else {
          auto _mls_x230 = _mls_specularsurf(_mls_surf1);
          auto _mls_x231 = _mls_vecdot(_mls_refl1, _mls_x221);
          auto _mls_x232 = _mls_vecscale(_mls_x227, _mls_x222);
          auto _mls_x233 = _mls_vecmult(_mls_x232, _mls_x226);
          auto _mls_x234 = (_mls_x231 < _mlsValue::create<_mls_Float>(0.0));
          if (_mlsValue::isIntLit(_mls_x234, 1)) {
            auto _mls_x239 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
            auto _mls_x240 = _mls_vecadd(_mls_x233, _mls_x239);
            _mls_retval = _mls_x240;
          } else {
            auto _mls_x235 = _mls_builtin_pow(_mls_x231, _mls_x228);
            auto _mls_x236 = _mls_vecscale(_mls_x230, _mls_x235);
            auto _mls_x237 = _mls_vecmult(_mls_x236, _mls_x226);
            auto _mls_x238 = _mls_vecadd(_mls_x233, _mls_x237);
            _mls_retval = _mls_x238;
          }
        }
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_map(_mlsValue _mls_f1, _mlsValue _mls_xs3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs3)) {
    auto _mls_x256 = _mlsValue::cast<_mls_Cons>(_mls_xs3)->_mls_head;
    auto _mls_x257 = _mlsValue::cast<_mls_Cons>(_mls_xs3)->_mls_tail;
    auto _mls_x258 = _mlsMethodCall<_mls_Callable>(_mls_f1)->_mls_apply1(_mls_x256);
    auto _mls_x259 = _mls_map(_mls_f1, _mls_x257);
    auto _mls_x260 = _mlsValue::create<_mls_Cons>(_mls_x258, _mls_x259);
    _mls_retval = _mls_x260;
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs3)) {
    auto _mls_x255 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x255;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_not(_mlsValue _mls_c) {
  _mlsValue _mls_retval;
  if (_mlsValue::isIntLit(_mls_c, 1)) {
    _mls_retval = _mlsValue::fromIntLit(0);
  } else {
    _mls_retval = _mlsValue::fromIntLit(1);
  }
  return _mls_retval;
}
_mlsValue _mls_null_(_mlsValue _mls_ls9) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls9)) {
    _mls_retval = _mlsValue::fromIntLit(1);
  } else {
    _mls_retval = _mlsValue::fromIntLit(0);
  }
  return _mls_retval;
}
_mlsValue _mls_ray(_mlsValue _mls_winsize1) {
  _mlsValue _mls_retval;
  auto _mls_x261 = _mls_testlights();
  auto _mls_x262 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(2.1), _mlsValue::create<_mls_Float>(1.3), _mlsValue::create<_mls_Float>(1.7));
  auto _mls_x263 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
  auto _mls_x264 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(1.0));
  auto _mls_x265 = _mls_camparams(_mls_x262, _mls_x263, _mls_x264, _mlsValue::create<_mls_Float>(45.0), _mls_winsize1);
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x265)) {
    auto _mls_x266 = _mlsValue::cast<_mls_Tuple3>(_mls_x265)->_mls_field0;
    auto _mls_x267 = _mlsValue::cast<_mls_Tuple3>(_mls_x265)->_mls_field1;
    auto _mls_x268 = _mlsValue::cast<_mls_Tuple3>(_mls_x265)->_mls_field2;
    auto _mls_x269 = _mlsValue::create<_mls_Lambda_f>(_mls_x268, _mls_x261, _mls_x267, _mls_x266);
    auto _mls_x270 = _mlsValue::create<_mls_Lambda_lscomp1>(_mls_winsize1, _mls_x269);
    auto _mls_x271 = (_mls_winsize1 - _mlsValue::create<_mls_Float>(1.0));
    auto _mls_x272 = _mls_enumFromTo(_mlsValue::create<_mls_Float>(0.0), _mls_x271);
    auto _mls_x273 = _mlsMethodCall<_mls_Callable>(_mls_x270)->_mls_apply1(_mls_x272);
    _mls_retval = _mls_x273;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_reflectray(_mlsValue _mls_pos2, _mlsValue _mls_newdir, _mlsValue _mls_lights1, _mlsValue _mls_intens, _mlsValue _mls_contrib1, _mlsValue _mls_colour) {
  _mlsValue _mls_retval;
  auto _mls_x274 = _mls_vecmult(_mls_intens, _mls_contrib1);
  auto _mls_x275 = _mls_vecscale(_mls_newdir, _mlsValue::create<_mls_Float>(1.0E-6));
  auto _mls_x276 = _mls_vecadd(_mls_pos2, _mls_x275);
  auto _mls_x277 = _mls_testspheres();
  auto _mls_x278 = _mls_trace(_mls_x277, _mls_x276, _mls_newdir);
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x278)) {
    auto _mls_x279 = _mlsValue::cast<_mls_Tuple3>(_mls_x278)->_mls_field0;
    auto _mls_x280 = _mlsValue::cast<_mls_Tuple3>(_mls_x278)->_mls_field1;
    auto _mls_x281 = _mlsValue::cast<_mls_Tuple3>(_mls_x278)->_mls_field2;
    if (_mlsValue::isIntLit(_mls_x279, 1)) {
      auto _mls_x283 = _mls_shade(_mls_lights1, _mls_x281, _mls_x276, _mls_newdir, _mls_x280, _mls_x274);
      _mls_retval = _mls_j1(_mls_x283, _mls_intens, _mls_x274, _mls_colour);
    } else {
      auto _mls_x282 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.078), _mlsValue::create<_mls_Float>(0.361), _mlsValue::create<_mls_Float>(0.753));
      _mls_retval = _mls_j1(_mls_x282, _mls_intens, _mls_x274, _mls_colour);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_reflectsurf(_mlsValue _mls_ss3) {
  _mlsValue _mls_retval;
  auto _mls_x284 = _mlsValue::create<_mls_Lambda_lscomp5>();
  auto _mls_x285 = _mlsMethodCall<_mls_Callable>(_mls_x284)->_mls_apply1(_mls_ss3);
  auto _mls_x286 = _mlsValue::create<_mls_Nil>();
  auto _mls_x287 = _mlsValue::create<_mls_Cons>(_mlsValue::create<_mls_Float>(0.0), _mls_x286);
  auto _mls_x288 = _mls_append(_mls_x285, _mls_x287);
  auto _mls_x289 = _mls_head1(_mls_x288);
  _mls_retval = _mls_x289;
  return _mls_retval;
}
_mlsValue _mls_refractray(_mlsValue _mls_newindex, _mlsValue _mls_olddir, _mlsValue _mls_innorm) {
  _mlsValue _mls_retval;
  auto _mls_x290 = _mls_vecdot(_mls_olddir, _mls_innorm);
  auto _mls_x291 = (-_mls_x290);
  auto _mls_x292 = (_mls_x291 < _mlsValue::create<_mls_Float>(0.0));
  if (_mlsValue::isIntLit(_mls_x292, 1)) {
    auto _mls_x294 = (-_mlsValue::create<_mls_Float>(1.0));
    auto _mls_x295 = _mls_vecscale(_mls_innorm, _mls_x294);
    auto _mls_x296 = (-_mls_x291);
    auto _mls_x297 = (_mlsValue::create<_mls_Float>(1.0) / _mls_newindex);
    auto _mls_x298 = _mlsValue::create<_mls_Tuple3>(_mls_x295, _mls_x296, _mls_x297);
    _mls_retval = _mls_j5(_mls_x298, _mls_olddir);
  } else {
    auto _mls_x293 = _mlsValue::create<_mls_Tuple3>(_mls_innorm, _mls_x291, _mls_newindex);
    _mls_retval = _mls_j5(_mls_x293, _mls_olddir);
  }
  return _mls_retval;
}
_mlsValue _mls_refractsurf(_mlsValue _mls_ss4) {
  _mlsValue _mls_retval;
  auto _mls_x299 = _mlsValue::create<_mls_Lambda_lscomp7>();
  auto _mls_x300 = _mlsMethodCall<_mls_Callable>(_mls_x299)->_mls_apply1(_mls_ss4);
  auto _mls_x301 = _mlsValue::create<_mls_Nil>();
  auto _mls_x302 = _mlsValue::create<_mls_Cons>(_mlsValue::create<_mls_Float>(1.0), _mls_x301);
  auto _mls_x303 = _mls_append(_mls_x300, _mls_x302);
  auto _mls_x304 = _mls_head1(_mls_x303);
  _mls_retval = _mls_x304;
  return _mls_retval;
}
_mlsValue _mls_repeatRun(_mlsValue _mls_n, _mlsValue _mls_i1) {
  _mlsValue _mls_retval;
  auto _mls_x305 = _mls_run(_mls_n);
  auto _mls_x306 = (_mls_i1 == _mlsValue::fromIntLit(1));
  if (_mlsValue::isIntLit(_mls_x306, 1)) {
    _mls_retval = _mls_x305;
  } else {
    auto _mls_x307 = (_mls_i1 - _mlsValue::fromIntLit(1));
    auto _mls_x308 = _mls_repeatRun(_mls_n, _mls_x307);
    _mls_retval = _mls_x308;
  }
  return _mls_retval;
}
_mlsValue _mls_run(_mlsValue _mls_winsize2) {
  _mlsValue _mls_retval;
  auto _mls_x309 = _mls_ray(_mls_winsize2);
  auto _mls_x310 = _mlsValue::create<_mls_Lambda_snd>();
  auto _mls_x311 = _mls_map(_mls_x310, _mls_x309);
  _mls_retval = _mls_x311;
  return _mls_retval;
}
_mlsValue _mls_s2() {
  _mlsValue _mls_retval;
  auto _mls_x312 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.035), _mlsValue::create<_mls_Float>(0.0325), _mlsValue::create<_mls_Float>(0.025));
  auto _mls_x313 = _mlsValue::create<_mls_Ambient>(_mls_x312);
  auto _mls_x314 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.5), _mlsValue::create<_mls_Float>(0.45), _mlsValue::create<_mls_Float>(0.35));
  auto _mls_x315 = _mlsValue::create<_mls_Diffuse>(_mls_x314);
  auto _mls_x316 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.8), _mlsValue::create<_mls_Float>(0.8), _mlsValue::create<_mls_Float>(0.8));
  auto _mls_x317 = _mlsValue::create<_mls_Specular>(_mls_x316);
  auto _mls_x318 = _mlsValue::create<_mls_Specpow>(_mlsValue::create<_mls_Float>(3.0));
  auto _mls_x319 = _mlsValue::create<_mls_Reflect>(_mlsValue::create<_mls_Float>(0.5));
  auto _mls_x320 = _mlsValue::create<_mls_Nil>();
  auto _mls_x321 = _mlsValue::create<_mls_Cons>(_mls_x319, _mls_x320);
  auto _mls_x322 = _mlsValue::create<_mls_Cons>(_mls_x318, _mls_x321);
  auto _mls_x323 = _mlsValue::create<_mls_Cons>(_mls_x317, _mls_x322);
  auto _mls_x324 = _mlsValue::create<_mls_Cons>(_mls_x315, _mls_x323);
  auto _mls_x325 = _mlsValue::create<_mls_Cons>(_mls_x313, _mls_x324);
  _mls_retval = _mls_x325;
  return _mls_retval;
}
_mlsValue _mls_shade(_mlsValue _mls_lights, _mlsValue _mls_sp, _mlsValue _mls_lookpos, _mlsValue _mls_dir, _mlsValue _mls_dist, _mlsValue _mls_contrib) {
  _mlsValue _mls_retval;
  auto _mls_x326 = _mls_vecscale(_mls_dir, _mls_dist);
  auto _mls_x327 = _mls_vecadd(_mls_lookpos, _mls_x326);
  auto _mls_x328 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0));
  auto _mls_x329 = _mls_spheresurf(_mls_sp);
  auto _mls_x330 = _mls_ambientsurf(_mls_x329);
  auto _mls_x331 = _mls_vecmult(_mls_x328, _mls_x330);
  auto _mls_x332 = _mls_spherenormal(_mls_x327, _mls_sp);
  auto _mls_x333 = (-_mlsValue::create<_mls_Float>(2.0));
  auto _mls_x334 = _mls_vecdot(_mls_dir, _mls_x332);
  auto _mls_x335 = (_mls_x333 * _mls_x334);
  auto _mls_x336 = _mls_vecscale(_mls_x332, _mls_x335);
  auto _mls_x337 = _mls_vecadd(_mls_dir, _mls_x336);
  auto _mls_x338 = _mlsValue::create<_mls_Lambda_lambda>(_mls_x332, _mls_x327, _mls_x337, _mls_x329);
  auto _mls_x339 = _mls_map(_mls_x338, _mls_lights);
  auto _mls_x340 = _mls_vecsum(_mls_x339);
  auto _mls_x341 = _mls_transmitsurf(_mls_x329);
  auto _mls_x342 = _mls_vecadd(_mls_x331, _mls_x340);
  auto _mls_x343 = _mls_bodysurf(_mls_x329);
  auto _mls_x344 = _mls_vecscale(_mls_x343, _mls_x341);
  auto _mls_x345 = (_mls_x341 < _mlsValue::create<_mls_Float>(1.0E-6));
  if (_mlsValue::isIntLit(_mls_x345, 1)) {
    auto _mls_x348 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_x342);
    _mls_retval = _mls_j4(_mls_x348, _mls_lights, _mls_x344, _mls_x327, _mls_x337, _mls_contrib, _mls_x329);
  } else {
    auto _mls_x346 = _mls_refractsurf(_mls_x329);
    auto _mls_x347 = _mls_transmitray(_mls_lights, _mls_x342, _mls_x327, _mls_dir, _mls_x346, _mls_x344, _mls_contrib, _mls_x332);
    _mls_retval = _mls_j4(_mls_x347, _mls_lights, _mls_x344, _mls_x327, _mls_x337, _mls_contrib, _mls_x329);
  }
  return _mls_retval;
}
_mlsValue _mls_shadowed(_mlsValue _mls_pos3, _mlsValue _mls_dir1, _mlsValue _mls_lcolour) {
  _mlsValue _mls_retval;
  auto _mls_x349 = _mls_testspheres();
  auto _mls_x350 = _mls_vecscale(_mls_dir1, _mlsValue::create<_mls_Float>(1.0E-6));
  auto _mls_x351 = _mls_vecadd(_mls_pos3, _mls_x350);
  auto _mls_x352 = _mls_trace(_mls_x349, _mls_x351, _mls_dir1);
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x352)) {
    auto _mls_x353 = _mlsValue::cast<_mls_Tuple3>(_mls_x352)->_mls_field0;
    auto _mls_x354 = _mls_not(_mls_x353);
    if (_mlsValue::isIntLit(_mls_x354, 1)) {
      auto _mls_x356 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mls_lcolour);
      _mls_retval = _mls_x356;
    } else {
      auto _mls_x355 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(1), _mls_lcolour);
      _mls_retval = _mls_x355;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_snd(_mlsValue _mls_x357) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x357)) {
    auto _mls_x358 = _mlsValue::cast<_mls_Tuple2>(_mls_x357)->_mls_field1;
    _mls_retval = _mls_x358;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_specpowsurf(_mlsValue _mls_ss5) {
  _mlsValue _mls_retval;
  auto _mls_x359 = _mlsValue::create<_mls_Lambda_lscomp6>();
  auto _mls_x360 = _mlsMethodCall<_mls_Callable>(_mls_x359)->_mls_apply1(_mls_ss5);
  auto _mls_x361 = _mlsValue::create<_mls_Nil>();
  auto _mls_x362 = _mlsValue::create<_mls_Cons>(_mlsValue::create<_mls_Float>(8.0), _mls_x361);
  auto _mls_x363 = _mls_append(_mls_x360, _mls_x362);
  auto _mls_x364 = _mls_head1(_mls_x363);
  _mls_retval = _mls_x364;
  return _mls_retval;
}
_mlsValue _mls_specularsurf(_mlsValue _mls_ss6) {
  _mlsValue _mls_retval;
  auto _mls_x365 = _mlsValue::create<_mls_Lambda_lscomp8>();
  auto _mls_x366 = _mlsMethodCall<_mls_Callable>(_mls_x365)->_mls_apply1(_mls_ss6);
  auto _mls_x367 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
  auto _mls_x368 = _mlsValue::create<_mls_Nil>();
  auto _mls_x369 = _mlsValue::create<_mls_Cons>(_mls_x367, _mls_x368);
  auto _mls_x370 = _mls_append(_mls_x366, _mls_x369);
  auto _mls_x371 = _mls_head1(_mls_x370);
  _mls_retval = _mls_x371;
  return _mls_retval;
}
_mlsValue _mls_sphereintersect(_mlsValue _mls_pos4, _mlsValue _mls_dir2, _mlsValue _mls_sp1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Sphere>(_mls_sp1)) {
    auto _mls_x372 = _mlsValue::cast<_mls_Sphere>(_mls_sp1)->_mls_pos;
    auto _mls_x373 = _mlsValue::cast<_mls_Sphere>(_mls_sp1)->_mls_radius;
    auto _mls_x374 = _mls_vecsub(_mls_pos4, _mls_x372);
    auto _mls_x375 = _mls_vecdot(_mls_x374, _mls_dir2);
    auto _mls_x376 = _mls_vecdot(_mls_x374, _mls_x374);
    auto _mls_x377 = (_mls_x375 * _mls_x375);
    auto _mls_x378 = (_mls_x377 - _mls_x376);
    auto _mls_x379 = (_mls_x373 * _mls_x373);
    auto _mls_x380 = (_mls_x378 + _mls_x379);
    auto _mls_x381 = (-_mls_x375);
    auto _mls_x382 = _mls_builtin_sqrt(_mls_x380);
    auto _mls_x383 = (_mls_x381 - _mls_x382);
    auto _mls_x384 = (-_mls_x375);
    auto _mls_x385 = _mls_builtin_sqrt(_mls_x380);
    auto _mls_x386 = (_mls_x384 + _mls_x385);
    auto _mls_x387 = (_mls_x380 < _mlsValue::create<_mls_Float>(0.0));
    if (_mlsValue::isIntLit(_mls_x387, 1)) {
      auto _mls_x393 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mlsValue::create<_mls_Float>(0.0));
      _mls_retval = _mls_x393;
    } else {
      auto _mls_x388 = (_mls_x383 < _mlsValue::create<_mls_Float>(0.0));
      if (_mlsValue::isIntLit(_mls_x388, 1)) {
        auto _mls_x390 = (_mls_x386 < _mlsValue::create<_mls_Float>(0.0));
        if (_mlsValue::isIntLit(_mls_x390, 1)) {
          auto _mls_x392 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(0), _mlsValue::create<_mls_Float>(0.0));
          _mls_retval = _mls_x392;
        } else {
          auto _mls_x391 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(1), _mls_x386);
          _mls_retval = _mls_x391;
        }
      } else {
        auto _mls_x389 = _mlsValue::create<_mls_Tuple2>(_mlsValue::fromIntLit(1), _mls_x383);
        _mls_retval = _mls_x389;
      }
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_spherenormal(_mlsValue _mls_pos5, _mlsValue _mls_sp2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Sphere>(_mls_sp2)) {
    auto _mls_x394 = _mlsValue::cast<_mls_Sphere>(_mls_sp2)->_mls_pos;
    auto _mls_x395 = _mlsValue::cast<_mls_Sphere>(_mls_sp2)->_mls_radius;
    auto _mls_x396 = _mls_vecsub(_mls_pos5, _mls_x394);
    auto _mls_x397 = (_mlsValue::create<_mls_Float>(1.0) / _mls_x395);
    auto _mls_x398 = _mls_vecscale(_mls_x396, _mls_x397);
    _mls_retval = _mls_x398;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_spheresurf(_mlsValue _mls_s) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Sphere>(_mls_s)) {
    auto _mls_x399 = _mlsValue::cast<_mls_Sphere>(_mls_s)->_mls_surface;
    _mls_retval = _mls_x399;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_tail1(_mlsValue _mls_xs4) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs4)) {
    auto _mls_x400 = _mlsValue::cast<_mls_Cons>(_mls_xs4)->_mls_tail;
    _mls_retval = _mls_x400;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_testlights() {
  _mlsValue _mls_retval;
  auto _mls_x401 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(4.0), _mlsValue::create<_mls_Float>(3.0), _mlsValue::create<_mls_Float>(2.0));
  auto _mls_x402 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.288675), _mlsValue::create<_mls_Float>(0.288675), _mlsValue::create<_mls_Float>(0.288675));
  auto _mls_x403 = _mlsValue::create<_mls_Point>(_mls_x401, _mls_x402);
  auto _mls_x404 = (-_mlsValue::create<_mls_Float>(4.0));
  auto _mls_x405 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(1.0), _mls_x404, _mlsValue::create<_mls_Float>(4.0));
  auto _mls_x406 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.288675), _mlsValue::create<_mls_Float>(0.288675), _mlsValue::create<_mls_Float>(0.288675));
  auto _mls_x407 = _mlsValue::create<_mls_Point>(_mls_x405, _mls_x406);
  auto _mls_x408 = (-_mlsValue::create<_mls_Float>(3.0));
  auto _mls_x409 = _mlsValue::create<_mls_Tuple3>(_mls_x408, _mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(5.0));
  auto _mls_x410 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.288675), _mlsValue::create<_mls_Float>(0.288675), _mlsValue::create<_mls_Float>(0.288675));
  auto _mls_x411 = _mlsValue::create<_mls_Point>(_mls_x409, _mls_x410);
  auto _mls_x412 = _mlsValue::create<_mls_Nil>();
  auto _mls_x413 = _mlsValue::create<_mls_Cons>(_mls_x411, _mls_x412);
  auto _mls_x414 = _mlsValue::create<_mls_Cons>(_mls_x407, _mls_x413);
  auto _mls_x415 = _mlsValue::create<_mls_Cons>(_mls_x403, _mls_x414);
  _mls_retval = _mls_x415;
  return _mls_retval;
}
_mlsValue _mls_testspheres() {
  _mlsValue _mls_retval;
  auto _mls_x416 = _mls_s2();
  auto _mls_x417 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
  auto _mls_x418 = _mlsValue::create<_mls_Sphere>(_mls_x417, _mlsValue::create<_mls_Float>(0.5), _mls_x416);
  auto _mls_x419 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.272166), _mlsValue::create<_mls_Float>(0.272166), _mlsValue::create<_mls_Float>(0.544331));
  auto _mls_x420 = _mlsValue::create<_mls_Sphere>(_mls_x419, _mlsValue::create<_mls_Float>(0.166667), _mls_x416);
  auto _mls_x421 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.643951), _mlsValue::create<_mls_Float>(0.172546), _mlsValue::create<_mls_Float>(0.0));
  auto _mls_x422 = _mlsValue::create<_mls_Sphere>(_mls_x421, _mlsValue::create<_mls_Float>(0.166667), _mls_x416);
  auto _mls_x423 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.172546), _mlsValue::create<_mls_Float>(0.643951), _mlsValue::create<_mls_Float>(0.0));
  auto _mls_x424 = _mlsValue::create<_mls_Sphere>(_mls_x423, _mlsValue::create<_mls_Float>(0.166667), _mls_x416);
  auto _mls_x425 = (-_mlsValue::create<_mls_Float>(0.371785));
  auto _mls_x426 = _mlsValue::create<_mls_Tuple3>(_mls_x425, _mlsValue::create<_mls_Float>(0.0996195), _mlsValue::create<_mls_Float>(0.544331));
  auto _mls_x427 = _mlsValue::create<_mls_Sphere>(_mls_x426, _mlsValue::create<_mls_Float>(0.166667), _mls_x416);
  auto _mls_x428 = (-_mlsValue::create<_mls_Float>(0.471405));
  auto _mls_x429 = _mlsValue::create<_mls_Tuple3>(_mls_x428, _mlsValue::create<_mls_Float>(0.471405), _mlsValue::create<_mls_Float>(0.0));
  auto _mls_x430 = _mlsValue::create<_mls_Sphere>(_mls_x429, _mlsValue::create<_mls_Float>(0.166667), _mls_x416);
  auto _mls_x431 = (-_mlsValue::create<_mls_Float>(0.643951));
  auto _mls_x432 = (-_mlsValue::create<_mls_Float>(0.172546));
  auto _mls_x433 = _mlsValue::create<_mls_Tuple3>(_mls_x431, _mls_x432, _mlsValue::create<_mls_Float>(0.0));
  auto _mls_x434 = _mlsValue::create<_mls_Sphere>(_mls_x433, _mlsValue::create<_mls_Float>(0.166667), _mls_x416);
  auto _mls_x435 = (-_mlsValue::create<_mls_Float>(0.371785));
  auto _mls_x436 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0996195), _mls_x435, _mlsValue::create<_mls_Float>(0.544331));
  auto _mls_x437 = _mlsValue::create<_mls_Sphere>(_mls_x436, _mlsValue::create<_mls_Float>(0.166667), _mls_x416);
  auto _mls_x438 = (-_mlsValue::create<_mls_Float>(0.172546));
  auto _mls_x439 = (-_mlsValue::create<_mls_Float>(0.643951));
  auto _mls_x440 = _mlsValue::create<_mls_Tuple3>(_mls_x438, _mls_x439, _mlsValue::create<_mls_Float>(0.0));
  auto _mls_x441 = _mlsValue::create<_mls_Sphere>(_mls_x440, _mlsValue::create<_mls_Float>(0.166667), _mls_x416);
  auto _mls_x442 = (-_mlsValue::create<_mls_Float>(0.471405));
  auto _mls_x443 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.471405), _mls_x442, _mlsValue::create<_mls_Float>(0.0));
  auto _mls_x444 = _mlsValue::create<_mls_Sphere>(_mls_x443, _mlsValue::create<_mls_Float>(0.166667), _mls_x416);
  auto _mls_x445 = _mlsValue::create<_mls_Nil>();
  auto _mls_x446 = _mlsValue::create<_mls_Cons>(_mls_x444, _mls_x445);
  auto _mls_x447 = _mlsValue::create<_mls_Cons>(_mls_x441, _mls_x446);
  auto _mls_x448 = _mlsValue::create<_mls_Cons>(_mls_x437, _mls_x447);
  auto _mls_x449 = _mlsValue::create<_mls_Cons>(_mls_x434, _mls_x448);
  auto _mls_x450 = _mlsValue::create<_mls_Cons>(_mls_x430, _mls_x449);
  auto _mls_x451 = _mlsValue::create<_mls_Cons>(_mls_x427, _mls_x450);
  auto _mls_x452 = _mlsValue::create<_mls_Cons>(_mls_x424, _mls_x451);
  auto _mls_x453 = _mlsValue::create<_mls_Cons>(_mls_x422, _mls_x452);
  auto _mls_x454 = _mlsValue::create<_mls_Cons>(_mls_x420, _mls_x453);
  auto _mls_x455 = _mlsValue::create<_mls_Cons>(_mls_x418, _mls_x454);
  _mls_retval = _mls_x455;
  return _mls_retval;
}
_mlsValue _mls_trace(_mlsValue _mls_spheres, _mlsValue _mls_pos6, _mlsValue _mls_dir3) {
  _mlsValue _mls_retval;
  auto _mls_x456 = _mlsValue::create<_mls_Lambda_f1>();
  auto _mls_x457 = _mlsValue::create<_mls_Lambda_sphmap>(_mls_dir3, _mls_pos6);
  auto _mls_x458 = _mlsMethodCall<_mls_Callable>(_mls_x457)->_mls_apply1(_mls_spheres);
  auto _mls_x459 = _mls_null_(_mls_x458);
  if (_mlsValue::isIntLit(_mls_x459, 1)) {
    auto _mls_x466 = _mls_head1(_mls_spheres);
    auto _mls_x467 = _mlsValue::create<_mls_Tuple3>(_mlsValue::fromIntLit(0), _mlsValue::create<_mls_Float>(1.0E8), _mls_x466);
    _mls_retval = _mls_x467;
  } else {
    auto _mls_x460 = _mls_head1(_mls_x458);
    auto _mls_x461 = _mls_tail1(_mls_x458);
    auto _mls_x462 = _mls_foldr(_mls_x456, _mls_x460, _mls_x461);
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x462)) {
      auto _mls_x463 = _mlsValue::cast<_mls_Tuple2>(_mls_x462)->_mls_field0;
      auto _mls_x464 = _mlsValue::cast<_mls_Tuple2>(_mls_x462)->_mls_field1;
      auto _mls_x465 = _mlsValue::create<_mls_Tuple3>(_mlsValue::fromIntLit(1), _mls_x463, _mls_x464);
      _mls_retval = _mls_x465;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  }
  return _mls_retval;
}
_mlsValue _mls_tracepixel(_mlsValue _mls_spheres1, _mlsValue _mls_lights2, _mlsValue _mls_x469, _mlsValue _mls_y2, _mlsValue _mls_firstray, _mlsValue _mls_scrnx, _mlsValue _mls_scrny) {
  _mlsValue _mls_retval;
  auto _mls_x468 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(2.1), _mlsValue::create<_mls_Float>(1.3), _mlsValue::create<_mls_Float>(1.7));
  auto _mls_x470 = _mls_vecscale(_mls_scrnx, _mls_x469);
  auto _mls_x471 = _mls_vecadd(_mls_firstray, _mls_x470);
  auto _mls_x472 = _mls_vecscale(_mls_scrny, _mls_y2);
  auto _mls_x473 = _mls_vecadd(_mls_x471, _mls_x472);
  auto _mls_x474 = _mls_vecnorm(_mls_x473);
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x474)) {
    auto _mls_x475 = _mlsValue::cast<_mls_Tuple2>(_mls_x474)->_mls_field0;
    auto _mls_x476 = _mls_trace(_mls_spheres1, _mls_x468, _mls_x475);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x476)) {
      auto _mls_x477 = _mlsValue::cast<_mls_Tuple3>(_mls_x476)->_mls_field0;
      auto _mls_x478 = _mlsValue::cast<_mls_Tuple3>(_mls_x476)->_mls_field1;
      auto _mls_x479 = _mlsValue::cast<_mls_Tuple3>(_mls_x476)->_mls_field2;
      if (_mlsValue::isIntLit(_mls_x477, 1)) {
        auto _mls_x481 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0), _mlsValue::create<_mls_Float>(1.0));
        auto _mls_x482 = _mls_shade(_mls_lights2, _mls_x479, _mls_x468, _mls_x475, _mls_x478, _mls_x481);
        _mls_retval = _mls_x482;
      } else {
        auto _mls_x480 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.078), _mlsValue::create<_mls_Float>(0.361), _mlsValue::create<_mls_Float>(0.753));
        _mls_retval = _mls_x480;
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_transmitray(_mlsValue _mls_lights3, _mlsValue _mls_colour1, _mlsValue _mls_pos7, _mlsValue _mls_dir4, _mlsValue _mls_index, _mlsValue _mls_intens1, _mlsValue _mls_contrib2, _mlsValue _mls_norm1) {
  _mlsValue _mls_retval;
  auto _mls_x483 = _mls_vecmult(_mls_intens1, _mls_contrib2);
  auto _mls_x484 = _mls_refractray(_mls_index, _mls_dir4, _mls_norm1);
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x484)) {
    auto _mls_x485 = _mlsValue::cast<_mls_Tuple2>(_mls_x484)->_mls_field1;
    auto _mls_x486 = _mls_vecscale(_mls_x485, _mlsValue::create<_mls_Float>(1.0E-6));
    auto _mls_x487 = _mls_vecadd(_mls_pos7, _mls_x486);
    auto _mls_x488 = _mls_testspheres();
    auto _mls_x489 = _mls_trace(_mls_x488, _mls_x487, _mls_x485);
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x489)) {
      auto _mls_x490 = _mlsValue::cast<_mls_Tuple3>(_mls_x489)->_mls_field0;
      auto _mls_x491 = _mlsValue::cast<_mls_Tuple3>(_mls_x489)->_mls_field1;
      auto _mls_x492 = _mlsValue::cast<_mls_Tuple3>(_mls_x489)->_mls_field2;
      if (_mlsValue::isIntLit(_mls_x490, 1)) {
        auto _mls_x494 = _mls_shade(_mls_lights3, _mls_x492, _mls_x487, _mls_x485, _mls_x491, _mls_x483);
        _mls_retval = _mls_j2(_mls_colour1, _mls_x483, _mls_intens1, _mls_x494);
      } else {
        auto _mls_x493 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.078), _mlsValue::create<_mls_Float>(0.361), _mlsValue::create<_mls_Float>(0.753));
        _mls_retval = _mls_j2(_mls_colour1, _mls_x483, _mls_intens1, _mls_x493);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_transmitsurf(_mlsValue _mls_ss7) {
  _mlsValue _mls_retval;
  auto _mls_x495 = _mlsValue::create<_mls_Lambda_lscomp>();
  auto _mls_x496 = _mlsMethodCall<_mls_Callable>(_mls_x495)->_mls_apply1(_mls_ss7);
  auto _mls_x497 = _mlsValue::create<_mls_Nil>();
  auto _mls_x498 = _mlsValue::create<_mls_Cons>(_mlsValue::create<_mls_Float>(0.0), _mls_x497);
  auto _mls_x499 = _mls_append(_mls_x496, _mls_x498);
  auto _mls_x500 = _mls_head1(_mls_x499);
  _mls_retval = _mls_x500;
  return _mls_retval;
}
_mlsValue _mls_vecadd(_mlsValue _mls_a1, _mlsValue _mls_a2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_a1)) {
    auto _mls_x501 = _mlsValue::cast<_mls_Tuple3>(_mls_a1)->_mls_field0;
    auto _mls_x502 = _mlsValue::cast<_mls_Tuple3>(_mls_a1)->_mls_field1;
    auto _mls_x503 = _mlsValue::cast<_mls_Tuple3>(_mls_a1)->_mls_field2;
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_a2)) {
      auto _mls_x504 = _mlsValue::cast<_mls_Tuple3>(_mls_a2)->_mls_field0;
      auto _mls_x505 = _mlsValue::cast<_mls_Tuple3>(_mls_a2)->_mls_field1;
      auto _mls_x506 = _mlsValue::cast<_mls_Tuple3>(_mls_a2)->_mls_field2;
      auto _mls_x507 = (_mls_x501 + _mls_x504);
      auto _mls_x508 = (_mls_x502 + _mls_x505);
      auto _mls_x509 = (_mls_x503 + _mls_x506);
      auto _mls_x510 = _mlsValue::create<_mls_Tuple3>(_mls_x507, _mls_x508, _mls_x509);
      _mls_retval = _mls_x510;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_veccross(_mlsValue _mls_x1100, _mlsValue _mls_x2100) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1100)) {
    auto _mls_x511 = _mlsValue::cast<_mls_Tuple3>(_mls_x1100)->_mls_field0;
    auto _mls_x512 = _mlsValue::cast<_mls_Tuple3>(_mls_x1100)->_mls_field1;
    auto _mls_x513 = _mlsValue::cast<_mls_Tuple3>(_mls_x1100)->_mls_field2;
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x2100)) {
      auto _mls_x514 = _mlsValue::cast<_mls_Tuple3>(_mls_x2100)->_mls_field0;
      auto _mls_x515 = _mlsValue::cast<_mls_Tuple3>(_mls_x2100)->_mls_field1;
      auto _mls_x516 = _mlsValue::cast<_mls_Tuple3>(_mls_x2100)->_mls_field2;
      auto _mls_x517 = (_mls_x512 * _mls_x516);
      auto _mls_x518 = (_mls_x515 * _mls_x513);
      auto _mls_x519 = (_mls_x517 - _mls_x518);
      auto _mls_x520 = (_mls_x513 * _mls_x514);
      auto _mls_x521 = (_mls_x516 * _mls_x511);
      auto _mls_x522 = (_mls_x520 - _mls_x521);
      auto _mls_x523 = (_mls_x511 * _mls_x515);
      auto _mls_x524 = (_mls_x514 * _mls_x512);
      auto _mls_x525 = (_mls_x523 - _mls_x524);
      auto _mls_x526 = _mlsValue::create<_mls_Tuple3>(_mls_x519, _mls_x522, _mls_x525);
      _mls_retval = _mls_x526;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_vecdot(_mlsValue _mls_x1101, _mlsValue _mls_x2101) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x1101)) {
    auto _mls_x527 = _mlsValue::cast<_mls_Tuple3>(_mls_x1101)->_mls_field0;
    auto _mls_x528 = _mlsValue::cast<_mls_Tuple3>(_mls_x1101)->_mls_field1;
    auto _mls_x529 = _mlsValue::cast<_mls_Tuple3>(_mls_x1101)->_mls_field2;
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_x2101)) {
      auto _mls_x530 = _mlsValue::cast<_mls_Tuple3>(_mls_x2101)->_mls_field0;
      auto _mls_x531 = _mlsValue::cast<_mls_Tuple3>(_mls_x2101)->_mls_field1;
      auto _mls_x532 = _mlsValue::cast<_mls_Tuple3>(_mls_x2101)->_mls_field2;
      auto _mls_x533 = (_mls_x527 * _mls_x530);
      auto _mls_x534 = (_mls_x528 * _mls_x531);
      auto _mls_x535 = (_mls_x533 + _mls_x534);
      auto _mls_x536 = (_mls_x529 * _mls_x532);
      auto _mls_x537 = (_mls_x535 + _mls_x536);
      _mls_retval = _mls_x537;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_vecmult(_mlsValue _mls_a11, _mlsValue _mls_a21) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_a11)) {
    auto _mls_x538 = _mlsValue::cast<_mls_Tuple3>(_mls_a11)->_mls_field0;
    auto _mls_x539 = _mlsValue::cast<_mls_Tuple3>(_mls_a11)->_mls_field1;
    auto _mls_x540 = _mlsValue::cast<_mls_Tuple3>(_mls_a11)->_mls_field2;
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_a21)) {
      auto _mls_x541 = _mlsValue::cast<_mls_Tuple3>(_mls_a21)->_mls_field0;
      auto _mls_x542 = _mlsValue::cast<_mls_Tuple3>(_mls_a21)->_mls_field1;
      auto _mls_x543 = _mlsValue::cast<_mls_Tuple3>(_mls_a21)->_mls_field2;
      auto _mls_x544 = (_mls_x538 * _mls_x541);
      auto _mls_x545 = (_mls_x539 * _mls_x542);
      auto _mls_x546 = (_mls_x540 * _mls_x543);
      auto _mls_x547 = _mlsValue::create<_mls_Tuple3>(_mls_x544, _mls_x545, _mls_x546);
      _mls_retval = _mls_x547;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_vecnorm(_mlsValue _mls_xyz) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_xyz)) {
    auto _mls_x548 = _mlsValue::cast<_mls_Tuple3>(_mls_xyz)->_mls_field0;
    auto _mls_x549 = _mlsValue::cast<_mls_Tuple3>(_mls_xyz)->_mls_field1;
    auto _mls_x550 = _mlsValue::cast<_mls_Tuple3>(_mls_xyz)->_mls_field2;
    auto _mls_x551 = (_mls_x548 * _mls_x548);
    auto _mls_x552 = (_mls_x549 * _mls_x549);
    auto _mls_x553 = (_mls_x551 + _mls_x552);
    auto _mls_x554 = (_mls_x550 * _mls_x550);
    auto _mls_x555 = (_mls_x553 + _mls_x554);
    auto _mls_x556 = _mls_builtin_sqrt(_mls_x555);
    auto _mls_x557 = (_mls_x548 / _mls_x556);
    auto _mls_x558 = (_mls_x549 / _mls_x556);
    auto _mls_x559 = (_mls_x550 / _mls_x556);
    auto _mls_x560 = _mlsValue::create<_mls_Tuple3>(_mls_x557, _mls_x558, _mls_x559);
    auto _mls_x561 = _mlsValue::create<_mls_Tuple2>(_mls_x560, _mls_x556);
    _mls_retval = _mls_x561;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_vecscale(_mlsValue _mls_xyz1, _mlsValue _mls_a3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_xyz1)) {
    auto _mls_x562 = _mlsValue::cast<_mls_Tuple3>(_mls_xyz1)->_mls_field0;
    auto _mls_x563 = _mlsValue::cast<_mls_Tuple3>(_mls_xyz1)->_mls_field1;
    auto _mls_x564 = _mlsValue::cast<_mls_Tuple3>(_mls_xyz1)->_mls_field2;
    auto _mls_x565 = (_mls_a3 * _mls_x562);
    auto _mls_x566 = (_mls_a3 * _mls_x563);
    auto _mls_x567 = (_mls_a3 * _mls_x564);
    auto _mls_x568 = _mlsValue::create<_mls_Tuple3>(_mls_x565, _mls_x566, _mls_x567);
    _mls_retval = _mls_x568;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_vecsub(_mlsValue _mls_a12, _mlsValue _mls_a22) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_a12)) {
    auto _mls_x569 = _mlsValue::cast<_mls_Tuple3>(_mls_a12)->_mls_field0;
    auto _mls_x570 = _mlsValue::cast<_mls_Tuple3>(_mls_a12)->_mls_field1;
    auto _mls_x571 = _mlsValue::cast<_mls_Tuple3>(_mls_a12)->_mls_field2;
    if (_mlsValue::isValueOf<_mls_Tuple3>(_mls_a22)) {
      auto _mls_x572 = _mlsValue::cast<_mls_Tuple3>(_mls_a22)->_mls_field0;
      auto _mls_x573 = _mlsValue::cast<_mls_Tuple3>(_mls_a22)->_mls_field1;
      auto _mls_x574 = _mlsValue::cast<_mls_Tuple3>(_mls_a22)->_mls_field2;
      auto _mls_x575 = (_mls_x569 - _mls_x572);
      auto _mls_x576 = (_mls_x570 - _mls_x573);
      auto _mls_x577 = (_mls_x571 - _mls_x574);
      auto _mls_x578 = _mlsValue::create<_mls_Tuple3>(_mls_x575, _mls_x576, _mls_x577);
      _mls_retval = _mls_x578;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_vecsum(_mlsValue _mls_param) {
  _mlsValue _mls_retval;
  auto _mls_x579 = _mlsValue::create<_mls_Lambda_vecadd>();
  auto _mls_x580 = _mlsValue::create<_mls_Tuple3>(_mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0), _mlsValue::create<_mls_Float>(0.0));
  auto _mls_x581 = _mls_foldr(_mls_x579, _mls_x580, _mls_param);
  _mls_retval = _mls_x581;
  return _mls_retval;
}
_mlsValue _mls_Lambda_f::_mls_apply2(_mlsValue _mls_i, _mlsValue _mls_j) {
  _mlsValue _mls_retval;
  auto _mls_x = _mls_testspheres();
  auto _mls_x1 = _mls_tracepixel(_mls_x, _mls_lam_arg1, _mls_i, _mls_j, _mls_lam_arg3, _mls_lam_arg2, _mls_lam_arg0);
  _mls_retval = _mls_x1;
  return _mls_retval;
}
_mlsValue _mls_Lambda_f1::_mls_apply2(_mlsValue _mls_d1s1, _mlsValue _mls_d2s2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_d1s1)) {
    auto _mls_x2 = _mlsValue::cast<_mls_Tuple2>(_mls_d1s1)->_mls_field0;
    auto _mls_x3 = _mlsValue::cast<_mls_Tuple2>(_mls_d1s1)->_mls_field1;
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_d2s2)) {
      auto _mls_x4 = _mlsValue::cast<_mls_Tuple2>(_mls_d2s2)->_mls_field0;
      auto _mls_x5 = _mlsValue::cast<_mls_Tuple2>(_mls_d2s2)->_mls_field1;
      auto _mls_x6 = (_mls_x2 < _mls_x4);
      if (_mlsValue::isIntLit(_mls_x6, 1)) {
        auto _mls_x8 = _mlsValue::create<_mls_Tuple2>(_mls_x2, _mls_x3);
        _mls_retval = _mls_x8;
      } else {
        auto _mls_x7 = _mlsValue::create<_mls_Tuple2>(_mls_x4, _mls_x5);
        _mls_retval = _mls_x7;
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda::_mls_apply1(_mlsValue _mls_l) {
  _mlsValue _mls_retval;
  auto _mls_x9 = _mls_lightray(_mls_l, _mls_lam_arg1, _mls_lam_arg0, _mls_lam_arg2, _mls_lam_arg3);
  _mls_retval = _mls_x9;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lscomp::_mls_apply1(_mlsValue _mls_ls) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls)) {
    auto _mls_x16 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x16;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls)) {
    auto _mls_x10 = _mlsValue::cast<_mls_Cons>(_mls_ls)->_mls_head;
    auto _mls_x11 = _mlsValue::cast<_mls_Cons>(_mls_ls)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Transmit>(_mls_x10)) {
      auto _mls_x13 = _mlsValue::cast<_mls_Transmit>(_mls_x10)->_mls_v;
      auto _mls_x14 = this->_mls_apply1(_mls_x11);
      auto _mls_x15 = _mlsValue::create<_mls_Cons>(_mls_x13, _mls_x14);
      _mls_retval = _mls_x15;
    } else {
      auto _mls_x12 = this->_mls_apply1(_mls_x11);
      _mls_retval = _mls_x12;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lscomp1::_mls_apply1(_mlsValue _mls_ls1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls1)) {
    auto _mls_x23 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x23;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls1)) {
    auto _mls_x17 = _mlsValue::cast<_mls_Cons>(_mls_ls1)->_mls_head;
    auto _mls_x18 = _mlsValue::cast<_mls_Cons>(_mls_ls1)->_mls_tail;
    auto _mls_x19 = _mlsValue::create<_mls_Lambda_lscomp21>(_mls_x18, _mlsValue(this, _mlsValue::inc_ref_tag{}), _mls_x17, _mls_lam_arg1);
    auto _mls_x20 = (_mls_lam_arg0 - _mlsValue::create<_mls_Float>(1.0));
    auto _mls_x21 = _mls_enumFromTo(_mlsValue::create<_mls_Float>(0.0), _mls_x20);
    auto _mls_x22 = _mlsMethodCall<_mls_Callable>(_mls_x19)->_mls_apply1(_mls_x21);
    _mls_retval = _mls_x22;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lscomp2::_mls_apply1(_mlsValue _mls_ls2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls2)) {
    auto _mls_x30 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x30;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls2)) {
    auto _mls_x24 = _mlsValue::cast<_mls_Cons>(_mls_ls2)->_mls_head;
    auto _mls_x25 = _mlsValue::cast<_mls_Cons>(_mls_ls2)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Body>(_mls_x24)) {
      auto _mls_x27 = _mlsValue::cast<_mls_Body>(_mls_x24)->_mls_v;
      auto _mls_x28 = this->_mls_apply1(_mls_x25);
      auto _mls_x29 = _mlsValue::create<_mls_Cons>(_mls_x27, _mls_x28);
      _mls_retval = _mls_x29;
    } else {
      auto _mls_x26 = this->_mls_apply1(_mls_x25);
      _mls_retval = _mls_x26;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lscomp21::_mls_apply1(_mlsValue _mls_ls21) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls21)) {
    auto _mls_x38 = _mlsMethodCall<_mls_Callable>(_mls_lam_arg1)->_mls_apply1(_mls_lam_arg0);
    _mls_retval = _mls_x38;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls21)) {
    auto _mls_x31 = _mlsValue::cast<_mls_Cons>(_mls_ls21)->_mls_head;
    auto _mls_x32 = _mlsValue::cast<_mls_Cons>(_mls_ls21)->_mls_tail;
    auto _mls_x33 = _mlsMethodCall<_mls_Callable>(_mls_lam_arg3)->_mls_apply2(_mls_lam_arg2, _mls_x31);
    auto _mls_x34 = this->_mls_apply1(_mls_x32);
    auto _mls_x35 = _mlsValue::create<_mls_Tuple2>(_mls_lam_arg2, _mls_x31);
    auto _mls_x36 = _mlsValue::create<_mls_Tuple2>(_mls_x35, _mls_x33);
    auto _mls_x37 = _mlsValue::create<_mls_Cons>(_mls_x36, _mls_x34);
    _mls_retval = _mls_x37;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lscomp3::_mls_apply1(_mlsValue _mls_ls3) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls3)) {
    auto _mls_x45 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x45;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls3)) {
    auto _mls_x39 = _mlsValue::cast<_mls_Cons>(_mls_ls3)->_mls_head;
    auto _mls_x40 = _mlsValue::cast<_mls_Cons>(_mls_ls3)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Diffuse>(_mls_x39)) {
      auto _mls_x42 = _mlsValue::cast<_mls_Diffuse>(_mls_x39)->_mls_v;
      auto _mls_x43 = this->_mls_apply1(_mls_x40);
      auto _mls_x44 = _mlsValue::create<_mls_Cons>(_mls_x42, _mls_x43);
      _mls_retval = _mls_x44;
    } else {
      auto _mls_x41 = this->_mls_apply1(_mls_x40);
      _mls_retval = _mls_x41;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lscomp4::_mls_apply1(_mlsValue _mls_ls4) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls4)) {
    auto _mls_x52 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x52;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls4)) {
    auto _mls_x46 = _mlsValue::cast<_mls_Cons>(_mls_ls4)->_mls_head;
    auto _mls_x47 = _mlsValue::cast<_mls_Cons>(_mls_ls4)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Ambient>(_mls_x46)) {
      auto _mls_x49 = _mlsValue::cast<_mls_Ambient>(_mls_x46)->_mls_v;
      auto _mls_x50 = this->_mls_apply1(_mls_x47);
      auto _mls_x51 = _mlsValue::create<_mls_Cons>(_mls_x49, _mls_x50);
      _mls_retval = _mls_x51;
    } else {
      auto _mls_x48 = this->_mls_apply1(_mls_x47);
      _mls_retval = _mls_x48;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lscomp5::_mls_apply1(_mlsValue _mls_ls5) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls5)) {
    auto _mls_x59 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x59;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls5)) {
    auto _mls_x53 = _mlsValue::cast<_mls_Cons>(_mls_ls5)->_mls_head;
    auto _mls_x54 = _mlsValue::cast<_mls_Cons>(_mls_ls5)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Reflect>(_mls_x53)) {
      auto _mls_x56 = _mlsValue::cast<_mls_Reflect>(_mls_x53)->_mls_v;
      auto _mls_x57 = this->_mls_apply1(_mls_x54);
      auto _mls_x58 = _mlsValue::create<_mls_Cons>(_mls_x56, _mls_x57);
      _mls_retval = _mls_x58;
    } else {
      auto _mls_x55 = this->_mls_apply1(_mls_x54);
      _mls_retval = _mls_x55;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lscomp6::_mls_apply1(_mlsValue _mls_ls6) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls6)) {
    auto _mls_x66 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x66;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls6)) {
    auto _mls_x60 = _mlsValue::cast<_mls_Cons>(_mls_ls6)->_mls_head;
    auto _mls_x61 = _mlsValue::cast<_mls_Cons>(_mls_ls6)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Specpow>(_mls_x60)) {
      auto _mls_x63 = _mlsValue::cast<_mls_Specpow>(_mls_x60)->_mls_v;
      auto _mls_x64 = this->_mls_apply1(_mls_x61);
      auto _mls_x65 = _mlsValue::create<_mls_Cons>(_mls_x63, _mls_x64);
      _mls_retval = _mls_x65;
    } else {
      auto _mls_x62 = this->_mls_apply1(_mls_x61);
      _mls_retval = _mls_x62;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lscomp7::_mls_apply1(_mlsValue _mls_ls7) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls7)) {
    auto _mls_x73 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x73;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls7)) {
    auto _mls_x67 = _mlsValue::cast<_mls_Cons>(_mls_ls7)->_mls_head;
    auto _mls_x68 = _mlsValue::cast<_mls_Cons>(_mls_ls7)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Refract>(_mls_x67)) {
      auto _mls_x70 = _mlsValue::cast<_mls_Refract>(_mls_x67)->_mls_v;
      auto _mls_x71 = this->_mls_apply1(_mls_x68);
      auto _mls_x72 = _mlsValue::create<_mls_Cons>(_mls_x70, _mls_x71);
      _mls_retval = _mls_x72;
    } else {
      auto _mls_x69 = this->_mls_apply1(_mls_x68);
      _mls_retval = _mls_x69;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lscomp8::_mls_apply1(_mlsValue _mls_ls8) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls8)) {
    auto _mls_x80 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x80;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls8)) {
    auto _mls_x74 = _mlsValue::cast<_mls_Cons>(_mls_ls8)->_mls_head;
    auto _mls_x75 = _mlsValue::cast<_mls_Cons>(_mls_ls8)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Specular>(_mls_x74)) {
      auto _mls_x77 = _mlsValue::cast<_mls_Specular>(_mls_x74)->_mls_v;
      auto _mls_x78 = this->_mls_apply1(_mls_x75);
      auto _mls_x79 = _mlsValue::create<_mls_Cons>(_mls_x77, _mls_x78);
      _mls_retval = _mls_x79;
    } else {
      auto _mls_x76 = this->_mls_apply1(_mls_x75);
      _mls_retval = _mls_x76;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_snd::_mls_apply1(_mlsValue _mls_arg) {
  _mlsValue _mls_retval;
  auto _mls_x81 = _mls_snd(_mls_arg);
  _mls_retval = _mls_x81;
  return _mls_retval;
}
_mlsValue _mls_Lambda_sphmap::_mls_apply1(_mlsValue _mls_xss) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xss)) {
    auto _mls_x91 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x91;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xss)) {
    auto _mls_x82 = _mlsValue::cast<_mls_Cons>(_mls_xss)->_mls_head;
    auto _mls_x83 = _mlsValue::cast<_mls_Cons>(_mls_xss)->_mls_tail;
    auto _mls_x84 = _mls_sphereintersect(_mls_lam_arg1, _mls_lam_arg0, _mls_x82);
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x84)) {
      auto _mls_x85 = _mlsValue::cast<_mls_Tuple2>(_mls_x84)->_mls_field0;
      auto _mls_x86 = _mlsValue::cast<_mls_Tuple2>(_mls_x84)->_mls_field1;
      if (_mlsValue::isIntLit(_mls_x85, 1)) {
        auto _mls_x88 = this->_mls_apply1(_mls_x83);
        auto _mls_x89 = _mlsValue::create<_mls_Tuple2>(_mls_x86, _mls_x82);
        auto _mls_x90 = _mlsValue::create<_mls_Cons>(_mls_x89, _mls_x88);
        _mls_retval = _mls_x90;
      } else {
        auto _mls_x87 = this->_mls_apply1(_mls_x83);
        _mls_retval = _mls_x87;
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_vecadd::_mls_apply2(_mlsValue _mls_arg1, _mlsValue _mls_arg2) {
  _mlsValue _mls_retval;
  auto _mls_x92 = _mls_vecadd(_mls_arg1, _mls_arg2);
  _mls_retval = _mls_x92;
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
