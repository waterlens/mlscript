#include "mlsprelude.h"
struct _mls_Expr;
struct _mls_Val;
struct _mls_Var;
struct _mls_Add;
_mlsValue _mls_main();
_mlsValue _mls_entry();
_mlsValue _mls_mk_expr(_mlsValue, _mlsValue);
_mlsValue _mls_mk_expr_case0(_mlsValue);
_mlsValue _mls_eeval_case2_sr_post(_mlsValue, _mlsValue);
_mlsValue _mls_eeval(_mlsValue);
_mlsValue _mls_dec(_mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_mk_expr_pre(_mlsValue, _mlsValue);
_mlsValue _mls_mk_expr_default(_mlsValue, _mlsValue);
struct _mls_Expr: public _mlsObject {
  
  constexpr static inline const char *typeName = "Expr";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Expr; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Val: public _mls_Expr {
  _mlsValue _mls_n;
  constexpr static inline const char *typeName = "Val";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_n.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_n);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_n.asObject()->operator==(*other.cast<_mls_Val>()->_mls_n.asObject()); }
  static _mlsValue create(_mlsValue _mls_n) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Val; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_n = _mls_n;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Var: public _mls_Expr {
  _mlsValue _mls_x;
  constexpr static inline const char *typeName = "Var";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_x.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_x);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_x.asObject()->operator==(*other.cast<_mls_Var>()->_mls_x.asObject()); }
  static _mlsValue create(_mlsValue _mls_x) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Var; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_x = _mls_x;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Add: public _mls_Expr {
  _mlsValue _mls_e1;
  _mlsValue _mls_e2;
  constexpr static inline const char *typeName = "Add";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_e1.print(); std::printf(", "); this->_mls_e2.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_e1); _mlsValue::destroy(this->_mls_e2);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_e1.asObject()->operator==(*other.cast<_mls_Add>()->_mls_e1.asObject()) && this->_mls_e2.asObject()->operator==(*other.cast<_mls_Add>()->_mls_e2.asObject()); }
  static _mlsValue create(_mlsValue _mls_e1, _mlsValue _mls_e2) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Add; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_e1 = _mls_e1; _mlsVal->_mls_e2 = _mls_e2;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_mk_expr_default(_mlsValue _mls_x40, _mlsValue _mls_x42) {
  _mlsValue _mls_retval;
  auto _mls_x39 = (_mls_x40 - _mlsValue::fromIntLit(1));
  auto _mls_x41 = (_mls_x42 + _mlsValue::fromIntLit(1));
  auto _mls_x43 = _mls_mk_expr(_mls_x39, _mls_x41);
  auto _mls_x44 = (_mls_x40 - _mlsValue::fromIntLit(1));
  auto _mls_x45 = _mls_dec(_mls_x42);
  auto _mls_x46 = _mls_mk_expr(_mls_x44, _mls_x45);
  auto _mls_x47 = _mlsValue::create<_mls_Add>(_mls_x43, _mls_x46);
  _mls_retval = _mls_x47;
  return _mls_retval;
}
_mlsValue _mls_mk_expr(_mlsValue _mls_x53, _mlsValue _mls_x54) {
  _mlsValue _mls_retval;
  auto [_mls_x55, _mls_x56, _mls_x57] = _mls_mk_expr_pre(_mls_x53, _mls_x54);
  if (_mlsValue::isIntLit(_mls_x55, 1)) {
    _mls_retval = _mls_mk_expr_case0(_mls_x56);
  } else {
    _mls_retval = _mls_mk_expr_default(_mls_x57, _mls_x56);
  }
  return _mls_retval;
}
_mlsValue _mls_main() {
  _mlsValue _mls_retval;
  auto [_mls_x, _mls_x22, _mls_x23] = _mls_mk_expr_pre(_mlsValue::fromIntLit(25), _mlsValue::fromIntLit(1));
  if (_mlsValue::isIntLit(_mls_x, 1)) {
    auto _mls_x28 = _mls_mk_expr_case0(_mls_x22);
    auto _mls_x29 = _mlsValue::cast<_mls_Val>(_mls_x28)->_mls_n;
    _mls_retval = _mls_x29;
  } else {
    auto _mls_x24 = _mls_mk_expr_default(_mls_x23, _mls_x22);
    auto _mls_x25 = _mlsValue::cast<_mls_Add>(_mls_x24)->_mls_e1;
    auto _mls_x26 = _mlsValue::cast<_mls_Add>(_mls_x24)->_mls_e2;
    auto _mls_x27 = _mls_eeval_case2_sr_post(_mls_x25, _mls_x26);
    _mls_retval = _mls_x27;
  }
  return _mls_retval;
}
_mlsValue _mls_eeval_case2_sr_post(_mlsValue _mls_x34, _mlsValue _mls_x36) {
  _mlsValue _mls_retval;
  auto _mls_x35 = _mls_eeval(_mls_x34);
  auto _mls_x37 = _mls_eeval(_mls_x36);
  auto _mls_x38 = (_mls_x35 + _mls_x37);
  _mls_retval = _mls_x38;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_mk_expr_pre(_mlsValue _mls_x51, _mlsValue _mls_x52) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x50 = (_mls_x51 == _mlsValue::fromIntLit(0));
  _mls_retval = std::make_tuple(_mls_x50, _mls_x52, _mls_x51);
  return _mls_retval;
}
_mlsValue _mls_eeval(_mlsValue _mls_x30) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Val>(_mls_x30)) {
    auto _mls_x33 = _mlsValue::cast<_mls_Val>(_mls_x30)->_mls_n;
    _mls_retval = _mls_x33;
  } else if (_mlsValue::isValueOf<_mls_Var>(_mls_x30)) {
    _mls_retval = _mlsValue::fromIntLit(0);
  } else if (_mlsValue::isValueOf<_mls_Add>(_mls_x30)) {
    auto _mls_x31 = _mlsValue::cast<_mls_Add>(_mls_x30)->_mls_e1;
    auto _mls_x32 = _mlsValue::cast<_mls_Add>(_mls_x30)->_mls_e2;
    _mls_retval = _mls_eeval_case2_sr_post(_mls_x31, _mls_x32);
  } else {
    throw std::runtime_error("match error" LINE_STRING);
  }
  return _mls_retval;
}
_mlsValue _mls_mk_expr_case0(_mlsValue _mls_x49) {
  _mlsValue _mls_retval;
  auto _mls_x48 = _mlsValue::create<_mls_Val>(_mls_x49);
  _mls_retval = _mls_x48;
  return _mls_retval;
}
_mlsValue _mls_dec(_mlsValue _mls_n1) {
  _mlsValue _mls_retval;
  auto _mls_x9 = (_mls_n1 == _mlsValue::fromIntLit(0));
  if (_mlsValue::isIntLit(_mls_x9, 1)) {
    _mls_retval = _mlsValue::fromIntLit(0);
  } else {
    auto _mls_x10 = (_mls_n1 - _mlsValue::fromIntLit(1));
    _mls_retval = _mls_x10;
  }
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x20 = _mls_main();
  _mls_retval = _mls_x20;
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
