#include "mlsprelude.h"
struct _mls_Lambda_delete_;
struct _mls_Lambda_lambda;
struct _mls_Lambda_lambda1;
struct _mls_Lambda_lambda10;
struct _mls_Lambda_lambda11;
struct _mls_Lambda_lambda2;
struct _mls_Lambda_lambda3;
struct _mls_Lambda_lambda4;
struct _mls_Lambda_lambda5;
struct _mls_Lambda_lambda6;
struct _mls_Lambda_lambda7;
struct _mls_Lambda_lambda8;
struct _mls_Lambda_lambda9;
struct _mls_List;
struct _mls_Cons;
struct _mls_Nil;
struct _mls_Tuple2;
_mlsValue _mls_append(_mlsValue, _mlsValue);
_mlsValue _mls_atleast(_mlsValue, _mlsValue);
_mlsValue _mls_award(_mlsValue, _mlsValue);
_mlsValue _mls_award_case01(_mlsValue, _mlsValue);
_mlsValue _mls_award_case0(_mlsValue, _mlsValue);
_mlsValue _mls_award_case0_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_awards_caller_post(_mlsValue);
_mlsValue _mls_awards_caller_post_post_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_awards_caller_post_post_caller_post_caller_post(_mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue> _mls_awards_caller_post_post_pre(_mlsValue);
std::tuple<_mlsValue, _mlsValue> _mls_awards_caller_post_pre(_mlsValue);
_mlsValue _mls_awards_case0_case0(_mlsValue, _mlsValue);
_mlsValue _mls_awards_case0_case1();
std::tuple<_mlsValue, _mlsValue> _mls_awards_case0_pre();
_mlsValue _mls_awards_default_case0(_mlsValue);
_mlsValue _mls_awards_default_default(_mlsValue, _mlsValue);
_mlsValue _mls_competitors(_mlsValue);
_mlsValue _mls_delete1(_mlsValue, _mlsValue);
_mlsValue _mls_delete_(_mlsValue, _mlsValue);
_mlsValue _mls_entry();
_mlsValue _mls_enumFromTo(_mlsValue, _mlsValue);
_mlsValue _mls_enumFromTo_case0(_mlsValue, _mlsValue);
_mlsValue _mls_enumFromTo_default();
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_enumFromTo_pre(_mlsValue, _mlsValue);
_mlsValue _mls_filter(_mlsValue, _mlsValue);
_mlsValue _mls_findallawards(_mlsValue);
_mlsValue _mls_findawards(_mlsValue);
_mlsValue _mls_findawards_caller_post(_mlsValue, _mlsValue);
_mlsValue _mls_foldl(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_intMod(_mlsValue, _mlsValue);
_mlsValue _mls_leTup2(_mlsValue, _mlsValue);
_mlsValue _mls_listDiff(_mlsValue, _mlsValue);
_mlsValue _mls_ltList(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_ltTup2(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_map(_mlsValue, _mlsValue);
_mlsValue _mls_map_case0_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_map_case1();
_mlsValue _mls_perms(_mlsValue, _mlsValue);
_mlsValue _mls_perms_case0();
_mlsValue _mls_perms_default(_mlsValue, _mlsValue);
_mlsValue _mls_perms_default_case0(_mlsValue);
_mlsValue _mls_perms_default_default(_mlsValue, _mlsValue);
_mlsValue _mls_perms_default_default_caller_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_perms_default_default_caller_post_post(_mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_perms_default_default_caller_post_pre(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_perms_default_pre(_mlsValue, _mlsValue);
_mlsValue _mls_print(_mlsValue);
_mlsValue _mls_qpart_case0_post(_mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue> _mls_qpart_case0_post_pre(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_qpart_case1_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_qpart_case1_sr_post_case0(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_qpart_case1_sr_post_case0_case0(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_qpart_case1_sr_post_case0_case1(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_qpart_case1_sr_post_case0_pre(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_qpart_case1_sr_post_default(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_qpart_case1_sr_post_default_case0(_mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_qpart_case1_sr_post_default_case1(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_qpart_case1_sr_post_default_pre(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_qsort(_mlsValue, _mlsValue);
_mlsValue _mls_rqpart_case0_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_rqpart_case1_sr_post(_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_rqsort(_mlsValue, _mlsValue);
_mlsValue _mls_rqsort_case1_sr_post(_mlsValue, _mlsValue, _mlsValue);
_mlsValue _mls_sort(_mlsValue);
_mlsValue _mls_sum(_mlsValue);
_mlsValue _mls_sum_go(_mlsValue, _mlsValue);
_mlsValue _mls_testAwards_nofib(_mlsValue);
struct _mls_Lambda_delete_: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_delete_";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_delete_; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_lambda: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda1: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda1; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda10: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda10; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda11: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda11; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_lambda2: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda2>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda3: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda3; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda4: public _mls_Callable {
  _mlsValue _mls_lam_arg0;
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_lam_arg0.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_lam_arg0);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_lam_arg0.asObject()->operator==(*other.cast<_mls_Lambda_lambda4>()->_mls_lam_arg0.asObject()); }
  static _mlsValue create(_mlsValue _mls_lam_arg0) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda4; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_lam_arg0 = _mls_lam_arg0;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda5: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda5; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply1(_mlsValue);
};
struct _mls_Lambda_lambda6: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda6; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_lambda7: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda7; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_lambda8: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda8; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_Lambda_lambda9: public _mls_Callable {
  
  constexpr static inline const char *typeName = "Lambda_lambda";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Lambda_lambda9; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  virtual _mlsValue _mls_apply2(_mlsValue, _mlsValue);
};
struct _mls_List: public _mlsObject {
  
  constexpr static inline const char *typeName = "List";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_List; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Cons: public _mls_List {
  _mlsValue _mls_head;
  _mlsValue _mls_tail;
  constexpr static inline const char *typeName = "Cons";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_head.print(); std::printf(", "); this->_mls_tail.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_head); _mlsValue::destroy(this->_mls_tail);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_head.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_head.asObject()) && this->_mls_tail.asObject()->operator==(*other.cast<_mls_Cons>()->_mls_tail.asObject()); }
  static _mlsValue create(_mlsValue _mls_head, _mlsValue _mls_tail) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Cons; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_head = _mls_head; _mlsVal->_mls_tail = _mls_tail;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Nil: public _mls_List {
  
  constexpr static inline const char *typeName = "Nil";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); }
  virtual void destroy() override {  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag; }
  static _mlsValue create() { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Nil; _mlsVal->refCount = 1; _mlsVal->tag = typeTag;  return _mlsValue(_mlsVal); }
  
};
struct _mls_Tuple2: public _mlsObject {
  _mlsValue _mls_field0;
  _mlsValue _mls_field1;
  constexpr static inline const char *typeName = "Tuple2";
  constexpr static inline uint32_t typeTag = nextTypeTag();
  virtual void print() const override { std::printf("%s", typeName); std::printf("("); this->_mls_field0.print(); std::printf(", "); this->_mls_field1.print();  std::printf(")"); }
  virtual void destroy() override { _mlsValue::destroy(this->_mls_field0); _mlsValue::destroy(this->_mls_field1);  operator delete (this, std::align_val_t(_mlsAlignment)); }
  virtual bool operator==(const _mlsObject &other) const override { return typeTag == other.tag && this->_mls_field0.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field0.asObject()) && this->_mls_field1.asObject()->operator==(*other.cast<_mls_Tuple2>()->_mls_field1.asObject()); }
  static _mlsValue create(_mlsValue _mls_field0, _mlsValue _mls_field1) { auto _mlsVal = new (std::align_val_t(_mlsAlignment)) _mls_Tuple2; _mlsVal->refCount = 1; _mlsVal->tag = typeTag; _mlsVal->_mls_field0 = _mls_field0; _mlsVal->_mls_field1 = _mls_field1;  return _mlsValue(_mlsVal); }
  
};
_mlsValue _mls_append(_mlsValue _mls_xs, _mlsValue _mls_ys) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs)) {
    _mls_retval = _mls_ys;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs)) {
    auto _mls_x28 = _mlsValue::cast<_mls_Cons>(_mls_xs)->_mls_head;
    auto _mls_x29 = _mlsValue::cast<_mls_Cons>(_mls_xs)->_mls_tail;
    auto _mls_x30 = _mls_append(_mls_x29, _mls_ys);
    auto _mls_x31 = _mlsValue::create<_mls_Cons>(_mls_x28, _mls_x30);
    _mls_retval = _mls_x31;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_atleast(_mlsValue _mls_sumscores, _mlsValue _mls_threshold) {
  _mlsValue _mls_retval;
  auto _mls_x32 = _mlsValue::create<_mls_Lambda_lambda2>(_mls_threshold);
  auto _mls_x33 = _mls_filter(_mls_x32, _mls_sumscores);
  _mls_retval = _mls_x33;
  return _mls_retval;
}
_mlsValue _mls_award(_mlsValue _mls_x223, _mlsValue _mls_x222) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x222)) {
    _mls_retval = _mls_award_case0(_mls_x222, _mls_x223);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_award_case01(_mlsValue _mls_x225, _mlsValue _mls_x227) {
  _mlsValue _mls_retval;
  auto _mls_x224 = _mlsValue::cast<_mls_Tuple2>(_mls_x225)->_mls_field0;
  auto _mls_x226 = _mlsValue::cast<_mls_Tuple2>(_mls_x225)->_mls_field1;
  _mls_retval = _mls_award_case0_sr_post(_mls_x227, _mls_x226, _mls_x224);
  return _mls_retval;
}
_mlsValue _mls_award_case0(_mlsValue _mls_x229, _mlsValue _mls_x231) {
  _mlsValue _mls_retval;
  auto _mls_x228 = _mlsValue::cast<_mls_Tuple2>(_mls_x229)->_mls_field0;
  auto _mls_x230 = _mlsValue::cast<_mls_Tuple2>(_mls_x229)->_mls_field1;
  _mls_retval = _mls_award_case0_sr_post(_mls_x231, _mls_x230, _mls_x228);
  return _mls_retval;
}
_mlsValue _mls_award_case0_sr_post(_mlsValue _mls_x232, _mlsValue _mls_x233, _mlsValue _mls_x237) {
  _mlsValue _mls_retval;
  auto _mls_x234 = _mls_atleast(_mls_x232, _mls_x233);
  auto _mls_x235 = _mls_sort(_mls_x234);
  auto _mls_x236 = _mlsValue::create<_mls_Lambda_lambda>(_mls_x237);
  auto _mls_x238 = _mls_map(_mls_x236, _mls_x235);
  _mls_retval = _mls_x238;
  return _mls_retval;
}
_mlsValue _mls_awards_caller_post(_mlsValue _mls_x239) {
  _mlsValue _mls_retval;
  auto [_mls_x240, _mls_x241] = _mls_awards_caller_post_pre(_mls_x239);
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x241)) {
    auto _mls_x245 = _mlsValue::cast<_mls_Cons>(_mls_x241)->_mls_head;
    auto _mls_x246 = _mlsValue::cast<_mls_Cons>(_mls_x241)->_mls_tail;
    auto _mls_x247 = _mls_map_case0_sr_post(_mls_x240, _mls_x245, _mls_x246);
    auto [_mls_x248, _mls_x249] = _mls_awards_caller_post_post_pre(_mls_x247);
    _mls_retval = _mls_awards_caller_post_post_caller_post(_mls_x248, _mls_x249);
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x241)) {
    auto _mls_x242 = _mls_map_case1();
    auto [_mls_x243, _mls_x244] = _mls_awards_caller_post_post_pre(_mls_x242);
    _mls_retval = _mls_awards_caller_post_post_caller_post(_mls_x243, _mls_x244);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_awards_caller_post_post_caller_post(_mlsValue _mls_x251, _mlsValue _mls_x253) {
  _mlsValue _mls_retval;
  auto _mls_x250 = _mlsValue::create<_mls_Tuple2>(_mlsValue::create<_mls_Str>("Silver"), _mlsValue::fromIntLit(60));
  auto _mls_x252 = _mls_award_case0(_mls_x250, _mls_x251);
  _mls_retval = _mls_awards_caller_post_post_caller_post_caller_post(_mls_x251, _mls_x252, _mls_x253);
  return _mls_retval;
}
_mlsValue _mls_awards_caller_post_post_caller_post_caller_post(_mlsValue _mls_x255, _mlsValue _mls_x257, _mlsValue _mls_x259) {
  _mlsValue _mls_retval;
  auto _mls_x254 = _mlsValue::create<_mls_Tuple2>(_mlsValue::create<_mls_Str>("Bronze"), _mlsValue::fromIntLit(50));
  auto _mls_x256 = _mls_award(_mls_x255, _mls_x254);
  auto _mls_x258 = _mls_append(_mls_x257, _mls_x256);
  auto _mls_x260 = _mls_append(_mls_x259, _mls_x258);
  _mls_retval = _mls_x260;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue> _mls_awards_caller_post_post_pre(_mlsValue _mls_x262) {
  std::tuple<_mlsValue, _mlsValue> _mls_retval;
  auto _mls_x261 = _mlsValue::create<_mls_Tuple2>(_mlsValue::create<_mls_Str>("Gold"), _mlsValue::fromIntLit(70));
  auto _mls_x263 = _mls_award_case01(_mls_x261, _mls_x262);
  _mls_retval = std::make_tuple(_mls_x262, _mls_x263);
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue> _mls_awards_caller_post_pre(_mlsValue _mls_x265) {
  std::tuple<_mlsValue, _mlsValue> _mls_retval;
  auto _mls_x264 = _mlsValue::create<_mls_Lambda_lambda5>();
  _mls_retval = std::make_tuple(_mls_x264, _mls_x265);
  return _mls_retval;
}
_mlsValue _mls_awards_case0_case0(_mlsValue _mls_x267, _mlsValue _mls_x269) {
  _mlsValue _mls_retval;
  auto _mls_x266 = _mlsValue::cast<_mls_Cons>(_mls_x267)->_mls_head;
  auto _mls_x268 = _mlsValue::cast<_mls_Cons>(_mls_x267)->_mls_tail;
  auto _mls_x270 = _mls_map_case0_sr_post(_mls_x269, _mls_x266, _mls_x268);
  auto [_mls_x271, _mls_x272] = _mls_awards_caller_post_post_pre(_mls_x270);
  _mls_retval = _mls_awards_caller_post_post_caller_post(_mls_x271, _mls_x272);
  return _mls_retval;
}
_mlsValue _mls_awards_case0_case1() {
  _mlsValue _mls_retval;
  auto _mls_x273 = _mls_map_case1();
  auto [_mls_x274, _mls_x275] = _mls_awards_caller_post_post_pre(_mls_x273);
  _mls_retval = _mls_awards_caller_post_post_caller_post(_mls_x274, _mls_x275);
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue> _mls_awards_case0_pre() {
  std::tuple<_mlsValue, _mlsValue> _mls_retval;
  auto _mls_x276 = _mls_perms_case0();
  auto [_mls_x277, _mls_x278] = _mls_awards_caller_post_pre(_mls_x276);
  _mls_retval = std::make_tuple(_mls_x278, _mls_x277);
  return _mls_retval;
}
_mlsValue _mls_awards_default_case0(_mlsValue _mls_x279) {
  _mlsValue _mls_retval;
  auto _mls_x280 = _mls_perms_default_case0(_mls_x279);
  _mls_retval = _mls_awards_caller_post(_mls_x280);
  return _mls_retval;
}
_mlsValue _mls_awards_default_default(_mlsValue _mls_x281, _mlsValue _mls_x282) {
  _mlsValue _mls_retval;
  auto _mls_x283 = _mls_perms_default_default(_mls_x281, _mls_x282);
  _mls_retval = _mls_awards_caller_post(_mls_x283);
  return _mls_retval;
}
_mlsValue _mls_competitors(_mlsValue _mls_i) {
  _mlsValue _mls_retval;
  auto _mls_x51 = _mlsValue::create<_mls_Nil>();
  auto _mls_x52 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(21), _mls_x51);
  auto _mls_x53 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(34), _mls_x52);
  auto _mls_x54 = _mlsValue::create<_mls_Cons>(_mls_i, _mls_x53);
  auto _mls_x55 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(40), _mls_x54);
  auto _mls_x56 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(27), _mls_x55);
  auto _mls_x57 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(35), _mls_x56);
  auto _mls_x58 = _mlsValue::create<_mls_Nil>();
  auto _mls_x59 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(14), _mls_x58);
  auto _mls_x60 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(8), _mls_x59);
  auto _mls_x61 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(5), _mls_x60);
  auto _mls_x62 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(10), _mls_x61);
  auto _mls_x63 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(17), _mls_x62);
  auto _mls_x64 = _mlsValue::create<_mls_Cons>(_mls_i, _mls_x63);
  auto _mls_x65 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(45), _mls_x64);
  auto _mls_x66 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(19), _mls_x65);
  auto _mls_x67 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(23), _mls_x66);
  auto _mls_x68 = _mlsValue::create<_mls_Nil>();
  auto _mls_x69 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(21), _mls_x68);
  auto _mls_x70 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(16), _mls_x69);
  auto _mls_x71 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(8), _mls_x70);
  auto _mls_x72 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(34), _mls_x71);
  auto _mls_x73 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(19), _mls_x72);
  auto _mls_x74 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(21), _mls_x73);
  auto _mls_x75 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(20), _mls_x74);
  auto _mls_x76 = _mlsValue::create<_mls_Cons>(_mls_i, _mls_x75);
  auto _mls_x77 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(18), _mls_x76);
  auto _mls_x78 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(1), _mls_x77);
  auto _mls_x79 = _mlsValue::create<_mls_Nil>();
  auto _mls_x80 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(14), _mls_x79);
  auto _mls_x81 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(18), _mls_x80);
  auto _mls_x82 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(9), _mls_x81);
  auto _mls_x83 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(41), _mls_x82);
  auto _mls_x84 = _mlsValue::create<_mls_Cons>(_mls_i, _mls_x83);
  auto _mls_x85 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(54), _mls_x84);
  auto _mls_x86 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(17), _mls_x85);
  auto _mls_x87 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(23), _mls_x86);
  auto _mls_x88 = _mlsValue::create<_mls_Cons>(_mlsValue::fromIntLit(9), _mls_x87);
  auto _mls_x89 = _mlsValue::create<_mls_Tuple2>(_mlsValue::create<_mls_Str>("Kevin"), _mls_x88);
  auto _mls_x90 = _mlsValue::create<_mls_Nil>();
  auto _mls_x91 = _mlsValue::create<_mls_Cons>(_mls_x89, _mls_x90);
  auto _mls_x92 = _mlsValue::create<_mls_Tuple2>(_mlsValue::create<_mls_Str>("Phil"), _mls_x78);
  auto _mls_x93 = _mlsValue::create<_mls_Cons>(_mls_x92, _mls_x91);
  auto _mls_x94 = _mlsValue::create<_mls_Tuple2>(_mlsValue::create<_mls_Str>("Hans"), _mls_x67);
  auto _mls_x95 = _mlsValue::create<_mls_Cons>(_mls_x94, _mls_x93);
  auto _mls_x96 = _mlsValue::create<_mls_Tuple2>(_mlsValue::create<_mls_Str>("Simon"), _mls_x57);
  auto _mls_x97 = _mlsValue::create<_mls_Cons>(_mls_x96, _mls_x95);
  _mls_retval = _mls_x97;
  return _mls_retval;
}
_mlsValue _mls_delete1(_mlsValue _mls_x101, _mlsValue _mls_ys1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ys1)) {
    auto _mls_x104 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x104;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ys1)) {
    auto _mls_x98 = _mlsValue::cast<_mls_Cons>(_mls_ys1)->_mls_head;
    auto _mls_x99 = _mlsValue::cast<_mls_Cons>(_mls_ys1)->_mls_tail;
    auto _mls_x100 = (_mls_x101 == _mls_x98);
    if (_mlsValue::isIntLit(_mls_x100, 1)) {
      _mls_retval = _mls_x99;
    } else {
      auto _mls_x102 = _mls_delete1(_mls_x101, _mls_x99);
      auto _mls_x103 = _mlsValue::create<_mls_Cons>(_mls_x98, _mls_x102);
      _mls_retval = _mls_x103;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_delete_(_mlsValue _mls_xs1, _mlsValue _mls_e) {
  _mlsValue _mls_retval;
  auto _mls_x105 = _mls_delete1(_mls_e, _mls_xs1);
  _mls_retval = _mls_x105;
  return _mls_retval;
}
_mlsValue _mls_entry() {
  _mlsValue _mls_retval;
  auto _mls_x106 = _mls_testAwards_nofib(_mlsValue::fromIntLit(2000));
  _mls_retval = _mls_x106;
  return _mls_retval;
}
_mlsValue _mls_enumFromTo(_mlsValue _mls_x284, _mlsValue _mls_x285) {
  _mlsValue _mls_retval;
  auto [_mls_x286, _mls_x287, _mls_x288] = _mls_enumFromTo_pre(_mls_x284, _mls_x285);
  if (_mlsValue::isIntLit(_mls_x286, 1)) {
    _mls_retval = _mls_enumFromTo_case0(_mls_x287, _mls_x288);
  } else {
    _mls_retval = _mls_enumFromTo_default();
  }
  return _mls_retval;
}
_mlsValue _mls_enumFromTo_case0(_mlsValue _mls_x290, _mlsValue _mls_x291) {
  _mlsValue _mls_retval;
  auto _mls_x289 = (_mls_x290 + _mlsValue::fromIntLit(1));
  auto _mls_x292 = _mls_enumFromTo(_mls_x289, _mls_x291);
  auto _mls_x293 = _mlsValue::create<_mls_Cons>(_mls_x290, _mls_x292);
  _mls_retval = _mls_x293;
  return _mls_retval;
}
_mlsValue _mls_enumFromTo_default() {
  _mlsValue _mls_retval;
  auto _mls_x294 = _mlsValue::create<_mls_Nil>();
  _mls_retval = _mls_x294;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_enumFromTo_pre(_mlsValue _mls_x296, _mlsValue _mls_x297) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x295 = (_mls_x296 <= _mls_x297);
  _mls_retval = std::make_tuple(_mls_x295, _mls_x296, _mls_x297);
  return _mls_retval;
}
_mlsValue _mls_filter(_mlsValue _mls_f, _mlsValue _mls_ls) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls)) {
    auto _mls_x118 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x118;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls)) {
    auto _mls_x112 = _mlsValue::cast<_mls_Cons>(_mls_ls)->_mls_head;
    auto _mls_x113 = _mlsValue::cast<_mls_Cons>(_mls_ls)->_mls_tail;
    auto _mls_x114 = _mlsMethodCall<_mls_Callable>(_mls_f)->_mls_apply1(_mls_x112);
    if (_mlsValue::isIntLit(_mls_x114, 1)) {
      auto _mls_x116 = _mls_filter(_mls_f, _mls_x113);
      auto _mls_x117 = _mlsValue::create<_mls_Cons>(_mls_x112, _mls_x116);
      _mls_retval = _mls_x117;
    } else {
      auto _mls_x115 = _mls_filter(_mls_f, _mls_x113);
      _mls_retval = _mls_x115;
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_findallawards(_mlsValue _mls_competitors1) {
  _mlsValue _mls_retval;
  auto _mls_x119 = _mlsValue::create<_mls_Lambda_lambda3>();
  auto _mls_x120 = _mls_map(_mls_x119, _mls_competitors1);
  _mls_retval = _mls_x120;
  return _mls_retval;
}
_mlsValue _mls_findawards(_mlsValue _mls_scores1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_scores1)) {
    auto [_mls_x303, _mls_x304] = _mls_awards_case0_pre();
    if (_mlsValue::isValueOf<_mls_Cons>(_mls_x303)) {
      auto _mls_x306 = _mls_awards_case0_case0(_mls_x303, _mls_x304);
      _mls_retval = _mls_findawards_caller_post(_mls_x306, _mls_scores1);
    } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x303)) {
      auto _mls_x305 = _mls_awards_case0_case1();
      _mls_retval = _mls_findawards_caller_post(_mls_x305, _mls_scores1);
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    auto [_mls_x298, _mls_x299, _mls_x300] = _mls_perms_default_pre(_mlsValue::fromIntLit(3), _mls_scores1);
    if (_mlsValue::isIntLit(_mls_x298, 1)) {
      auto _mls_x302 = _mls_awards_default_case0(_mls_x299);
      _mls_retval = _mls_findawards_caller_post(_mls_x302, _mls_scores1);
    } else {
      auto _mls_x301 = _mls_awards_default_default(_mls_x299, _mls_x300);
      _mls_retval = _mls_findawards_caller_post(_mls_x301, _mls_scores1);
    }
  }
  return _mls_retval;
}
_mlsValue _mls_findawards_caller_post(_mlsValue _mls_x307, _mlsValue _mls_x313) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x307)) {
    auto _mls_x319 = _mlsValue::create<_mls_Nil>();
    _mls_retval = _mls_x319;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x307)) {
    auto _mls_x308 = _mlsValue::cast<_mls_Cons>(_mls_x307)->_mls_head;
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x308)) {
      auto _mls_x309 = _mlsValue::cast<_mls_Tuple2>(_mls_x308)->_mls_field0;
      auto _mls_x310 = _mlsValue::cast<_mls_Tuple2>(_mls_x308)->_mls_field1;
      if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_x310)) {
        auto _mls_x311 = _mlsValue::cast<_mls_Tuple2>(_mls_x310)->_mls_field0;
        auto _mls_x312 = _mlsValue::cast<_mls_Tuple2>(_mls_x310)->_mls_field1;
        auto _mls_x314 = _mls_listDiff(_mls_x313, _mls_x312);
        auto _mls_x315 = _mls_findawards(_mls_x314);
        auto _mls_x316 = _mlsValue::create<_mls_Tuple2>(_mls_x311, _mls_x312);
        auto _mls_x317 = _mlsValue::create<_mls_Tuple2>(_mls_x309, _mls_x316);
        auto _mls_x318 = _mlsValue::create<_mls_Cons>(_mls_x317, _mls_x315);
        _mls_retval = _mls_x318;
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_foldl(_mlsValue _mls_f1, _mlsValue _mls_a6, _mlsValue _mls_xs2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs2)) {
    _mls_retval = _mls_a6;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs2)) {
    auto _mls_x133 = _mlsValue::cast<_mls_Cons>(_mls_xs2)->_mls_head;
    auto _mls_x134 = _mlsValue::cast<_mls_Cons>(_mls_xs2)->_mls_tail;
    auto _mls_x135 = _mlsMethodCall<_mls_Callable>(_mls_f1)->_mls_apply2(_mls_a6, _mls_x133);
    auto _mls_x136 = _mls_foldl(_mls_f1, _mls_x135, _mls_x134);
    _mls_retval = _mls_x136;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_intMod(_mlsValue _mls_a7, _mlsValue _mls_b6) {
  _mlsValue _mls_retval;
  auto _mls_x137 = _mls_builtin_floor_mod(_mls_a7, _mls_b6);
  _mls_retval = _mls_x137;
  return _mls_retval;
}
_mlsValue _mls_leTup2(_mlsValue _mls_a8, _mlsValue _mls_b7) {
  _mlsValue _mls_retval;
  auto _mls_x138 = _mlsValue::create<_mls_Lambda_lambda6>();
  auto _mls_x139 = _mlsValue::create<_mls_Lambda_lambda9>();
  auto _mls_x140 = _mlsValue::create<_mls_Lambda_lambda11>();
  auto _mls_x141 = _mls_ltTup2(_mls_a8, _mls_b7, _mls_x138, _mls_x139, _mls_x140);
  _mls_retval = _mls_x141;
  return _mls_retval;
}
_mlsValue _mls_listDiff(_mlsValue _mls_a9, _mlsValue _mls_ls1) {
  _mlsValue _mls_retval;
  auto _mls_x142 = _mlsValue::create<_mls_Lambda_delete_>();
  auto _mls_x143 = _mls_foldl(_mls_x142, _mls_a9, _mls_ls1);
  _mls_retval = _mls_x143;
  return _mls_retval;
}
_mlsValue _mls_ltList(_mlsValue _mls_xs3, _mlsValue _mls_ys2, _mlsValue _mls_lt, _mlsValue _mls_gt) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs3)) {
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_ys2)) {
      _mls_retval = _mlsValue::fromIntLit(0);
    } else {
      _mls_retval = _mlsValue::fromIntLit(1);
    }
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs3)) {
    auto _mls_x144 = _mlsValue::cast<_mls_Cons>(_mls_xs3)->_mls_head;
    auto _mls_x145 = _mlsValue::cast<_mls_Cons>(_mls_xs3)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_ys2)) {
      _mls_retval = _mlsValue::fromIntLit(0);
    } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ys2)) {
      auto _mls_x146 = _mlsValue::cast<_mls_Cons>(_mls_ys2)->_mls_head;
      auto _mls_x147 = _mlsValue::cast<_mls_Cons>(_mls_ys2)->_mls_tail;
      auto _mls_x148 = _mlsMethodCall<_mls_Callable>(_mls_lt)->_mls_apply2(_mls_x144, _mls_x146);
      if (_mlsValue::isIntLit(_mls_x148, 1)) {
        _mls_retval = _mlsValue::fromIntLit(1);
      } else {
        auto _mls_x149 = _mlsMethodCall<_mls_Callable>(_mls_gt)->_mls_apply2(_mls_x144, _mls_x146);
        if (_mlsValue::isIntLit(_mls_x149, 1)) {
          _mls_retval = _mlsValue::fromIntLit(0);
        } else {
          auto _mls_x150 = _mls_ltList(_mls_x145, _mls_x147, _mls_lt, _mls_gt);
          _mls_retval = _mls_x150;
        }
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_ltTup2(_mlsValue _mls_t1, _mlsValue _mls_t2, _mlsValue _mls_lt1, _mlsValue _mls_gt1, _mlsValue _mls_lt2) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_t1)) {
    auto _mls_x151 = _mlsValue::cast<_mls_Tuple2>(_mls_t1)->_mls_field0;
    auto _mls_x152 = _mlsValue::cast<_mls_Tuple2>(_mls_t1)->_mls_field1;
    if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_t2)) {
      auto _mls_x153 = _mlsValue::cast<_mls_Tuple2>(_mls_t2)->_mls_field0;
      auto _mls_x154 = _mlsValue::cast<_mls_Tuple2>(_mls_t2)->_mls_field1;
      auto _mls_x155 = _mlsMethodCall<_mls_Callable>(_mls_lt1)->_mls_apply2(_mls_x151, _mls_x153);
      if (_mlsValue::isIntLit(_mls_x155, 1)) {
        _mls_retval = _mlsValue::fromIntLit(1);
      } else {
        auto _mls_x156 = _mlsMethodCall<_mls_Callable>(_mls_gt1)->_mls_apply2(_mls_x151, _mls_x153);
        if (_mlsValue::isIntLit(_mls_x156, 1)) {
          _mls_retval = _mlsValue::fromIntLit(0);
        } else {
          auto _mls_x157 = _mlsMethodCall<_mls_Callable>(_mls_lt2)->_mls_apply2(_mls_x152, _mls_x154);
          _mls_retval = _mls_x157;
        }
      }
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_map(_mlsValue _mls_x323, _mlsValue _mls_x320) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x320)) {
    auto _mls_x321 = _mlsValue::cast<_mls_Cons>(_mls_x320)->_mls_head;
    auto _mls_x322 = _mlsValue::cast<_mls_Cons>(_mls_x320)->_mls_tail;
    _mls_retval = _mls_map_case0_sr_post(_mls_x323, _mls_x321, _mls_x322);
  } else if (_mlsValue::isValueOf<_mls_Nil>(_mls_x320)) {
    _mls_retval = _mls_map_case1();
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_map_case0_sr_post(_mlsValue _mls_x324, _mlsValue _mls_x325, _mlsValue _mls_x327) {
  _mlsValue _mls_retval;
  auto _mls_x326 = _mlsMethodCall<_mls_Callable>(_mls_x324)->_mls_apply1(_mls_x325);
  auto _mls_x328 = _mls_map(_mls_x324, _mls_x327);
  auto _mls_x329 = _mlsValue::create<_mls_Cons>(_mls_x326, _mls_x328);
  _mls_retval = _mls_x329;
  return _mls_retval;
}
_mlsValue _mls_map_case1() {
  _mlsValue _mls_retval;
  auto _mls_x330 = _mlsValue::create<_mls_Nil>();
  _mls_retval = _mls_x330;
  return _mls_retval;
}
_mlsValue _mls_perms(_mlsValue _mls_x332, _mlsValue _mls_x331) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x331)) {
    _mls_retval = _mls_perms_case0();
  } else {
    _mls_retval = _mls_perms_default(_mls_x332, _mls_x331);
  }
  return _mls_retval;
}
_mlsValue _mls_perms_case0() {
  _mlsValue _mls_retval;
  auto _mls_x333 = _mlsValue::create<_mls_Nil>();
  _mls_retval = _mls_x333;
  return _mls_retval;
}
_mlsValue _mls_perms_default(_mlsValue _mls_x334, _mlsValue _mls_x335) {
  _mlsValue _mls_retval;
  auto [_mls_x336, _mls_x337, _mls_x338] = _mls_perms_default_pre(_mls_x334, _mls_x335);
  if (_mlsValue::isIntLit(_mls_x336, 1)) {
    _mls_retval = _mls_perms_default_case0(_mls_x337);
  } else {
    _mls_retval = _mls_perms_default_default(_mls_x337, _mls_x338);
  }
  return _mls_retval;
}
_mlsValue _mls_perms_default_case0(_mlsValue _mls_x340) {
  _mlsValue _mls_retval;
  auto _mls_x339 = _mlsValue::create<_mls_Lambda_lambda10>();
  auto _mls_x341 = _mls_map(_mls_x339, _mls_x340);
  _mls_retval = _mls_x341;
  return _mls_retval;
}
_mlsValue _mls_perms_default_default(_mlsValue _mls_x342, _mlsValue _mls_x346) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Cons>(_mls_x342)) {
    auto _mls_x343 = _mlsValue::cast<_mls_Cons>(_mls_x342)->_mls_head;
    auto _mls_x344 = _mlsValue::cast<_mls_Cons>(_mls_x342)->_mls_tail;
    auto _mls_x345 = (_mls_x346 - _mlsValue::fromIntLit(1));
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x344)) {
      auto _mls_x352 = _mls_perms_case0();
      auto [_mls_x353, _mls_x354, _mls_x355, _mls_x356] = _mls_perms_default_default_caller_post_pre(_mls_x343, _mls_x352, _mls_x346, _mls_x344);
      auto _mls_x357 = _mls_map(_mls_x353, _mls_x354);
      _mls_retval = _mls_perms_default_default_caller_post_post(_mls_x355, _mls_x356, _mls_x357);
    } else {
      auto [_mls_x347, _mls_x348, _mls_x349] = _mls_perms_default_pre(_mls_x345, _mls_x344);
      if (_mlsValue::isIntLit(_mls_x347, 1)) {
        auto _mls_x351 = _mls_perms_default_case0(_mls_x348);
        _mls_retval = _mls_perms_default_default_caller_post(_mls_x343, _mls_x351, _mls_x346, _mls_x344);
      } else {
        auto _mls_x350 = _mls_perms_default_default(_mls_x348, _mls_x349);
        _mls_retval = _mls_perms_default_default_caller_post(_mls_x343, _mls_x350, _mls_x346, _mls_x344);
      }
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_perms_default_default_caller_post(_mlsValue _mls_x358, _mlsValue _mls_x359, _mlsValue _mls_x360, _mlsValue _mls_x361) {
  _mlsValue _mls_retval;
  auto [_mls_x362, _mls_x363, _mls_x364, _mls_x365] = _mls_perms_default_default_caller_post_pre(_mls_x358, _mls_x359, _mls_x360, _mls_x361);
  auto _mls_x366 = _mls_map(_mls_x362, _mls_x363);
  _mls_retval = _mls_perms_default_default_caller_post_post(_mls_x364, _mls_x365, _mls_x366);
  return _mls_retval;
}
_mlsValue _mls_perms_default_default_caller_post_post(_mlsValue _mls_x367, _mlsValue _mls_x368, _mlsValue _mls_x370) {
  _mlsValue _mls_retval;
  auto _mls_x369 = _mls_perms(_mls_x367, _mls_x368);
  auto _mls_x371 = _mls_append(_mls_x370, _mls_x369);
  _mls_retval = _mls_x371;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_perms_default_default_caller_post_pre(_mlsValue _mls_x373, _mlsValue _mls_x374, _mlsValue _mls_x375, _mlsValue _mls_x376) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x372 = _mlsValue::create<_mls_Lambda_lambda4>(_mls_x373);
  _mls_retval = std::make_tuple(_mls_x372, _mls_x374, _mls_x375, _mls_x376);
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_perms_default_pre(_mlsValue _mls_x378, _mlsValue _mls_x379) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x377 = (_mls_x378 == _mlsValue::fromIntLit(1));
  _mls_retval = std::make_tuple(_mls_x377, _mls_x379, _mls_x378);
  return _mls_retval;
}
_mlsValue _mls_print(_mlsValue _mls_x177) {
  _mlsValue _mls_retval;
  auto _mls_x176 = _mls_builtin_println(_mls_x177);
  _mls_retval = _mls_x176;
  return _mls_retval;
}
_mlsValue _mls_qpart_case0_post(_mlsValue _mls_x380, _mlsValue _mls_x381, _mlsValue _mls_x382) {
  _mlsValue _mls_retval;
  auto [_mls_x383, _mls_x384] = _mls_qpart_case0_post_pre(_mls_x380, _mls_x381, _mls_x382);
  auto _mls_x385 = _mls_rqsort(_mls_x383, _mls_x384);
  _mls_retval = _mls_x385;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue> _mls_qpart_case0_post_pre(_mlsValue _mls_x387, _mlsValue _mls_x388, _mlsValue _mls_x389) {
  std::tuple<_mlsValue, _mlsValue> _mls_retval;
  auto _mls_x386 = _mlsValue::create<_mls_Cons>(_mls_x387, _mls_x388);
  _mls_retval = std::make_tuple(_mls_x389, _mls_x386);
  return _mls_retval;
}
_mlsValue _mls_qpart_case1_sr_post(_mlsValue _mls_x390, _mlsValue _mls_x396, _mlsValue _mls_x391, _mlsValue _mls_x393, _mlsValue _mls_x395, _mlsValue _mls_x394) {
  _mlsValue _mls_retval;
  auto _mls_x392 = _mls_leTup2(_mls_x390, _mls_x391);
  if (_mlsValue::isIntLit(_mls_x392, 1)) {
    _mls_retval = _mls_qpart_case1_sr_post_case0(_mls_x393, _mls_x391, _mls_x394, _mls_x390, _mls_x395, _mls_x396);
  } else {
    _mls_retval = _mls_qpart_case1_sr_post_default(_mls_x393, _mls_x391, _mls_x394, _mls_x390, _mls_x395, _mls_x396);
  }
  return _mls_retval;
}
_mlsValue _mls_qpart_case1_sr_post_case0(_mlsValue _mls_x397, _mlsValue _mls_x398, _mlsValue _mls_x399, _mlsValue _mls_x400, _mlsValue _mls_x401, _mlsValue _mls_x402) {
  _mlsValue _mls_retval;
  auto [_mls_x403, _mls_x404, _mls_x405, _mls_x406, _mls_x407] = _mls_qpart_case1_sr_post_case0_pre(_mls_x397, _mls_x398, _mls_x399, _mls_x400, _mls_x401, _mls_x402);
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x403)) {
    _mls_retval = _mls_qpart_case1_sr_post_case0_case0(_mls_x405, _mls_x407, _mls_x404, _mls_x406);
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x403)) {
    _mls_retval = _mls_qpart_case1_sr_post_case0_case1(_mls_x403, _mls_x404, _mls_x405, _mls_x406, _mls_x407);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_qpart_case1_sr_post_case0_case0(_mlsValue _mls_x408, _mlsValue _mls_x409, _mlsValue _mls_x411, _mlsValue _mls_x412) {
  _mlsValue _mls_retval;
  auto _mls_x410 = _mls_rqsort(_mls_x408, _mls_x409);
  auto _mls_x413 = _mls_qpart_case0_post(_mls_x411, _mls_x410, _mls_x412);
  _mls_retval = _mls_x413;
  return _mls_retval;
}
_mlsValue _mls_qpart_case1_sr_post_case0_case1(_mlsValue _mls_x415, _mlsValue _mls_x417, _mlsValue _mls_x420, _mlsValue _mls_x419, _mlsValue _mls_x418) {
  _mlsValue _mls_retval;
  auto _mls_x414 = _mlsValue::cast<_mls_Cons>(_mls_x415)->_mls_head;
  auto _mls_x416 = _mlsValue::cast<_mls_Cons>(_mls_x415)->_mls_tail;
  auto _mls_x421 = _mls_qpart_case1_sr_post(_mls_x417, _mls_x418, _mls_x414, _mls_x419, _mls_x420, _mls_x416);
  _mls_retval = _mls_x421;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_qpart_case1_sr_post_case0_pre(_mlsValue _mls_x427, _mlsValue _mls_x423, _mlsValue _mls_x425, _mlsValue _mls_x426, _mlsValue _mls_x424, _mlsValue _mls_x428) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x422 = _mlsValue::create<_mls_Cons>(_mls_x423, _mls_x424);
  _mls_retval = std::make_tuple(_mls_x425, _mls_x426, _mls_x422, _mls_x427, _mls_x428);
  return _mls_retval;
}
_mlsValue _mls_qpart_case1_sr_post_default(_mlsValue _mls_x429, _mlsValue _mls_x430, _mlsValue _mls_x431, _mlsValue _mls_x432, _mlsValue _mls_x433, _mlsValue _mls_x434) {
  _mlsValue _mls_retval;
  auto [_mls_x435, _mls_x436, _mls_x437, _mls_x438, _mls_x439] = _mls_qpart_case1_sr_post_default_pre(_mls_x429, _mls_x430, _mls_x431, _mls_x432, _mls_x433, _mls_x434);
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x439)) {
    _mls_retval = _mls_qpart_case1_sr_post_default_case0(_mls_x437, _mls_x436, _mls_x435, _mls_x438);
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x439)) {
    _mls_retval = _mls_qpart_case1_sr_post_default_case1(_mls_x435, _mls_x436, _mls_x437, _mls_x438, _mls_x439);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_qpart_case1_sr_post_default_case0(_mlsValue _mls_x440, _mlsValue _mls_x441, _mlsValue _mls_x443, _mlsValue _mls_x444) {
  _mlsValue _mls_retval;
  auto _mls_x442 = _mls_rqsort(_mls_x440, _mls_x441);
  auto _mls_x445 = _mls_qpart_case0_post(_mls_x443, _mls_x442, _mls_x444);
  _mls_retval = _mls_x445;
  return _mls_retval;
}
_mlsValue _mls_qpart_case1_sr_post_default_case1(_mlsValue _mls_x449, _mlsValue _mls_x450, _mlsValue _mls_x452, _mlsValue _mls_x451, _mlsValue _mls_x447) {
  _mlsValue _mls_retval;
  auto _mls_x446 = _mlsValue::cast<_mls_Cons>(_mls_x447)->_mls_head;
  auto _mls_x448 = _mlsValue::cast<_mls_Cons>(_mls_x447)->_mls_tail;
  auto _mls_x453 = _mls_qpart_case1_sr_post(_mls_x449, _mls_x450, _mls_x446, _mls_x451, _mls_x452, _mls_x448);
  _mls_retval = _mls_x453;
  return _mls_retval;
}
std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_qpart_case1_sr_post_default_pre(_mlsValue _mls_x456, _mlsValue _mls_x455, _mlsValue _mls_x460, _mlsValue _mls_x457, _mlsValue _mls_x459, _mlsValue _mls_x458) {
  std::tuple<_mlsValue, _mlsValue, _mlsValue, _mlsValue, _mlsValue> _mls_retval;
  auto _mls_x454 = _mlsValue::create<_mls_Cons>(_mls_x455, _mls_x456);
  _mls_retval = std::make_tuple(_mls_x457, _mls_x458, _mls_x459, _mls_x454, _mls_x460);
  return _mls_retval;
}
_mlsValue _mls_qsort(_mlsValue _mls_ls2, _mlsValue _mls_r1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_ls2)) {
    _mls_retval = _mls_r1;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_ls2)) {
    auto _mls_x189 = _mlsValue::cast<_mls_Cons>(_mls_ls2)->_mls_head;
    auto _mls_x190 = _mlsValue::cast<_mls_Cons>(_mls_ls2)->_mls_tail;
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x190)) {
      auto _mls_x194 = _mlsValue::create<_mls_Cons>(_mls_x189, _mls_r1);
      _mls_retval = _mls_x194;
    } else {
      auto _mls_x191 = _mlsValue::create<_mls_Nil>();
      auto _mls_x192 = _mlsValue::create<_mls_Nil>();
      if (_mlsValue::isValueOf<_mls_Nil>(_mls_x190)) {
        auto [_mls_x478, _mls_x479] = _mls_qpart_case0_post_pre(_mls_x189, _mls_r1, _mls_x191);
        auto _mls_x480 = _mls_rqsort(_mls_x478, _mls_x479);
        _mls_retval = _mls_x480;
      } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x190)) {
        auto _mls_x461 = _mlsValue::cast<_mls_Cons>(_mls_x190)->_mls_head;
        auto _mls_x462 = _mlsValue::cast<_mls_Cons>(_mls_x190)->_mls_tail;
        auto _mls_x463 = _mls_leTup2(_mls_x189, _mls_x461);
        if (_mlsValue::isIntLit(_mls_x463, 1)) {
          auto [_mls_x471, _mls_x472, _mls_x473, _mls_x474, _mls_x475] = _mls_qpart_case1_sr_post_case0_pre(_mls_x191, _mls_x461, _mls_x462, _mls_x189, _mls_x192, _mls_r1);
          if (_mlsValue::isValueOf<_mls_Nil>(_mls_x471)) {
            auto _mls_x477 = _mls_qpart_case1_sr_post_case0_case0(_mls_x473, _mls_x475, _mls_x472, _mls_x474);
            _mls_retval = _mls_x477;
          } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x471)) {
            auto _mls_x476 = _mls_qpart_case1_sr_post_case0_case1(_mls_x471, _mls_x472, _mls_x473, _mls_x474, _mls_x475);
            _mls_retval = _mls_x476;
          } else {
            _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
          }
        } else {
          auto [_mls_x464, _mls_x465, _mls_x466, _mls_x467, _mls_x468] = _mls_qpart_case1_sr_post_default_pre(_mls_x191, _mls_x461, _mls_x462, _mls_x189, _mls_x192, _mls_r1);
          if (_mlsValue::isValueOf<_mls_Nil>(_mls_x468)) {
            auto _mls_x470 = _mls_qpart_case1_sr_post_default_case0(_mls_x466, _mls_x465, _mls_x464, _mls_x467);
            _mls_retval = _mls_x470;
          } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x468)) {
            auto _mls_x469 = _mls_qpart_case1_sr_post_default_case1(_mls_x464, _mls_x465, _mls_x466, _mls_x467, _mls_x468);
            _mls_retval = _mls_x469;
          } else {
            _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
          }
        }
      } else {
        _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
      }
    }
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_rqpart_case0_post(_mlsValue _mls_x482, _mlsValue _mls_x483, _mlsValue _mls_x484) {
  _mlsValue _mls_retval;
  auto _mls_x481 = _mlsValue::create<_mls_Cons>(_mls_x482, _mls_x483);
  auto _mls_x485 = _mls_qsort(_mls_x484, _mls_x481);
  _mls_retval = _mls_x485;
  return _mls_retval;
}
_mlsValue _mls_rqpart_case1_sr_post(_mlsValue _mls_x491, _mlsValue _mls_x487, _mlsValue _mls_x486, _mlsValue _mls_x494, _mlsValue _mls_x490, _mlsValue _mls_x495) {
  _mlsValue _mls_retval;
  auto _mls_x488 = _mls_leTup2(_mls_x486, _mls_x487);
  if (_mlsValue::isIntLit(_mls_x488, 1)) {
    auto _mls_x499 = _mlsValue::create<_mls_Cons>(_mls_x486, _mls_x495);
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x491)) {
      auto _mls_x503 = _mls_qsort(_mls_x490, _mls_x494);
      auto _mls_x504 = _mls_rqpart_case0_post(_mls_x487, _mls_x503, _mls_x499);
      _mls_retval = _mls_x504;
    } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x491)) {
      auto _mls_x500 = _mlsValue::cast<_mls_Cons>(_mls_x491)->_mls_head;
      auto _mls_x501 = _mlsValue::cast<_mls_Cons>(_mls_x491)->_mls_tail;
      auto _mls_x502 = _mls_rqpart_case1_sr_post(_mls_x501, _mls_x487, _mls_x500, _mls_x494, _mls_x490, _mls_x499);
      _mls_retval = _mls_x502;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  } else {
    auto _mls_x489 = _mlsValue::create<_mls_Cons>(_mls_x486, _mls_x490);
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x491)) {
      auto _mls_x497 = _mls_qsort(_mls_x489, _mls_x494);
      auto _mls_x498 = _mls_rqpart_case0_post(_mls_x487, _mls_x497, _mls_x495);
      _mls_retval = _mls_x498;
    } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x491)) {
      auto _mls_x492 = _mlsValue::cast<_mls_Cons>(_mls_x491)->_mls_head;
      auto _mls_x493 = _mlsValue::cast<_mls_Cons>(_mls_x491)->_mls_tail;
      auto _mls_x496 = _mls_rqpart_case1_sr_post(_mls_x493, _mls_x487, _mls_x492, _mls_x494, _mls_x489, _mls_x495);
      _mls_retval = _mls_x496;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  }
  return _mls_retval;
}
_mlsValue _mls_rqsort(_mlsValue _mls_x505, _mlsValue _mls_x508) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x505)) {
    _mls_retval = _mls_x508;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x505)) {
    auto _mls_x506 = _mlsValue::cast<_mls_Cons>(_mls_x505)->_mls_head;
    auto _mls_x507 = _mlsValue::cast<_mls_Cons>(_mls_x505)->_mls_tail;
    _mls_retval = _mls_rqsort_case1_sr_post(_mls_x507, _mls_x506, _mls_x508);
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_rqsort_case1_sr_post(_mlsValue _mls_x509, _mlsValue _mls_x514, _mlsValue _mls_x515) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_x509)) {
    auto _mls_x519 = _mlsValue::create<_mls_Cons>(_mls_x514, _mls_x515);
    _mls_retval = _mls_x519;
  } else {
    auto _mls_x510 = _mlsValue::create<_mls_Nil>();
    auto _mls_x511 = _mlsValue::create<_mls_Nil>();
    if (_mlsValue::isValueOf<_mls_Nil>(_mls_x509)) {
      auto _mls_x517 = _mls_qsort(_mls_x511, _mls_x515);
      auto _mls_x518 = _mls_rqpart_case0_post(_mls_x514, _mls_x517, _mls_x510);
      _mls_retval = _mls_x518;
    } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_x509)) {
      auto _mls_x512 = _mlsValue::cast<_mls_Cons>(_mls_x509)->_mls_head;
      auto _mls_x513 = _mlsValue::cast<_mls_Cons>(_mls_x509)->_mls_tail;
      auto _mls_x516 = _mls_rqpart_case1_sr_post(_mls_x513, _mls_x514, _mls_x512, _mls_x515, _mls_x511, _mls_x510);
      _mls_retval = _mls_x516;
    } else {
      _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
    }
  }
  return _mls_retval;
}
_mlsValue _mls_sort(_mlsValue _mls_l) {
  _mlsValue _mls_retval;
  auto _mls_x212 = _mlsValue::create<_mls_Nil>();
  auto _mls_x213 = _mls_qsort(_mls_l, _mls_x212);
  _mls_retval = _mls_x213;
  return _mls_retval;
}
_mlsValue _mls_sum(_mlsValue _mls_xs5) {
  _mlsValue _mls_retval;
  auto _mls_x214 = _mls_sum_go(_mls_xs5, _mlsValue::fromIntLit(0));
  _mls_retval = _mls_x214;
  return _mls_retval;
}
_mlsValue _mls_sum_go(_mlsValue _mls_xs6, _mlsValue _mls_a10) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Nil>(_mls_xs6)) {
    _mls_retval = _mls_a10;
  } else if (_mlsValue::isValueOf<_mls_Cons>(_mls_xs6)) {
    auto _mls_x215 = _mlsValue::cast<_mls_Cons>(_mls_xs6)->_mls_head;
    auto _mls_x216 = _mlsValue::cast<_mls_Cons>(_mls_xs6)->_mls_tail;
    auto _mls_x217 = (_mls_a10 + _mls_x215);
    auto _mls_x218 = _mls_sum_go(_mls_x216, _mls_x217);
    _mls_retval = _mls_x218;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_testAwards_nofib(_mlsValue _mls_n) {
  _mlsValue _mls_retval;
  auto _mls_x219 = _mlsValue::create<_mls_Lambda_lambda1>();
  auto [_mls_x520, _mls_x521, _mls_x522] = _mls_enumFromTo_pre(_mlsValue::fromIntLit(1), _mls_n);
  if (_mlsValue::isIntLit(_mls_x520, 1)) {
    auto _mls_x525 = _mls_enumFromTo_case0(_mls_x521, _mls_x522);
    auto _mls_x526 = _mlsValue::cast<_mls_Cons>(_mls_x525)->_mls_head;
    auto _mls_x527 = _mlsValue::cast<_mls_Cons>(_mls_x525)->_mls_tail;
    auto _mls_x528 = _mls_map_case0_sr_post(_mls_x219, _mls_x526, _mls_x527);
    _mls_retval = _mls_x528;
  } else {
    auto _mls_x523 = _mls_enumFromTo_default();
    auto _mls_x524 = _mls_map_case1();
    _mls_retval = _mls_x524;
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_delete_::_mls_apply2(_mlsValue _mls_arg, _mlsValue _mls_arg1) {
  _mlsValue _mls_retval;
  auto _mls_x = _mls_delete_(_mls_arg, _mls_arg1);
  _mls_retval = _mls_x;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda::_mls_apply1(_mlsValue _mls_ps) {
  _mlsValue _mls_retval;
  auto _mls_x1 = _mlsValue::create<_mls_Tuple2>(_mls_lam_arg0, _mls_ps);
  _mls_retval = _mls_x1;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda1::_mls_apply1(_mlsValue _mls_x2) {
  _mlsValue _mls_retval;
  auto _mls_x3 = _mls_intMod(_mls_x2, _mlsValue::fromIntLit(100));
  auto _mls_x4 = _mls_competitors(_mls_x3);
  auto _mls_x5 = _mls_findallawards(_mls_x4);
  auto _mls_x6 = _mls_print(_mls_x5);
  _mls_retval = _mls_x6;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda10::_mls_apply1(_mlsValue _mls_x9) {
  _mlsValue _mls_retval;
  auto _mls_x7 = _mlsValue::create<_mls_Nil>();
  auto _mls_x8 = _mlsValue::create<_mls_Cons>(_mls_x9, _mls_x7);
  _mls_retval = _mls_x8;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda11::_mls_apply2(_mlsValue _mls_a, _mlsValue _mls_b) {
  _mlsValue _mls_retval;
  auto _mls_x10 = _mlsValue::create<_mls_Lambda_lambda7>();
  auto _mls_x11 = _mlsValue::create<_mls_Lambda_lambda8>();
  auto _mls_x12 = _mls_ltList(_mls_a, _mls_b, _mls_x10, _mls_x11);
  _mls_retval = _mls_x12;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda2::_mls_apply1(_mlsValue _mls_caseScrut) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_caseScrut)) {
    auto _mls_x13 = _mlsValue::cast<_mls_Tuple2>(_mls_caseScrut)->_mls_field0;
    auto _mls_x14 = _mlsValue::cast<_mls_Tuple2>(_mls_caseScrut)->_mls_field1;
    auto _mls_x15 = (_mls_x13 >= _mls_lam_arg0);
    _mls_retval = _mls_x15;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda3::_mls_apply1(_mlsValue _mls_caseScrut1) {
  _mlsValue _mls_retval;
  if (_mlsValue::isValueOf<_mls_Tuple2>(_mls_caseScrut1)) {
    auto _mls_x16 = _mlsValue::cast<_mls_Tuple2>(_mls_caseScrut1)->_mls_field0;
    auto _mls_x17 = _mlsValue::cast<_mls_Tuple2>(_mls_caseScrut1)->_mls_field1;
    auto _mls_x18 = _mls_findawards(_mls_x17);
    auto _mls_x19 = _mlsValue::create<_mls_Tuple2>(_mls_x16, _mls_x18);
    _mls_retval = _mls_x19;
  } else {
    _mlsUtil::panic_with("match error", __func__, __FILE__, __LINE__);
  }
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda4::_mls_apply1(_mlsValue _mls_x21) {
  _mlsValue _mls_retval;
  auto _mls_x20 = _mlsValue::create<_mls_Cons>(_mls_lam_arg0, _mls_x21);
  _mls_retval = _mls_x20;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda5::_mls_apply1(_mlsValue _mls_p) {
  _mlsValue _mls_retval;
  auto _mls_x22 = _mls_sum(_mls_p);
  auto _mls_x23 = _mlsValue::create<_mls_Tuple2>(_mls_x22, _mls_p);
  _mls_retval = _mls_x23;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda6::_mls_apply2(_mlsValue _mls_a1, _mlsValue _mls_b1) {
  _mlsValue _mls_retval;
  auto _mls_x24 = (_mls_a1 < _mls_b1);
  _mls_retval = _mls_x24;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda7::_mls_apply2(_mlsValue _mls_a2, _mlsValue _mls_b2) {
  _mlsValue _mls_retval;
  auto _mls_x25 = (_mls_a2 < _mls_b2);
  _mls_retval = _mls_x25;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda8::_mls_apply2(_mlsValue _mls_a3, _mlsValue _mls_b3) {
  _mlsValue _mls_retval;
  auto _mls_x26 = (_mls_a3 > _mls_b3);
  _mls_retval = _mls_x26;
  return _mls_retval;
}
_mlsValue _mls_Lambda_lambda9::_mls_apply2(_mlsValue _mls_a4, _mlsValue _mls_b4) {
  _mlsValue _mls_retval;
  auto _mls_x27 = (_mls_a4 > _mls_b4);
  _mls_retval = _mls_x27;
  return _mls_retval;
}
_mlsValue _mlsMain() { return _mls_entry(); }
int main() { return _mlsLargeStack(_mlsMainWrapper); }
